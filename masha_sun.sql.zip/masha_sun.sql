-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 29, 2021 at 10:03 AM
-- Server version: 5.7.24
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `masha_sun`
--

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_actiondom`
--

CREATE TABLE `modx_access_actiondom` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_actions`
--

CREATE TABLE `modx_access_actions` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_category`
--

CREATE TABLE `modx_access_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_context`
--

CREATE TABLE `modx_access_context` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_context`
--

INSERT INTO `modx_access_context` (`id`, `target`, `principal_class`, `principal`, `authority`, `policy`) VALUES
(1, 'web', 'modUserGroup', 0, 9999, 3),
(2, 'mgr', 'modUserGroup', 1, 0, 2),
(3, 'web', 'modUserGroup', 1, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_elements`
--

CREATE TABLE `modx_access_elements` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_media_source`
--

CREATE TABLE `modx_access_media_source` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_menus`
--

CREATE TABLE `modx_access_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_namespace`
--

CREATE TABLE `modx_access_namespace` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_permissions`
--

CREATE TABLE `modx_access_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `template` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `value` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_permissions`
--

INSERT INTO `modx_access_permissions` (`id`, `template`, `name`, `description`, `value`) VALUES
(1, 1, 'about', 'perm.about_desc', 1),
(2, 1, 'access_permissions', 'perm.access_permissions_desc', 1),
(3, 1, 'actions', 'perm.actions_desc', 1),
(4, 1, 'change_password', 'perm.change_password_desc', 1),
(5, 1, 'change_profile', 'perm.change_profile_desc', 1),
(6, 1, 'charsets', 'perm.charsets_desc', 1),
(7, 1, 'class_map', 'perm.class_map_desc', 1),
(8, 1, 'components', 'perm.components_desc', 1),
(9, 1, 'content_types', 'perm.content_types_desc', 1),
(10, 1, 'countries', 'perm.countries_desc', 1),
(11, 1, 'create', 'perm.create_desc', 1),
(12, 1, 'credits', 'perm.credits_desc', 1),
(13, 1, 'customize_forms', 'perm.customize_forms_desc', 1),
(14, 1, 'dashboards', 'perm.dashboards_desc', 1),
(15, 1, 'database', 'perm.database_desc', 1),
(16, 1, 'database_truncate', 'perm.database_truncate_desc', 1),
(17, 1, 'delete_category', 'perm.delete_category_desc', 1),
(18, 1, 'delete_chunk', 'perm.delete_chunk_desc', 1),
(19, 1, 'delete_context', 'perm.delete_context_desc', 1),
(20, 1, 'delete_document', 'perm.delete_document_desc', 1),
(21, 1, 'delete_weblink', 'perm.delete_weblink_desc', 1),
(22, 1, 'delete_symlink', 'perm.delete_symlink_desc', 1),
(23, 1, 'delete_static_resource', 'perm.delete_static_resource_desc', 1),
(24, 1, 'delete_eventlog', 'perm.delete_eventlog_desc', 1),
(25, 1, 'delete_plugin', 'perm.delete_plugin_desc', 1),
(26, 1, 'delete_propertyset', 'perm.delete_propertyset_desc', 1),
(27, 1, 'delete_snippet', 'perm.delete_snippet_desc', 1),
(28, 1, 'delete_template', 'perm.delete_template_desc', 1),
(29, 1, 'delete_tv', 'perm.delete_tv_desc', 1),
(30, 1, 'delete_role', 'perm.delete_role_desc', 1),
(31, 1, 'delete_user', 'perm.delete_user_desc', 1),
(32, 1, 'directory_chmod', 'perm.directory_chmod_desc', 1),
(33, 1, 'directory_create', 'perm.directory_create_desc', 1),
(34, 1, 'directory_list', 'perm.directory_list_desc', 1),
(35, 1, 'directory_remove', 'perm.directory_remove_desc', 1),
(36, 1, 'directory_update', 'perm.directory_update_desc', 1),
(37, 1, 'edit_category', 'perm.edit_category_desc', 1),
(38, 1, 'edit_chunk', 'perm.edit_chunk_desc', 1),
(39, 1, 'edit_context', 'perm.edit_context_desc', 1),
(40, 1, 'edit_document', 'perm.edit_document_desc', 1),
(41, 1, 'edit_weblink', 'perm.edit_weblink_desc', 1),
(42, 1, 'edit_symlink', 'perm.edit_symlink_desc', 1),
(43, 1, 'edit_static_resource', 'perm.edit_static_resource_desc', 1),
(44, 1, 'edit_locked', 'perm.edit_locked_desc', 1),
(45, 1, 'edit_plugin', 'perm.edit_plugin_desc', 1),
(46, 1, 'edit_propertyset', 'perm.edit_propertyset_desc', 1),
(47, 1, 'edit_role', 'perm.edit_role_desc', 1),
(48, 1, 'edit_snippet', 'perm.edit_snippet_desc', 1),
(49, 1, 'edit_template', 'perm.edit_template_desc', 1),
(50, 1, 'edit_tv', 'perm.edit_tv_desc', 1),
(51, 1, 'edit_user', 'perm.edit_user_desc', 1),
(52, 1, 'element_tree', 'perm.element_tree_desc', 1),
(53, 1, 'empty_cache', 'perm.empty_cache_desc', 1),
(54, 1, 'error_log_erase', 'perm.error_log_erase_desc', 1),
(55, 1, 'error_log_view', 'perm.error_log_view_desc', 1),
(56, 1, 'export_static', 'perm.export_static_desc', 1),
(57, 1, 'file_create', 'perm.file_create_desc', 1),
(58, 1, 'file_list', 'perm.file_list_desc', 1),
(59, 1, 'file_manager', 'perm.file_manager_desc', 1),
(60, 1, 'file_remove', 'perm.file_remove_desc', 1),
(61, 1, 'file_tree', 'perm.file_tree_desc', 1),
(62, 1, 'file_update', 'perm.file_update_desc', 1),
(63, 1, 'file_upload', 'perm.file_upload_desc', 1),
(64, 1, 'file_unpack', 'perm.file_unpack_desc', 1),
(65, 1, 'file_view', 'perm.file_view_desc', 1),
(66, 1, 'flush_sessions', 'perm.flush_sessions_desc', 1),
(67, 1, 'frames', 'perm.frames_desc', 1),
(68, 1, 'help', 'perm.help_desc', 1),
(69, 1, 'home', 'perm.home_desc', 1),
(70, 1, 'import_static', 'perm.import_static_desc', 1),
(71, 1, 'languages', 'perm.languages_desc', 1),
(72, 1, 'lexicons', 'perm.lexicons_desc', 1),
(73, 1, 'list', 'perm.list_desc', 1),
(74, 1, 'load', 'perm.load_desc', 1),
(75, 1, 'logout', 'perm.logout_desc', 1),
(76, 1, 'logs', 'perm.logs_desc', 1),
(77, 1, 'menu_reports', 'perm.menu_reports_desc', 1),
(78, 1, 'menu_security', 'perm.menu_security_desc', 1),
(79, 1, 'menu_site', 'perm.menu_site_desc', 1),
(80, 1, 'menu_support', 'perm.menu_support_desc', 1),
(81, 1, 'menu_system', 'perm.menu_system_desc', 1),
(82, 1, 'menu_tools', 'perm.menu_tools_desc', 1),
(83, 1, 'menu_trash', 'perm.menu_trash_desc', 1),
(84, 1, 'menu_user', 'perm.menu_user_desc', 1),
(85, 1, 'menus', 'perm.menus_desc', 1),
(86, 1, 'messages', 'perm.messages_desc', 1),
(87, 1, 'namespaces', 'perm.namespaces_desc', 1),
(88, 1, 'new_category', 'perm.new_category_desc', 1),
(89, 1, 'new_chunk', 'perm.new_chunk_desc', 1),
(90, 1, 'new_context', 'perm.new_context_desc', 1),
(91, 1, 'new_document', 'perm.new_document_desc', 1),
(92, 1, 'new_static_resource', 'perm.new_static_resource_desc', 1),
(93, 1, 'new_symlink', 'perm.new_symlink_desc', 1),
(94, 1, 'new_weblink', 'perm.new_weblink_desc', 1),
(95, 1, 'new_document_in_root', 'perm.new_document_in_root_desc', 1),
(96, 1, 'new_plugin', 'perm.new_plugin_desc', 1),
(97, 1, 'new_propertyset', 'perm.new_propertyset_desc', 1),
(98, 1, 'new_role', 'perm.new_role_desc', 1),
(99, 1, 'new_snippet', 'perm.new_snippet_desc', 1),
(100, 1, 'new_template', 'perm.new_template_desc', 1),
(101, 1, 'new_tv', 'perm.new_tv_desc', 1),
(102, 1, 'new_user', 'perm.new_user_desc', 1),
(103, 1, 'packages', 'perm.packages_desc', 1),
(104, 1, 'policy_delete', 'perm.policy_delete_desc', 1),
(105, 1, 'policy_edit', 'perm.policy_edit_desc', 1),
(106, 1, 'policy_new', 'perm.policy_new_desc', 1),
(107, 1, 'policy_save', 'perm.policy_save_desc', 1),
(108, 1, 'policy_view', 'perm.policy_view_desc', 1),
(109, 1, 'policy_template_delete', 'perm.policy_template_delete_desc', 1),
(110, 1, 'policy_template_edit', 'perm.policy_template_edit_desc', 1),
(111, 1, 'policy_template_new', 'perm.policy_template_new_desc', 1),
(112, 1, 'policy_template_save', 'perm.policy_template_save_desc', 1),
(113, 1, 'policy_template_view', 'perm.policy_template_view_desc', 1),
(114, 1, 'property_sets', 'perm.property_sets_desc', 1),
(115, 1, 'providers', 'perm.providers_desc', 1),
(116, 1, 'publish_document', 'perm.publish_document_desc', 1),
(117, 1, 'purge_deleted', 'perm.purge_deleted_desc', 1),
(118, 1, 'remove', 'perm.remove_desc', 1),
(119, 1, 'remove_locks', 'perm.remove_locks_desc', 1),
(120, 1, 'resource_duplicate', 'perm.resource_duplicate_desc', 1),
(121, 1, 'resourcegroup_delete', 'perm.resourcegroup_delete_desc', 1),
(122, 1, 'resourcegroup_edit', 'perm.resourcegroup_edit_desc', 1),
(123, 1, 'resourcegroup_new', 'perm.resourcegroup_new_desc', 1),
(124, 1, 'resourcegroup_resource_edit', 'perm.resourcegroup_resource_edit_desc', 1),
(125, 1, 'resourcegroup_resource_list', 'perm.resourcegroup_resource_list_desc', 1),
(126, 1, 'resourcegroup_save', 'perm.resourcegroup_save_desc', 1),
(127, 1, 'resourcegroup_view', 'perm.resourcegroup_view_desc', 1),
(128, 1, 'resource_quick_create', 'perm.resource_quick_create_desc', 1),
(129, 1, 'resource_quick_update', 'perm.resource_quick_update_desc', 1),
(130, 1, 'resource_tree', 'perm.resource_tree_desc', 1),
(131, 1, 'save', 'perm.save_desc', 1),
(132, 1, 'save_category', 'perm.save_category_desc', 1),
(133, 1, 'save_chunk', 'perm.save_chunk_desc', 1),
(134, 1, 'save_context', 'perm.save_context_desc', 1),
(135, 1, 'save_document', 'perm.save_document_desc', 1),
(136, 1, 'save_plugin', 'perm.save_plugin_desc', 1),
(137, 1, 'save_propertyset', 'perm.save_propertyset_desc', 1),
(138, 1, 'save_role', 'perm.save_role_desc', 1),
(139, 1, 'save_snippet', 'perm.save_snippet_desc', 1),
(140, 1, 'save_template', 'perm.save_template_desc', 1),
(141, 1, 'save_tv', 'perm.save_tv_desc', 1),
(142, 1, 'save_user', 'perm.save_user_desc', 1),
(143, 1, 'search', 'perm.search_desc', 1),
(144, 1, 'set_sudo', 'perm.set_sudo_desc', 1),
(145, 1, 'settings', 'perm.settings_desc', 1),
(146, 1, 'events', 'perm.events_desc', 1),
(147, 1, 'source_save', 'perm.source_save_desc', 1),
(148, 1, 'source_delete', 'perm.source_delete_desc', 1),
(149, 1, 'source_edit', 'perm.source_edit_desc', 1),
(150, 1, 'source_view', 'perm.source_view_desc', 1),
(151, 1, 'sources', 'perm.sources_desc', 1),
(152, 1, 'steal_locks', 'perm.steal_locks_desc', 1),
(153, 1, 'tree_show_element_ids', 'perm.tree_show_element_ids_desc', 1),
(154, 1, 'tree_show_resource_ids', 'perm.tree_show_resource_ids_desc', 1),
(155, 1, 'undelete_document', 'perm.undelete_document_desc', 1),
(156, 1, 'unpublish_document', 'perm.unpublish_document_desc', 1),
(157, 1, 'unlock_element_properties', 'perm.unlock_element_properties_desc', 1),
(158, 1, 'usergroup_delete', 'perm.usergroup_delete_desc', 1),
(159, 1, 'usergroup_edit', 'perm.usergroup_edit_desc', 1),
(160, 1, 'usergroup_new', 'perm.usergroup_new_desc', 1),
(161, 1, 'usergroup_save', 'perm.usergroup_save_desc', 1),
(162, 1, 'usergroup_user_edit', 'perm.usergroup_user_edit_desc', 1),
(163, 1, 'usergroup_user_list', 'perm.usergroup_user_list_desc', 1),
(164, 1, 'usergroup_view', 'perm.usergroup_view_desc', 1),
(165, 1, 'view', 'perm.view_desc', 1),
(166, 1, 'view_category', 'perm.view_category_desc', 1),
(167, 1, 'view_chunk', 'perm.view_chunk_desc', 1),
(168, 1, 'view_context', 'perm.view_context_desc', 1),
(169, 1, 'view_document', 'perm.view_document_desc', 1),
(170, 1, 'view_element', 'perm.view_element_desc', 1),
(171, 1, 'view_eventlog', 'perm.view_eventlog_desc', 1),
(172, 1, 'view_offline', 'perm.view_offline_desc', 1),
(173, 1, 'view_plugin', 'perm.view_plugin_desc', 1),
(174, 1, 'view_propertyset', 'perm.view_propertyset_desc', 1),
(175, 1, 'view_role', 'perm.view_role_desc', 1),
(176, 1, 'view_snippet', 'perm.view_snippet_desc', 1),
(177, 1, 'view_sysinfo', 'perm.view_sysinfo_desc', 1),
(178, 1, 'view_template', 'perm.view_template_desc', 1),
(179, 1, 'view_tv', 'perm.view_tv_desc', 1),
(180, 1, 'view_user', 'perm.view_user_desc', 1),
(181, 1, 'view_unpublished', 'perm.view_unpublished_desc', 1),
(182, 1, 'workspaces', 'perm.workspaces_desc', 1),
(183, 2, 'add_children', 'perm.add_children_desc', 1),
(184, 2, 'copy', 'perm.copy_desc', 1),
(185, 2, 'create', 'perm.create_desc', 1),
(186, 2, 'delete', 'perm.delete_desc', 1),
(187, 2, 'list', 'perm.list_desc', 1),
(188, 2, 'load', 'perm.load_desc', 1),
(189, 2, 'move', 'perm.move_desc', 1),
(190, 2, 'publish', 'perm.publish_desc', 1),
(191, 2, 'remove', 'perm.remove_desc', 1),
(192, 2, 'save', 'perm.save_desc', 1),
(193, 2, 'steal_lock', 'perm.steal_lock_desc', 1),
(194, 2, 'undelete', 'perm.undelete_desc', 1),
(195, 2, 'unpublish', 'perm.unpublish_desc', 1),
(196, 2, 'view', 'perm.view_desc', 1),
(197, 3, 'load', 'perm.load_desc', 1),
(198, 3, 'list', 'perm.list_desc', 1),
(199, 3, 'view', 'perm.view_desc', 1),
(200, 3, 'save', 'perm.save_desc', 1),
(201, 3, 'remove', 'perm.remove_desc', 1),
(202, 4, 'add_children', 'perm.add_children_desc', 1),
(203, 4, 'create', 'perm.create_desc', 1),
(204, 4, 'copy', 'perm.copy_desc', 1),
(205, 4, 'delete', 'perm.delete_desc', 1),
(206, 4, 'list', 'perm.list_desc', 1),
(207, 4, 'load', 'perm.load_desc', 1),
(208, 4, 'remove', 'perm.remove_desc', 1),
(209, 4, 'save', 'perm.save_desc', 1),
(210, 4, 'view', 'perm.view_desc', 1),
(211, 5, 'create', 'perm.create_desc', 1),
(212, 5, 'copy', 'perm.copy_desc', 1),
(213, 5, 'list', 'perm.list_desc', 1),
(214, 5, 'load', 'perm.load_desc', 1),
(215, 5, 'remove', 'perm.remove_desc', 1),
(216, 5, 'save', 'perm.save_desc', 1),
(217, 5, 'view', 'perm.view_desc', 1),
(218, 6, 'load', 'perm.load_desc', 1),
(219, 6, 'list', 'perm.list_desc', 1),
(220, 6, 'view', 'perm.view_desc', 1),
(221, 6, 'save', 'perm.save_desc', 1),
(222, 6, 'remove', 'perm.remove_desc', 1),
(223, 6, 'view_unpublished', 'perm.view_unpublished_desc', 1),
(224, 6, 'copy', 'perm.copy_desc', 1),
(225, 7, 'list', 'perm.list_desc', 1),
(226, 7, 'load', 'perm.load_desc', 1),
(227, 7, 'view', 'perm.view_desc', 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_policies`
--

CREATE TABLE `modx_access_policies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `template` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `class` varchar(191) NOT NULL DEFAULT '',
  `data` text,
  `lexicon` varchar(191) NOT NULL DEFAULT 'permissions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_policies`
--

INSERT INTO `modx_access_policies` (`id`, `name`, `description`, `parent`, `template`, `class`, `data`, `lexicon`) VALUES
(1, 'Resource', 'MODX Resource Policy with all attributes.', 0, 2, '', '{\"add_children\":true,\"create\":true,\"copy\":true,\"delete\":true,\"list\":true,\"load\":true,\"move\":true,\"publish\":true,\"remove\":true,\"save\":true,\"steal_lock\":true,\"undelete\":true,\"unpublish\":true,\"view\":true}', 'permissions'),
(2, 'Administrator', 'Context administration policy with all permissions.', 0, 1, '', '{\"about\":true,\"access_permissions\":true,\"actions\":true,\"change_password\":true,\"change_profile\":true,\"charsets\":true,\"class_map\":true,\"components\":true,\"content_types\":true,\"countries\":true,\"create\":true,\"credits\":true,\"customize_forms\":true,\"dashboards\":true,\"database\":true,\"database_truncate\":true,\"delete_category\":true,\"delete_chunk\":true,\"delete_context\":true,\"delete_document\":true,\"delete_weblink\":true,\"delete_symlink\":true,\"delete_static_resource\":true,\"delete_eventlog\":true,\"delete_plugin\":true,\"delete_propertyset\":true,\"delete_role\":true,\"delete_snippet\":true,\"delete_template\":true,\"delete_tv\":true,\"delete_user\":true,\"directory_chmod\":true,\"directory_create\":true,\"directory_list\":true,\"directory_remove\":true,\"directory_update\":true,\"edit_category\":true,\"edit_chunk\":true,\"edit_context\":true,\"edit_document\":true,\"edit_weblink\":true,\"edit_symlink\":true,\"edit_static_resource\":true,\"edit_locked\":true,\"edit_plugin\":true,\"edit_propertyset\":true,\"edit_role\":true,\"edit_snippet\":true,\"edit_template\":true,\"edit_tv\":true,\"edit_user\":true,\"element_tree\":true,\"empty_cache\":true,\"error_log_erase\":true,\"error_log_view\":true,\"events\":true,\"export_static\":true,\"file_create\":true,\"file_list\":true,\"file_manager\":true,\"file_remove\":true,\"file_tree\":true,\"file_update\":true,\"file_upload\":true,\"file_unpack\":true,\"file_view\":true,\"flush_sessions\":true,\"frames\":true,\"help\":true,\"home\":true,\"import_static\":true,\"languages\":true,\"lexicons\":true,\"list\":true,\"load\":true,\"logout\":true,\"logs\":true,\"menus\":true,\"menu_reports\":true,\"menu_security\":true,\"menu_site\":true,\"menu_support\":true,\"menu_system\":true,\"menu_tools\":true,\"menu_user\":true,\"messages\":true,\"namespaces\":true,\"new_category\":true,\"new_chunk\":true,\"new_context\":true,\"new_document\":true,\"new_document_in_root\":true,\"new_plugin\":true,\"new_propertyset\":true,\"new_role\":true,\"new_snippet\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_template\":true,\"new_tv\":true,\"new_user\":true,\"new_weblink\":true,\"packages\":true,\"policy_delete\":true,\"policy_edit\":true,\"policy_new\":true,\"policy_save\":true,\"policy_template_delete\":true,\"policy_template_edit\":true,\"policy_template_new\":true,\"policy_template_save\":true,\"policy_template_view\":true,\"policy_view\":true,\"property_sets\":true,\"providers\":true,\"publish_document\":true,\"purge_deleted\":true,\"remove\":true,\"remove_locks\":true,\"resource_duplicate\":true,\"resourcegroup_delete\":true,\"resourcegroup_edit\":true,\"resourcegroup_new\":true,\"resourcegroup_resource_edit\":true,\"resourcegroup_resource_list\":true,\"resourcegroup_save\":true,\"resourcegroup_view\":true,\"resource_quick_create\":true,\"resource_quick_update\":true,\"resource_tree\":true,\"save\":true,\"save_category\":true,\"save_chunk\":true,\"save_context\":true,\"save_document\":true,\"save_plugin\":true,\"save_propertyset\":true,\"save_role\":true,\"save_snippet\":true,\"save_template\":true,\"save_tv\":true,\"save_user\":true,\"search\":true,\"set_sudo\":true,\"settings\":true,\"sources\":true,\"source_delete\":true,\"source_edit\":true,\"source_save\":true,\"source_view\":true,\"steal_locks\":true,\"tree_show_element_ids\":true,\"tree_show_resource_ids\":true,\"undelete_document\":true,\"unlock_element_properties\":true,\"unpublish_document\":true,\"usergroup_delete\":true,\"usergroup_edit\":true,\"usergroup_new\":true,\"usergroup_save\":true,\"usergroup_user_edit\":true,\"usergroup_user_list\":true,\"usergroup_view\":true,\"view\":true,\"view_category\":true,\"view_chunk\":true,\"view_context\":true,\"view_document\":true,\"view_element\":true,\"view_eventlog\":true,\"view_offline\":true,\"view_plugin\":true,\"view_propertyset\":true,\"view_role\":true,\"view_snippet\":true,\"view_sysinfo\":true,\"view_template\":true,\"view_tv\":true,\"view_unpublished\":true,\"view_user\":true,\"workspaces\":true}', 'permissions'),
(3, 'Load Only', 'A minimal policy with permission to load an object.', 0, 3, '', '{\"load\":true}', 'permissions'),
(4, 'Load, List and View', 'Provides load, list and view permissions only.', 0, 3, '', '{\"load\":true,\"list\":true,\"view\":true}', 'permissions'),
(5, 'Object', 'An Object policy with all permissions.', 0, 3, '', '{\"load\":true,\"list\":true,\"view\":true,\"save\":true,\"remove\":true}', 'permissions'),
(6, 'Element', 'MODX Element policy with all attributes.', 0, 4, '', '{\"add_children\":true,\"create\":true,\"delete\":true,\"list\":true,\"load\":true,\"remove\":true,\"save\":true,\"view\":true,\"copy\":true}', 'permissions'),
(7, 'Content Editor', 'Context administration policy with limited, content-editing related Permissions, but no publishing.', 0, 1, '', '{\"change_profile\":true,\"class_map\":true,\"countries\":true,\"edit_document\":true,\"edit_weblink\":true,\"edit_symlink\":true,\"edit_static_resource\":true,\"frames\":true,\"help\":true,\"home\":true,\"load\":true,\"list\":true,\"logout\":true,\"menu_reports\":true,\"menu_site\":true,\"menu_support\":true,\"menu_tools\":true,\"menu_user\":true,\"resource_duplicate\":true,\"resource_tree\":true,\"save_document\":true,\"source_view\":true,\"tree_show_resource_ids\":true,\"view\":true,\"view_document\":true,\"view_template\":true,\"new_document\":true,\"new_weblink\":true,\"new_symlink\":true,\"new_static_resource\":true,\"delete_document\":true,\"delete_weblink\":true,\"delete_symlink\":true,\"delete_static_resource\":true}', 'permissions'),
(8, 'Media Source Admin', 'Media Source administration policy.', 0, 5, '', '{\"create\":true,\"copy\":true,\"load\":true,\"list\":true,\"save\":true,\"remove\":true,\"view\":true}', 'permissions'),
(9, 'Media Source User', 'Media Source user policy, with basic viewing and using - but no editing - of Media Sources.', 0, 5, '', '{\"load\":true,\"list\":true,\"view\":true}', 'permissions'),
(10, 'Developer', 'Context administration policy with most Permissions except Administrator and Security functions.', 0, 0, '', '{\"about\":true,\"change_password\":true,\"change_profile\":true,\"charsets\":true,\"class_map\":true,\"components\":true,\"content_types\":true,\"countries\":true,\"create\":true,\"credits\":true,\"customize_forms\":true,\"dashboards\":true,\"database\":true,\"delete_category\":true,\"delete_chunk\":true,\"delete_context\":true,\"delete_document\":true,\"delete_eventlog\":true,\"delete_plugin\":true,\"delete_propertyset\":true,\"delete_snippet\":true,\"delete_template\":true,\"delete_tv\":true,\"delete_role\":true,\"delete_user\":true,\"directory_chmod\":true,\"directory_create\":true,\"directory_list\":true,\"directory_remove\":true,\"directory_update\":true,\"edit_category\":true,\"edit_chunk\":true,\"edit_context\":true,\"edit_document\":true,\"edit_weblink\":true,\"edit_symlink\":true,\"edit_static_resource\":true,\"edit_locked\":true,\"edit_plugin\":true,\"edit_propertyset\":true,\"edit_role\":true,\"edit_snippet\":true,\"edit_template\":true,\"edit_tv\":true,\"edit_user\":true,\"element_tree\":true,\"empty_cache\":true,\"error_log_erase\":true,\"error_log_view\":true,\"export_static\":true,\"file_create\":true,\"file_list\":true,\"file_manager\":true,\"file_remove\":true,\"file_tree\":true,\"file_update\":true,\"file_upload\":true,\"file_unpack\":true,\"file_view\":true,\"frames\":true,\"help\":true,\"home\":true,\"import_static\":true,\"languages\":true,\"lexicons\":true,\"list\":true,\"load\":true,\"logout\":true,\"logs\":true,\"menu_reports\":true,\"menu_site\":true,\"menu_support\":true,\"menu_system\":true,\"menu_tools\":true,\"menu_user\":true,\"menus\":true,\"messages\":true,\"namespaces\":true,\"new_category\":true,\"new_chunk\":true,\"new_context\":true,\"new_document\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_weblink\":true,\"new_document_in_root\":true,\"new_plugin\":true,\"new_propertyset\":true,\"new_role\":true,\"new_snippet\":true,\"new_template\":true,\"new_tv\":true,\"new_user\":true,\"packages\":true,\"property_sets\":true,\"providers\":true,\"publish_document\":true,\"purge_deleted\":true,\"remove\":true,\"resource_duplicate\":true,\"resource_quick_create\":true,\"resource_quick_update\":true,\"resource_tree\":true,\"save\":true,\"save_category\":true,\"save_chunk\":true,\"save_context\":true,\"save_document\":true,\"save_plugin\":true,\"save_propertyset\":true,\"save_snippet\":true,\"save_template\":true,\"save_tv\":true,\"save_user\":true,\"search\":true,\"settings\":true,\"source_delete\":true,\"source_edit\":true,\"source_save\":true,\"source_view\":true,\"sources\":true,\"tree_show_element_ids\":true,\"tree_show_resource_ids\":true,\"undelete_document\":true,\"unpublish_document\":true,\"unlock_element_properties\":true,\"view\":true,\"view_category\":true,\"view_chunk\":true,\"view_context\":true,\"view_document\":true,\"view_element\":true,\"view_eventlog\":true,\"view_offline\":true,\"view_plugin\":true,\"view_propertyset\":true,\"view_role\":true,\"view_snippet\":true,\"view_sysinfo\":true,\"view_template\":true,\"view_tv\":true,\"view_user\":true,\"view_unpublished\":true,\"workspaces\":true}', 'permissions'),
(11, 'Context', 'A standard Context policy that you can apply when creating Context ACLs for basic read/write and view_unpublished access within a Context.', 0, 6, '', '{\"load\":true,\"list\":true,\"view\":true,\"save\":true,\"remove\":true,\"copy\":true,\"view_unpublished\":true}', 'permissions'),
(12, 'Hidden Namespace', 'Hidden Namespace policy, will not show Namespace in lists.', 0, 7, '', '{\"load\":false,\"list\":false,\"view\":true}', 'permissions');

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_policy_templates`
--

CREATE TABLE `modx_access_policy_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `template_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` mediumtext,
  `lexicon` varchar(191) NOT NULL DEFAULT 'permissions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_policy_templates`
--

INSERT INTO `modx_access_policy_templates` (`id`, `template_group`, `name`, `description`, `lexicon`) VALUES
(1, 1, 'AdministratorTemplate', 'Context administration policy template with all permissions.', 'permissions'),
(2, 3, 'ResourceTemplate', 'Resource Policy Template with all attributes.', 'permissions'),
(3, 2, 'ObjectTemplate', 'Object Policy Template with all attributes.', 'permissions'),
(4, 4, 'ElementTemplate', 'Element Policy Template with all attributes.', 'permissions'),
(5, 5, 'MediaSourceTemplate', 'Media Source Policy Template with all attributes.', 'permissions'),
(6, 2, 'ContextTemplate', 'Context Policy Template with all attributes.', 'permissions'),
(7, 6, 'NamespaceTemplate', 'Namespace Policy Template with all attributes.', 'permissions');

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_policy_template_groups`
--

CREATE TABLE `modx_access_policy_template_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_policy_template_groups`
--

INSERT INTO `modx_access_policy_template_groups` (`id`, `name`, `description`) VALUES
(1, 'Admin', 'All admin policy templates.'),
(2, 'Object', 'All Object-based policy templates.'),
(3, 'Resource', 'All Resource-based policy templates.'),
(4, 'Element', 'All Element-based policy templates.'),
(5, 'MediaSource', 'All Media Source-based policy templates.'),
(6, 'Namespace', 'All Namespace based policy templates.');

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_resources`
--

CREATE TABLE `modx_access_resources` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_resource_groups`
--

CREATE TABLE `modx_access_resource_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_templatevars`
--

CREATE TABLE `modx_access_templatevars` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_actiondom`
--

CREATE TABLE `modx_actiondom` (
  `id` int(10) UNSIGNED NOT NULL,
  `set` int(11) NOT NULL DEFAULT '0',
  `action` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `xtype` varchar(100) NOT NULL DEFAULT '',
  `container` varchar(191) NOT NULL DEFAULT '',
  `rule` varchar(100) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `constraint` varchar(191) NOT NULL DEFAULT '',
  `constraint_field` varchar(100) NOT NULL DEFAULT '',
  `constraint_class` varchar(100) NOT NULL DEFAULT '',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `for_parent` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_actions`
--

CREATE TABLE `modx_actions` (
  `id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(100) NOT NULL DEFAULT 'core',
  `controller` varchar(191) NOT NULL,
  `haslayout` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `lang_topics` text NOT NULL,
  `assets` text NOT NULL,
  `help_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_actions`
--

INSERT INTO `modx_actions` (`id`, `namespace`, `controller`, `haslayout`, `lang_topics`, `assets`, `help_url`) VALUES
(5, 'lingua', 'index', 1, 'lingua:default', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_actions_fields`
--

CREATE TABLE `modx_actions_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `action` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(191) NOT NULL DEFAULT '',
  `type` varchar(100) NOT NULL DEFAULT 'field',
  `tab` varchar(191) NOT NULL DEFAULT '',
  `form` varchar(191) NOT NULL DEFAULT '',
  `other` varchar(191) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_actions_fields`
--

INSERT INTO `modx_actions_fields` (`id`, `action`, `name`, `type`, `tab`, `form`, `other`, `rank`) VALUES
(1, 'resource/update', 'modx-resource-settings', 'tab', '', 'modx-panel-resource', '', 0),
(2, 'resource/update', 'modx-resource-main-left', 'tab', '', 'modx-panel-resource', '', 1),
(3, 'resource/update', 'id', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 0),
(4, 'resource/update', 'pagetitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 1),
(5, 'resource/update', 'longtitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 2),
(6, 'resource/update', 'description', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 3),
(7, 'resource/update', 'introtext', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 4),
(8, 'resource/update', 'modx-resource-main-right', 'tab', '', 'modx-panel-resource', '', 2),
(9, 'resource/update', 'template', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 0),
(10, 'resource/update', 'alias', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 1),
(11, 'resource/update', 'menutitle', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 2),
(12, 'resource/update', 'link_attributes', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 3),
(13, 'resource/update', 'hidemenu', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 4),
(14, 'resource/update', 'published', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 5),
(15, 'resource/update', 'modx-page-settings', 'tab', '', 'modx-panel-resource', '', 3),
(16, 'resource/update', 'modx-page-settings-left', 'tab', '', 'modx-panel-resource', '', 4),
(17, 'resource/update', 'parent-cmb', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 0),
(18, 'resource/update', 'class_key', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 1),
(19, 'resource/update', 'content_type', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 2),
(20, 'resource/update', 'content_dispo', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 3),
(21, 'resource/update', 'menuindex', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 4),
(22, 'resource/update', 'modx-page-settings-right', 'tab', '', 'modx-panel-resource', '', 5),
(23, 'resource/update', 'publishedon', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 0),
(24, 'resource/update', 'pub_date', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 1),
(25, 'resource/update', 'unpub_date', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 2),
(26, 'resource/update', 'modx-page-settings-right-box-left', 'tab', '', 'modx-panel-resource', '', 6),
(27, 'resource/update', 'isfolder', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 0),
(28, 'resource/update', 'searchable', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 1),
(29, 'resource/update', 'alias_visible', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 2),
(30, 'resource/update', 'richtext', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 3),
(31, 'resource/update', 'uri_override', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 4),
(32, 'resource/update', 'uri', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 5),
(33, 'resource/update', 'modx-page-settings-right-box-right', 'tab', '', 'modx-panel-resource', '', 7),
(34, 'resource/update', 'cacheable', 'field', 'modx-page-settings-right-box-right', 'modx-panel-resource', '', 0),
(35, 'resource/update', 'syncsite', 'field', 'modx-page-settings-right-box-right', 'modx-panel-resource', '', 1),
(36, 'resource/update', 'deleted', 'field', 'modx-page-settings-right-box-right', 'modx-panel-resource', '', 2),
(37, 'resource/update', 'modx-panel-resource-tv', 'tab', '', 'modx-panel-resource', 'tv', 8),
(38, 'resource/update', 'modx-resource-access-permissions', 'tab', '', 'modx-panel-resource', '', 9),
(39, 'resource/update', 'modx-resource-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 0),
(40, 'resource/update', 'modx-symlink-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 1),
(41, 'resource/update', 'modx-weblink-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 2),
(42, 'resource/create', 'modx-resource-settings', 'tab', '', 'modx-panel-resource', '', 0),
(43, 'resource/create', 'modx-resource-main-left', 'tab', '', 'modx-panel-resource', '', 1),
(44, 'resource/create', 'id', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 0),
(45, 'resource/create', 'pagetitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 1),
(46, 'resource/create', 'longtitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 2),
(47, 'resource/create', 'description', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 3),
(48, 'resource/create', 'introtext', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 4),
(49, 'resource/create', 'modx-resource-main-right', 'tab', '', 'modx-panel-resource', '', 2),
(50, 'resource/create', 'template', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 0),
(51, 'resource/create', 'alias', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 1),
(52, 'resource/create', 'menutitle', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 2),
(53, 'resource/create', 'link_attributes', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 3),
(54, 'resource/create', 'hidemenu', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 4),
(55, 'resource/create', 'published', 'field', 'modx-resource-main-right', 'modx-panel-resource', '', 5),
(56, 'resource/create', 'modx-page-settings', 'tab', '', 'modx-panel-resource', '', 3),
(57, 'resource/create', 'modx-page-settings-left', 'tab', '', 'modx-panel-resource', '', 4),
(58, 'resource/create', 'parent-cmb', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 0),
(59, 'resource/create', 'class_key', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 1),
(60, 'resource/create', 'content_type', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 2),
(61, 'resource/create', 'content_dispo', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 3),
(62, 'resource/create', 'menuindex', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 4),
(63, 'resource/create', 'modx-page-settings-right', 'tab', '', 'modx-panel-resource', '', 5),
(64, 'resource/create', 'publishedon', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 0),
(65, 'resource/create', 'pub_date', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 1),
(66, 'resource/create', 'unpub_date', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 2),
(67, 'resource/create', 'modx-page-settings-right-box-left', 'tab', '', 'modx-panel-resource', '', 6),
(68, 'resource/create', 'isfolder', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 0),
(69, 'resource/create', 'searchable', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 1),
(70, 'resource/create', 'alias_visible', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 2),
(71, 'resource/create', 'richtext', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 3),
(72, 'resource/create', 'uri_override', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 4),
(73, 'resource/create', 'uri', 'field', 'modx-page-settings-right-box-left', 'modx-panel-resource', '', 5),
(74, 'resource/create', 'modx-page-settings-right-box-right', 'tab', '', 'modx-panel-resource', '', 7),
(75, 'resource/create', 'cacheable', 'field', 'modx-page-settings-right-box-right', 'modx-panel-resource', '', 0),
(76, 'resource/create', 'syncsite', 'field', 'modx-page-settings-right-box-right', 'modx-panel-resource', '', 1),
(77, 'resource/create', 'deleted', 'field', 'modx-page-settings-right-box-right', 'modx-panel-resource', '', 2),
(78, 'resource/create', 'modx-panel-resource-tv', 'tab', '', 'modx-panel-resource', 'tv', 8),
(79, 'resource/create', 'modx-resource-access-permissions', 'tab', '', 'modx-panel-resource', '', 9),
(80, 'resource/create', 'modx-resource-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_active_users`
--

CREATE TABLE `modx_active_users` (
  `internalKey` int(9) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `lasthit` int(20) NOT NULL DEFAULT '0',
  `id` int(10) DEFAULT NULL,
  `action` varchar(191) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_categories`
--

CREATE TABLE `modx_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent` int(10) UNSIGNED DEFAULT '0',
  `category` varchar(45) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_categories`
--

INSERT INTO `modx_categories` (`id`, `parent`, `category`, `rank`) VALUES
(5, 0, 'Collections', 0),
(6, 0, 'pdoTools', 0),
(7, 0, 'Lingua', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_categories_closure`
--

CREATE TABLE `modx_categories_closure` (
  `ancestor` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `descendant` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `depth` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_categories_closure`
--

INSERT INTO `modx_categories_closure` (`ancestor`, `descendant`, `depth`) VALUES
(0, 5, 0),
(0, 6, 0),
(0, 7, 0),
(5, 5, 0),
(6, 6, 0),
(7, 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_class_map`
--

CREATE TABLE `modx_class_map` (
  `id` int(10) UNSIGNED NOT NULL,
  `class` varchar(120) NOT NULL DEFAULT '',
  `parent_class` varchar(120) NOT NULL DEFAULT '',
  `name_field` varchar(191) NOT NULL DEFAULT 'name',
  `path` tinytext,
  `lexicon` varchar(191) NOT NULL DEFAULT 'core:resource'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_class_map`
--

INSERT INTO `modx_class_map` (`id`, `class`, `parent_class`, `name_field`, `path`, `lexicon`) VALUES
(1, 'modDocument', 'modResource', 'pagetitle', '', 'core:resource'),
(2, 'modWebLink', 'modResource', 'pagetitle', '', 'core:resource'),
(3, 'modSymLink', 'modResource', 'pagetitle', '', 'core:resource'),
(4, 'modStaticResource', 'modResource', 'pagetitle', '', 'core:resource'),
(5, 'modTemplate', 'modElement', 'templatename', '', 'core:resource'),
(6, 'modTemplateVar', 'modElement', 'name', '', 'core:resource'),
(7, 'modChunk', 'modElement', 'name', '', 'core:resource'),
(8, 'modSnippet', 'modElement', 'name', '', 'core:resource'),
(9, 'modPlugin', 'modElement', 'name', '', 'core:resource');

-- --------------------------------------------------------

--
-- Table structure for table `modx_collection_resource_template`
--

CREATE TABLE `modx_collection_resource_template` (
  `collection_template` int(10) UNSIGNED NOT NULL,
  `resource_template` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_collection_selections`
--

CREATE TABLE `modx_collection_selections` (
  `collection` int(10) UNSIGNED NOT NULL,
  `resource` int(10) UNSIGNED NOT NULL,
  `menuindex` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_collection_settings`
--

CREATE TABLE `modx_collection_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `collection` int(10) UNSIGNED NOT NULL,
  `template` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_collection_settings`
--

INSERT INTO `modx_collection_settings` (`id`, `collection`, `template`) VALUES
(1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_collection_templates`
--

CREATE TABLE `modx_collection_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `global_template` int(1) NOT NULL DEFAULT '0',
  `bulk_actions` int(1) NOT NULL DEFAULT '0',
  `allow_dd` int(1) NOT NULL DEFAULT '1',
  `page_size` int(10) NOT NULL DEFAULT '20',
  `sort_field` varchar(100) NOT NULL DEFAULT 'id',
  `sort_dir` varchar(4) NOT NULL DEFAULT 'asc',
  `sort_type` varchar(64) DEFAULT NULL,
  `child_template` int(10) UNSIGNED DEFAULT NULL,
  `child_resource_type` varchar(100) NOT NULL DEFAULT 'modDocument',
  `resource_type_selection` int(1) NOT NULL DEFAULT '1',
  `tab_label` varchar(255) NOT NULL DEFAULT 'collections.children',
  `button_label` varchar(255) NOT NULL DEFAULT 'collections.children.create',
  `content_place` varchar(255) NOT NULL DEFAULT 'original',
  `view_for` int(1) UNSIGNED NOT NULL DEFAULT '0',
  `link_label` varchar(255) NOT NULL DEFAULT 'selections.create',
  `context_menu` varchar(512) NOT NULL DEFAULT 'view,edit,duplicate,publish,unpublish,-,delete,undelete,remove,-,unlink',
  `buttons` varchar(512) NOT NULL DEFAULT 'open,view,edit,duplicate,publish:orange,unpublish,delete,undelete,remove,unlink',
  `allowed_resource_types` varchar(512) NOT NULL DEFAULT '',
  `back_to_collection_label` varchar(255) NOT NULL DEFAULT 'collections.children.back_to_collection_label',
  `back_to_selection_label` varchar(255) NOT NULL DEFAULT 'selections.back_to_selection_label',
  `selection_create_sort` varchar(255) NOT NULL DEFAULT 'id:desc',
  `child_hide_from_menu` int(1) DEFAULT NULL,
  `child_published` int(1) DEFAULT NULL,
  `child_cacheable` int(1) DEFAULT NULL,
  `child_searchable` int(1) DEFAULT NULL,
  `child_richtext` int(1) DEFAULT NULL,
  `child_content_type` int(10) NOT NULL DEFAULT '0',
  `parent` varchar(100) NOT NULL DEFAULT '',
  `child_content_disposition` int(1) DEFAULT NULL,
  `permanent_sort_before` varchar(255) NOT NULL DEFAULT '',
  `permanent_sort_after` varchar(255) NOT NULL DEFAULT '',
  `selection_link_condition` text,
  `search_query_exclude_tvs` int(1) NOT NULL DEFAULT '0',
  `search_query_exclude_tagger` int(1) NOT NULL DEFAULT '0',
  `search_query_title_only` int(1) NOT NULL DEFAULT '0',
  `show_quick_create` tinyint(1) NOT NULL DEFAULT '1',
  `quick_create_label` varchar(255) NOT NULL DEFAULT 'collections.children.quick_create',
  `fred_default_blueprint` varchar(36) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_collection_templates`
--

INSERT INTO `modx_collection_templates` (`id`, `name`, `description`, `global_template`, `bulk_actions`, `allow_dd`, `page_size`, `sort_field`, `sort_dir`, `sort_type`, `child_template`, `child_resource_type`, `resource_type_selection`, `tab_label`, `button_label`, `content_place`, `view_for`, `link_label`, `context_menu`, `buttons`, `allowed_resource_types`, `back_to_collection_label`, `back_to_selection_label`, `selection_create_sort`, `child_hide_from_menu`, `child_published`, `child_cacheable`, `child_searchable`, `child_richtext`, `child_content_type`, `parent`, `child_content_disposition`, `permanent_sort_before`, `permanent_sort_after`, `selection_link_condition`, `search_query_exclude_tvs`, `search_query_exclude_tagger`, `search_query_title_only`, `show_quick_create`, `quick_create_label`, `fred_default_blueprint`) VALUES
(1, 'Blog', 'A default view that works well for blogs.', 0, 1, 1, 10, 'publishedon', 'desc', NULL, NULL, 'modDocument', 1, 'collections.children', 'collections.children.create', 'original', 0, 'selections.create', 'view,edit,duplicate,publish,unpublish,-,delete,undelete,remove,-,unlink', 'open,view,edit,duplicate,publish:orange,unpublish,delete,undelete,remove,unlink', '', 'collections.children.back_to_collection_label', 'selections.back_to_selection_label', 'id:desc', NULL, NULL, NULL, NULL, NULL, 0, '', 1, '', '', '', 0, 0, 0, 1, 'collections.children.quick_create', ''),
(2, 'Gallery', '', 1, 0, 1, 20, 'id', 'asc', NULL, 4, 'modStaticResource', 1, 'collections.children', 'collections.children.create', 'original', 0, 'selections.create', 'view,edit,duplicate,publish,unpublish,-,delete,undelete,remove,-,unlink', 'view,edit,duplicate,publish:orange,unpublish,delete,undelete,remove,unlink', '', 'collections.children.back_to_collection_label', 'selections.back_to_selection_label', 'id:desc', NULL, NULL, NULL, NULL, NULL, 0, '', NULL, '', '', '', 0, 0, 0, 1, 'collections.children.quick_create', '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_collection_template_columns`
--

CREATE TABLE `modx_collection_template_columns` (
  `id` int(10) UNSIGNED NOT NULL,
  `template` int(10) UNSIGNED NOT NULL,
  `label` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `hidden` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `sortable` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `width` int(10) UNSIGNED NOT NULL DEFAULT '100',
  `editor` varchar(255) NOT NULL DEFAULT '',
  `renderer` varchar(255) NOT NULL DEFAULT '',
  `php_renderer` varchar(255) NOT NULL DEFAULT '',
  `position` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `sort_type` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_collection_template_columns`
--

INSERT INTO `modx_collection_template_columns` (`id`, `template`, `label`, `name`, `hidden`, `sortable`, `width`, `editor`, `renderer`, `php_renderer`, `position`, `sort_type`) VALUES
(1, 1, 'id', 'id', 1, 1, 40, '', '', '', 0, NULL),
(2, 1, 'publishedon', 'publishedon', 0, 1, 40, '', 'Collections.renderer.datetimeTwoLines', '', 1, NULL),
(3, 1, 'pagetitle', 'pagetitle', 0, 1, 170, '', 'Collections.renderer.pagetitleWithButtons', '', 2, NULL),
(4, 1, 'alias', 'alias', 0, 1, 100, '', '', '', 3, NULL),
(5, 1, 'resource_menuindex', 'menuindex', 0, 1, 50, '{\"xtype\":\"numberfield\",\"allowNegative\":false,\"allowDecimal\":false}', '', '', 4, NULL),
(6, 2, 'id', 'id', 1, 0, 40, '', '', '', 0, NULL),
(7, 2, 'Название', 'pagetitle', 0, 0, 100, '', '', '', 2, NULL),
(8, 2, 'Картинка', 'tv_image', 0, 0, 400, '', 'Collections.renderer.image', '', 3, NULL),
(9, 2, 'Опубликован', 'published', 0, 0, 100, '', 'Collections.renderer.boolean', '', 4, NULL),
(10, 2, 'menuIndex', 'menuindex', 0, 1, 40, '', '', '', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_content_type`
--

CREATE TABLE `modx_content_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` tinytext,
  `mime_type` tinytext,
  `file_extensions` tinytext,
  `headers` mediumtext,
  `binary` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_content_type`
--

INSERT INTO `modx_content_type` (`id`, `name`, `description`, `mime_type`, `file_extensions`, `headers`, `binary`) VALUES
(1, 'HTML', 'HTML content', 'text/html', '.html', NULL, 0),
(2, 'XML', 'XML content', 'text/xml', '.xml', NULL, 0),
(3, 'text', 'plain text content', 'text/plain', '.txt', NULL, 0),
(4, 'CSS', 'CSS content', 'text/css', '.css', NULL, 0),
(5, 'javascript', 'javascript content', 'text/javascript', '.js', NULL, 0),
(6, 'RSS', 'For RSS feeds', 'application/rss+xml', '.rss', NULL, 0),
(7, 'JSON', 'JSON', 'application/json', '.json', NULL, 0),
(8, 'PDF', 'PDF Files', 'application/pdf', '.pdf', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_context`
--

CREATE TABLE `modx_context` (
  `key` varchar(100) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `description` tinytext,
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_context`
--

INSERT INTO `modx_context` (`key`, `name`, `description`, `rank`) VALUES
('mgr', 'Manager', 'The default manager or administration context for content management activity.', 0),
('web', 'Website', 'The default front-end context for your web site.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_context_resource`
--

CREATE TABLE `modx_context_resource` (
  `context_key` varchar(191) NOT NULL,
  `resource` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_context_setting`
--

CREATE TABLE `modx_context_setting` (
  `context_key` varchar(191) NOT NULL,
  `key` varchar(50) NOT NULL,
  `value` mediumtext,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(191) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_context_setting`
--

INSERT INTO `modx_context_setting` (`context_key`, `key`, `value`, `xtype`, `namespace`, `area`, `editedon`) VALUES
('mgr', 'allow_tags_in_post', '1', 'combo-boolean', 'core', 'system', NULL),
('mgr', 'modRequest.class', 'modManagerRequest', 'textfield', 'core', 'system', NULL),
('web', 'modRequest.class', 'LinguaRequest', 'textfield', 'core', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_dashboard`
--

CREATE TABLE `modx_dashboard` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `hide_trees` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_dashboard`
--

INSERT INTO `modx_dashboard` (`id`, `name`, `description`, `hide_trees`) VALUES
(1, 'Default', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_dashboard_widget`
--

CREATE TABLE `modx_dashboard_widget` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `type` varchar(100) NOT NULL,
  `content` mediumtext,
  `namespace` varchar(191) NOT NULL DEFAULT '',
  `lexicon` varchar(191) NOT NULL DEFAULT 'core:dashboards',
  `size` varchar(191) NOT NULL DEFAULT 'half'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_dashboard_widget`
--

INSERT INTO `modx_dashboard_widget` (`id`, `name`, `description`, `type`, `content`, `namespace`, `lexicon`, `size`) VALUES
(1, 'w_newsfeed', 'w_newsfeed_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.modx-news.php', 'core', 'core:dashboards', 'half'),
(2, 'w_securityfeed', 'w_securityfeed_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.modx-security.php', 'core', 'core:dashboards', 'half'),
(3, 'w_whosonline', 'w_whosonline_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.grid-online.php', 'core', 'core:dashboards', 'half'),
(4, 'w_recentlyeditedresources', 'w_recentlyeditedresources_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.grid-rer.php', 'core', 'core:dashboards', 'half'),
(5, 'w_configcheck', 'w_configcheck_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.configcheck.php', 'core', 'core:dashboards', 'full');

-- --------------------------------------------------------

--
-- Table structure for table `modx_dashboard_widget_placement`
--

CREATE TABLE `modx_dashboard_widget_placement` (
  `dashboard` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `widget` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_dashboard_widget_placement`
--

INSERT INTO `modx_dashboard_widget_placement` (`dashboard`, `widget`, `rank`) VALUES
(1, 5, 0),
(1, 1, 1),
(1, 2, 2),
(1, 3, 3),
(1, 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `modx_documentgroup_names`
--

CREATE TABLE `modx_documentgroup_names` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `private_memgroup` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `private_webgroup` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_document_groups`
--

CREATE TABLE `modx_document_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `document_group` int(10) NOT NULL DEFAULT '0',
  `document` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_element_property_sets`
--

CREATE TABLE `modx_element_property_sets` (
  `element` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `element_class` varchar(100) NOT NULL DEFAULT '',
  `property_set` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_extension_packages`
--

CREATE TABLE `modx_extension_packages` (
  `id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `name` varchar(100) NOT NULL DEFAULT 'core',
  `path` text,
  `table_prefix` varchar(191) NOT NULL DEFAULT '',
  `service_class` varchar(191) NOT NULL DEFAULT '',
  `service_name` varchar(191) NOT NULL DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_fc_profiles`
--

CREATE TABLE `modx_fc_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_fc_profiles_usergroups`
--

CREATE TABLE `modx_fc_profiles_usergroups` (
  `usergroup` int(11) NOT NULL DEFAULT '0',
  `profile` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_fc_sets`
--

CREATE TABLE `modx_fc_sets` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile` int(11) NOT NULL DEFAULT '0',
  `action` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `template` int(11) NOT NULL DEFAULT '0',
  `constraint` varchar(191) NOT NULL DEFAULT '',
  `constraint_field` varchar(100) NOT NULL DEFAULT '',
  `constraint_class` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_gallery_albums`
--

CREATE TABLE `modx_gallery_albums` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `year` varchar(100) DEFAULT NULL,
  `description` text,
  `createdon` datetime DEFAULT NULL,
  `createdby` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `prominent` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `watermark` varchar(255) NOT NULL DEFAULT '',
  `cover_filename` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_gallery_album_contexts`
--

CREATE TABLE `modx_gallery_album_contexts` (
  `id` int(10) UNSIGNED NOT NULL,
  `album` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_gallery_album_items`
--

CREATE TABLE `modx_gallery_album_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `item` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `album` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_gallery_items`
--

CREATE TABLE `modx_gallery_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `mediatype` varchar(40) NOT NULL DEFAULT 'image',
  `url` text,
  `createdon` datetime DEFAULT NULL,
  `createdby` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `duration` varchar(40) NOT NULL DEFAULT '',
  `streamer` text,
  `watermark_pos` varchar(10) NOT NULL DEFAULT 'tl'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_gallery_tags`
--

CREATE TABLE `modx_gallery_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `item` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `tag` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_lexicon_entries`
--

CREATE TABLE `modx_lexicon_entries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `topic` varchar(191) NOT NULL DEFAULT 'default',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `language` varchar(20) NOT NULL DEFAULT 'en',
  `createdon` datetime DEFAULT NULL,
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_lingua_langs`
--

CREATE TABLE `modx_lingua_langs` (
  `id` int(10) UNSIGNED NOT NULL,
  `active` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `local_name` varchar(255) DEFAULT NULL,
  `lang_code` char(2) NOT NULL,
  `lcid_string` char(10) DEFAULT NULL,
  `lcid_dec` int(6) UNSIGNED DEFAULT NULL,
  `date_format_lite` char(32) DEFAULT 'Y-m-d',
  `date_format_full` char(32) DEFAULT 'Y-m-d H:i:s',
  `is_rtl` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `flag` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_lingua_langs`
--

INSERT INTO `modx_lingua_langs` (`id`, `active`, `local_name`, `lang_code`, `lcid_string`, `lcid_dec`, `date_format_lite`, `date_format_full`, `is_rtl`, `flag`) VALUES
(1, 1, 'English', 'en', 'en-us', 1033, 'm/j/Y', 'm/j/Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/us.gif'),
(10, 1, 'Français', 'fr', 'fr-fr', 1036, 'm/j/Y', 'm/j/Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/fr.gif'),
(11, 0, 'Español', 'es', 'es-es', 1034, 'd/m/Y', 'd/m/Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/es.gif'),
(12, 0, 'Deutsch', 'de', 'de-de', 1031, 'd.m.Y', 'd.m.Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/de.gif'),
(13, 0, 'Italiano', 'it', 'it-it', 1040, 'd/m/Y', 'd/m/Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/it.gif'),
(14, 0, '中国的', 'zh', 'zh-cn', 2052, 'Y-m-d', 'Y-m-d H:i:s', 0, 'assets/components/lingua/icons/flags/gif/cn.gif'),
(15, 0, 'ประเทศไทย', 'th', 'th-th', 1054, 'd-m-Y', 'd-m-Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/th.gif'),
(9, 1, 'Русский', 'ru', 'ru', 1049, 'j/m/Y', 'j M Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/ru.gif'),
(16, 0, 'Bahasa Indonesia', 'id', 'id', 1057, 'd-m-Y', 'd-m-Y H:i:s', 0, 'assets/components/lingua/icons/flags/gif/id.gif');

-- --------------------------------------------------------

--
-- Table structure for table `modx_lingua_resource_scopes`
--

CREATE TABLE `modx_lingua_resource_scopes` (
  `id` int(10) UNSIGNED NOT NULL,
  `resource_id` int(10) UNSIGNED NOT NULL,
  `properties` text NOT NULL,
  `as_parent` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `as_ancestor` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `exclude_self` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_lingua_site_content`
--

CREATE TABLE `modx_lingua_site_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `resource_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `lang_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pagetitle` varchar(255) NOT NULL DEFAULT '',
  `longtitle` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) DEFAULT '',
  `link_attributes` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) NOT NULL DEFAULT '0',
  `isfolder` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `introtext` text,
  `content` mediumtext,
  `menutitle` varchar(255) NOT NULL DEFAULT '',
  `context_key` varchar(100) NOT NULL DEFAULT 'web',
  `content_type` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `uri` text,
  `uri_override` tinyint(1) NOT NULL DEFAULT '0',
  `properties` mediumtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_lingua_site_content`
--

INSERT INTO `modx_lingua_site_content` (`id`, `resource_id`, `lang_id`, `pagetitle`, `longtitle`, `description`, `alias`, `link_attributes`, `parent`, `isfolder`, `introtext`, `content`, `menutitle`, `context_key`, `content_type`, `uri`, `uri_override`, `properties`) VALUES
(1, 1, 1, 'Main', 'Welcome', '', 'main', '', 0, 0, '', '        <section id=\"hero\" class=\"visible\">\r\n            <div class=\"hero-logo logo\" data-speed=\"0\" data-blur=\"0\">\r\n                <img src=\"/img/logo-[[!lingua.cultureKey]].svg\" alt=\"\">\r\n                <h1>#Mary sun</h1>\r\n                <span>The world of especial artist</span>\r\n            </div>\r\n            <div class=\"layer-parallax\">\r\n                <div class=\"layer lazy\" data-speed=\"5\" data-blur=\"1.5\" data-src=\"/img/layers/flowers.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"3\" data-blur=\"0.3\" data-src=\"/img/layers/grass.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"1.6\" data-blur=\"0.1\" data-src=\"/img/layers/mountains.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"1\" data-blur=\"0\" data-src=\"/img/layers/sky.png\"></div>\r\n            </div>\r\n        </section>\r\n        <section id=\"about\">\r\n            <div class=\"container\">\r\n                <div class=\"row flex\">\r\n                    <div class=\"col s12 center-align\">\r\n                        <h2>About me</h2>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"swiper-container\" id=\"swiper-about\">\r\n                <div class=\"swiper-wrapper\">\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Childhood\" data-src=\"/img/slides/slide3.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/childhood.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Childhood</h3>\r\n                                    <p>\r\n                                        Mary Mordvinceva was born in the summer of 2000th in the Leninsk-Kuznetsky city of Kemerovo district. Helen, the mother of a girl, puts a lot of power and love into her daughter – \r\n                                        as soon as Mary starts to sit, mother sit girl on her lap and read her childish books, and the girl considers pictures, memorize animals, characters, and colors. \r\n                                        That was the start of her devotion to art. In the summer of 2004th, a whole family moved to resort city Goryachiy Kluch. There Mary started to paint. At the beginning by the words \r\n                                        of her mother it was «kalya-malya», but by a time here paintings became more and more awares.\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/plant1.png\" data-lx=\"38\" data-ly=\"40\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.001\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/plant.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.002\" data-v-depth=\"0.02\"></div>\r\n                    </div>\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Becoming\" data-src=\"/img/slides/slide2.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/becoming.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Becoming</h3>\r\n                                    <p>\r\n                                        In 2007th, like the rest, a girl went to school. In the neighbor\'s entrance was opened art studio «Pink cat», where Mary immediately signed up and going there for already more than 13 years. Head of studio Zhanna Smirnova helped a girl to open herself in the creation and taught different technics of painting. By Helen\'s words, she perfectly remembers a moment, when the paintings of Mary became to a new level of quality. «It was in September of 2013th. The daughter wrote a picture «Rain», which surprised not just me, but a teacher. A few professional artists high appreciated her craftsmanship».\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/birdy.png\" data-lx=\"43\" data-ly=\"40\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.002\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/plants_birdy.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.005\" data-v-depth=\"0.01\"></div>\r\n                    </div>\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Success\" data-src=\"/img/slides/slide1.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/success.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Success</h3>\r\n                                    <p>\r\n                                        The first personal exhibition «A child\'s sight» was opened in the November of 2016th, and the year of finishing school, in the museum of the native city, where Mary represented to her auditory 40 of her works.\r\n                                        The second one took a place in 2017th at the Krasnodar state museum named after Kovalenko, at the same time girl became a member of the 5th All-Russian culture and education event «Night of arts».\r\n                                        In 2018th she takes a part in the International forum «Different worlds», where she take Grant-Prix. At the moment few professional artists have already recomended Mary to find some students.\r\n                                        It\'s extremely important, that unique author\'s technics do not disappear, and found it\'s continuators.\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/bird2.png\" data-lx=\"43\" data-ly=\"2\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.002\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/bird1.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.005\" data-v-depth=\"0.01\"></div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"swiper-pagination\"></div>\r\n            </div>\r\n        </section>\r\n        <section id=\"gallery\">\r\n            <div class=\"center-align\">\r\n                <h2>Image gallery</h2>\r\n            </div>\r\n            <div class=\"gallery-wrapper\">\r\n                [[!galleryRand? &tpl=`mainPage_galleryTpl` &count=`10` &parent=`2`]]\r\n            </div>\r\n            <div class=\"center-align\">\r\n                <a href=\"[[~2]]\" class=\"btn\">Discover more</a>\r\n            </div>\r\n        </section>\r\n        <section id=\"check-yourself\">\r\n            <div class=\"container\">\r\n                <div class=\"row\">\r\n                    <div class=\"col l6 offset-l3 center-align\">\r\n                        [[$quiz_[[!lingua.cultureKey]]]]\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>', '', 'web', 1, 'main.html', 0, NULL),
(2, 2, 1, 'Gallery', 'My paintings', '', 'gallery', '', 0, 1, '', 'A content of another webpage\r\n\r\n<a href=\"/\">Main</a>', '', 'web', 1, 'gallery/', 0, NULL),
(3, 1, 10, 'D\'accueil', 'Bonjour!', '', 'main', '', 0, 0, '', '        <section id=\"hero\" class=\"visible\">\r\n            <div class=\"hero-logo logo\" data-speed=\"0\" data-blur=\"0\">\r\n                <img src=\"/img/logo-[[!lingua.cultureKey]].svg\" alt=\"\">\r\n                <h1>#Marie soleil</h1>\r\n                <span>Le monde de l\'artiste spécial</span>\r\n            </div>\r\n            <div class=\"layer-parallax\">\r\n                <div class=\"layer lazy\" data-speed=\"5\" data-blur=\"1.5\" data-src=\"/img/layers/flowers.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"3\" data-blur=\"0.3\" data-src=\"/img/layers/grass.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"1.6\" data-blur=\"0.1\" data-src=\"/img/layers/mountains.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"1\" data-blur=\"0\" data-src=\"/img/layers/sky.png\"></div>\r\n            </div>\r\n        </section>\r\n        <section id=\"about\">\r\n            <div class=\"container\">\r\n                <div class=\"row flex\">\r\n                    <div class=\"col s12 center-align\">\r\n                        <h2>À propos de moi</h2>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"swiper-container\" id=\"swiper-about\">\r\n                <div class=\"swiper-wrapper\">\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Enfance\" data-src=\"/img/slides/slide3.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/childhood.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Enfance</h3>\r\n                                    <p>\r\n                                        Marie Mordvinceva est née à l\'été 2000 dans la ville de Leninsk-Kuznetsky du district de Kemerovo. Helen, la mère d\'une fille, met beaucoup de pouvoir et d\'amour dans sa fille - \r\n                                        dès que Marie commence à s\'asseoir, la mère s\'assoit sur ses genoux et lit ses livres enfantins, et la fille considère des images, mémorise des animaux, des personnages, et couleurs. \r\n                                        Ce fut le début de sa dévotion à l\'art. À l\'été 2004, toute une famille a déménagé dans la station balnéaire de Goryachiy Kluch. Là, Marie a commencé à peindre. \r\n                                        Au début, selon les mots de sa mère, c\'était «kalya-malya», mais à un moment donné, les peintures sont devenues de plus en plus conscientes.\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/plant1.png\" data-lx=\"38\" data-ly=\"40\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.001\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/plant.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.002\" data-v-depth=\"0.02\"></div>\r\n                    </div>\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Devenir\" data-src=\"/img/slides/slide2.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/becoming.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Devenir</h3>\r\n                                    <p>\r\n                                        En 2007, comme les autres, une fille est allée à l\'école. Dans l\'entrée du voisin a été ouvert le studio d\'art «Pink cat», où Marie s\'est immédiatement inscrite et y va depuis déjà plus de 13 ans. \r\n                                        La directrice du studio Zhanna Smirnova a aidé une jeune fille à s\'ouvrir à la création et lui a enseigné différentes techniques de peinture. Selon les mots d\'Helen, elle se souvient parfaitement \r\n                                        d\'un moment où les peintures de Marie ont atteint un nouveau niveau de qualité. «C\'était en septembre 2013. La fille a écrit une image «Rain», qui a surpris non seulement moi, mais un enseignant. \r\n                                        Quelques artistes professionnels ont beaucoup apprécié son savoir-faire».\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/birdy.png\" data-lx=\"43\" data-ly=\"40\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.002\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/plants_birdy.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.005\" data-v-depth=\"0.01\"></div>\r\n                    </div>\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Succès\" data-src=\"/img/slides/slide1.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/success.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Succès</h3>\r\n                                    <p>\r\n                                        La première exposition personnelle «La vue d\'un enfant» a été inaugurée en novembre 2016, et l\'année de fin d\'études, dans le musée de la ville natale, où Marie a représenté à son auditoire 40 de ses œuvres. \r\n                                        Le deuxième a eu lieu en 2017 au musée d\'État de Krasnodar nommé d\'après Kovalenko, en même temps, la fille est devenue membre du 5e événement culturel et éducatif panrusse «Nuit des arts». \r\n                                        En 2018, elle participe au forum international «Différents mondes», où elle remporte le Grant-Prix. À l\'heure actuelle, peu d\'artistes professionnels ont déjà recommandé Marie pour trouver des étudiants. \r\n                                        C\'est extrêmement important, que les techniques d\'auteur unique ne disparaissent pas, et trouvent ses continuateurs.\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/bird2.png\" data-lx=\"43\" data-ly=\"2\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.002\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/bird1.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.005\" data-v-depth=\"0.01\"></div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"swiper-pagination\"></div>\r\n            </div>\r\n        </section>\r\n        <section id=\"gallery\">\r\n            <div class=\"center-align\">\r\n                <h2>Galerie d\'images</h2>\r\n            </div>\r\n            <div class=\"gallery-wrapper\">\r\n                [[!galleryRand? &tpl=`mainPage_galleryTpl` &count=`10` &parent=`2`]]\r\n            </div>\r\n            <div class=\"center-align\">\r\n                <a href=\"[[~2]]\" class=\"btn\">Découvrir plus</a>\r\n            </div>\r\n        </section>\r\n        <section id=\"check-yourself\">\r\n            <div class=\"container\">\r\n                <div class=\"row\">\r\n                    <div class=\"col l6 offset-l3 center-align\">\r\n                        [[$quiz_fr]]\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>', '', 'web', 1, 'main.html', 0, NULL),
(4, 2, 10, 'Galerie', 'Mes peintures', '', 'gallery', '', 0, 1, '', 'Mon histoire\r\n\r\n<a href=\"/\">Page d\'accueil</a>', '', 'web', 1, 'gallery/', 0, NULL),
(5, 3, 10, 'Par les créateurs', 'Quelques mots de créateurs', '', 'by-creators', '', 0, 0, '', '<section>\r\n    <div class=\"container\">\r\n        <div class=\"row\">\r\n            <div class=\"col s12\">\r\n                <h1>Créateurs au nom</h1>\r\n            </div>\r\n        </div>\r\n        <div class=\"row\">\r\n            <div class=\"col xl3 l4 m5 s12\">\r\n                <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"lazy responsive-img\" data-src=\"/img/behalf_creators1.jpg\" width=\"726\" height=\"700\">\r\n            </div>\r\n            <div class=\"col xl9 l8 m7 s12\">\r\n                <h2>Les chromosomes superflus ne les rendent pas étrangers</h2>\r\n                <p>\r\n                    Ce site Web est dédié à un être humain \"ensoleillé\" inhabituel - une artiste talentueuse trisomique, Mary Mordvintseva. Seul un petit nombre d\'entre nous croit aux opportunités \r\n                    et aux avantages de ces personnes pour la société, mais nous nous trompons fortement. Oui, les \"enfants ensoleillés\" ont besoin de plus d\'attention et d\'aide pour le développement \r\n                    et le statut de la personnalité, mais si vous aidez un petit si spécial dans la recherche de ses talents, vous ne pouvez qu\'envoyer son studieux et son rendement dans son entreprise bien-aimée.\r\n                </p>\r\n            </div>\r\n        </div>\r\n        <div class=\"row flex\">\r\n            <div class=\"col s12 center-algn\">\r\n                <h2 class=\"center-align\">Mythes, qui nous entrent dans l\'illusion</h2>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth1.jpg\">\r\n                        <h3 class=\"card-title\">Mythe n°1 : Le syndrome de Down est une maladie</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Réalité : Le syndrome de Down est un simple problème génétique. Si le génome d\'un humain ordinaire avait 46 chromosomes, le génome d\'un enfant \"ensoleillé\" à 47 chromosomes. \r\n                            Mais ce chromosome superflu ne le rend pas étranger au reste du monde. Le syndrome de Down ne peut pas être guéri et plus encore tout à être infecté. Son émergence ne dépend \r\n                            ni de la couleur de la peau, ni de l\'âge, ni du mode de vie.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth2.jpg\">\r\n                        <h3 class=\"card-title\">Mythe n°2 : Ils sont dangereux pour la société</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Réalité : Ce mythe répandu n\'a aucun fondement. L\'histoire ne connaît pas les crimes commis par des personnes trisomiques. Ils sont comme tous les humains ordinaires, joyeux, tristes, \r\n                            capricieux, mais leur humeur n\'est pas remplacée par l\'attaque de l\'agressivité. A l\'inverse, un comportement calme et bienveillant est beaucoup plus caractéristique des \"enfants ensoleillés\".\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth3.jpg\">\r\n                        <h3 class=\"card-title\">Mythe n°3 : Ils ne peuvent pas apprendre</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Réalité : Les « enfants ensoleillés » sont très bons pour apprendre les bases de l\'écriture, de la lecture et des sciences exactes. Ils peuvent maîtriser l\'ordinateur, \r\n                            les langues étrangères et bien plus encore. Déjà aujourd\'hui, ils jouent au théâtre, dansent et peignent. Les personnes trisomiques passent par les mêmes étapes \r\n                            de développement que le reste des personnes, à la différence près qu\'elles ont besoin de plus de temps, d\'attention de la part des enseignants et des parents.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12 offset-xl2 offset-l2\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth4.jpg\">\r\n                        <h3 class=\"card-title\">Mythe n°4 : On ne peut pas leur confier le travail</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Réalité : En occident, les humains trisomiques peuvent vous rencontrer à la réception de l\'hôtel, vous aider au supermarché, vous servir à la poste, \r\n                            ou préparer des biscuits maison parce qu\'ils en ont l\'opportunité. La Russie dans ce sens ne fait que les premiers pas, c\'est pourquoi il est très \r\n                            important de soutenir tous les changements positifs de cette manière.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12 offset-m3\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth5.jpg\">\r\n                        <h3 class=\"card-title\">Mythe n°5 : Le syndrome de Down est une rareté.</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Réalité : C\'est la déviation la plus courante, qui est observée chez chaque 700e enfant. Chaque année, en Russie, naît environ 2000 de tels \r\n                            \"enfants ensoleillés\". C\'est imperceptible car 85 % des tout-petits restent dans les maisons de bébé et ensuite errent d\'un établissement public à l\'autre.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</section>', '', 'web', 1, 'by-creators.html', 0, NULL),
(6, 3, 1, 'Behalf creators', 'A few words behalf of creators of this website', '', 'by-creators', '', 0, 0, '', '<section>\r\n    <div class=\"container\">\r\n        <div class=\"row\">\r\n            <div class=\"col s12\">\r\n                <h1>Behalf creators</h1>\r\n            </div>\r\n        </div>\r\n        <div class=\"row\">\r\n            <div class=\"col xl3 l4 m5 s12\">\r\n                <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"lazy responsive-img\" data-src=\"/img/behalf_creators1.jpg\" width=\"726\" height=\"700\">\r\n            </div>\r\n            <div class=\"col xl9 l8 m7 s12\">\r\n                <h2>Superfluous chromosome doesn\'t make \'em foreign</h2>\r\n                <p>\r\n                    This website is dedicated to an unusual \"sunny\" human - a talented artist with Down syndrome, Mary Mordvinceva. Only a few of us believe \r\n                    in the opportunities and good of those people for society, but we\'re strongly mistaken. Yes, \"sunny children\" need more attention \r\n                    and help at development and standing of personality, but if you help such a special little one in a search of its talents, \r\n                    you may only envy its studiousness and output on its beloved business.\r\n                </p>\r\n            </div>\r\n        </div>\r\n        <div class=\"row flex\">\r\n            <div class=\"col s12 center-algn\">\r\n                <h2 class=\"center-align\">Myths, which enter us to delusion</h2>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth1.jpg\">\r\n                        <h3 class=\"card-title\">Myth #1: Down syndrome is a disease</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Reality: Down syndrome is a simple genetic glitch. If the genome of a normal human has 46 chromosomes, a \"sunny\" child\'s genome has 47 chromosomes. \r\n                            But this superfluous chromosome doesn\'t make him foreign to the rest of the world. Down syndrome can\'t be healed and more than all to be infected. \r\n                            Its emergence depends on neither skin color, age, or lifestyle.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth2.jpg\">\r\n                        <h3 class=\"card-title\">Myth #2: They\'re dangerous for society</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Reality: This spread myth has no basis. History doesn\'t know crimes made by people with Down syndrome. They\'re like all common humans rejoice, \r\n                            sad, capricing, but their mood is not replaced by the attack of aggression. In opposite, calm and kindly behavior is much more characteristically \r\n                            for \"sunny children\".\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth3.jpg\">\r\n                        <h3 class=\"card-title\">Myth #3: They can\'t learn</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Reality: \"Sunny children\" are very good at learning the basics of writing, reading, and accurate sciences. They may master the computer, \r\n                            foreign languages, and much more. Already today they\'re playing in theater, dancing, and painting. People with Down syndrome go through \r\n                            the same steps of development as the rest of people with the just difference that they need more time, attention from the teachers and parents.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12 offset-xl2 offset-l2\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth4.jpg\">\r\n                        <h3 class=\"card-title\">Myth #4: They can\'t be entrusted to work</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Reality: In the west, humans with Down syndrome can meet you at the reception in the hotel, help you at the supermarket, serve you at the post office, or bread home cookies \r\n                            because they have such an opportunity. Russia in this sense just makes the first steps, that\'s why it\'s very important to support all positive changes in this way.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12 offset-m3\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth5.jpg\">\r\n                        <h3 class=\"card-title\">Myth #5: Down syndrome is a rarity</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Reality: It\'s the most common deviation, which is observed in every 700th child. Annually In Russia borning around 2000 such \"sunny children\". \r\n                            It is imperceptible because 85% of little ones stay at the baby houses and after that roam from one state institution to another.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</section>', '', 'web', 1, 'by-creators.html', 0, NULL),
(9, 4, 10, 'montagnes', '', '', 'montagnes', '', 2, 0, '', '', '', 'web', 1, 'gallery/montagnes.html', 0, NULL),
(10, 4, 1, 'Mountains', '', '', 'mountains', '', 2, 0, '', '', '', 'web', 1, 'gallery/mountains.html', 0, NULL),
(11, 5, 10, 'Montagnes', '', '', 'montagnes', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/montagnes.html', 0, NULL),
(12, 5, 1, 'Mountains', '', '', 'mountains', '', 2, 0, '', 'img/hero_bgr.jpg', '', 'web', 1, 'gallery/mountains.html', 0, NULL),
(13, 6, 10, 'Fleurs abstraites', '', '', 'flowering-garden', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/flowering-garden.html', 0, NULL),
(14, 6, 1, 'Flowering garden', 'Jardin fleuri', '', 'flowering-garden', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/flowering-garden.html', 0, NULL),
(15, 7, 10, 'Afrique sensuelle', '', '', 'abstraction', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/abstraction.html', 0, NULL),
(16, 7, 1, 'Sultry Africa', '', '', 'abstraction', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/abstraction.html', 0, NULL),
(17, 8, 10, 'Peintures Turuli', '', '', 'peintures-turuli', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/peintures-turuli.html', 0, NULL),
(18, 8, 1, 'Turuli pages', '', '', 'turuli-pages', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/turuli-pages.html', 0, NULL),
(19, 9, 10, 'Jeune coq', '', '', 'jeune-coq', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/jeune-coq.html', 0, NULL),
(20, 9, 1, 'Cockerel', '', '', 'cockerel', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/cockerel.html', 0, NULL),
(21, 10, 10, 'Camomille', '', '', 'camomille', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/camomille.html', 0, NULL),
(22, 10, 1, 'Chamomiles', '', '', 'chamomiles', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/chamomiles.html', 0, NULL),
(23, 11, 10, 'Soleil d\'automne', '', '', 'soleil-dautomne', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/soleil-dautomne.html', 0, NULL),
(24, 11, 1, 'Autumn sun', '', '', 'autumn-sun', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/autumn-sun.html', 0, NULL),
(25, 12, 10, 'Afrique sensuelle', '', '', 'afrique-sensuelle', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/afrique-sensuelle.html', 0, NULL),
(26, 12, 1, 'Sultry africa', '', '', 'sultry-africa', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/sultry-africa.html', 0, NULL),
(27, 13, 10, 'Forêt d\'automne', '', '', 'forêt-dautomne', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/forêt-dautomne.html', 0, NULL),
(28, 13, 1, 'Autumn forest', '', '', 'autumn-forest', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/autumn-forest.html', 0, NULL),
(29, 14, 10, 'Les peintures de Turuli', '', '', 'les-peintures-de-turuli', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/les-peintures-de-turuli.html', 0, NULL),
(30, 14, 1, 'Turuli\'s paints', '', '', 'turulis-paints', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/turulis-paints.html', 0, NULL),
(31, 15, 10, 'Nature morte au vase bleu', '', '', 'nature-morte-au-vase-bleu', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/nature-morte-au-vase-bleu.html', 0, NULL),
(32, 15, 1, 'Still life with blue vase', '', '', 'still-life-with-blue-vase', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/still-life-with-blue-vase.html', 0, NULL),
(33, 16, 10, 'Trois peupliers au clair de lune', '', '', 'trois-peupliers-au-clair-de-lune', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/trois-peupliers-au-clair-de-lune.html', 0, NULL),
(34, 16, 1, 'Three poplars at the moonlight', '', '', 'three-poplars-at-the-moonlight', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/three-poplars-at-the-moonlight.html', 0, NULL),
(35, 17, 10, 'Asters', '', '', 'asters', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/asters.html', 0, NULL),
(36, 17, 1, 'Asters', '', '', 'asters', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/asters.html', 0, NULL),
(37, 18, 10, 'Coucher de soleil', '', '', 'coucher-de-soleil', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/coucher-de-soleil.html', 0, NULL),
(38, 18, 1, 'Sunset', '', '', 'sunset', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/sunset.html', 0, NULL),
(39, 19, 10, 'Bouquet rose', '', '', 'bouquet-rose', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/bouquet-rose.html', 0, NULL),
(40, 19, 1, 'Pink bouquet', '', '', 'pink-bouquet', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/pink-bouquet.html', 0, NULL),
(41, 20, 10, 'Escalier', '', '', 'escalier', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/escalier.html', 0, NULL),
(42, 20, 1, 'Stairway', '', '', 'stairway', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/stairway.html', 0, NULL),
(43, 21, 10, 'Le lac', '', '', 'le-lac', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/le-lac.html', 0, NULL),
(44, 21, 1, 'The lake', '', '', 'the-lake', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/the-lake.html', 0, NULL),
(45, 22, 10, 'Sur la mer Noire', '', '', 'sur-la-mer-noire', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/sur-la-mer-noire.html', 0, NULL),
(46, 22, 1, 'On Black Sea', '', '', 'on-black-sea', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/on-black-sea.html', 0, NULL),
(47, 23, 10, 'Petit cheval', '', '', 'petit-cheval', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/petit-cheval.html', 0, NULL),
(48, 23, 1, 'Little horsy', '', '', 'little-horsy', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/little-horsy.html', 0, NULL),
(49, 24, 10, 'Lotus', '', '', 'lotus', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/lotus.html', 0, NULL),
(50, 24, 1, 'Lotuses', '', '', 'lotuses', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/lotuses.html', 0, NULL),
(51, 25, 10, 'Fleurs rouges', '', '', 'fleurs-rouges', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/fleurs-rouges.html', 0, NULL),
(52, 25, 1, 'Red flowers', '', '', 'red-flowers', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/red-flowers.html', 0, NULL),
(53, 26, 10, 'Chat avec des chatons', '', '', 'chat-avec-des-chatons', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/chat-avec-des-chatons.html', 0, NULL),
(54, 26, 1, 'Cat with kittens', '', '', 'cat-with-kittens', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/cat-with-kittens.html', 0, NULL),
(55, 27, 10, 'Montagne «Chat»', '', '', 'montagne-«chat»', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/montagne-«chat».html', 0, NULL),
(56, 27, 1, 'Mountain «Cat»', '', '', 'mountain-«cat»', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/mountain-«cat».html', 0, NULL),
(57, 28, 10, 'Cosmos', '', '', 'cosmos', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/cosmos.html', 0, NULL),
(58, 28, 1, 'Cosmos', '', '', 'cosmos', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/cosmos.html', 0, NULL),
(59, 29, 10, 'Les doutes', '', '', 'les-doutes', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/les-doutes.html', 0, NULL),
(60, 29, 1, 'Doubts', '', '', 'doubts', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/doubts.html', 0, NULL),
(61, 30, 10, 'Cascade', '', '', 'cascade', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/cascade.html', 0, NULL),
(62, 30, 1, 'Waterfall', '', '', 'waterfall', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/waterfall.html', 0, NULL),
(63, 31, 10, 'Maison dans le jardin', '', '', 'maison-dans-le-jardin', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/maison-dans-le-jardin.html', 0, NULL),
(64, 31, 1, 'House in the garden', '', '', 'house-in-the-garden', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/house-in-the-garden.html', 0, NULL),
(65, 32, 10, 'Nature morte décorative', '', '', 'nature-morte-décorative', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/nature-morte-décorative.html', 0, NULL),
(66, 32, 1, 'Decorative still life', '', '', 'decorative-still-life', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/decorative-still-life.html', 0, NULL),
(67, 33, 10, 'Humeur printanière', '', '', 'humeur-printanière', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/humeur-printanière.html', 0, NULL),
(68, 33, 1, 'Spring mood', '', '', 'spring-mood', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/spring-mood.html', 0, NULL),
(69, 34, 10, 'Bouleaux', '', '', 'bouleaux', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/bouleaux.html', 0, NULL),
(70, 34, 1, 'Birch trees', '', '', 'birch-trees', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/birch-trees.html', 0, NULL),
(71, 35, 10, 'Jardin fleuri', '', '', 'jardin-fleuri', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/jardin-fleuri.html', 0, NULL),
(72, 35, 1, 'Blooming garden', '', '', 'blooming-garden', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/blooming-garden.html', 0, NULL),
(73, 36, 10, 'Mer au coucher du soleil', '', '', 'mer-au-coucher-du-soleil', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/mer-au-coucher-du-soleil.html', 0, NULL),
(74, 36, 1, 'Sea at sunset', '', '', 'sea-at-sunset', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/sea-at-sunset.html', 0, NULL),
(75, 37, 10, 'Pêcheurs', '', '', 'pêcheurs', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/pêcheurs.html', 0, NULL),
(76, 37, 1, 'Fishermen', '', '', 'fishers', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/fishers.html', 0, NULL),
(77, 38, 10, 'Quel est le clair de lune qui se cache?', '', '', 'quel-est-le-clair-de-lune-qui-se-cache', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/quel-est-le-clair-de-lune-qui-se-cache.html', 0, NULL),
(78, 38, 1, 'What moonlight is hiding out?', '', '', 'what-moonlight-is-hiding-out', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/what-moonlight-is-hiding-out.html', 0, NULL),
(79, 39, 10, 'La tempête', '', '', 'la-tempête', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/la-tempête.html', 0, NULL),
(80, 39, 1, 'The storm', '', '', 'the-storm', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/the-storm.html', 0, NULL),
(81, 40, 10, 'Chang-An, Vietnam', '', '', 'chang-an,-vietnam', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/chang-an,-vietnam.html', 0, NULL),
(82, 40, 1, 'Chang-An, Vietnam', '', '', 'chang-an,-vietnam', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/chang-an,-vietnam.html', 0, NULL),
(83, 41, 10, 'Vagabond', '', '', 'vagabond', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/vagabond.html', 0, NULL),
(84, 41, 1, 'Wanderer', '', '', 'wanderer', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/wanderer.html', 0, NULL),
(85, 42, 10, 'Adieu', '', '', 'adieu', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/adieu.html', 0, NULL),
(86, 42, 1, 'Farewell', '', '', 'farewell', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/farewell.html', 0, NULL),
(87, 43, 10, 'Oiseau sur la branche', '', '', 'oiseau-sur-la-branche', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/oiseau-sur-la-branche.html', 0, NULL),
(88, 43, 1, 'Bird on the branch', '', '', 'bird-on-the-branch', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/bird-on-the-branch.html', 0, NULL),
(89, 44, 10, 'Îles', '', '', 'îles', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/îles.html', 0, NULL),
(90, 44, 1, 'Islands', '', '', 'islands', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/islands.html', 0, NULL),
(91, 45, 10, 'Coucher de soleil flamboyant', '', '', 'coucher-de-soleil-flamboyant', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/coucher-de-soleil-flamboyant.html', 0, NULL),
(92, 45, 1, 'Flaming sunset', '', '', 'flaming-sunset', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/flaming-sunset.html', 0, NULL),
(93, 46, 10, 'Lever de soleil dans les montagnes', '', '', 'lever-de-soleil-dans-les-montagnes', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/lever-de-soleil-dans-les-montagnes.html', 0, NULL),
(94, 46, 1, 'Sunrise in mountains', '', '', 'sunrise-in-mountains', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/sunrise-in-mountains.html', 0, NULL),
(95, 47, 10, 'La lumière du soir', '', '', 'la-lumière-du-soir', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/la-lumière-du-soir.html', 0, NULL),
(96, 47, 1, 'Evening light', '', '', 'evening-light', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/evening-light.html', 0, NULL),
(97, 48, 10, 'Fleurs', '', '', 'fleurs', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/fleurs.html', 0, NULL),
(98, 48, 1, 'Flowers', '', '', 'flowers', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/flowers.html', 0, NULL),
(99, 49, 10, 'La forêt', '', '', 'la-forêt', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/la-forêt.html', 0, NULL),
(100, 49, 1, 'Forest', '', '', 'forest', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/forest.html', 0, NULL),
(101, 50, 10, 'La branche de Sakura', '', '', 'la-branche-de-sakura', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/la-branche-de-sakura.html', 0, NULL),
(102, 50, 1, 'Sakura\'s branch', '', '', 'sakuras-branch', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/sakuras-branch.html', 0, NULL),
(103, 51, 10, 'L\' ange', '', '', 'l-ange', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/l-ange.html', 0, NULL),
(104, 51, 1, 'Angel', '', '', 'angel', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/angel.html', 0, NULL),
(105, 52, 10, 'Coquelicots', '', '', 'coquelicots', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/coquelicots.html', 0, NULL),
(106, 52, 1, 'Poppies', '', '', 'poppies', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/poppies.html', 0, NULL),
(107, 53, 10, 'Prairie alpine', '', '', 'alpages', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/alpages.html', 0, NULL),
(108, 53, 1, 'Alpen meadow', '', '', 'alpen-meadows', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/alpen-meadows.html', 0, NULL),
(109, 54, 10, 'Deux lotus', '', '', 'deux-lotus', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/deux-lotus.html', 0, NULL),
(110, 54, 1, 'Two lotuses', '', '', 'two-lotuses', '', 2, 0, '', NULL, '', 'web', 1, 'gallery/two-lotuses.html', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_lingua_site_tmplvars`
--

CREATE TABLE `modx_lingua_site_tmplvars` (
  `id` int(10) UNSIGNED NOT NULL,
  `tmplvarid` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_lingua_site_tmplvars_patterns`
--

CREATE TABLE `modx_lingua_site_tmplvars_patterns` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `search` varchar(255) DEFAULT NULL,
  `replacement` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_lingua_site_tmplvars_patterns`
--

INSERT INTO `modx_lingua_site_tmplvars_patterns` (`id`, `type`, `search`, `replacement`) VALUES
(1, 'tag', '/(\"|\'){1}tv-tags-{{tvId}}(\"|\'){1}/', '${1}tv-tags-{{tvCloneId}}${2}'),
(2, 'tag', '/fld{{tvId}}/', 'fld{{tvCloneId}}'),
(3, 'tag', '/tv-{{tvId}}-tag-list/', 'tv-{{tvCloneId}}-tag-list'),
(4, 'tag', '/o.id != \'{{tvId}}\'/', 'o.id != \'{{tvCloneId}}\''),
(5, 'tag', '/(\"|\'){1}tvdef{{tvId}}(\"|\'){1}/', '${1}tvdef{{tvCloneId}}${2}'),
(6, 'autotag', '/(\"|\'){1}tv-tags-{{tvId}}(\"|\'){1}/', '${1}tv-tags-{{tvCloneId}}${2}'),
(7, 'autotag', '/fld{{tvId}}/', 'fld{{tvCloneId}}'),
(8, 'autotag', '/tv-{{tvId}}-tag-list/', 'tv-{{tvCloneId}}-tag-list'),
(9, 'autotag', '/o.id != \'{{tvId}}\'/', 'o.id != \'{{tvCloneId}}\''),
(10, 'autotag', '/(\"|\'){1}tvdef{{tvId}}(\"|\'){1}/', '${1}tvdef{{tvCloneId}}${2}'),
(11, 'autotag', '/(\"|\'){1}tvdef{{tvId}}(\"|\'){1}/', '${1}tvdef{{tvCloneId}}${2}'),
(12, 'option', '/(\"|\'){1}tv{{tvId}}-/', '${1}tv{{tvCloneId}}-'),
(13, 'checkbox', '/(\"|\'){1}tv{{tvId}}-/', '${1}tv{{tvCloneId}}-'),
(14, 'checkbox', '/(\"|\'){1}tv-{{tvId}}(\"|\'){1}/', '${1}tv-{{tvCloneId}}${2}'),
(15, 'checkbox', '/(\"|\'){1}tvdef{{tvId}}(\"|\'){1}/', '${1}tvdef{{tvCloneId}}${2}'),
(16, 'file', '/(\"|\'){1}tvbrowser{{tvId}}(\"|\'){1}/', '${1}tvbrowser{{tvCloneId}}${2}'),
(17, 'file', '/(\"|\'){1}tvpanel{{tvId}}(\"|\'){1}/', '${1}tvpanel{{tvCloneId}}${2}'),
(18, 'file', '/fld{{tvId}}/', 'fld{{tvCloneId}}'),
(19, 'file', '/tv: (\"|\'){1}{{tvId}}(\"|\'){1}/', 'tv: ${1}{{tvCloneId}}${2}'),
(20, 'image', '/(\"|\'){1}tvbrowser{{tvId}}(\"|\'){1}/', '${1}tvbrowser{{tvCloneId}}${2}'),
(21, 'image', '/(\"|\'){1}tv-image-{{tvId}}(\"|\'){1}/', '${1}tv-image-{{tvCloneId}}${2}'),
(22, 'image', '/(\"|\'){1}tv-image-preview-{{tvId}}(\"|\'){1}/', '${1}tv-image-preview-{{tvCloneId}}${2}'),
(23, 'image', '/fld{{tvId}}/', 'fld{{tvCloneId}}'),
(24, 'image', '/tv: (\"|\'){1}{{tvId}}(\"|\'){1}/', 'tv: ${1}{{tvCloneId}}${2}'),
(25, 'url', '/(\"|\'){1}tv{{tvId}}_prefix(\"|\'){1}/', '${1}tv{{tvCloneId}}_prefix${2}'),
(26, 'migx', '/(\"|\'){1}tvpanel{{tvId}}(\"|\'){1}/', '${1}tvpanel{{tvCloneId}}${2}'),
(27, 'migx', '/(\"|\'){1}tvpanel2{{tvId}}(\"|\'){1}/', '${1}tvpanel2{{tvCloneId}}${2}'),
(28, 'migx', '/(\"|\'){1}modx-window-mi-grid-update-{{tvId}}(\"|\'){1}/', '${1}modx-window-mi-grid-update-{{tvCloneId}}${2}'),
(29, 'migx', '/MODx.panel.MiGridUpdate{{tvId}}/', 'MODx.panel.MiGridUpdate{{tvCloneId}}'),
(30, 'migx', '/(\"|\'){1}modx-window-tv-item-update-{{tvId}}(\"|\'){1}/', '${1}modx-window-tv-item-update-{{tvCloneId}}${2}'),
(31, 'migx', '/(\"|\'){1}xdbedit-panel-object-{{tvId}}(\"|\'){1}/', '${1}xdbedit-panel-object-{{tvCloneId}}${2}'),
(32, 'migx', '/(\"|\'){1}modx-grid-multitvgrid-{{tvId}}(\"|\'){1}/', '${1}modx-grid-multitvgrid-{{tvCloneId}}${2}'),
(33, 'migx', '/tv_id=(\\s)*(\"|\'){1}{{tvId}}(\"|\'){1}/', 'tv_id=${1}${2}{{tvCloneId}}${3}'),
(34, 'migx', '/(\"|\'){1}tv{{tvId}}_items(\"|\'){1}/', '${1}tv{{tvCloneId}}_items${2}'),
(35, 'migx', '/(\"|\'){1}{{tvId}}_gridDD(\"|\'){1}/', '${1}{{tvCloneId}}_gridDD${2}'),
(36, 'migx', '/(\"|\'){1}modx-window-mi-iframe-{{tvId}}(\"|\'){1}/', '${1}modx-window-mi-iframe-{{tvCloneId}}${2}'),
(37, 'migx', '/(\"|\'){1}migx_iframewin_object_id_{{tvId}}(\"|\'){1}/', '${1}migx_iframewin_object_id_{{tvCloneId}}${2}'),
(38, 'migx', '/(\"|\'){1}migx_iframewin_iframeTpl_{{tvId}}(\"|\'){1}/', '${1}migx_iframewin_iframeTpl_{{tvCloneId}}${2}'),
(39, 'migx', '/(\"|\'){1}modx-window-migx-iframe-{{tvId}}(\"|\'){1}/', '${1}modx-window-migx-iframe-{{tvCloneId}}${2}'),
(40, 'migx', '/(\"|\'){1}migx_iframewin_form_{{tvId}}(\"|\'){1}/', '${1}migx_iframewin_form_{{tvCloneId}}${2}'),
(41, 'migx', '/(\"|\'){1}iframewin_iframe_{{tvId}}(\"|\'){1}/', '${1}iframewin_iframe_{{tvCloneId}}${2}'),
(42, 'migx', '/(\"|\'){1}migx_iframewin_json_{{tvId}}(\"|\'){1}/', '${1}migx_iframewin_json_{{tvCloneId}}${2}'),
(43, 'migx', '/(\"|\'){1}migx_iframewin_co_id_{{tvId}}(\"|\'){1}/', '${1}migx_iframewin_co_id_{{tvCloneId}}${2}'),
(44, 'migx', '/(\"|\'){1}migx_iframewin_store_params_{{tvId}}(\"|\'){1}/', '${1}migx_iframewin_store_params_{{tvCloneId}}${2}'),
(45, 'migx', '/tv_id:(\\s)*(\"|\'){1}{{tvId}}(\"|\'){1}/', 'tv_id:${1}${2}{{tvCloneId}}${3}');

-- --------------------------------------------------------

--
-- Table structure for table `modx_lingua_site_tmplvar_contentvalues`
--

CREATE TABLE `modx_lingua_site_tmplvar_contentvalues` (
  `id` int(10) UNSIGNED NOT NULL,
  `lang_id` int(10) NOT NULL DEFAULT '0',
  `tmplvarid` int(10) NOT NULL DEFAULT '0',
  `contentid` int(10) NOT NULL DEFAULT '0',
  `value` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_manager_log`
--

CREATE TABLE `modx_manager_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `occurred` datetime DEFAULT NULL,
  `action` varchar(100) NOT NULL DEFAULT '',
  `classKey` varchar(100) NOT NULL DEFAULT '',
  `item` varchar(191) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_manager_log`
--

INSERT INTO `modx_manager_log` (`id`, `user`, `occurred`, `action`, `classKey`, `item`) VALUES
(1, 1, '2021-08-06 13:15:34', 'login', 'modContext', 'mgr'),
(2, 1, '2021-08-06 13:19:12', 'lingua.LangsCreate_create', 'linguaLangs', '9'),
(3, 1, '2021-08-06 13:19:22', 'lingua.LangsUpdate_update', 'linguaLangs', '9'),
(4, 1, '2021-08-06 13:19:24', 'lingua.LangsUpdate_update', 'linguaLangs', '8'),
(5, 1, '2021-08-06 13:19:28', 'lingua.LangsUpdate_update', 'linguaLangs', '7'),
(6, 1, '2021-08-06 13:19:28', 'lingua.LangsUpdate_update', 'linguaLangs', '6'),
(7, 1, '2021-08-06 13:19:29', 'lingua.LangsUpdate_update', 'linguaLangs', '5'),
(8, 1, '2021-08-06 13:19:30', 'lingua.LangsUpdate_update', 'linguaLangs', '4'),
(9, 1, '2021-08-06 13:19:31', 'lingua.LangsUpdate_update', 'linguaLangs', '4'),
(10, 1, '2021-08-06 13:19:33', 'lingua.LangsUpdate_update', 'linguaLangs', '6'),
(11, 1, '2021-08-06 13:19:34', 'lingua.LangsUpdate_update', 'linguaLangs', '5'),
(12, 1, '2021-08-06 13:19:35', 'lingua.LangsUpdate_update', 'linguaLangs', '7'),
(13, 1, '2021-08-06 13:19:36', 'lingua.LangsUpdate_update', 'linguaLangs', '8'),
(14, 1, '2021-08-06 13:19:43', 'lingua.LinguaRemove_delete', 'linguaLangs', '8'),
(15, 1, '2021-08-06 13:19:46', 'lingua.LinguaRemove_delete', 'linguaLangs', '7'),
(16, 1, '2021-08-06 13:19:50', 'lingua.LinguaRemove_delete', 'linguaLangs', '6'),
(17, 1, '2021-08-06 13:19:54', 'lingua.LinguaRemove_delete', 'linguaLangs', '5'),
(18, 1, '2021-08-06 13:19:56', 'lingua.LinguaRemove_delete', 'linguaLangs', '4'),
(19, 1, '2021-08-06 13:20:00', 'lingua.LinguaRemove_delete', 'linguaLangs', '3'),
(20, 1, '2021-08-06 13:20:04', 'lingua.LinguaRemove_delete', 'linguaLangs', '2'),
(21, 1, '2021-08-06 13:20:29', 'lingua.LangsUpdate_update', 'linguaLangs', '9'),
(22, 1, '2021-08-06 13:20:47', 'lingua.LangsUpdate_update', 'linguaLangs', '9'),
(23, 1, '2021-08-06 13:21:41', 'resource_update', 'modResource', '1'),
(24, 1, '2021-08-06 13:21:57', 'resource_update', 'modResource', '1'),
(25, 1, '2021-08-06 13:22:08', 'resource_update', 'modResource', '1'),
(26, 1, '2021-08-06 13:27:29', 'template_update', 'modTemplate', '1'),
(27, 1, '2021-08-06 13:27:30', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(28, 1, '2021-08-06 13:27:48', 'template_update', 'modTemplate', '1'),
(29, 1, '2021-08-06 13:27:48', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(30, 1, '2021-08-06 13:28:29', 'template_update', 'modTemplate', '1'),
(31, 1, '2021-08-06 13:28:29', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(32, 1, '2021-08-06 13:28:38', 'template_update', 'modTemplate', '1'),
(33, 1, '2021-08-06 13:28:38', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(34, 1, '2021-08-06 13:29:18', 'lingua.LangsUpdate_update', 'linguaLangs', '9'),
(35, 1, '2021-08-06 13:29:41', 'clear_cache', '', 'mgr'),
(36, 1, '2021-08-06 13:29:49', 'clear_cache', '', 'mgr'),
(37, 1, '2021-08-06 13:35:04', 'template_update', 'modTemplate', '1'),
(38, 1, '2021-08-06 13:35:05', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(39, 1, '2021-08-06 13:40:51', 'template_update', 'modTemplate', '1'),
(40, 1, '2021-08-06 13:40:51', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(41, 1, '2021-08-06 13:43:14', 'setting_create', 'modContextSetting', 'modRequest.class'),
(42, 1, '2021-08-06 13:45:55', 'resource_create', 'modDocument', '2'),
(43, 1, '2021-08-06 13:46:08', 'publish_resource', 'modDocument', '2'),
(44, 1, '2021-08-06 13:46:54', 'setting_update', 'modSystemSetting', 'use_editor'),
(45, 1, '2021-08-06 13:47:38', 'resource_update', 'modResource', '1'),
(46, 1, '2021-08-06 13:48:02', 'resource_update', 'modResource', '2'),
(47, 1, '2021-08-06 14:33:10', 'template_update', 'modTemplate', '1'),
(48, 1, '2021-08-06 14:33:10', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(49, 1, '2021-08-06 14:33:17', 'template_update', 'modTemplate', '1'),
(50, 1, '2021-08-06 14:33:18', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(51, 1, '2021-08-06 14:33:29', 'chunk_create', 'modChunk', '1'),
(52, 1, '2021-08-06 14:33:55', 'chunk_update', 'modChunk', '1'),
(53, 1, '2021-08-06 14:33:56', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 1 Default'),
(54, 1, '2021-08-06 14:34:29', 'chunk_update', 'modChunk', '1'),
(55, 1, '2021-08-06 14:34:29', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 1 Default'),
(56, 1, '2021-08-06 14:41:47', 'chunk_create', 'modChunk', '2'),
(57, 1, '2021-08-06 14:42:18', 'chunk_create', 'modChunk', '3'),
(58, 1, '2021-08-06 14:42:40', 'template_update', 'modTemplate', '1'),
(59, 1, '2021-08-06 14:42:40', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(60, 1, '2021-08-06 14:46:36', 'chunk_update', 'modChunk', '3'),
(61, 1, '2021-08-06 14:46:37', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(62, 1, '2021-08-06 14:46:59', 'chunk_update', 'modChunk', '3'),
(63, 1, '2021-08-06 14:47:00', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(64, 1, '2021-08-06 14:51:11', 'chunk_update', 'modChunk', '3'),
(65, 1, '2021-08-06 14:51:12', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(66, 1, '2021-08-06 14:51:33', 'chunk_update', 'modChunk', '3'),
(67, 1, '2021-08-06 14:51:33', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(68, 1, '2021-08-06 14:52:19', 'chunk_update', 'modChunk', '3'),
(69, 1, '2021-08-06 14:52:20', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(70, 1, '2021-08-06 14:53:01', 'chunk_update', 'modChunk', '3'),
(71, 1, '2021-08-06 14:53:01', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(72, 1, '2021-08-06 14:53:11', 'chunk_update', 'modChunk', '3'),
(73, 1, '2021-08-06 14:53:11', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(74, 1, '2021-08-06 14:53:25', 'chunk_update', 'modChunk', '3'),
(75, 1, '2021-08-06 14:53:26', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(76, 1, '2021-08-06 14:53:33', 'chunk_update', 'modChunk', '3'),
(77, 1, '2021-08-06 14:53:33', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(78, 1, '2021-08-06 14:53:40', 'chunk_update', 'modChunk', '3'),
(79, 1, '2021-08-06 14:53:41', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(80, 1, '2021-08-06 14:53:46', 'chunk_update', 'modChunk', '3'),
(81, 1, '2021-08-06 14:53:46', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(82, 1, '2021-08-06 14:58:24', 'snippet_create', 'modSnippet', '5'),
(83, 1, '2021-08-06 14:59:01', 'chunk_update', 'modChunk', '3'),
(84, 1, '2021-08-06 14:59:02', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(85, 1, '2021-08-06 15:02:21', 'snippet_update', 'modSnippet', '5'),
(86, 1, '2021-08-06 15:02:21', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(87, 1, '2021-08-06 15:03:43', 'snippet_update', 'modSnippet', '5'),
(88, 1, '2021-08-06 15:03:43', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(89, 1, '2021-08-06 15:03:51', 'snippet_update', 'modSnippet', '5'),
(90, 1, '2021-08-06 15:03:52', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(91, 1, '2021-08-06 15:04:00', 'snippet_update', 'modSnippet', '5'),
(92, 1, '2021-08-06 15:04:00', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(93, 1, '2021-08-06 15:04:20', 'snippet_update', 'modSnippet', '5'),
(94, 1, '2021-08-06 15:04:20', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(95, 1, '2021-08-06 15:04:30', 'snippet_update', 'modSnippet', '5'),
(96, 1, '2021-08-06 15:04:30', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(97, 1, '2021-08-06 15:04:49', 'snippet_update', 'modSnippet', '5'),
(98, 1, '2021-08-06 15:04:49', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(99, 1, '2021-08-06 15:06:51', 'snippet_update', 'modSnippet', '5'),
(100, 1, '2021-08-06 15:06:51', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(101, 1, '2021-08-06 15:07:08', 'snippet_update', 'modSnippet', '5'),
(102, 1, '2021-08-06 15:07:09', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 5 Default'),
(103, 1, '2021-08-06 15:08:27', 'chunk_update', 'modChunk', '2'),
(104, 1, '2021-08-06 15:08:28', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(105, 1, '2021-08-06 15:09:20', 'chunk_create', 'modChunk', '4'),
(106, 1, '2021-08-06 16:00:34', 'lingua.LangsCreate_create', 'linguaLangs', '10'),
(107, 1, '2021-08-06 16:01:42', 'resource_update', 'modResource', '1'),
(108, 1, '2021-08-06 16:02:51', 'resource_update', 'modResource', '1'),
(109, 1, '2021-08-06 16:03:01', 'resource_update', 'modResource', '1'),
(110, 1, '2021-08-06 16:03:35', 'resource_update', 'modResource', '1'),
(111, 1, '2021-08-06 16:05:39', 'chunk_update', 'modChunk', '2'),
(112, 1, '2021-08-06 16:05:39', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(113, 1, '2021-08-06 16:06:54', 'chunk_update', 'modChunk', '2'),
(114, 1, '2021-08-06 16:06:54', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(115, 1, '2021-08-06 16:09:09', 'resource_update', 'modResource', '2'),
(116, 1, '2021-08-06 16:10:04', 'resource_update', 'modResource', '2'),
(117, 1, '2021-08-06 17:22:09', 'chunk_create', 'modChunk', '5'),
(118, 1, '2021-08-06 17:22:33', 'template_update', 'modTemplate', '1'),
(119, 1, '2021-08-06 17:22:33', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(120, 1, '2021-08-06 17:24:29', 'template_update', 'modTemplate', '1'),
(121, 1, '2021-08-06 17:24:29', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(122, 1, '2021-08-06 17:24:56', 'template_update', 'modTemplate', '1'),
(123, 1, '2021-08-06 17:24:56', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(124, 1, '2021-08-06 17:25:19', 'resource_update', 'modResource', '1'),
(125, 1, '2021-08-06 17:27:08', 'resource_update', 'modResource', '1'),
(126, 1, '2021-08-06 17:27:25', 'resource_update', 'modResource', '1'),
(127, 1, '2021-08-06 17:30:31', 'chunk_update', 'modChunk', '2'),
(128, 1, '2021-08-06 17:30:32', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(129, 1, '2021-08-06 17:33:14', 'chunk_update', 'modChunk', '3'),
(130, 1, '2021-08-06 17:33:14', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(131, 1, '2021-08-06 17:33:38', 'chunk_update', 'modChunk', '3'),
(132, 1, '2021-08-06 17:33:38', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(133, 1, '2021-08-06 17:36:41', 'chunk_update', 'modChunk', '3'),
(134, 1, '2021-08-06 17:36:41', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(135, 1, '2021-08-06 17:59:31', 'resource_update', 'modResource', '1'),
(136, 1, '2021-08-06 17:59:56', 'resource_update', 'modResource', '1'),
(137, 1, '2021-08-06 18:05:40', 'resource_update', 'modResource', '1'),
(138, 1, '2021-08-06 18:06:10', 'resource_update', 'modResource', '1'),
(139, 1, '2021-08-06 18:07:12', 'resource_update', 'modResource', '1'),
(140, 1, '2021-08-06 18:07:21', 'resource_update', 'modResource', '1'),
(141, 1, '2021-08-09 08:43:51', 'login', 'modContext', 'mgr'),
(142, 1, '2021-08-09 08:45:42', 'resource_update', 'modResource', '1'),
(143, 1, '2021-08-09 08:46:17', 'resource_update', 'modResource', '1'),
(144, 1, '2021-08-09 08:49:42', 'resource_update', 'modResource', '1'),
(145, 1, '2021-08-09 08:51:59', 'resource_update', 'modResource', '1'),
(146, 1, '2021-08-09 08:53:28', 'chunk_update', 'modChunk', '5'),
(147, 1, '2021-08-09 08:53:28', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 5 Default'),
(148, 1, '2021-08-09 08:53:41', 'chunk_update', 'modChunk', '5'),
(149, 1, '2021-08-09 08:53:41', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 5 Default'),
(150, 1, '2021-08-09 09:10:57', 'setting_update', 'modSystemSetting', 'locale'),
(151, 1, '2021-08-09 09:12:58', 'resource_update', 'modResource', '1'),
(152, 1, '2021-08-09 09:13:47', 'resource_update', 'modResource', '1'),
(153, 1, '2021-08-09 09:23:37', 'chunk_update', 'modChunk', '1'),
(154, 1, '2021-08-09 09:23:37', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 1 Default'),
(155, 1, '2021-08-09 09:46:38', 'chunk_create', 'modChunk', '6'),
(156, 1, '2021-08-09 09:47:37', 'chunk_update', 'modChunk', '6'),
(157, 1, '2021-08-09 09:47:37', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 6 Default'),
(158, 1, '2021-08-09 09:47:48', 'chunk_duplicate', 'modChunk', '7'),
(159, 1, '2021-08-09 09:57:16', 'chunk_update', 'modChunk', '7'),
(160, 1, '2021-08-09 09:57:17', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 7 Default'),
(161, 1, '2021-08-09 09:57:35', 'chunk_duplicate', 'modChunk', '8'),
(162, 1, '2021-08-09 10:02:14', 'chunk_update', 'modChunk', '8'),
(163, 1, '2021-08-09 10:02:14', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 8 Default'),
(164, 1, '2021-08-09 10:06:03', 'login', 'modContext', 'mgr'),
(165, 1, '2021-08-09 10:06:58', 'template_update', 'modTemplate', '1'),
(166, 1, '2021-08-09 10:06:58', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(167, 1, '2021-08-09 10:11:21', 'chunk_update', 'modChunk', '7'),
(168, 1, '2021-08-09 10:11:21', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 7 Default'),
(169, 1, '2021-08-09 10:11:36', 'chunk_update', 'modChunk', '8'),
(170, 1, '2021-08-09 10:11:36', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 8 Default'),
(171, 1, '2021-08-09 10:11:48', 'chunk_update', 'modChunk', '6'),
(172, 1, '2021-08-09 10:11:48', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 6 Default'),
(173, 1, '2021-08-09 10:13:25', 'resource_update', 'modResource', '1'),
(174, 1, '2021-08-09 10:29:26', 'resource_update', 'modResource', '1'),
(175, 1, '2021-08-09 10:29:32', 'resource_update', 'modResource', '1'),
(176, 1, '2021-08-09 10:29:41', 'resource_update', 'modResource', '1'),
(177, 1, '2021-08-09 10:30:54', 'template_update', 'modTemplate', '1'),
(178, 1, '2021-08-09 10:30:54', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(179, 1, '2021-08-09 10:32:57', 'chunk_create', 'modChunk', '9'),
(180, 1, '2021-08-09 10:35:21', 'lingua.ResourceScopesCreate_create', 'linguaResourceScopes', '1'),
(181, 1, '2021-08-09 10:35:40', 'lingua.ResourceScopesRemove_delete', 'linguaResourceScopes', '1'),
(182, 1, '2021-08-09 10:40:01', 'resource_update', 'modResource', '1'),
(183, 1, '2021-08-09 10:40:30', 'resource_update', 'modResource', '2'),
(184, 1, '2021-08-09 10:40:48', 'resource_update', 'modResource', '2'),
(185, 1, '2021-08-09 10:40:54', 'resource_update', 'modResource', '2'),
(186, 1, '2021-08-09 10:41:01', 'resource_update', 'modResource', '2'),
(187, 1, '2021-08-09 10:41:59', 'resource_update', 'modResource', '2'),
(188, 1, '2021-08-09 10:42:55', 'resource_create', 'modDocument', '3'),
(189, 1, '2021-08-09 10:43:46', 'resource_update', 'modResource', '3'),
(190, 1, '2021-08-09 10:44:45', 'resource_update', 'modResource', '3'),
(191, 1, '2021-08-09 10:45:19', 'resource_create', 'modDocument', '4'),
(192, 1, '2021-08-09 10:45:23', 'resource_update', 'modResource', '4'),
(193, 1, '2021-08-09 10:45:25', 'resource_update', 'modResource', '4'),
(194, 1, '2021-08-09 10:46:13', 'resource_update', 'modResource', '4'),
(195, 1, '2021-08-09 10:46:59', 'resource_update', 'modResource', '4'),
(196, 1, '2021-08-09 10:47:37', 'chunk_update', 'modChunk', '9'),
(197, 1, '2021-08-09 10:47:37', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 9 Default'),
(198, 1, '2021-08-09 10:48:07', 'clear_cache', '', 'mgr'),
(199, 1, '2021-08-09 10:51:10', 'chunk_update', 'modChunk', '9'),
(200, 1, '2021-08-09 10:51:11', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 9 Default'),
(201, 1, '2021-08-09 11:01:18', 'login', 'modContext', 'mgr'),
(202, 1, '2021-08-09 11:01:28', 'chunk_update', 'modChunk', '9'),
(203, 1, '2021-08-09 11:01:28', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 9 Default'),
(204, 1, '2021-08-09 11:02:07', 'chunk_update', 'modChunk', '9'),
(205, 1, '2021-08-09 11:02:08', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 9 Default'),
(206, 1, '2021-08-09 11:02:23', 'chunk_update', 'modChunk', '9'),
(207, 1, '2021-08-09 11:02:23', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 9 Default'),
(208, 1, '2021-08-09 11:03:19', 'chunk_update', 'modChunk', '9'),
(209, 1, '2021-08-09 11:03:19', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 9 Default'),
(210, 1, '2021-08-09 11:03:36', 'chunk_create', 'modChunk', '10'),
(211, 1, '2021-08-09 11:04:07', 'chunk_update', 'modChunk', '10'),
(212, 1, '2021-08-09 11:04:07', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 10 Default'),
(213, 1, '2021-08-09 11:05:53', 'resource_update', 'modResource', '1'),
(214, 1, '2021-08-09 11:06:33', 'resource_update', 'modResource', '1'),
(215, 1, '2021-08-09 11:06:39', 'resource_update', 'modResource', '1'),
(216, 1, '2021-08-09 11:07:37', 'chunk_update', 'modChunk', '10'),
(217, 1, '2021-08-09 11:07:38', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 10 Default'),
(218, 1, '2021-08-09 11:08:32', 'chunk_update', 'modChunk', '10'),
(219, 1, '2021-08-09 11:08:32', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 10 Default'),
(220, 1, '2021-08-09 11:08:40', 'chunk_update', 'modChunk', '10'),
(221, 1, '2021-08-09 11:08:41', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 10 Default'),
(222, 1, '2021-08-09 11:16:49', 'resource_update', 'modResource', '1'),
(223, 1, '2021-08-09 11:17:56', 'resource_update', 'modResource', '1'),
(224, 1, '2021-08-09 11:18:46', 'resource_update', 'modResource', '1'),
(225, 1, '2021-08-09 11:39:45', 'resource_update', 'modResource', '1'),
(226, 1, '2021-08-09 11:42:05', 'resource_update', 'modResource', '1'),
(227, 1, '2021-08-09 12:05:23', 'resource_update', 'modResource', '1'),
(228, 1, '2021-08-09 12:05:50', 'resource_update', 'modResource', '1'),
(229, 1, '2021-08-09 12:07:29', 'resource_update', 'modResource', '1'),
(230, 1, '2021-08-09 12:09:31', 'resource_update', 'modResource', '1'),
(231, 1, '2021-08-09 12:17:31', 'resource_update', 'modResource', '1'),
(232, 1, '2021-08-09 12:25:25', 'resource_update', 'modResource', '1'),
(233, 1, '2021-08-09 12:53:07', 'resource_update', 'modResource', '1'),
(234, 1, '2021-08-09 13:14:28', 'resource_update', 'modResource', '1'),
(235, 1, '2021-08-09 13:19:35', 'resource_update', 'modResource', '1'),
(236, 1, '2021-08-09 13:22:37', 'resource_update', 'modResource', '1'),
(237, 1, '2021-08-09 13:22:43', 'resource_update', 'modResource', '1'),
(238, 1, '2021-08-09 13:44:15', 'resource_update', 'modResource', '1'),
(239, 1, '2021-08-09 13:48:18', 'resource_update', 'modResource', '1'),
(240, 1, '2021-08-09 14:28:59', 'resource_update', 'modResource', '1'),
(241, 1, '2021-08-09 14:29:08', 'resource_update', 'modResource', '1'),
(242, 1, '2021-08-09 14:31:58', 'resource_update', 'modResource', '1'),
(243, 1, '2021-08-09 14:39:41', 'resource_update', 'modResource', '1'),
(244, 1, '2021-08-09 14:39:55', 'resource_update', 'modResource', '1'),
(245, 1, '2021-08-09 15:28:46', 'resource_update', 'modResource', '1'),
(246, 1, '2021-08-09 15:43:15', 'resource_update', 'modResource', '1'),
(247, 1, '2021-08-09 15:43:48', 'resource_update', 'modResource', '1'),
(248, 1, '2021-08-09 15:44:13', 'resource_update', 'modResource', '1'),
(249, 1, '2021-08-09 15:48:31', 'resource_update', 'modResource', '1'),
(250, 1, '2021-08-09 15:49:09', 'resource_update', 'modResource', '1'),
(251, 1, '2021-08-09 16:03:31', 'resource_update', 'modResource', '1'),
(252, 1, '2021-08-09 16:21:29', 'resource_update', 'modResource', '1'),
(253, 1, '2021-08-09 16:21:42', 'resource_update', 'modResource', '1'),
(254, 1, '2021-08-09 16:23:57', 'resource_update', 'modResource', '1'),
(255, 1, '2021-08-09 16:24:07', 'resource_update', 'modResource', '1'),
(256, 1, '2021-08-09 16:24:19', 'resource_update', 'modResource', '1'),
(257, 1, '2021-08-09 16:25:37', 'resource_update', 'modResource', '1'),
(258, 1, '2021-08-09 16:46:05', 'template_update', 'modTemplate', '1'),
(259, 1, '2021-08-09 16:46:06', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(260, 1, '2021-08-09 16:51:37', 'chunk_update', 'modChunk', '7'),
(261, 1, '2021-08-09 16:51:37', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 7 Default'),
(262, 1, '2021-08-09 16:52:18', 'chunk_update', 'modChunk', '6'),
(263, 1, '2021-08-09 16:52:18', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 6 Default'),
(264, 1, '2021-08-09 16:54:33', 'chunk_update', 'modChunk', '8'),
(265, 1, '2021-08-09 16:54:34', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 8 Default'),
(266, 1, '2021-08-09 17:13:38', 'resource_update', 'modResource', '1'),
(267, 1, '2021-08-09 17:15:44', 'resource_update', 'modResource', '1'),
(268, 1, '2021-08-09 17:16:35', 'resource_update', 'modResource', '1'),
(269, 1, '2021-08-09 17:25:32', 'resource_update', 'modResource', '1'),
(270, 1, '2021-08-09 17:27:19', 'resource_update', 'modResource', '1'),
(271, 1, '2021-08-09 17:27:29', 'resource_update', 'modResource', '1'),
(272, 1, '2021-08-09 17:28:30', 'resource_update', 'modResource', '1'),
(273, 1, '2021-08-09 17:29:03', 'resource_update', 'modResource', '1'),
(274, 1, '2021-08-10 09:14:36', 'resource_update', 'modResource', '1'),
(275, 1, '2021-08-10 09:14:56', 'resource_update', 'modResource', '1'),
(276, 1, '2021-08-10 09:17:03', 'resource_update', 'modResource', '1'),
(277, 1, '2021-08-10 09:33:32', 'resource_update', 'modResource', '1'),
(278, 1, '2021-08-10 09:33:48', 'resource_update', 'modResource', '1'),
(279, 1, '2021-08-10 09:38:42', 'resource_update', 'modResource', '1'),
(280, 1, '2021-08-10 09:40:03', 'resource_update', 'modResource', '1'),
(281, 1, '2021-08-10 13:06:26', 'resource_update', 'modResource', '1'),
(282, 1, '2021-08-10 13:08:06', 'resource_update', 'modResource', '1'),
(283, 1, '2021-08-10 13:17:37', 'resource_update', 'modResource', '1'),
(284, 1, '2021-08-10 13:35:50', 'resource_update', 'modResource', '1'),
(285, 1, '2021-08-10 13:57:33', 'resource_update', 'modResource', '1'),
(286, 1, '2021-08-10 13:57:46', 'resource_update', 'modResource', '1'),
(287, 1, '2021-08-10 13:58:11', 'resource_update', 'modResource', '1'),
(288, 1, '2021-08-10 13:58:24', 'resource_update', 'modResource', '1'),
(289, 1, '2021-08-10 13:59:16', 'resource_update', 'modResource', '1'),
(290, 1, '2021-08-10 13:59:21', 'resource_update', 'modResource', '1'),
(291, 1, '2021-08-10 13:59:47', 'resource_update', 'modResource', '1'),
(292, 1, '2021-08-10 14:00:02', 'resource_update', 'modResource', '1'),
(293, 1, '2021-08-10 14:00:24', 'resource_update', 'modResource', '1'),
(294, 1, '2021-08-10 14:01:29', 'resource_update', 'modResource', '1'),
(295, 1, '2021-08-10 14:01:45', 'resource_update', 'modResource', '1'),
(296, 1, '2021-08-10 14:04:46', 'resource_update', 'modResource', '1'),
(297, 1, '2021-08-10 14:05:09', 'resource_update', 'modResource', '1'),
(298, 1, '2021-08-10 14:05:22', 'resource_update', 'modResource', '1'),
(299, 1, '2021-08-10 14:05:38', 'resource_update', 'modResource', '1'),
(300, 1, '2021-08-10 14:05:56', 'resource_update', 'modResource', '1'),
(301, 1, '2021-08-10 14:06:34', 'resource_update', 'modResource', '1'),
(302, 1, '2021-08-10 14:07:34', 'resource_update', 'modResource', '1'),
(303, 1, '2021-08-10 14:09:45', 'resource_update', 'modResource', '1'),
(304, 1, '2021-08-10 14:10:33', 'resource_update', 'modResource', '1'),
(305, 1, '2021-08-10 14:10:53', 'resource_update', 'modResource', '1'),
(306, 1, '2021-08-10 14:11:13', 'resource_update', 'modResource', '1'),
(307, 1, '2021-08-10 14:11:24', 'resource_update', 'modResource', '1'),
(308, 1, '2021-08-10 14:11:39', 'resource_update', 'modResource', '1'),
(309, 1, '2021-08-10 14:11:56', 'resource_update', 'modResource', '1'),
(310, 1, '2021-08-10 14:12:29', 'resource_update', 'modResource', '1'),
(311, 1, '2021-08-10 14:13:37', 'resource_update', 'modResource', '1'),
(312, 1, '2021-08-10 14:14:13', 'resource_update', 'modResource', '1'),
(313, 1, '2021-08-10 14:44:00', 'resource_update', 'modResource', '1'),
(314, 1, '2021-08-10 14:44:11', 'resource_update', 'modResource', '1'),
(315, 1, '2021-08-10 14:45:11', 'resource_update', 'modResource', '1'),
(316, 1, '2021-08-10 14:45:46', 'resource_update', 'modResource', '1'),
(317, 1, '2021-08-10 14:51:13', 'resource_update', 'modResource', '1'),
(318, 1, '2021-08-10 14:51:29', 'resource_update', 'modResource', '1'),
(319, 1, '2021-08-10 14:51:54', 'resource_update', 'modResource', '1'),
(320, 1, '2021-08-10 14:52:04', 'resource_update', 'modResource', '1'),
(321, 1, '2021-08-10 14:52:34', 'resource_update', 'modResource', '1'),
(322, 1, '2021-08-10 14:54:15', 'resource_update', 'modResource', '1'),
(323, 1, '2021-08-10 14:54:53', 'resource_update', 'modResource', '1'),
(324, 1, '2021-08-10 14:55:13', 'resource_update', 'modResource', '1'),
(325, 1, '2021-08-10 14:55:54', 'resource_update', 'modResource', '1'),
(326, 1, '2021-08-10 14:56:34', 'resource_update', 'modResource', '1'),
(327, 1, '2021-08-10 14:56:42', 'resource_update', 'modResource', '1'),
(328, 1, '2021-08-10 14:59:40', 'resource_update', 'modResource', '1'),
(329, 1, '2021-08-10 15:00:01', 'resource_update', 'modResource', '1'),
(330, 1, '2021-08-10 15:00:15', 'resource_update', 'modResource', '1'),
(331, 1, '2021-08-10 15:00:33', 'resource_update', 'modResource', '1'),
(332, 1, '2021-08-10 15:00:45', 'resource_update', 'modResource', '1'),
(333, 1, '2021-08-10 15:12:30', 'resource_update', 'modResource', '1'),
(334, 1, '2021-08-10 15:13:32', 'resource_update', 'modResource', '1'),
(335, 1, '2021-08-10 15:13:41', 'resource_update', 'modResource', '1'),
(336, 1, '2021-08-10 15:14:17', 'resource_update', 'modResource', '1'),
(337, 1, '2021-08-10 15:14:34', 'resource_update', 'modResource', '1'),
(338, 1, '2021-08-10 15:15:12', 'resource_update', 'modResource', '1'),
(339, 1, '2021-08-10 15:15:24', 'resource_update', 'modResource', '1'),
(340, 1, '2021-08-10 15:15:45', 'resource_update', 'modResource', '1'),
(341, 1, '2021-08-10 15:16:09', 'resource_update', 'modResource', '1'),
(342, 1, '2021-08-10 15:16:38', 'resource_update', 'modResource', '1'),
(343, 1, '2021-08-10 15:20:40', 'resource_update', 'modResource', '1'),
(344, 1, '2021-08-10 15:21:12', 'resource_update', 'modResource', '1'),
(345, 1, '2021-08-10 15:21:29', 'resource_update', 'modResource', '1'),
(346, 1, '2021-08-10 15:22:26', 'resource_update', 'modResource', '1'),
(347, 1, '2021-08-10 15:40:01', 'resource_update', 'modResource', '1'),
(348, 1, '2021-08-10 15:48:07', 'resource_update', 'modResource', '1'),
(349, 1, '2021-08-10 15:49:07', 'resource_update', 'modResource', '1'),
(350, 1, '2021-08-10 15:49:34', 'resource_update', 'modResource', '1'),
(351, 1, '2021-08-10 15:49:42', 'resource_update', 'modResource', '1'),
(352, 1, '2021-08-10 15:50:14', 'resource_update', 'modResource', '1'),
(353, 1, '2021-08-10 15:50:22', 'resource_update', 'modResource', '1'),
(354, 1, '2021-08-10 15:53:57', 'chunk_update', 'modChunk', '2'),
(355, 1, '2021-08-10 15:53:57', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(356, 1, '2021-08-10 15:54:09', 'chunk_update', 'modChunk', '2'),
(357, 1, '2021-08-10 15:54:10', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(358, 1, '2021-08-10 15:54:45', 'chunk_update', 'modChunk', '2'),
(359, 1, '2021-08-10 15:54:45', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(360, 1, '2021-08-10 15:57:43', 'chunk_update', 'modChunk', '2'),
(361, 1, '2021-08-10 15:57:44', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(362, 1, '2021-08-10 16:01:07', 'chunk_update', 'modChunk', '2'),
(363, 1, '2021-08-10 16:01:07', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(364, 1, '2021-08-10 16:05:14', 'chunk_update', 'modChunk', '2'),
(365, 1, '2021-08-10 16:05:15', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(366, 1, '2021-08-10 16:11:52', 'chunk_update', 'modChunk', '2'),
(367, 1, '2021-08-10 16:11:52', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(368, 1, '2021-08-10 16:12:04', 'chunk_update', 'modChunk', '2'),
(369, 1, '2021-08-10 16:12:04', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(370, 1, '2021-08-10 16:14:42', 'chunk_update', 'modChunk', '2'),
(371, 1, '2021-08-10 16:14:42', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(372, 1, '2021-08-10 16:58:26', 'chunk_update', 'modChunk', '2'),
(373, 1, '2021-08-10 16:58:26', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(374, 1, '2021-08-10 17:31:26', 'setting_update', 'modSystemSetting', 'friendly_urls'),
(375, 1, '2021-08-10 17:31:56', 'setting_update', 'modSystemSetting', 'use_alias_path'),
(376, 1, '2021-08-10 17:38:50', 'clear_cache', '', 'mgr'),
(377, 1, '2021-08-10 17:38:55', 'clear_cache', '', 'mgr'),
(378, 1, '2021-08-10 17:40:59', 'unpublish_resource', 'modResource', '4'),
(379, 1, '2021-08-10 17:42:36', 'resource_update', 'modResource', '4'),
(380, 1, '2021-08-10 17:42:48', 'resource_update', 'modResource', '4'),
(381, 1, '2021-08-10 17:43:16', 'resource_update', 'modResource', '4'),
(382, 1, '2021-08-10 17:48:30', 'setting_update', 'modSystemSetting', 'friendly_urls_strict'),
(383, 1, '2021-08-10 17:48:35', 'setting_update', 'modSystemSetting', 'friendly_urls_strict'),
(384, 1, '2021-08-10 17:48:43', 'setting_update', 'modSystemSetting', 'global_duplicate_uri_check'),
(385, 1, '2021-08-10 17:49:35', 'setting_update', 'modSystemSetting', 'manager_use_fullname'),
(386, 1, '2021-08-10 17:49:46', 'setting_update', 'modSystemSetting', 'manager_use_fullname'),
(387, 1, '2021-08-10 17:50:35', 'resource_update', 'modResource', '1'),
(388, 1, '2021-08-10 17:50:51', 'resource_update', 'modResource', '1'),
(389, 1, '2021-08-10 17:50:57', 'resource_update', 'modResource', '1'),
(390, 1, '2021-08-10 17:51:25', 'resource_update', 'modResource', '1'),
(391, 1, '2021-08-10 17:54:10', 'resource_update', 'modResource', '3'),
(392, 1, '2021-08-10 17:54:23', 'resource_update', 'modResource', '3'),
(393, 1, '2021-08-10 17:54:56', 'resource_update', 'modResource', '3'),
(394, 1, '2021-08-10 17:55:15', 'resource_update', 'modResource', '3'),
(395, 1, '2021-08-10 18:44:09', 'resource_update', 'modResource', '3'),
(396, 1, '2021-08-11 09:59:45', 'chunk_update', 'modChunk', '2'),
(397, 1, '2021-08-11 09:59:45', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(398, 1, '2021-08-11 10:00:12', 'chunk_update', 'modChunk', '2'),
(399, 1, '2021-08-11 10:00:12', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(400, 1, '2021-08-11 10:02:22', 'chunk_create', 'modChunk', '11'),
(401, 1, '2021-08-11 10:02:48', 'chunk_update', 'modChunk', '2'),
(402, 1, '2021-08-11 10:02:48', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(403, 1, '2021-08-11 10:03:14', 'chunk_update', 'modChunk', '2'),
(404, 1, '2021-08-11 10:03:14', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 2 Default'),
(405, 1, '2021-08-11 10:03:39', 'chunk_update', 'modChunk', '11'),
(406, 1, '2021-08-11 10:03:39', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 11 Default'),
(407, 1, '2021-08-11 10:04:21', 'chunk_update', 'modChunk', '11'),
(408, 1, '2021-08-11 10:04:22', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 11 Default'),
(409, 1, '2021-08-11 10:09:32', 'chunk_update', 'modChunk', '11'),
(410, 1, '2021-08-11 10:09:32', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 11 Default'),
(411, 1, '2021-08-11 10:10:23', 'delete_resource', 'modDocument', '2'),
(412, 1, '2021-08-11 10:10:48', 'undelete_resource', 'modResource', '2'),
(413, 1, '2021-08-11 10:11:27', 'resource_update', 'modResource', '2'),
(414, 1, '2021-08-11 10:12:42', 'resource_update', 'modResource', '2'),
(415, 1, '2021-08-11 10:12:47', 'undelete_resource', 'modResource', '2'),
(416, 1, '2021-08-11 10:14:47', 'resource_update', 'modResource', '3'),
(417, 1, '2021-08-11 10:14:57', 'resource_update', 'modResource', '3'),
(418, 1, '2021-08-11 10:16:35', 'resource_update', 'modResource', '1'),
(419, 1, '2021-08-11 10:17:01', 'delete_resource', 'modDocument', '4'),
(420, 1, '2021-08-11 10:17:18', 'empty_trash', 'modResource', '4'),
(421, 1, '2021-08-11 10:25:35', 'resource_update', 'modResource', '3'),
(422, 1, '2021-08-11 10:25:44', 'resource_update', 'modResource', '3'),
(423, 1, '2021-08-11 10:27:03', 'resource_update', 'modResource', '3'),
(424, 1, '2021-08-11 10:29:40', 'resource_update', 'modResource', '3'),
(425, 1, '2021-08-11 10:30:05', 'resource_update', 'modResource', '3'),
(426, 1, '2021-08-11 10:30:33', 'resource_update', 'modResource', '3'),
(427, 1, '2021-08-11 10:31:07', 'resource_update', 'modResource', '3'),
(428, 1, '2021-08-11 10:31:37', 'resource_update', 'modResource', '3'),
(429, 1, '2021-08-11 10:35:59', 'chunk_update', 'modChunk', '4'),
(430, 1, '2021-08-11 10:35:59', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(431, 1, '2021-08-11 10:37:26', 'chunk_update', 'modChunk', '3'),
(432, 1, '2021-08-11 10:37:26', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 3 Default'),
(433, 1, '2021-08-11 10:38:55', 'chunk_update', 'modChunk', '4'),
(434, 1, '2021-08-11 10:38:56', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(435, 1, '2021-08-11 10:39:25', 'chunk_update', 'modChunk', '4'),
(436, 1, '2021-08-11 10:39:25', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(437, 1, '2021-08-11 10:39:52', 'chunk_update', 'modChunk', '4'),
(438, 1, '2021-08-11 10:39:53', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(439, 1, '2021-08-11 10:41:21', 'chunk_update', 'modChunk', '4'),
(440, 1, '2021-08-11 10:41:22', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(441, 1, '2021-08-11 10:41:47', 'chunk_update', 'modChunk', '4'),
(442, 1, '2021-08-11 10:41:47', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(443, 1, '2021-08-11 10:42:11', 'chunk_update', 'modChunk', '4'),
(444, 1, '2021-08-11 10:42:11', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(445, 1, '2021-08-11 10:42:34', 'chunk_update', 'modChunk', '4'),
(446, 1, '2021-08-11 10:42:35', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(447, 1, '2021-08-11 10:43:04', 'chunk_update', 'modChunk', '4'),
(448, 1, '2021-08-11 10:43:04', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(449, 1, '2021-08-11 10:43:35', 'chunk_update', 'modChunk', '4'),
(450, 1, '2021-08-11 10:43:35', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 4 Default'),
(451, 1, '2021-08-11 10:48:58', 'resource_update', 'modResource', '3'),
(452, 1, '2021-08-11 10:50:33', 'resource_update', 'modResource', '3'),
(453, 1, '2021-08-11 10:54:55', 'resource_update', 'modResource', '3'),
(454, 1, '2021-08-11 10:57:56', 'resource_update', 'modResource', '3'),
(455, 1, '2021-08-11 10:58:25', 'resource_update', 'modResource', '3'),
(456, 1, '2021-08-11 10:58:54', 'resource_update', 'modResource', '3'),
(457, 1, '2021-08-11 11:00:35', 'resource_update', 'modResource', '3'),
(458, 1, '2021-08-11 11:00:48', 'resource_update', 'modResource', '3'),
(459, 1, '2021-08-11 11:03:34', 'resource_update', 'modResource', '3'),
(460, 1, '2021-08-11 11:05:19', 'resource_update', 'modResource', '3'),
(461, 1, '2021-08-11 11:07:43', 'resource_update', 'modResource', '3'),
(462, 1, '2021-08-11 11:08:35', 'resource_update', 'modResource', '3'),
(463, 1, '2021-08-11 11:09:09', 'resource_update', 'modResource', '3'),
(464, 1, '2021-08-11 11:09:33', 'resource_update', 'modResource', '3'),
(465, 1, '2021-08-11 11:09:49', 'resource_update', 'modResource', '3'),
(466, 1, '2021-08-11 11:10:25', 'resource_update', 'modResource', '3'),
(467, 1, '2021-08-11 11:10:51', 'resource_update', 'modResource', '3'),
(468, 1, '2021-08-11 11:11:20', 'resource_update', 'modResource', '3'),
(469, 1, '2021-08-11 11:18:47', 'resource_update', 'modResource', '3'),
(470, 1, '2021-08-11 11:19:05', 'resource_update', 'modResource', '3'),
(471, 1, '2021-08-11 11:25:27', 'resource_update', 'modResource', '3'),
(472, 1, '2021-08-11 11:52:24', 'gallery.album_create', 'galAlbum', '1'),
(473, 1, '2021-08-11 12:19:41', 'tv_create', 'modTemplateVar', '1'),
(474, 1, '2021-08-11 12:19:51', 'tv_update', 'modTemplateVar', '1'),
(475, 1, '2021-08-11 12:19:51', 'propertyset_update_from_element', 'modPropertySet', 'modTemplateVar 1 Default'),
(476, 1, '2021-08-11 12:20:23', 'tv_duplicate', 'modTemplateVar', '2'),
(477, 1, '2021-08-11 12:20:46', 'tv_duplicate', 'modTemplateVar', '3'),
(478, 1, '2021-08-11 12:21:44', 'directory_create', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/'),
(479, 1, '2021-08-11 12:21:44', 'file_upload', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/'),
(480, 1, '2021-08-11 12:24:43', 'file_upload', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/'),
(481, 1, '2021-08-11 12:25:21', 'file_upload', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/'),
(482, 1, '2021-08-11 12:26:42', 'file_remove', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/1.png'),
(483, 1, '2021-08-11 12:26:42', 'file_remove', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/2.jpg'),
(484, 1, '2021-08-11 12:26:42', 'file_remove', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/3.jpg'),
(485, 1, '2021-08-11 12:26:42', 'gallery.album_delete', 'galAlbum', '1'),
(486, 1, '2021-08-11 12:27:21', 'template_update', 'modTemplate', '1'),
(487, 1, '2021-08-11 12:27:21', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(488, 1, '2021-08-11 12:27:25', 'tv_delete', 'modTemplateVar', '2'),
(489, 1, '2021-08-11 12:27:29', 'tv_delete', 'modTemplateVar', '3'),
(490, 1, '2021-08-11 12:27:33', 'tv_delete', 'modTemplateVar', '1'),
(491, 1, '2021-08-11 12:40:47', 'gallery.album_create', 'galAlbum', '2'),
(492, 1, '2021-08-11 12:41:12', 'gallery.album_update', 'galAlbum', '2'),
(493, 1, '2021-08-11 12:41:31', 'gallery.album_update', 'galAlbum', '2'),
(494, 1, '2021-08-11 12:42:24', 'gallery.album_update', 'galAlbum', '2'),
(495, 1, '2021-08-11 12:51:44', 'gallery.album_update', 'galAlbum', '2'),
(496, 1, '2021-08-11 12:52:45', 'gallery.album_update', 'galAlbum', '2'),
(497, 1, '2021-08-11 12:54:13', 'gallery.album_update', 'galAlbum', '2'),
(498, 1, '2021-08-11 12:55:38', 'tv_create', 'modTemplateVar', '1'),
(499, 1, '2021-08-11 12:56:10', 'file_upload', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/img/'),
(500, 1, '2021-08-11 12:56:16', 'file_remove', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/img/testy.jpg'),
(501, 1, '2021-08-11 12:57:25', 'gallery.album_update', 'galAlbum', '2'),
(502, 1, '2021-08-11 13:07:23', 'gallery.album_update', 'galAlbum', '2'),
(503, 1, '2021-08-11 13:07:37', 'gallery.album_update', 'galAlbum', '2'),
(504, 1, '2021-08-11 13:07:58', 'file_upload', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/2/'),
(505, 1, '2021-08-11 13:14:42', 'directory_remove', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/1/'),
(506, 1, '2021-08-11 13:14:59', 'directory_remove', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/2/'),
(507, 1, '2021-08-11 13:33:11', 'gallery.item_update', 'galItem', '4'),
(508, 1, '2021-08-11 13:33:15', 'gallery.item_delete', 'galItem', '4'),
(509, 1, '2021-08-11 13:33:27', 'file_upload', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/2/'),
(510, 1, '2021-08-11 13:35:04', 'tv_update', 'modTemplateVar', '1'),
(511, 1, '2021-08-11 13:35:04', 'propertyset_update_from_element', 'modPropertySet', 'modTemplateVar 1 Default'),
(512, 1, '2021-08-11 13:37:00', 'tv_update', 'modTemplateVar', '1'),
(513, 1, '2021-08-11 13:37:00', 'propertyset_update_from_element', 'modPropertySet', 'modTemplateVar 1 Default'),
(514, 1, '2021-08-11 13:48:11', 'file_remove', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/assets/gallery/2/5.png'),
(515, 1, '2021-08-11 13:48:11', 'gallery.item_delete', 'galItem', '5'),
(516, 1, '2021-08-11 13:48:42', 'gallery.album_delete', 'galAlbum', '2'),
(517, 1, '2021-08-11 13:54:38', 'resource_update', 'modResource', '2'),
(518, 1, '2021-08-11 13:55:33', 'tv_update', 'modTemplateVar', '1'),
(519, 1, '2021-08-11 13:55:33', 'propertyset_update_from_element', 'modPropertySet', 'modTemplateVar 1 Default'),
(520, 1, '2021-08-11 13:56:22', 'template_duplicate', 'modTemplate', '2'),
(521, 1, '2021-08-11 13:56:28', 'template_update', 'modTemplate', '2'),
(522, 1, '2021-08-11 13:56:28', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 2 Default'),
(523, 1, '2021-08-11 13:56:37', 'template_update', 'modTemplate', '1'),
(524, 1, '2021-08-11 13:56:37', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 1 Default'),
(525, 1, '2021-08-11 13:58:40', 'resource_create', 'modDocument', '4'),
(526, 1, '2021-08-11 14:03:32', 'collections.template_create', 'CollectionTemplate', '2'),
(527, 1, '2021-08-11 14:08:45', 'collections.template.column_create', 'CollectionTemplateColumn', '7'),
(528, 1, '2021-08-11 14:09:43', 'collections.template.column_create', 'CollectionTemplateColumn', '8'),
(529, 1, '2021-08-11 14:10:35', 'collections.template.column_update', 'CollectionTemplateColumn', '8'),
(530, 1, '2021-08-11 14:12:58', 'collections.template_update', 'CollectionTemplate', '1'),
(531, 1, '2021-08-11 14:13:51', 'collections.template.column_update', 'CollectionTemplateColumn', '8'),
(532, 1, '2021-08-11 14:13:53', 'collections.template_update', 'CollectionTemplate', '2'),
(533, 1, '2021-08-11 14:14:24', 'delete_resource', 'modDocument', '4'),
(534, 1, '2021-08-11 14:14:34', 'template_delete', 'modTemplate', '2'),
(535, 1, '2021-08-11 14:14:46', 'tv_delete', 'modTemplateVar', '1'),
(536, 1, '2021-08-11 14:15:45', 'resource_update', 'modResource', '2'),
(537, 1, '2021-08-11 14:16:40', 'collections.template_update', 'CollectionTemplate', '2'),
(538, 1, '2021-08-11 14:17:43', 'resource_create', 'modStaticResource', '5'),
(539, 1, '2021-08-11 14:20:55', 'collections.template.column_update', 'CollectionTemplateColumn', '8'),
(540, 1, '2021-08-11 14:21:28', 'resource_update', 'modResource', '5'),
(541, 1, '2021-08-11 14:22:13', 'resource_update', 'modResource', '5'),
(542, 1, '2021-08-11 14:24:19', 'resource_update', 'modResource', '2'),
(543, 1, '2021-08-11 14:25:17', 'resource_update', 'modResource', '2'),
(544, 1, '2021-08-11 14:25:38', 'chunk_create', 'modChunk', '18'),
(545, 1, '2021-08-11 14:25:50', 'chunk_update', 'modChunk', '18'),
(546, 1, '2021-08-11 14:25:50', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(547, 1, '2021-08-11 14:26:26', 'resource_update', 'modResource', '2'),
(548, 1, '2021-08-11 14:27:18', 'template_duplicate', 'modTemplate', '3'),
(549, 1, '2021-08-11 14:27:33', 'template_update', 'modTemplate', '3'),
(550, 1, '2021-08-11 14:27:34', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(551, 1, '2021-08-11 14:28:04', 'resource_update', 'modResource', '2'),
(552, 1, '2021-08-11 14:28:18', 'resource_update', 'modResource', '2'),
(553, 1, '2021-08-11 14:28:33', 'resource_update', 'modResource', '2'),
(554, 1, '2021-08-11 14:31:50', 'template_update', 'modTemplate', '3'),
(555, 1, '2021-08-11 14:31:50', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(556, 1, '2021-08-11 14:35:51', 'template_update', 'modTemplate', '3'),
(557, 1, '2021-08-11 14:35:52', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(558, 1, '2021-08-11 14:36:11', 'template_update', 'modTemplate', '3'),
(559, 1, '2021-08-11 14:36:11', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(560, 1, '2021-08-11 14:36:49', 'template_update', 'modTemplate', '3'),
(561, 1, '2021-08-11 14:36:50', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(562, 1, '2021-08-11 14:37:08', 'template_update', 'modTemplate', '3'),
(563, 1, '2021-08-11 14:37:08', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(564, 1, '2021-08-11 14:37:47', 'chunk_update', 'modChunk', '18'),
(565, 1, '2021-08-11 14:37:48', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(566, 1, '2021-08-11 14:41:02', 'template_update', 'modTemplate', '3'),
(567, 1, '2021-08-11 14:41:02', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(568, 1, '2021-08-11 14:42:07', 'chunk_update', 'modChunk', '18'),
(569, 1, '2021-08-11 14:42:08', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(570, 1, '2021-08-11 14:44:16', 'chunk_update', 'modChunk', '18'),
(571, 1, '2021-08-11 14:44:17', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(572, 1, '2021-08-11 14:45:31', 'chunk_update', 'modChunk', '18'),
(573, 1, '2021-08-11 14:45:31', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(574, 1, '2021-08-11 14:46:12', 'chunk_update', 'modChunk', '18'),
(575, 1, '2021-08-11 14:46:12', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(576, 1, '2021-08-11 14:46:53', 'chunk_update', 'modChunk', '18'),
(577, 1, '2021-08-11 14:46:54', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(578, 1, '2021-08-11 14:47:16', 'chunk_update', 'modChunk', '18'),
(579, 1, '2021-08-11 14:47:17', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(580, 1, '2021-08-11 14:48:49', 'chunk_update', 'modChunk', '18'),
(581, 1, '2021-08-11 14:49:29', 'chunk_update', 'modChunk', '18'),
(582, 1, '2021-08-11 14:49:29', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(583, 1, '2021-08-11 14:50:04', 'chunk_update', 'modChunk', '18'),
(584, 1, '2021-08-11 14:50:04', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(585, 1, '2021-08-11 14:50:29', 'template_update', 'modTemplate', '3'),
(586, 1, '2021-08-11 14:50:30', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(587, 1, '2021-08-11 14:51:16', 'chunk_update', 'modChunk', '18'),
(588, 1, '2021-08-11 14:51:16', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(589, 1, '2021-08-11 14:52:33', 'resource_update', 'modResource', '2'),
(590, 1, '2021-08-11 14:54:13', 'resource_update', 'modResource', '1'),
(591, 1, '2021-08-11 15:06:44', 'chunk_update', 'modChunk', '18'),
(592, 1, '2021-08-11 15:06:45', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(593, 1, '2021-08-11 15:07:07', 'chunk_update', 'modChunk', '18'),
(594, 1, '2021-08-11 15:07:08', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(595, 1, '2021-08-11 15:08:40', 'delete_resource', 'modStaticResource', '5'),
(596, 1, '2021-08-11 15:22:32', 'resource_create', 'modStaticResource', '6'),
(597, 1, '2021-08-11 15:23:54', 'template_duplicate', 'modTemplate', '4'),
(598, 1, '2021-08-11 15:24:16', 'tv_create', 'modTemplateVar', '2'),
(599, 1, '2021-08-11 15:24:28', 'tv_update', 'modTemplateVar', '2'),
(600, 1, '2021-08-11 15:24:28', 'propertyset_update_from_element', 'modPropertySet', 'modTemplateVar 2 Default'),
(601, 1, '2021-08-11 15:25:04', 'resource_update', 'modResource', '6'),
(602, 1, '2021-08-11 15:25:24', 'tv_update', 'modTemplateVar', '2'),
(603, 1, '2021-08-11 15:25:24', 'propertyset_update_from_element', 'modPropertySet', 'modTemplateVar 2 Default'),
(604, 1, '2021-08-11 15:25:27', 'tv_update', 'modTemplateVar', '2'),
(605, 1, '2021-08-11 15:25:27', 'propertyset_update_from_element', 'modPropertySet', 'modTemplateVar 2 Default'),
(606, 1, '2021-08-11 15:26:00', 'collections.template.column_update', 'CollectionTemplateColumn', '8'),
(607, 1, '2021-08-11 15:26:03', 'collections.template_update', 'CollectionTemplate', '2'),
(608, 1, '2021-08-11 15:27:08', 'template_update', 'modTemplate', '3'),
(609, 1, '2021-08-11 15:27:08', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(610, 1, '2021-08-11 15:27:38', 'chunk_update', 'modChunk', '18'),
(611, 1, '2021-08-11 15:27:38', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(612, 1, '2021-08-11 15:27:50', 'chunk_update', 'modChunk', '18'),
(613, 1, '2021-08-11 15:27:50', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(614, 1, '2021-08-11 15:28:02', 'chunk_update', 'modChunk', '18'),
(615, 1, '2021-08-11 15:28:02', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(616, 1, '2021-08-11 15:29:18', 'template_update', 'modTemplate', '3'),
(617, 1, '2021-08-11 15:29:19', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(618, 1, '2021-08-11 15:29:34', 'chunk_update', 'modChunk', '18'),
(619, 1, '2021-08-11 15:29:34', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(620, 1, '2021-08-11 15:31:24', 'resource_update', 'modResource', '6'),
(621, 1, '2021-08-11 15:32:36', 'collections.template_update', 'CollectionTemplate', '2'),
(622, 1, '2021-08-11 15:34:01', 'resource_create', 'modStaticResource', '7'),
(623, 1, '2021-08-11 15:37:05', 'resource_create', 'modStaticResource', '8'),
(624, 1, '2021-08-11 15:39:44', 'resource_update', 'modResource', '6'),
(625, 1, '2021-08-11 15:41:28', 'resource_update', 'modResource', '7'),
(626, 1, '2021-08-11 15:42:03', 'resource_update', 'modResource', '8'),
(627, 1, '2021-08-11 15:43:35', 'resource_update', 'modResource', '6'),
(628, 1, '2021-08-11 16:05:07', 'delete_resource', 'modStaticResource', '6'),
(629, 1, '2021-08-11 16:05:12', 'delete_resource', 'modStaticResource', '8');
INSERT INTO `modx_manager_log` (`id`, `user`, `occurred`, `action`, `classKey`, `item`) VALUES
(630, 1, '2021-08-11 16:05:16', 'delete_resource', 'modStaticResource', '7'),
(631, 1, '2021-08-11 16:08:34', 'resource_create', 'modStaticResource', '9'),
(632, 1, '2021-08-11 16:08:40', 'resource_update', 'modResource', '9'),
(633, 1, '2021-08-11 16:10:22', 'resource_create', 'modStaticResource', '10'),
(634, 1, '2021-08-11 16:11:55', 'resource_create', 'modStaticResource', '11'),
(635, 1, '2021-08-11 16:13:38', 'resource_create', 'modStaticResource', '12'),
(636, 1, '2021-08-11 16:14:46', 'resource_create', 'modStaticResource', '13'),
(637, 1, '2021-08-11 16:16:57', 'resource_create', 'modStaticResource', '14'),
(638, 1, '2021-08-11 16:17:03', 'resource_update', 'modResource', '14'),
(639, 1, '2021-08-11 16:18:56', 'resource_create', 'modStaticResource', '15'),
(640, 1, '2021-08-11 16:21:10', 'resource_create', 'modStaticResource', '16'),
(641, 1, '2021-08-11 16:22:22', 'resource_create', 'modStaticResource', '17'),
(642, 1, '2021-08-11 16:22:43', 'resource_update', 'modResource', '17'),
(643, 1, '2021-08-11 16:24:00', 'resource_create', 'modStaticResource', '18'),
(644, 1, '2021-08-11 16:25:05', 'resource_create', 'modStaticResource', '19'),
(645, 1, '2021-08-11 16:25:16', 'resource_update', 'modResource', '19'),
(646, 1, '2021-08-11 16:27:19', 'collections.template.column_create', 'CollectionTemplateColumn', '9'),
(647, 1, '2021-08-11 16:28:54', 'resource_create', 'modStaticResource', '20'),
(648, 1, '2021-08-11 16:30:05', 'resource_create', 'modStaticResource', '21'),
(649, 1, '2021-08-11 16:31:02', 'resource_update', 'modResource', '21'),
(650, 1, '2021-08-11 16:32:55', 'resource_create', 'modStaticResource', '22'),
(651, 1, '2021-08-11 16:33:31', 'resource_update', 'modResource', '22'),
(652, 1, '2021-08-11 16:35:24', 'resource_create', 'modStaticResource', '23'),
(653, 1, '2021-08-11 16:36:59', 'resource_create', 'modStaticResource', '24'),
(654, 1, '2021-08-11 16:38:57', 'resource_create', 'modStaticResource', '25'),
(655, 1, '2021-08-11 16:40:20', 'resource_create', 'modStaticResource', '26'),
(656, 1, '2021-08-11 16:45:29', 'resource_create', 'modStaticResource', '27'),
(657, 1, '2021-08-11 16:46:32', 'resource_create', 'modStaticResource', '28'),
(658, 1, '2021-08-11 16:48:07', 'resource_create', 'modStaticResource', '29'),
(659, 1, '2021-08-11 16:49:06', 'resource_create', 'modStaticResource', '30'),
(660, 1, '2021-08-11 16:50:23', 'resource_create', 'modStaticResource', '31'),
(661, 1, '2021-08-11 16:52:14', 'resource_create', 'modStaticResource', '32'),
(662, 1, '2021-08-11 16:53:32', 'resource_create', 'modStaticResource', '33'),
(663, 1, '2021-08-11 16:55:06', 'resource_create', 'modStaticResource', '34'),
(664, 1, '2021-08-11 16:56:14', 'file_rename', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/img/gallery/flowering-garden.jpg'),
(665, 1, '2021-08-11 16:56:52', 'resource_create', 'modStaticResource', '35'),
(666, 1, '2021-08-11 16:56:59', 'resource_update', 'modResource', '35'),
(667, 1, '2021-08-11 16:58:15', 'resource_create', 'modStaticResource', '36'),
(668, 1, '2021-08-11 16:59:45', 'resource_create', 'modStaticResource', '37'),
(669, 1, '2021-08-11 17:13:15', 'resource_update', 'modResource', '37'),
(670, 1, '2021-08-11 17:14:30', 'resource_update', 'modResource', '2'),
(671, 1, '2021-08-11 17:16:05', 'resource_create', 'modStaticResource', '38'),
(672, 1, '2021-08-11 17:16:24', 'resource_update', 'modResource', '38'),
(673, 1, '2021-08-11 17:16:35', 'resource_update', 'modResource', '38'),
(674, 1, '2021-08-11 17:18:05', 'resource_create', 'modStaticResource', '39'),
(675, 1, '2021-08-11 17:19:34', 'resource_create', 'modStaticResource', '40'),
(676, 1, '2021-08-11 17:21:39', 'file_rename', '', 'C:/2Br-projects/Masha_sun/6-08-2021_Layout/!Layout/release/img/gallery/nomad.jpg'),
(677, 1, '2021-08-11 17:21:45', 'resource_create', 'modStaticResource', '41'),
(678, 1, '2021-08-11 17:23:03', 'resource_create', 'modStaticResource', '42'),
(679, 1, '2021-08-11 17:24:40', 'resource_create', 'modStaticResource', '43'),
(680, 1, '2021-08-11 17:25:30', 'resource_create', 'modStaticResource', '44'),
(681, 1, '2021-08-11 17:26:02', 'resource_update', 'modResource', '44'),
(682, 1, '2021-08-11 17:27:05', 'resource_create', 'modStaticResource', '45'),
(683, 1, '2021-08-11 17:28:28', 'resource_create', 'modStaticResource', '46'),
(684, 1, '2021-08-11 17:31:01', 'resource_create', 'modStaticResource', '47'),
(685, 1, '2021-08-11 17:32:07', 'resource_create', 'modStaticResource', '48'),
(686, 1, '2021-08-11 17:33:19', 'resource_create', 'modStaticResource', '49'),
(687, 1, '2021-08-11 17:35:55', 'resource_create', 'modStaticResource', '50'),
(688, 1, '2021-08-11 17:37:13', 'resource_create', 'modStaticResource', '51'),
(689, 1, '2021-08-11 17:38:41', 'resource_create', 'modStaticResource', '52'),
(690, 1, '2021-08-11 17:40:01', 'resource_create', 'modStaticResource', '53'),
(691, 1, '2021-08-11 17:40:17', 'resource_update', 'modResource', '53'),
(692, 1, '2021-08-11 17:41:33', 'resource_update', 'modResource', '53'),
(693, 1, '2021-08-11 17:42:20', 'resource_create', 'modStaticResource', '54'),
(694, 1, '2021-08-11 17:43:18', 'template_update', 'modTemplate', '3'),
(695, 1, '2021-08-11 17:43:18', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(696, 1, '2021-08-11 17:44:28', 'resource_update', 'modResource', '54'),
(697, 1, '2021-08-11 17:44:38', 'resource_update', 'modResource', '54'),
(698, 1, '2021-08-11 17:48:44', 'template_update', 'modTemplate', '3'),
(699, 1, '2021-08-11 17:48:44', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(700, 1, '2021-08-11 17:50:42', 'resource_update', 'modResource', '35'),
(701, 1, '2021-08-11 17:52:08', 'chunk_update', 'modChunk', '18'),
(702, 1, '2021-08-11 17:52:08', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(703, 1, '2021-08-11 18:05:58', 'chunk_update', 'modChunk', '18'),
(704, 1, '2021-08-11 18:05:58', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(705, 1, '2021-08-12 08:47:17', 'snippet_create', 'modSnippet', '28'),
(706, 1, '2021-08-12 08:47:48', 'chunk_update', 'modChunk', '18'),
(707, 1, '2021-08-12 08:47:49', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(708, 1, '2021-08-12 08:48:27', 'snippet_update', 'modSnippet', '28'),
(709, 1, '2021-08-12 08:48:27', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(710, 1, '2021-08-12 08:48:51', 'chunk_update', 'modChunk', '18'),
(711, 1, '2021-08-12 08:48:51', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(712, 1, '2021-08-12 08:52:14', 'snippet_update', 'modSnippet', '28'),
(713, 1, '2021-08-12 08:52:14', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(714, 1, '2021-08-12 08:52:26', 'snippet_update', 'modSnippet', '28'),
(715, 1, '2021-08-12 08:52:26', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(716, 1, '2021-08-12 08:53:41', 'snippet_update', 'modSnippet', '28'),
(717, 1, '2021-08-12 08:53:42', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(718, 1, '2021-08-12 08:54:00', 'snippet_update', 'modSnippet', '28'),
(719, 1, '2021-08-12 08:54:00', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(720, 1, '2021-08-12 08:54:20', 'snippet_update', 'modSnippet', '28'),
(721, 1, '2021-08-12 08:54:20', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(722, 1, '2021-08-12 08:55:01', 'snippet_update', 'modSnippet', '28'),
(723, 1, '2021-08-12 08:55:02', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(724, 1, '2021-08-12 08:55:05', 'snippet_update', 'modSnippet', '28'),
(725, 1, '2021-08-12 08:55:05', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(726, 1, '2021-08-12 08:55:28', 'snippet_update', 'modSnippet', '28'),
(727, 1, '2021-08-12 08:55:28', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(728, 1, '2021-08-12 08:55:45', 'snippet_update', 'modSnippet', '28'),
(729, 1, '2021-08-12 08:55:45', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(730, 1, '2021-08-12 08:56:01', 'snippet_update', 'modSnippet', '28'),
(731, 1, '2021-08-12 08:56:02', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(732, 1, '2021-08-12 08:56:20', 'snippet_update', 'modSnippet', '28'),
(733, 1, '2021-08-12 08:56:21', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(734, 1, '2021-08-12 08:56:50', 'snippet_update', 'modSnippet', '28'),
(735, 1, '2021-08-12 08:56:50', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(736, 1, '2021-08-12 08:57:41', 'snippet_update', 'modSnippet', '28'),
(737, 1, '2021-08-12 08:57:41', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(738, 1, '2021-08-12 08:58:32', 'snippet_update', 'modSnippet', '28'),
(739, 1, '2021-08-12 08:58:32', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(740, 1, '2021-08-12 08:58:49', 'snippet_update', 'modSnippet', '28'),
(741, 1, '2021-08-12 08:58:49', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(742, 1, '2021-08-12 09:00:34', 'snippet_update', 'modSnippet', '28'),
(743, 1, '2021-08-12 09:00:34', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(744, 1, '2021-08-12 09:00:45', 'snippet_update', 'modSnippet', '28'),
(745, 1, '2021-08-12 09:00:46', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(746, 1, '2021-08-12 09:01:58', 'snippet_update', 'modSnippet', '28'),
(747, 1, '2021-08-12 09:01:59', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(748, 1, '2021-08-12 09:04:13', 'snippet_update', 'modSnippet', '28'),
(749, 1, '2021-08-12 09:04:13', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(750, 1, '2021-08-12 09:04:45', 'snippet_update', 'modSnippet', '28'),
(751, 1, '2021-08-12 09:04:45', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(752, 1, '2021-08-12 09:04:59', 'snippet_update', 'modSnippet', '28'),
(753, 1, '2021-08-12 09:04:59', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(754, 1, '2021-08-12 09:05:09', 'snippet_update', 'modSnippet', '28'),
(755, 1, '2021-08-12 09:05:10', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(756, 1, '2021-08-12 09:05:34', 'snippet_update', 'modSnippet', '28'),
(757, 1, '2021-08-12 09:05:34', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(758, 1, '2021-08-12 09:07:04', 'snippet_update', 'modSnippet', '28'),
(759, 1, '2021-08-12 09:07:04', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(760, 1, '2021-08-12 09:09:06', 'snippet_update', 'modSnippet', '28'),
(761, 1, '2021-08-12 09:09:06', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(762, 1, '2021-08-12 09:11:08', 'snippet_update', 'modSnippet', '28'),
(763, 1, '2021-08-12 09:11:08', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(764, 1, '2021-08-12 09:11:44', 'snippet_update', 'modSnippet', '28'),
(765, 1, '2021-08-12 09:11:44', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(766, 1, '2021-08-12 09:12:10', 'snippet_update', 'modSnippet', '28'),
(767, 1, '2021-08-12 09:12:10', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(768, 1, '2021-08-12 09:13:02', 'snippet_update', 'modSnippet', '28'),
(769, 1, '2021-08-12 09:13:03', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(770, 1, '2021-08-12 09:13:25', 'snippet_update', 'modSnippet', '28'),
(771, 1, '2021-08-12 09:13:25', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(772, 1, '2021-08-12 09:14:27', 'snippet_update', 'modSnippet', '28'),
(773, 1, '2021-08-12 09:14:27', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(774, 1, '2021-08-12 09:14:33', 'snippet_update', 'modSnippet', '28'),
(775, 1, '2021-08-12 09:14:33', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(776, 1, '2021-08-12 09:15:22', 'snippet_update', 'modSnippet', '28'),
(777, 1, '2021-08-12 09:15:23', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(778, 1, '2021-08-12 09:15:43', 'snippet_update', 'modSnippet', '28'),
(779, 1, '2021-08-12 09:15:43', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(780, 1, '2021-08-12 09:15:55', 'snippet_update', 'modSnippet', '28'),
(781, 1, '2021-08-12 09:15:56', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(782, 1, '2021-08-12 09:16:11', 'snippet_update', 'modSnippet', '28'),
(783, 1, '2021-08-12 09:16:11', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(784, 1, '2021-08-12 09:16:21', 'snippet_update', 'modSnippet', '28'),
(785, 1, '2021-08-12 09:16:21', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(786, 1, '2021-08-12 09:16:31', 'snippet_update', 'modSnippet', '28'),
(787, 1, '2021-08-12 09:16:32', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(788, 1, '2021-08-12 09:20:01', 'snippet_update', 'modSnippet', '28'),
(789, 1, '2021-08-12 09:20:01', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(790, 1, '2021-08-12 09:20:05', 'snippet_update', 'modSnippet', '28'),
(791, 1, '2021-08-12 09:20:05', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(792, 1, '2021-08-12 09:28:14', 'snippet_update', 'modSnippet', '28'),
(793, 1, '2021-08-12 09:28:14', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(794, 1, '2021-08-12 09:29:19', 'snippet_update', 'modSnippet', '28'),
(795, 1, '2021-08-12 09:29:20', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(796, 1, '2021-08-12 09:29:41', 'snippet_update', 'modSnippet', '28'),
(797, 1, '2021-08-12 09:29:41', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(798, 1, '2021-08-12 09:30:25', 'snippet_update', 'modSnippet', '28'),
(799, 1, '2021-08-12 09:30:26', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(800, 1, '2021-08-12 09:30:39', 'snippet_update', 'modSnippet', '28'),
(801, 1, '2021-08-12 09:30:39', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(802, 1, '2021-08-12 09:31:21', 'snippet_update', 'modSnippet', '28'),
(803, 1, '2021-08-12 09:31:21', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(804, 1, '2021-08-12 09:32:09', 'snippet_update', 'modSnippet', '28'),
(805, 1, '2021-08-12 09:32:09', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(806, 1, '2021-08-12 09:34:37', 'snippet_update', 'modSnippet', '28'),
(807, 1, '2021-08-12 09:34:37', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(808, 1, '2021-08-12 09:34:53', 'snippet_update', 'modSnippet', '28'),
(809, 1, '2021-08-12 09:34:53', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(810, 1, '2021-08-12 09:36:09', 'snippet_update', 'modSnippet', '28'),
(811, 1, '2021-08-12 09:36:09', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(812, 1, '2021-08-12 09:37:28', 'snippet_update', 'modSnippet', '28'),
(813, 1, '2021-08-12 09:37:28', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(814, 1, '2021-08-12 09:37:42', 'snippet_update', 'modSnippet', '28'),
(815, 1, '2021-08-12 09:37:43', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(816, 1, '2021-08-12 09:38:39', 'snippet_update', 'modSnippet', '28'),
(817, 1, '2021-08-12 09:38:39', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(818, 1, '2021-08-12 09:40:45', 'snippet_update', 'modSnippet', '28'),
(819, 1, '2021-08-12 09:40:46', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(820, 1, '2021-08-12 09:41:02', 'snippet_update', 'modSnippet', '28'),
(821, 1, '2021-08-12 09:41:03', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(822, 1, '2021-08-12 09:41:30', 'snippet_update', 'modSnippet', '28'),
(823, 1, '2021-08-12 09:41:30', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(824, 1, '2021-08-12 09:42:02', 'snippet_update', 'modSnippet', '28'),
(825, 1, '2021-08-12 09:42:03', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(826, 1, '2021-08-12 09:42:07', 'snippet_update', 'modSnippet', '28'),
(827, 1, '2021-08-12 09:42:08', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(828, 1, '2021-08-12 09:42:39', 'snippet_update', 'modSnippet', '28'),
(829, 1, '2021-08-12 09:42:39', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(830, 1, '2021-08-12 09:43:01', 'snippet_update', 'modSnippet', '28'),
(831, 1, '2021-08-12 09:43:02', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(832, 1, '2021-08-12 09:43:53', 'snippet_update', 'modSnippet', '28'),
(833, 1, '2021-08-12 09:43:53', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(834, 1, '2021-08-12 09:45:01', 'snippet_update', 'modSnippet', '28'),
(835, 1, '2021-08-12 09:45:01', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(836, 1, '2021-08-12 09:45:19', 'snippet_update', 'modSnippet', '28'),
(837, 1, '2021-08-12 09:45:20', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(838, 1, '2021-08-12 09:46:16', 'snippet_update', 'modSnippet', '28'),
(839, 1, '2021-08-12 09:46:17', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(840, 1, '2021-08-12 09:46:38', 'snippet_update', 'modSnippet', '28'),
(841, 1, '2021-08-12 09:46:38', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(842, 1, '2021-08-12 09:46:54', 'snippet_update', 'modSnippet', '28'),
(843, 1, '2021-08-12 09:46:54', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(844, 1, '2021-08-12 09:47:05', 'snippet_update', 'modSnippet', '28'),
(845, 1, '2021-08-12 09:47:05', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(846, 1, '2021-08-12 09:47:34', 'snippet_update', 'modSnippet', '28'),
(847, 1, '2021-08-12 09:47:34', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(848, 1, '2021-08-12 09:48:03', 'chunk_update', 'modChunk', '18'),
(849, 1, '2021-08-12 09:48:04', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(850, 1, '2021-08-12 09:48:42', 'chunk_update', 'modChunk', '18'),
(851, 1, '2021-08-12 09:48:42', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(852, 1, '2021-08-12 09:49:12', 'chunk_update', 'modChunk', '18'),
(853, 1, '2021-08-12 09:49:12', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(854, 1, '2021-08-12 09:50:24', 'chunk_update', 'modChunk', '18'),
(855, 1, '2021-08-12 09:50:24', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(856, 1, '2021-08-12 09:52:03', 'snippet_update', 'modSnippet', '28'),
(857, 1, '2021-08-12 09:52:03', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(858, 1, '2021-08-12 09:53:48', 'chunk_update', 'modChunk', '18'),
(859, 1, '2021-08-12 09:53:49', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(860, 1, '2021-08-12 09:54:20', 'chunk_update', 'modChunk', '18'),
(861, 1, '2021-08-12 09:54:21', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(862, 1, '2021-08-12 09:55:23', 'chunk_update', 'modChunk', '18'),
(863, 1, '2021-08-12 09:55:24', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 18 Default'),
(864, 1, '2021-08-12 10:00:56', 'snippet_update', 'modSnippet', '28'),
(865, 1, '2021-08-12 10:00:56', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 28 Default'),
(866, 1, '2021-08-12 10:10:19', 'login', 'modContext', 'mgr'),
(867, 1, '2021-08-12 10:39:19', 'chunk_create', 'modChunk', '19'),
(868, 1, '2021-08-12 10:41:12', 'resource_update', 'modResource', '1'),
(869, 1, '2021-08-12 10:43:31', 'snippet_create', 'modSnippet', '29'),
(870, 1, '2021-08-12 10:43:57', 'resource_update', 'modResource', '1'),
(871, 1, '2021-08-12 10:46:40', 'snippet_update', 'modSnippet', '29'),
(872, 1, '2021-08-12 10:46:40', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(873, 1, '2021-08-12 10:46:49', 'snippet_update', 'modSnippet', '29'),
(874, 1, '2021-08-12 10:46:50', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(875, 1, '2021-08-12 10:47:36', 'snippet_update', 'modSnippet', '29'),
(876, 1, '2021-08-12 10:47:37', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(877, 1, '2021-08-12 10:48:09', 'snippet_update', 'modSnippet', '29'),
(878, 1, '2021-08-12 10:48:09', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(879, 1, '2021-08-12 10:48:43', 'snippet_update', 'modSnippet', '29'),
(880, 1, '2021-08-12 10:48:43', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(881, 1, '2021-08-12 10:52:04', 'snippet_update', 'modSnippet', '29'),
(882, 1, '2021-08-12 10:52:04', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(883, 1, '2021-08-12 10:53:22', 'snippet_update', 'modSnippet', '29'),
(884, 1, '2021-08-12 10:53:22', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(885, 1, '2021-08-12 10:54:08', 'snippet_update', 'modSnippet', '29'),
(886, 1, '2021-08-12 10:54:08', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(887, 1, '2021-08-12 11:10:15', 'snippet_update', 'modSnippet', '29'),
(888, 1, '2021-08-12 11:10:15', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(889, 1, '2021-08-12 11:10:24', 'snippet_update', 'modSnippet', '29'),
(890, 1, '2021-08-12 11:10:25', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(891, 1, '2021-08-12 11:10:28', 'snippet_update', 'modSnippet', '29'),
(892, 1, '2021-08-12 11:10:28', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(893, 1, '2021-08-12 11:10:49', 'snippet_update', 'modSnippet', '29'),
(894, 1, '2021-08-12 11:10:50', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(895, 1, '2021-08-12 11:11:37', 'snippet_update', 'modSnippet', '29'),
(896, 1, '2021-08-12 11:11:38', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(897, 1, '2021-08-12 11:11:58', 'snippet_update', 'modSnippet', '29'),
(898, 1, '2021-08-12 11:11:59', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(899, 1, '2021-08-12 11:12:16', 'snippet_update', 'modSnippet', '29'),
(900, 1, '2021-08-12 11:12:16', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(901, 1, '2021-08-12 11:15:28', 'snippet_update', 'modSnippet', '29'),
(902, 1, '2021-08-12 11:15:29', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(903, 1, '2021-08-12 11:15:59', 'setting_update', 'modSystemSetting', 'log_deprecated'),
(904, 1, '2021-08-12 11:17:48', 'snippet_update', 'modSnippet', '29'),
(905, 1, '2021-08-12 11:17:49', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(906, 1, '2021-08-12 11:18:06', 'snippet_update', 'modSnippet', '29'),
(907, 1, '2021-08-12 11:18:06', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(908, 1, '2021-08-12 11:18:46', 'snippet_update', 'modSnippet', '29'),
(909, 1, '2021-08-12 11:18:47', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(910, 1, '2021-08-12 11:18:58', 'snippet_update', 'modSnippet', '29'),
(911, 1, '2021-08-12 11:18:59', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(912, 1, '2021-08-12 11:19:18', 'snippet_update', 'modSnippet', '29'),
(913, 1, '2021-08-12 11:19:19', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(914, 1, '2021-08-12 11:19:27', 'snippet_update', 'modSnippet', '29'),
(915, 1, '2021-08-12 11:19:27', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(916, 1, '2021-08-12 11:19:37', 'snippet_update', 'modSnippet', '29'),
(917, 1, '2021-08-12 11:19:37', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(918, 1, '2021-08-12 11:19:57', 'snippet_update', 'modSnippet', '29'),
(919, 1, '2021-08-12 11:19:57', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(920, 1, '2021-08-12 11:20:54', 'snippet_update', 'modSnippet', '29'),
(921, 1, '2021-08-12 11:20:54', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(922, 1, '2021-08-12 11:26:59', 'snippet_update', 'modSnippet', '29'),
(923, 1, '2021-08-12 11:26:59', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(924, 1, '2021-08-12 11:27:18', 'snippet_update', 'modSnippet', '29'),
(925, 1, '2021-08-12 11:27:19', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(926, 1, '2021-08-12 11:27:34', 'snippet_update', 'modSnippet', '29'),
(927, 1, '2021-08-12 11:27:34', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(928, 1, '2021-08-12 11:27:41', 'snippet_update', 'modSnippet', '29'),
(929, 1, '2021-08-12 11:27:42', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(930, 1, '2021-08-12 11:28:11', 'snippet_update', 'modSnippet', '29'),
(931, 1, '2021-08-12 11:28:11', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(932, 1, '2021-08-12 11:28:20', 'snippet_update', 'modSnippet', '29'),
(933, 1, '2021-08-12 11:28:20', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(934, 1, '2021-08-12 11:28:31', 'snippet_update', 'modSnippet', '29'),
(935, 1, '2021-08-12 11:28:31', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(936, 1, '2021-08-12 11:29:20', 'snippet_update', 'modSnippet', '29'),
(937, 1, '2021-08-12 11:29:21', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(938, 1, '2021-08-12 11:29:45', 'snippet_update', 'modSnippet', '29'),
(939, 1, '2021-08-12 11:29:45', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(940, 1, '2021-08-12 11:29:54', 'snippet_update', 'modSnippet', '29'),
(941, 1, '2021-08-12 11:29:54', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(942, 1, '2021-08-12 11:31:34', 'snippet_update', 'modSnippet', '29'),
(943, 1, '2021-08-12 11:31:34', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(944, 1, '2021-08-12 11:31:48', 'snippet_update', 'modSnippet', '29'),
(945, 1, '2021-08-12 11:31:48', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(946, 1, '2021-08-12 11:32:06', 'chunk_update', 'modChunk', '19'),
(947, 1, '2021-08-12 11:32:06', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 19 Default'),
(948, 1, '2021-08-12 11:32:48', 'snippet_update', 'modSnippet', '29'),
(949, 1, '2021-08-12 11:32:48', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(950, 1, '2021-08-12 11:33:51', 'snippet_update', 'modSnippet', '29'),
(951, 1, '2021-08-12 11:33:51', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(952, 1, '2021-08-12 11:34:24', 'resource_update', 'modResource', '1'),
(953, 1, '2021-08-12 11:38:13', 'snippet_update', 'modSnippet', '29'),
(954, 1, '2021-08-12 11:38:13', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(955, 1, '2021-08-12 11:38:30', 'snippet_update', 'modSnippet', '29'),
(956, 1, '2021-08-12 11:38:30', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(957, 1, '2021-08-12 11:39:50', 'snippet_update', 'modSnippet', '29'),
(958, 1, '2021-08-12 11:39:51', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(959, 1, '2021-08-12 11:40:08', 'snippet_update', 'modSnippet', '29'),
(960, 1, '2021-08-12 11:40:08', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(961, 1, '2021-08-12 11:41:02', 'snippet_update', 'modSnippet', '29'),
(962, 1, '2021-08-12 11:41:02', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(963, 1, '2021-08-12 11:41:26', 'resource_update', 'modResource', '1'),
(964, 1, '2021-08-12 11:41:47', 'snippet_update', 'modSnippet', '29'),
(965, 1, '2021-08-12 11:41:47', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(966, 1, '2021-08-12 11:41:58', 'snippet_update', 'modSnippet', '29'),
(967, 1, '2021-08-12 11:41:58', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(968, 1, '2021-08-12 11:44:31', 'snippet_update', 'modSnippet', '29'),
(969, 1, '2021-08-12 11:44:32', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(970, 1, '2021-08-12 11:45:21', 'snippet_update', 'modSnippet', '29'),
(971, 1, '2021-08-12 11:45:22', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(972, 1, '2021-08-12 11:47:10', 'snippet_update', 'modSnippet', '29'),
(973, 1, '2021-08-12 11:47:11', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(974, 1, '2021-08-12 11:47:40', 'snippet_update', 'modSnippet', '29'),
(975, 1, '2021-08-12 11:47:40', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(976, 1, '2021-08-12 11:53:13', 'snippet_update', 'modSnippet', '29'),
(977, 1, '2021-08-12 11:53:14', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(978, 1, '2021-08-12 11:53:25', 'snippet_update', 'modSnippet', '29'),
(979, 1, '2021-08-12 11:53:25', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(980, 1, '2021-08-12 11:54:01', 'snippet_update', 'modSnippet', '29'),
(981, 1, '2021-08-12 11:54:01', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(982, 1, '2021-08-12 11:54:12', 'snippet_update', 'modSnippet', '29'),
(983, 1, '2021-08-12 11:54:12', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(984, 1, '2021-08-12 11:54:25', 'snippet_update', 'modSnippet', '29'),
(985, 1, '2021-08-12 11:54:26', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(986, 1, '2021-08-12 11:54:44', 'snippet_update', 'modSnippet', '29'),
(987, 1, '2021-08-12 11:54:44', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(988, 1, '2021-08-12 11:55:11', 'snippet_update', 'modSnippet', '29'),
(989, 1, '2021-08-12 11:55:11', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(990, 1, '2021-08-12 11:55:23', 'snippet_update', 'modSnippet', '29'),
(991, 1, '2021-08-12 11:55:23', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(992, 1, '2021-08-12 11:56:19', 'snippet_update', 'modSnippet', '29'),
(993, 1, '2021-08-12 11:56:19', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(994, 1, '2021-08-12 11:56:45', 'snippet_update', 'modSnippet', '29'),
(995, 1, '2021-08-12 11:56:45', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(996, 1, '2021-08-12 11:57:00', 'snippet_update', 'modSnippet', '29'),
(997, 1, '2021-08-12 11:57:01', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(998, 1, '2021-08-12 11:57:08', 'snippet_update', 'modSnippet', '29'),
(999, 1, '2021-08-12 11:57:09', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1000, 1, '2021-08-12 11:57:17', 'snippet_update', 'modSnippet', '29'),
(1001, 1, '2021-08-12 11:57:18', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1002, 1, '2021-08-12 11:59:27', 'snippet_update', 'modSnippet', '29'),
(1003, 1, '2021-08-12 11:59:27', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1004, 1, '2021-08-12 12:00:05', 'snippet_update', 'modSnippet', '29'),
(1005, 1, '2021-08-12 12:00:06', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1006, 1, '2021-08-12 12:01:42', 'snippet_update', 'modSnippet', '29'),
(1007, 1, '2021-08-12 12:01:43', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1008, 1, '2021-08-12 12:06:39', 'snippet_update', 'modSnippet', '29'),
(1009, 1, '2021-08-12 12:06:39', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1010, 1, '2021-08-12 12:06:54', 'snippet_update', 'modSnippet', '29'),
(1011, 1, '2021-08-12 12:06:54', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1012, 1, '2021-08-12 12:07:29', 'snippet_update', 'modSnippet', '29'),
(1013, 1, '2021-08-12 12:07:30', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1014, 1, '2021-08-12 12:07:43', 'snippet_update', 'modSnippet', '29'),
(1015, 1, '2021-08-12 12:07:43', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1016, 1, '2021-08-12 12:08:10', 'snippet_update', 'modSnippet', '29'),
(1017, 1, '2021-08-12 12:08:10', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1018, 1, '2021-08-12 12:08:25', 'snippet_update', 'modSnippet', '29'),
(1019, 1, '2021-08-12 12:08:25', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1020, 1, '2021-08-12 12:09:36', 'snippet_update', 'modSnippet', '29'),
(1021, 1, '2021-08-12 12:09:37', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1022, 1, '2021-08-12 12:09:52', 'snippet_update', 'modSnippet', '29'),
(1023, 1, '2021-08-12 12:09:53', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1024, 1, '2021-08-12 12:10:03', 'snippet_update', 'modSnippet', '29'),
(1025, 1, '2021-08-12 12:10:04', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1026, 1, '2021-08-12 12:10:31', 'snippet_update', 'modSnippet', '29'),
(1027, 1, '2021-08-12 12:10:31', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1028, 1, '2021-08-12 12:11:32', 'snippet_update', 'modSnippet', '29'),
(1029, 1, '2021-08-12 12:11:33', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1030, 1, '2021-08-12 12:16:04', 'chunk_update', 'modChunk', '19'),
(1031, 1, '2021-08-12 12:16:05', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 19 Default'),
(1032, 1, '2021-08-12 12:20:35', 'snippet_update', 'modSnippet', '29'),
(1033, 1, '2021-08-12 12:20:36', 'propertyset_update_from_element', 'modPropertySet', 'modSnippet 29 Default'),
(1034, 1, '2021-08-12 12:39:10', 'chunk_update', 'modChunk', '19'),
(1035, 1, '2021-08-12 12:39:10', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 19 Default'),
(1036, 1, '2021-08-12 12:39:49', 'chunk_update', 'modChunk', '19'),
(1037, 1, '2021-08-12 12:39:50', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 19 Default'),
(1038, 1, '2021-08-12 12:48:20', 'chunk_create', 'modChunk', '20'),
(1039, 1, '2021-08-12 12:48:47', 'chunk_duplicate', 'modChunk', '21'),
(1040, 1, '2021-08-12 12:49:21', 'chunk_update', 'modChunk', '21'),
(1041, 1, '2021-08-12 12:49:22', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 21 Default'),
(1042, 1, '2021-08-12 12:49:29', 'chunk_update', 'modChunk', '21'),
(1043, 1, '2021-08-12 12:49:29', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 21 Default'),
(1044, 1, '2021-08-12 12:49:46', 'chunk_duplicate', 'modChunk', '22'),
(1045, 1, '2021-08-12 12:50:12', 'chunk_update', 'modChunk', '22'),
(1046, 1, '2021-08-12 12:50:12', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 22 Default'),
(1047, 1, '2021-08-12 12:55:53', 'package_uninstall', 'transport.modTransportPackage', 'unknown'),
(1048, 1, '2021-08-12 13:00:13', 'clear_cache', '', 'mgr'),
(1049, 1, '2021-08-12 13:00:17', 'clear_cache', '', 'mgr'),
(1050, 1, '2021-08-12 13:03:42', 'setting_update', 'modSystemSetting', 'which_element_editor'),
(1051, 1, '2021-08-12 13:06:42', 'setting_update', 'modSystemSetting', 'locale'),
(1052, 1, '2021-08-12 13:07:01', 'setting_update', 'modSystemSetting', 'locale'),
(1053, 1, '2021-08-12 13:47:39', 'plugin_update', 'modPlugin', '1'),
(1054, 1, '2021-08-12 13:47:40', 'propertyset_update_from_element', 'modPropertySet', 'modPlugin 1 Default'),
(1055, 1, '2021-08-12 13:48:04', 'plugin_update', 'modPlugin', '1'),
(1056, 1, '2021-08-12 13:48:04', 'propertyset_update_from_element', 'modPropertySet', 'modPlugin 1 Default'),
(1057, 1, '2021-08-12 13:48:30', 'package_uninstall', 'transport.modTransportPackage', 'unknown'),
(1058, 1, '2021-08-12 13:58:31', 'template_update', 'modTemplate', '3'),
(1059, 1, '2021-08-12 13:59:23', 'template_update', 'modTemplate', '3'),
(1060, 1, '2021-08-12 14:07:39', 'template_update', 'modTemplate', '3'),
(1061, 1, '2021-08-12 14:07:39', 'propertyset_update_from_element', 'modPropertySet', 'modTemplate 3 Default'),
(1062, 1, '2021-08-12 14:08:21', 'resource_update', 'modResource', '1'),
(1063, 1, '2021-08-12 14:09:59', 'resource_update', 'modResource', '1'),
(1064, 1, '2021-08-12 14:20:45', 'chunk_update', 'modChunk', '22'),
(1065, 1, '2021-08-12 14:20:45', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 22 Default'),
(1066, 1, '2021-08-12 14:21:38', 'chunk_update', 'modChunk', '21'),
(1067, 1, '2021-08-12 14:21:38', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 21 Default'),
(1068, 1, '2021-08-12 14:21:53', 'chunk_update', 'modChunk', '20'),
(1069, 1, '2021-08-12 14:21:53', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 20 Default'),
(1070, 1, '2021-08-12 14:22:51', 'resource_update', 'modResource', '1'),
(1071, 1, '2021-08-12 14:23:27', 'resource_update', 'modResource', '1'),
(1072, 1, '2021-08-12 14:24:41', 'resource_update', 'modResource', '1'),
(1073, 1, '2021-08-12 14:25:16', 'chunk_update', 'modChunk', '22'),
(1074, 1, '2021-08-12 14:25:16', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 22 Default'),
(1075, 1, '2021-08-12 14:25:44', 'chunk_update', 'modChunk', '22'),
(1076, 1, '2021-08-12 14:25:44', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 22 Default'),
(1077, 1, '2021-08-12 14:26:23', 'chunk_update', 'modChunk', '22'),
(1078, 1, '2021-08-12 14:26:23', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 22 Default'),
(1079, 1, '2021-08-12 14:27:52', 'resource_update', 'modResource', '1'),
(1080, 1, '2021-08-12 14:28:51', 'chunk_update', 'modChunk', '20'),
(1081, 1, '2021-08-12 14:28:51', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 20 Default'),
(1082, 1, '2021-08-12 14:29:39', 'resource_update', 'modResource', '1'),
(1083, 1, '2021-08-12 14:30:18', 'chunk_update', 'modChunk', '21'),
(1084, 1, '2021-08-12 14:30:18', 'propertyset_update_from_element', 'modPropertySet', 'modChunk 21 Default'),
(1085, 1, '2021-08-12 14:31:07', 'resource_update', 'modResource', '1'),
(1086, 1, '2021-08-12 14:31:23', 'resource_update', 'modResource', '1'),
(1087, 1, '2021-08-12 14:34:07', 'resource_update', 'modResource', '1'),
(1088, 1, '2021-08-12 14:35:19', 'resource_update', 'modResource', '1'),
(1089, 1, '2021-10-29 09:58:02', 'login', 'modContext', 'mgr'),
(1090, 1, '2021-10-29 10:03:15', 'collections.template.column_create', 'CollectionTemplateColumn', '10');

-- --------------------------------------------------------

--
-- Table structure for table `modx_media_sources`
--

CREATE TABLE `modx_media_sources` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `class_key` varchar(100) NOT NULL DEFAULT 'sources.modFileMediaSource',
  `properties` mediumtext,
  `is_stream` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_media_sources`
--

INSERT INTO `modx_media_sources` (`id`, `name`, `description`, `class_key`, `properties`, `is_stream`) VALUES
(1, 'Filesystem', '', 'sources.modFileMediaSource', 'a:0:{}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_media_sources_contexts`
--

CREATE TABLE `modx_media_sources_contexts` (
  `source` int(11) NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_media_sources_elements`
--

CREATE TABLE `modx_media_sources_elements` (
  `source` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `object_class` varchar(100) NOT NULL DEFAULT 'modTemplateVar',
  `object` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_media_sources_elements`
--

INSERT INTO `modx_media_sources_elements` (`source`, `object_class`, `object`, `context_key`) VALUES
(1, 'modTemplateVar', 1, 'web'),
(1, 'modTemplateVar', 2, 'web'),
(1, 'modTemplateVar', 3, 'web');

-- --------------------------------------------------------

--
-- Table structure for table `modx_membergroup_names`
--

CREATE TABLE `modx_membergroup_names` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `dashboard` int(10) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_membergroup_names`
--

INSERT INTO `modx_membergroup_names` (`id`, `name`, `description`, `parent`, `rank`, `dashboard`) VALUES
(1, 'Administrator', NULL, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_member_groups`
--

CREATE TABLE `modx_member_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `member` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `role` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_member_groups`
--

INSERT INTO `modx_member_groups` (`id`, `user_group`, `member`, `role`, `rank`) VALUES
(1, 1, 1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_menus`
--

CREATE TABLE `modx_menus` (
  `text` varchar(191) NOT NULL DEFAULT '',
  `parent` varchar(191) NOT NULL DEFAULT '',
  `action` varchar(191) NOT NULL DEFAULT '',
  `description` varchar(191) NOT NULL DEFAULT '',
  `icon` varchar(191) NOT NULL DEFAULT '',
  `menuindex` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `handler` text NOT NULL,
  `permissions` text NOT NULL,
  `namespace` varchar(100) NOT NULL DEFAULT 'core'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_menus`
--

INSERT INTO `modx_menus` (`text`, `parent`, `action`, `description`, `icon`, `menuindex`, `params`, `handler`, `permissions`, `namespace`) VALUES
('about', 'usernav', 'help', '', '<i class=\"icon-question-circle icon icon-large\"></i>', 7, '', '', 'help', 'core'),
('acls', 'admin', 'security/permission', 'acls_desc', '', 5, '', '', 'access_permissions', 'core'),
('admin', 'usernav', '', '', '<i class=\"icon-gear icon icon-large\"></i>', 6, '', '', 'settings', 'core'),
('bespoke_manager', 'admin', 'security/forms', 'bespoke_manager_desc', '', 1, '', '', 'customize_forms', 'core'),
('collections.menu.collection_templates', 'components', 'home', 'collections.menu.collection_templates_desc', '', 0, '', '', '', 'collections'),
('components', 'topnav', '', '', '', 2, '', '', 'components', 'core'),
('content_types', 'site', 'system/contenttype', 'content_types_desc', '', 8, '', '', 'content_types', 'core'),
('contexts', 'admin', 'context', 'contexts_desc', '', 3, '', '', 'view_context', 'core'),
('dashboards', 'admin', 'system/dashboards', 'dashboards_desc', '', 2, '', '', 'dashboards', 'core'),
('edit_menu', 'admin', 'system/action', 'edit_menu_desc', '', 4, '', '', 'actions', 'core'),
('eventlog_viewer', 'reports', 'system/event', 'eventlog_viewer_desc', '', 2, '', '', 'view_eventlog', 'core'),
('file_browser', 'media', 'media/browser', 'file_browser_desc', '', 0, '', '', 'file_manager', 'core'),
('flush_access', 'manage', '', 'flush_access_desc', '', 3, '', 'MODx.msg.confirm({\n    title: _(\'flush_access\')\n    ,text: _(\'flush_access_confirm\')\n    ,url: MODx.config.connector_url\n    ,params: {\n        action: \'security/access/flush\'\n    }\n    ,listeners: {\n        \'success\': {fn:function() { location.href = \'./\'; },scope:this},\n        \'failure\': {fn:function(response) { Ext.MessageBox.alert(\'failure\', response.responseText); },scope:this},\n    }\n});', 'access_permissions', 'core'),
('flush_sessions', 'manage', '', 'flush_sessions_desc', '', 4, '', 'MODx.msg.confirm({\n    title: _(\'flush_sessions\')\n    ,text: _(\'flush_sessions_confirm\')\n    ,url: MODx.config.connector_url\n    ,params: {\n        action: \'security/flush\'\n    }\n    ,listeners: {\n        \'success\': {fn:function() { location.href = \'./\'; },scope:this}\n    }\n});', 'flush_sessions', 'core'),
('import_resources', 'site', 'system/import', 'import_resources_desc', '', 6, '', '', 'import_static', 'core'),
('import_site', 'site', 'system/import/html', 'import_site_desc', '', 5, '', '', 'import_static', 'core'),
('installer', 'components', 'workspaces', 'installer_desc', '', 0, '', '', 'packages', 'core'),
('lexicon_management', 'admin', 'workspaces/lexicon', 'lexicon_management_desc', '', 7, '', '', 'lexicons', 'core'),
('lingua', 'components', '5', 'lingua_desc', 'images/icons/plugin.gif', 0, '', '', '', 'core'),
('logout', 'user', 'security/logout', 'logout_desc', '', 2, '', 'MODx.logout(); return false;', 'logout', 'core'),
('manage', 'topnav', '', '', '', 3, '', '', 'menu_tools', 'core'),
('media', 'topnav', '', 'media_desc', '', 1, '', '', 'file_manager', 'core'),
('messages', 'user', 'security/message', 'messages_desc', '', 1, '', '', 'messages', 'core'),
('namespaces', 'admin', 'workspaces/namespace', 'namespaces_desc', '', 8, '', '', 'namespaces', 'core'),
('new_resource', 'site', 'resource/create', 'new_resource_desc', '', 0, '', '', 'new_document', 'core'),
('preview', 'site', '', 'preview_desc', '', 4, '', 'MODx.preview(); return false;', '', 'core'),
('profile', 'user', 'security/profile', 'profile_desc', '', 0, '', '', 'change_profile', 'core'),
('propertysets', 'admin', 'element/propertyset', 'propertysets_desc', '', 6, '', '', 'property_sets', 'core'),
('refreshuris', 'refresh_site', '', 'refreshuris_desc', '', 0, '', 'MODx.refreshURIs(); return false;', 'empty_cache', 'core'),
('refresh_site', 'manage', '', 'refresh_site_desc', '', 1, '', 'MODx.clearCache(); return false;', 'empty_cache', 'core'),
('remove_locks', 'manage', '', 'remove_locks_desc', '', 2, '', 'MODx.removeLocks();return false;', 'remove_locks', 'core'),
('reports', 'manage', '', 'reports_desc', '', 5, '', '', 'menu_reports', 'core'),
('resource_groups', 'site', 'security/resourcegroup', 'resource_groups_desc', '', 7, '', '', 'access_permissions', 'core'),
('site', 'topnav', '', '', '', 0, '', '', 'menu_site', 'core'),
('site_schedule', 'reports', 'resource/site_schedule', 'site_schedule_desc', '', 0, '', '', 'view_document', 'core'),
('sources', 'media', 'source', 'sources_desc', '', 1, '', '', 'sources', 'core'),
('system_settings', 'admin', 'system/settings', 'system_settings_desc', '', 0, '', '', 'settings', 'core'),
('topnav', '', '', 'topnav_desc', '', 0, '', '', '', 'core'),
('user', 'usernav', '', '', '<span id=\"user-avatar\">{$userImage}</span> <span id=\"user-username\">{$username}</span>', 5, '', '', 'menu_user', 'core'),
('usernav', '', '', 'usernav_desc', '', 0, '', '', '', 'core'),
('users', 'manage', 'security/user', 'user_management_desc', '', 0, '', '', 'view_user', 'core'),
('view_logging', 'reports', 'system/logs', 'view_logging_desc', '', 1, '', '', 'logs', 'core'),
('view_sysinfo', 'reports', 'system/info', 'view_sysinfo_desc', '', 3, '', '', 'view_sysinfo', 'core');

-- --------------------------------------------------------

--
-- Table structure for table `modx_namespaces`
--

CREATE TABLE `modx_namespaces` (
  `name` varchar(40) NOT NULL DEFAULT '',
  `path` text,
  `assets_path` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_namespaces`
--

INSERT INTO `modx_namespaces` (`name`, `path`, `assets_path`) VALUES
('ace', '{core_path}components/ace/', ''),
('collections', '{core_path}components/collections/', '{assets_path}components/collections/'),
('core', '{core_path}', '{assets_path}'),
('lingua', '{core_path}components/lingua/', '{assets_path}components/lingua/'),
('pdotools', '{core_path}components/pdotools/', ''),
('wayfinder', '{core_path}components/wayfinder/', '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_property_set`
--

CREATE TABLE `modx_property_set` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `category` int(10) NOT NULL DEFAULT '0',
  `description` varchar(191) NOT NULL DEFAULT '',
  `properties` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_register_messages`
--

CREATE TABLE `modx_register_messages` (
  `topic` int(10) UNSIGNED NOT NULL,
  `id` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `valid` datetime NOT NULL,
  `accessed` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `accesses` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `expires` int(20) NOT NULL DEFAULT '0',
  `payload` mediumtext NOT NULL,
  `kill` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_register_messages`
--

INSERT INTO `modx_register_messages` (`topic`, `id`, `created`, `valid`, `accessed`, `accesses`, `expires`, `payload`, `kill`) VALUES
(1, 'c74d97b01eae257e44aa9d5bade97baf', '2021-08-11 16:21:12', '2021-08-11 16:21:12', NULL, 0, 1628688432, 'if (time() > 1628688432) return null;\nreturn 1;\n', 0),
(1, 'e369853df766fa44e1ed0ff613f563bd', '2021-08-11 16:55:08', '2021-08-11 16:55:08', NULL, 0, 1628690468, 'if (time() > 1628690468) return null;\nreturn 1;\n', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_register_queues`
--

CREATE TABLE `modx_register_queues` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `options` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_register_queues`
--

INSERT INTO `modx_register_queues` (`id`, `name`, `options`) VALUES
(1, 'locks', 'a:1:{s:9:\"directory\";s:5:\"locks\";}'),
(2, 'resource_reload', 'a:1:{s:9:\"directory\";s:15:\"resource_reload\";}');

-- --------------------------------------------------------

--
-- Table structure for table `modx_register_topics`
--

CREATE TABLE `modx_register_topics` (
  `id` int(10) UNSIGNED NOT NULL,
  `queue` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `options` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_register_topics`
--

INSERT INTO `modx_register_topics` (`id`, `queue`, `name`, `created`, `updated`, `options`) VALUES
(1, 1, '/resource/', '2021-08-06 13:17:51', NULL, NULL),
(2, 2, '/resourcereload/', '2021-08-11 13:57:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_session`
--

CREATE TABLE `modx_session` (
  `id` varchar(191) NOT NULL DEFAULT '',
  `access` int(20) UNSIGNED NOT NULL,
  `data` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_session`
--

INSERT INTO `modx_session` (`id`, `access`, `data`) VALUES
('1d85c09632ec618c903d194f8e82cfb5', 1628495442, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}cultureKey|s:2:\"ru\";modx.mgr.user.token|s:52:\"modx610d0af8630c32.23114400_16110d3dba5c229.92289840\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:11:{i:0;s:23:\"6110d3dc2d8423.95343928\";i:1;s:23:\"6110d53cde7b36.43949190\";i:2;s:23:\"6110d994de9e18.81307981\";i:3;s:23:\"6110da83e9b9c3.21868635\";i:4;s:23:\"6110dbb4bc22c0.31512227\";i:5;s:23:\"6110dbd7090601.71098690\";i:6;s:23:\"6110dc4d1c5b47.10927038\";i:7;s:23:\"6110dc5ae2e029.15830945\";i:8;s:23:\"6110dc818ad362.05364319\";i:9;s:23:\"6110dcf3e736d6.32533180\";i:10;s:23:\"6110dd114a2e46.51775176\";}modx.user.1.userGroups|a:1:{i:0;i:1;}'),
('34fb160d1f2a93fbb335a8ad95936f0a', 1628768197, 'modx.user.0.resourceGroups|a:1:{s:3:\"mgr\";a:0:{}}modx.user.0.attributes|a:2:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}s:3:\"mgr\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}cultureKey|s:2:\"en\";modx.mgr.user.token|s:52:\"modx610d0af8630c32.23114400_16110e0ce8fb127.76491713\";modx.mgr.session.cookie.lifetime|i:604800;modx.mgr.user.config|a:0:{}newResourceTokens|a:266:{i:0;s:23:\"6110e184813798.57344438\";i:1;s:23:\"6110e2b52f1a11.28751725\";i:2;s:23:\"61111f0b3640c2.63845827\";i:3;s:23:\"611136349a5640.15924330\";i:4;s:23:\"6112193bf28999.42707902\";i:5;s:23:\"61121ab011f4e2.60937542\";i:6;s:23:\"61121da437e7d8.11023898\";i:7;s:23:\"61124ef25328f5.41724420\";i:8;s:23:\"6112755a94bd55.88135141\";i:9;s:23:\"61128e9aa3f603.45645899\";i:10;s:23:\"61128f2bee1221.11732503\";i:11;s:23:\"61128f376da650.14864161\";i:12;s:23:\"61128fbdc7b8e7.07558361\";i:13;s:23:\"61128fe9032f31.02723361\";i:14;s:23:\"611290537f6645.51102009\";i:15;s:23:\"6112907f0ed3e4.45515271\";i:16;s:23:\"6112922b7fa771.91127799\";i:17;s:23:\"611292afc9e662.33516409\";i:18;s:23:\"61129326cef512.85821692\";i:19;s:23:\"6112932f6b2c05.62621085\";i:20;s:23:\"611374fc51d130.88454384\";i:21;s:23:\"611377ee280cc6.16193566\";i:22;s:23:\"611378741a1489.79137499\";i:23;s:23:\"6113789a6b0c30.39212702\";i:24;s:23:\"611379344a9992.11485952\";i:25;s:23:\"61137a59c2ed56.79955665\";i:26;s:23:\"61137a5d9dd2e0.66529494\";i:27;s:23:\"61138047547ff6.67107599\";i:28;s:23:\"61139af1533b54.81898769\";i:29;s:23:\"61139e6f81a3b4.07301588\";i:30;s:23:\"61139ea2733d94.54844229\";i:31;s:23:\"6113a85e310661.19791216\";i:32;s:23:\"6113ac62cde0f5.34126173\";i:33;s:23:\"6113ac6f841276.78442323\";i:34;s:23:\"6113ac7bd3e916.66537543\";i:35;s:23:\"6113acbbb4efd9.95777145\";i:36;s:23:\"6113acec9ff551.66043514\";i:37;s:23:\"6113acf1b95230.73692967\";i:38;s:23:\"6113ad0d2b42e1.44734671\";i:39;s:23:\"6113ad62ae4ff8.38959342\";i:40;s:23:\"6113ad6d183972.17208542\";i:41;s:23:\"6113afc388a678.88181618\";i:42;s:23:\"6113b0027b7237.50760518\";i:43;s:23:\"6113b006274443.80854043\";i:44;s:23:\"6113b030456ff5.34142227\";i:45;s:23:\"6113b0bc6a44b0.68841684\";i:46;s:23:\"6113b0c4b7fab4.53075401\";i:47;s:23:\"6113b0d89355f3.88636615\";i:48;s:23:\"6113b10a2635d8.59012854\";i:49;s:23:\"6113b12add9268.01400253\";i:50;s:23:\"6113b157109691.21333876\";i:51;s:23:\"6113b16a2862d4.35025484\";i:52;s:23:\"6113b172632db6.30373769\";i:53;s:23:\"6113b19f3c2c26.22014748\";i:54;s:23:\"6113b1a524acb9.56024127\";i:55;s:23:\"6113b1d9aebfd2.94498884\";i:56;s:23:\"6113b1decd13e1.90560151\";i:57;s:23:\"6113b210388e51.98478233\";i:58;s:23:\"6113b224ade476.78776341\";i:59;s:23:\"6113b29f2a78f2.29813466\";i:60;s:23:\"6113b2acb6b9c8.47993751\";i:61;s:23:\"6113b2bdbf0cb6.93826465\";i:62;s:23:\"6113b2c7271b96.70499689\";i:63;s:23:\"6113b2dd5d51c2.09691448\";i:64;s:23:\"6113b33fdae889.63983676\";i:65;s:23:\"6113b3da914d30.93355780\";i:66;s:23:\"6113b432ecdd32.36828678\";i:67;s:23:\"6113b448df4864.90842054\";i:68;s:23:\"6113b45f168989.63279526\";i:69;s:23:\"6113b5f7d4fac3.81215621\";i:70;s:23:\"6113b9ee44b4f9.60637453\";i:71;s:23:\"6113ba342bf7b8.20738162\";i:72;s:23:\"6113bd97560d39.32855520\";i:73;s:23:\"6113bd9fc06ad6.72365132\";i:74;s:23:\"6113bda724c914.03933943\";i:75;s:23:\"6113bdbc9ad4a0.49839124\";i:76;s:23:\"6113bdc3a19785.76909618\";i:77;s:23:\"6113c0a0ac0b01.67442436\";i:78;s:23:\"6113c10a517ad2.31288670\";i:79;s:23:\"6113c18308d344.34941646\";i:80;s:23:\"6113c18d2f6891.51815115\";i:81;s:23:\"6113c19823e670.74861442\";i:82;s:23:\"6113c1bc92c3a7.29595553\";i:83;s:23:\"6113c1dfe127c6.26812022\";i:84;s:23:\"6113c2b9d8de00.94618044\";i:85;s:23:\"6113c2c14ebef0.65873368\";i:86;s:23:\"6113c2cb135006.10923665\";i:87;s:23:\"6113c2d2ca5c09.51137064\";i:88;s:23:\"6113c2dd931cf7.34462070\";i:89;s:23:\"6113c2f1804ea3.68185521\";i:90;s:23:\"6113c33833e4b1.80278424\";i:91;s:23:\"6113c33e6ddfd1.49249807\";i:92;s:23:\"6113c36d7d9e85.81539432\";i:93;s:23:\"6113c371d3ae11.38298596\";i:94;s:23:\"6113c3bb3a6596.95012027\";i:95;s:23:\"6113c3bedb5584.25075288\";i:96;s:23:\"6113c3cb011f16.52420509\";i:97;s:23:\"6113c47348f830.21896513\";i:98;s:23:\"6113c478dd17f2.93625643\";i:99;s:23:\"6113c48a280792.45974171\";i:100;s:23:\"6113c513c17444.28049329\";i:101;s:23:\"6113c5322b7fb3.10160551\";i:102;s:23:\"6113c58b8c3f83.79475059\";i:103;s:23:\"6113c5954dcdc6.95940775\";i:104;s:23:\"6113c5a1d0dd74.40768091\";i:105;s:23:\"6113c5ea665049.91856568\";i:106;s:23:\"6113c5f9aab0d4.66207769\";i:107;s:23:\"6113c5fa60ac03.19029040\";i:108;s:23:\"6113cb45bde093.64510018\";i:109;s:23:\"6113cbd49f0db1.46407304\";i:110;s:23:\"6113cbdb43f4a2.67097283\";i:111;s:23:\"6113cbf88853c8.94116731\";i:112;s:23:\"6113cc40ba8c54.89227803\";i:113;s:23:\"6113cc4d69faa4.39039219\";i:114;s:23:\"6113cc52424df0.03305603\";i:115;s:23:\"6113cc9da73df4.47952652\";i:116;s:23:\"6113cca0d12219.84703512\";i:117;s:23:\"6113cca7c0ac02.88991890\";i:118;s:23:\"6113cd04901383.80099282\";i:119;s:23:\"6113cd098e1d94.27007298\";i:120;s:23:\"6113cd13cd5880.41910554\";i:121;s:23:\"6113cd488ba458.24510917\";i:122;s:23:\"6113cd555f50b3.27489151\";i:123;s:23:\"6113cd5b0a7731.78497642\";i:124;s:23:\"6113cdcb431ad9.22052703\";i:125;s:23:\"6113cdd20e93a3.55374906\";i:126;s:23:\"6113cdfcc8b7c4.48114334\";i:127;s:23:\"6113ce4205d355.91154936\";i:128;s:23:\"6113ce8336a533.65332485\";i:129;s:23:\"6113ce89202261.01575292\";i:130;s:23:\"6113cec8e174b0.62038606\";i:131;s:23:\"6113cee49e0ae0.47282239\";i:132;s:23:\"6113cf1054ea27.61688712\";i:133;s:23:\"6113cf1716d8a3.55604508\";i:134;s:23:\"6113cf1eb5a4e4.79599583\";i:135;s:23:\"6113cf28a32293.23511973\";i:136;s:23:\"6113cf360b8ef2.15850005\";i:137;s:23:\"6113cf72d239f7.09530534\";i:138;s:23:\"6113cf77ee9f57.13212564\";i:139;s:23:\"6113cf7d4d2f73.37722289\";i:140;s:23:\"6113cfb6230327.71963752\";i:141;s:23:\"6113cfbe1ac6f8.66110194\";i:142;s:23:\"6113d043533d94.92125989\";i:143;s:23:\"6113d05e86ed76.75194413\";i:144;s:23:\"6113d0985ed1e4.35013893\";i:145;s:23:\"6113d0a84f5ab7.85441769\";i:146;s:23:\"6113d0ad5f2383.28337668\";i:147;s:23:\"6113d0def33e67.87866294\";i:148;s:23:\"6113d13c157276.10473744\";i:149;s:23:\"6113d13fe68631.69221545\";i:150;s:23:\"6113d18987b5a9.18843412\";i:151;s:23:\"6113d18d4457d5.97304731\";i:152;s:23:\"6113d19bc44a24.93473657\";i:153;s:23:\"6113d1b25d5738.14311772\";i:154;s:23:\"6113d1b791f991.11967424\";i:155;s:23:\"6113d21ed561d0.53439583\";i:156;s:23:\"6113d2293aa610.02890029\";i:157;s:23:\"6113d22ebb89e5.11377635\";i:158;s:23:\"6113d27d0af979.60098728\";i:159;s:23:\"6113d281eee462.93436770\";i:160;s:23:\"6113d289433e22.75432623\";i:161;s:23:\"6113d2f37e8be1.25572001\";i:162;s:23:\"6113d2f7943959.64833305\";i:163;s:23:\"6113d2fb313f01.37908520\";i:164;s:23:\"6113d345f1f3f3.72387877\";i:165;s:23:\"6113d353af94e8.67704339\";i:166;s:23:\"6113d35f19e4e6.58100312\";i:167;s:23:\"6113d47b0e4b33.55353991\";i:168;s:23:\"6113d47f982b63.74165670\";i:169;s:23:\"6113d483034002.23435523\";i:170;s:23:\"6113d4badaa159.43778544\";i:171;s:23:\"6113d4e08b13a6.55042802\";i:172;s:23:\"6113d4e4a39e02.09927736\";i:173;s:23:\"6113d519446ce0.62396410\";i:174;s:23:\"6113d51e834e77.04137522\";i:175;s:23:\"6113d5238f29d2.46337859\";i:176;s:23:\"6113d5544c2621.27694275\";i:177;s:23:\"6113d557f32c29.21469640\";i:178;s:23:\"6113d55fcb0108.80310072\";i:179;s:23:\"6113d5a1189f05.17963597\";i:180;s:23:\"6113d5aaf2aa98.70083291\";i:181;s:23:\"6113d5b85fbd09.76479319\";i:182;s:23:\"6113d5d76b7b54.82021113\";i:183;s:23:\"6113d610d9c5b0.25353295\";i:184;s:23:\"6113d614a66ca1.24104669\";i:185;s:23:\"6113d62608f0e8.30740965\";i:186;s:23:\"6113d65e019082.08079890\";i:187;s:23:\"6113d6640e09d4.99338410\";i:188;s:23:\"6113d66ae8ede3.17078163\";i:189;s:23:\"6113d6bcd4db63.20398378\";i:190;s:23:\"6113d6dfe76281.46319714\";i:191;s:23:\"6113d7260567e6.67857091\";i:192;s:23:\"6113d7325e18a9.69258915\";i:193;s:23:\"6113d73f699301.19627187\";i:194;s:23:\"6113d77a05d872.59766844\";i:195;s:23:\"6113d77ecbdd87.14012154\";i:196;s:23:\"6113d78717a5c9.66538374\";i:197;s:23:\"6113d7d35de2c5.78353260\";i:198;s:23:\"6113d7eec974d3.18866227\";i:199;s:23:\"6113daeda26287.11568661\";i:200;s:23:\"6113db4201c546.15430133\";i:201;s:23:\"6113db4f70b1c1.86708332\";i:202;s:23:\"6113dba78c0b29.66520037\";i:203;s:23:\"6113dbc57dcd19.66329302\";i:204;s:23:\"6113dbdc4522e0.18135850\";i:205;s:23:\"6113dc1fd68714.38515683\";i:206;s:23:\"6113dc2847a6f4.19676015\";i:207;s:23:\"6113dc2cbde4f9.34048485\";i:208;s:23:\"6113dc782d7939.36705741\";i:209;s:23:\"6113dc7e972712.78702847\";i:210;s:23:\"6113dc8aa42990.00819775\";i:211;s:23:\"6113dcfb5311d3.31171037\";i:212;s:23:\"6113dd00d7b357.37087016\";i:213;s:23:\"6113dd0b48baf7.23487841\";i:214;s:23:\"6113dd4934ebd9.48533684\";i:215;s:23:\"6113dd4cd2cec5.33394255\";i:216;s:23:\"6113dd51b9e011.75532582\";i:217;s:23:\"6113ddaa89e0e4.20645916\";i:218;s:23:\"6113ddafd15621.76155882\";i:219;s:23:\"6113ddbd78bb06.78867854\";i:220;s:23:\"6113dddcbf2994.67423820\";i:221;s:23:\"6113ddfdf24454.25593056\";i:222;s:23:\"6113de02ebf2c2.90031742\";i:223;s:23:\"6113de3b166b48.42545561\";i:224;s:23:\"6113de4183c5a2.87520852\";i:225;s:23:\"6113de4a2b8fb9.50010567\";i:226;s:23:\"6113de8df287f6.46545656\";i:227;s:23:\"6113deb24c0b33.17380524\";i:228;s:23:\"6113deb8ebcd63.53557135\";i:229;s:23:\"6113df26ece6d5.61805214\";i:230;s:23:\"6113df2e3cae37.43434353\";i:231;s:23:\"6113df336c1f40.31616626\";i:232;s:23:\"6113df691e9541.07129595\";i:233;s:23:\"6113df6e8f92e9.11670778\";i:234;s:23:\"6113df7324f936.16639092\";i:235;s:23:\"6113dfb105e9c0.55197039\";i:236;s:23:\"6113dfd4de3c74.66558851\";i:237;s:23:\"6113dfd8ca6c85.19025624\";i:238;s:23:\"6113e04d841f93.89853923\";i:239;s:23:\"6113e052c26ed8.45772665\";i:240;s:23:\"6113e0587b4db3.37879900\";i:241;s:23:\"6113e09bc96e35.62200365\";i:242;s:23:\"6113e0c0104916.02078852\";i:243;s:23:\"6113e0c6073472.75056384\";i:244;s:23:\"6113e0f35a4514.94575948\";i:245;s:23:\"6113e0fbec7177.98875758\";i:246;s:23:\"6113e1155f8ad7.95438368\";i:247;s:23:\"6113e1437656f8.16812536\";i:248;s:23:\"6113e1a3ee7747.94867026\";i:249;s:23:\"6113e1a944f977.46690472\";i:250;s:23:\"6113e1ced9de29.43035702\";i:251;s:23:\"6113e1e60b4224.29083454\";i:252;s:23:\"6113e22d4dd6b6.38581215\";i:253;s:23:\"6113e23d39e143.13819511\";i:254;s:23:\"6113e39e3774e0.55757408\";i:255;s:23:\"6113e3b2ca7064.45785538\";i:256;s:23:\"6114b594755652.79219058\";i:257;s:23:\"611500df4fccf2.90062801\";i:258;s:23:\"611500ff910105.04311929\";i:259;s:23:\"6115017677bda1.39681588\";i:260;s:23:\"611504714cb621.58874018\";i:261;s:23:\"611504d271ece6.37369483\";i:262;s:23:\"6115059eb27393.25985971\";i:263;s:23:\"61150615c57397.76111716\";i:264;s:23:\"61150659a29fc8.67547476\";i:265;s:23:\"611507c5ab4565.28776024\";}modx.user.1.userGroups|a:1:{i:0;i:1;}'),
('4c6d030e2b6bedcc70059034c8d6de8d', 1628762593, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}cultureKey|s:2:\"ru\";modx.mgr.user.token|s:52:\"modx610d0af8630c32.23114400_16114c95b8c58a2.71818597\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:11:{i:0;s:23:\"6114c9671c6be8.46695583\";i:1;s:23:\"6114cf5990c5f6.73709356\";i:2;s:23:\"6114d033b66322.34966428\";i:3;s:23:\"6114d056458918.94494331\";i:4;s:23:\"6114d12982d3e6.23008944\";i:5;s:23:\"6114dcf821e381.04249271\";i:6;s:23:\"6114dead994372.22385448\";i:7;s:23:\"6114e02e6dd261.64495666\";i:8;s:23:\"6114efa29059e3.71238330\";i:9;s:23:\"6114f13f750da4.78991492\";i:10;s:23:\"6114f1e0e9fac1.25478021\";}'),
('8638a067917094d1d2701d76c98de234', 1628492643, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}cultureKey|s:2:\"fr\";modx.mgr.user.token|s:52:\"modx610d0af8630c32.23114400_16110c097db2924.81008756\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:8:{i:0;s:23:\"6110c0dc6f4458.43411203\";i:1;s:23:\"6110c29c349507.93881983\";i:2;s:23:\"6110c325e46cc6.98182509\";i:3;s:23:\"6110c71242f144.26837203\";i:4;s:23:\"6110ca23803892.72875183\";i:5;s:23:\"6110d30411ccd7.16613463\";i:6;s:23:\"6110d35e999700.01065647\";i:7;s:23:\"6110d3631ad748.87166614\";}'),
('8dacb736ab1fc49346031b0c5a64d0ba', 1628263077, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:0:{}cultureKey|s:2:\"fr\";'),
('9a73f26526370621fb8ac0304a2295e0', 1628573543, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:0:{}'),
('9f4fdb029ce64505e61dc3183f094d49', 1628261953, 'modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}modx.mgr.user.token|s:52:\"modx610d0af8630c32.23114400_1610d0bc69c5320.01456520\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:20:{i:0;s:23:\"610d0c4f8abfc7.42085167\";i:1;s:23:\"610d0d179213a9.24515147\";i:2;s:23:\"610d0e836784b9.14560111\";i:3;s:23:\"610d103707b4a8.48495969\";i:4;s:23:\"610d11a2544ce4.29456889\";i:5;s:23:\"610d12aa624e39.34399899\";i:6;s:23:\"610d12e50eae92.15200109\";i:7;s:23:\"610d12f48d0600.18894302\";i:8;s:23:\"610d1326c49ef2.80644133\";i:9;s:23:\"610d134eb03bd1.91591962\";i:10;s:23:\"610d15ce924e47.96044240\";i:11;s:23:\"610d1cc8aec1a4.70399849\";i:12;s:23:\"610d1ce64ec408.82805972\";i:13;s:23:\"610d1ee1846606.06296972\";i:14;s:23:\"610d328bab27b1.33027336\";i:15;s:23:\"610d3421e18402.92064420\";i:16;s:23:\"610d4577d59107.49263013\";i:17;s:23:\"610d45d2062ab3.69891208\";i:18;s:23:\"610d45e25eccc9.82708309\";i:19;s:23:\"610d463ef1ba97.72633082\";}cultureKey|s:2:\"en\";modx.user.1.userGroups|a:1:{i:0;i:1;}'),
('f1855c976d708b2a682fd89e521fd3ea', 1635491004, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}modx.mgr.user.token|s:52:\"modx610d0af8630c32.23114400_1617b9b7a4a9468.52510822\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:3:{i:0;s:23:\"617b9b848d4f10.11794689\";i:1;s:23:\"617b9c57c95888.68128591\";i:2;s:23:\"617b9cbc3d2780.43421734\";}'),
('f84fea09b48236c53fede65efb97ea4e', 1628520973, 'modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:16:\"modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";s:1:\"0\";s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:22:\"modAccessResourceGroup\";a:0:{}s:17:\"modAccessCategory\";a:0:{}s:28:\"sources.modAccessMediaSource\";a:0:{}s:18:\"modAccessNamespace\";a:0:{}}}modx.user.contextTokens|a:0:{}cultureKey|s:2:\"en\";');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_content`
--

CREATE TABLE `modx_site_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'document',
  `contentType` varchar(50) NOT NULL DEFAULT 'text/html',
  `pagetitle` varchar(191) NOT NULL DEFAULT '',
  `longtitle` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `alias` varchar(191) DEFAULT '',
  `alias_visible` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `link_attributes` varchar(191) NOT NULL DEFAULT '',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `pub_date` int(20) NOT NULL DEFAULT '0',
  `unpub_date` int(20) NOT NULL DEFAULT '0',
  `parent` int(10) NOT NULL DEFAULT '0',
  `isfolder` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `introtext` text,
  `content` mediumtext,
  `richtext` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `template` int(10) NOT NULL DEFAULT '0',
  `menuindex` int(10) NOT NULL DEFAULT '0',
  `searchable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `cacheable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `createdby` int(10) NOT NULL DEFAULT '0',
  `createdon` int(20) NOT NULL DEFAULT '0',
  `editedby` int(10) NOT NULL DEFAULT '0',
  `editedon` int(20) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `deletedon` int(20) NOT NULL DEFAULT '0',
  `deletedby` int(10) NOT NULL DEFAULT '0',
  `publishedon` int(20) NOT NULL DEFAULT '0',
  `publishedby` int(10) NOT NULL DEFAULT '0',
  `menutitle` varchar(191) NOT NULL DEFAULT '',
  `donthit` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `privateweb` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `privatemgr` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `content_dispo` tinyint(1) NOT NULL DEFAULT '0',
  `hidemenu` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `class_key` varchar(100) NOT NULL DEFAULT 'modDocument',
  `context_key` varchar(100) NOT NULL DEFAULT 'web',
  `content_type` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `uri` text,
  `uri_override` tinyint(1) NOT NULL DEFAULT '0',
  `hide_children_in_tree` tinyint(1) NOT NULL DEFAULT '0',
  `show_in_tree` tinyint(1) NOT NULL DEFAULT '1',
  `properties` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_content`
--

INSERT INTO `modx_site_content` (`id`, `type`, `contentType`, `pagetitle`, `longtitle`, `description`, `alias`, `alias_visible`, `link_attributes`, `published`, `pub_date`, `unpub_date`, `parent`, `isfolder`, `introtext`, `content`, `richtext`, `template`, `menuindex`, `searchable`, `cacheable`, `createdby`, `createdon`, `editedby`, `editedon`, `deleted`, `deletedon`, `deletedby`, `publishedon`, `publishedby`, `menutitle`, `donthit`, `privateweb`, `privatemgr`, `content_dispo`, `hidemenu`, `class_key`, `context_key`, `content_type`, `uri`, `uri_override`, `hide_children_in_tree`, `show_in_tree`, `properties`) VALUES
(1, 'document', 'text/html', 'Главная', 'Добро пожаловать!', '', 'main', 1, '', 1, 0, 0, 0, 0, '', '        <section id=\"hero\" class=\"visible\">\r\n            <div class=\"hero-logo logo\" data-speed=\"0\" data-blur=\"0\">\r\n                <img src=\"/img/logo-[[!lingua.cultureKey]].svg\" alt=\"\">\r\n                <h1>#Маша солнце</h1>\r\n                <span>Мир особого художника</span>\r\n            </div>\r\n            <div class=\"layer-parallax\">\r\n                <div class=\"layer lazy\" data-speed=\"5\" data-blur=\"1.5\" data-src=\"/img/layers/flowers.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"3\" data-blur=\"0.3\" data-src=\"/img/layers/grass.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"1.6\" data-blur=\"0.1\" data-src=\"/img/layers/mountains.png\"></div>\r\n                <div class=\"layer lazy\" data-speed=\"1\" data-blur=\"0\" data-src=\"/img/layers/sky.png\"></div>\r\n            </div>\r\n        </section>\r\n        <section id=\"about\">\r\n            <div class=\"container\">\r\n                <div class=\"row flex\">\r\n                    <div class=\"col s12 center-align\">\r\n                        <h2>Обо мне</h2>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"swiper-container\" id=\"swiper-about\">\r\n                <div class=\"swiper-wrapper\">\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Детство\" data-src=\"/img/slides/slide3.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col l6 xl6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/childhood.jpg\">\r\n                                </div>\r\n                                <div class=\"col l6 xl5 offset-xl1 s12\">\r\n                                    <h3>Детство</h3>\r\n                                    <p>\r\n                                        Мордвинцева Мария Георгиевна родилась летом 2000г. в городе Ленинск-Кузнецкий Кемеровской области. Елена (мама девочки) вложила много сил и любви в дочку – как только Маша начала сидеть, \r\n                                        она сажала её на колени и читала детские книжки, а девочка рассматривала картинки, запоминала животных, персонажей и цвета. Так началось её увлечение рисунками. Весной 2004г. \r\n                                        семья переехала в город-курорт Горячий ключ. Там Маша и начала рисовать. Сначала, по словам мамы это были «каля-маля», но постепенно рисунки Маши становились всё более осмысленными.\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"overlay lazy\" data-src=\"/img/plant1.png\" data-lx=\"38\" data-ly=\"40\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.001\" data-v-depth=\"0.01\"></div>\r\n                            <div class=\"overlay lazy\" data-src=\"/img/plant.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.002\" data-v-depth=\"0.02\"></div>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Становление\" data-src=\"/img/slides/slide2.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/becoming.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Становление</h3>\r\n                                    <p>\r\n                                        В 2007-м году, как и все, девочка пошла в школу. В соседнем подъезде открылась художественная студия «Розовый кот», куда Маша записалась сразу же, и ходит в неё уже почти 13 лет. \r\n                                        Руководитель студии Жанна Викторовна Смирнова помогла девочке раскрыть себя в творчестве и научила различным техникам живописи. По словам Елены, она прекрасно помнит момент, \r\n                                        когда картины Маши вышли на качественно новый уровень. «Это было в сентябре 2013г. Дочка написала картину «Дождь», которая удивила не только меня, но и преподавателя. \r\n                                        Несколько профессиональных художников очень высоко оценили мастерство исполнения.…»\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/birdy.png\" data-lx=\"43\" data-ly=\"40\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.002\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/plants_birdy.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.005\" data-v-depth=\"0.01\"></div>\r\n                    </div>\r\n                    <div class=\"swiper-slide lazy\" data-header=\"Успех\" data-src=\"/img/slides/slide1.jpg\">\r\n                        <div class=\"container\">\r\n                            <div class=\"row\">\r\n                                <div class=\"col m6 s12\">\r\n                                    <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"responsive-img hide-m-down lazy\" data-src=\"/img/slides/success.jpg\">\r\n                                </div>\r\n                                <div class=\"col m5 offset-m1 s12\">\r\n                                    <h3>Успех</h3>\r\n                                    <p>\r\n                                        Первая персональная экспозиция «Взгляд ребёнка» открылась в ноябре 2016г., как раз в год окончания школы, в музее родного города, на которой Маша представила аудитории 40 своих работ. \r\n                                        2-я выставка состоялась в 2017г. в Краснодарском краевом музее им. Коваленко, тогда же девушка становится участницей V Всероссийской культурно- образовательной акции «Ночь искусств». \r\n                                        В 2018г она принимает участие в Международном форуме «Разные миры», где она получает Гран-при. На данный момент уже несколько профессиональных художников порекомендовали Маше найти учениц. \r\n                                        Крайне важно, чтобы уникальная авторская техника письма не потерялась, а нашла своих продолжателей.\r\n                                    </p>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/bird2.png\" data-lx=\"43\" data-ly=\"2\" data-mx=\"65\" data-my=\"40\" data-h-depth=\"0.002\" data-v-depth=\"0.01\"></div>\r\n                        <div class=\"overlay lazy\" data-src=\"/img/bird1.png\" data-lx=\"75\" data-ly=\"70\" data-mx=\"90\" data-my=\"70\" data-h-depth=\"0.005\" data-v-depth=\"0.01\"></div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"swiper-pagination\"></div>\r\n            </div>\r\n        </section>\r\n        <section id=\"gallery\">\r\n            <div class=\"center-align\">\r\n                <h2>Мои работы</h2>\r\n            </div>\r\n            <div class=\"gallery-wrapper\">\r\n                [[!galleryRand? &tpl=`mainPage_galleryTpl` &count=`10` &parent=`2`]]\r\n            </div>\r\n            <div class=\"center-align\">\r\n                <a href=\"[[~2]]\" class=\"btn\">Смотреть все работы</a>\r\n            </div>\r\n        </section>\r\n        <section id=\"check-yourself\">\r\n            <div class=\"container\">\r\n                <div class=\"row\">\r\n                    <div class=\"col l6 offset-l3 center-align\">\r\n                        [[$quiz_[[!lingua.cultureKey]]]]\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </section>', 1, 1, 0, 1, 1, 1, 1628244737, 1, 1628768119, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 'modDocument', 'web', 1, 'main.html', 0, 0, 1, NULL),
(2, 'document', 'text/html', 'Галерея', 'Мои картины', '', 'gallery', 1, '', 1, 0, 0, 0, 1, '', '', 1, 3, 1, 1, 1, 1, 1628246755, 1, 1628691270, 0, 0, 0, 1628246760, 1, '', 0, 0, 0, 0, 0, 'CollectionContainer', 'web', 1, 'gallery/', 0, 0, 1, NULL),
(3, 'document', 'text/html', 'От создателей', 'Пара слов от создателей', '', 'by-creators', 1, '', 1, 0, 0, 0, 0, '', '<section>\r\n    <div class=\"container\">\r\n        <div class=\"row\">\r\n            <div class=\"col s12\">\r\n                <h1>От создателей</h1>\r\n            </div>\r\n        </div>\r\n        <div class=\"row\">\r\n            <div class=\"col xl3 l4 m5 s12\">\r\n                <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" class=\"lazy responsive-img\" data-src=\"/img/behalf_creators1.jpg\" width=\"726\" height=\"700\">\r\n            </div>\r\n            <div class=\"col xl9 l8 m7 s12\">\r\n                <h2>Лишняя хромосома не делает их чужими</h2>\r\n                <p>\r\n                    Этот сайт посвящен необычному и солнечному человеку - талантливой художнице с синдромом Дауна Маше Мордвинцевой. Мало кто из нас верит \r\n                    в возможности и пользу этих людей для общества, но мы глубоко заблуждаемся. Да, \"солнечным детям\" нужно больше внимания и больше помощи \r\n                    в развитии и становлении личности, но, если помочь такому особенному малышу в поиске его талантов, то их усердию \r\n                    и отдаче в любимом деле можно только позавидовать.\r\n                </p>\r\n            </div>\r\n        </div>\r\n        <div class=\"row flex\">\r\n            <div class=\"col s12 center-algn\">\r\n                <h2 class=\"center-align\">Мифы, которые вводят нас в заблуждение</h2>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth1.jpg\">\r\n                        <h3 class=\"card-title\">Миф №1: Синдром Дауна – это болезнь</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Правда: На самом деле это простой генетический сбой. Если в геноме обычного человека 46 хромосом, то солнечный ребенок рождается с 47. \r\n                            Но одна лишняя хромосома не делает его чужим для всего остального мира. Синдром Дауна невозможно вылечить и тем более, заразиться им. \r\n                            Его появление не связано ни с цветом кожи, ни с возрастом, ни с образом жизни.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth2.jpg\">\r\n                        <h3 class=\"card-title\">Миф №2: Они опасны для общества</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Правда: Этот распространенный миф не имеет под собой никаких оснований. История не знает преступлений, совершенных людьми с синдромом Дауна. \r\n                            Они, как и все обычные люди, радуются, грустят, капризничают, но их настроение не сменяется приступами агрессии. Напротив, спокойное и добродушное \r\n                            поведение намного характернее для \"солнечных деток\". А вот настоящую опасность для них представляет человеческое невежество.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth3.jpg\">\r\n                        <h3 class=\"card-title\">Миф №3: Они не могут обучаться</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Правда: Солнечные дети прекрасно постигают основы письма, чтения и точных наук. Могут освоить компьютер, иностранные языки и многое другое. \r\n                            Уже сегодня они играют в театре, занимаются танцами и рисуют. Люди с синдромом Дауна проходят такие этапы развития, что и другие люди \r\n                            с той лишь разницей, что им на это нужно больше времени и внимания от педагогов и родителей.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12 offset-xl2 offset-l2\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth4.jpg\">\r\n                        <h3 class=\"card-title\">Миф №4: Им нельзя поручать работу</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Правда: На западе человек с синдромом Дауна может встретить вас на ресепшене в гостинице, помочь в супермаркете, обслужить на почте или испечь \r\n                            домашнее печенье, потому что могут и получают такую возможность. В этих странах видят и понимают потенциал \"солнечных людей\" и пускают много \r\n                            сил на его реализацию. В этом отношении Россия делает лишь первые шаги, поэтому очень важно поддерживать все позитивные изменения в этой области.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"col l4 m6 s12 offset-m3\">\r\n                <div class=\"card\">\r\n                    <div class=\"card-image\">\r\n                        <img src=\"/img/lazy-placeholder.jpg\" alt=\"\" width=\"877\" height=\"593\" class=\"responsive-img lazy\" data-src=\"/img/myth5.jpg\">\r\n                        <h3 class=\"card-title\">Миф №5: Синдром Дауна – это редкость</h3>\r\n                    </div>\r\n                    <div class=\"card-content\">\r\n                        <p>\r\n                            Правда: Это самое частое генетическое отклонение, которое наблюдают у каждого 700 ребенка. В России каждый год рождается около 2000 таких \"солнечных деток\". \r\n                            Это незаметно, потому что 85% малышей остаются в домах малюток и после этого кочуют из одного госучреждения в другое, проживая всю жизнь вдали от общества. \r\n                            В это время на Западе число отказников не достигает и нескольких процентов, а \"солнечных детей\" усыновляют многие семьи.\r\n                        </p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</section>', 1, 1, 2, 1, 1, 1, 1628494975, 1, 1628670327, 0, 0, 0, 1628494920, 1, '', 0, 0, 0, 0, 0, 'modDocument', 'web', 1, 'by-creators.html', 0, 0, 1, NULL),
(4, 'document', 'text/html', 'Горы', '', '', 'горы', 1, '', 0, 0, 0, 2, 0, '', '', 1, 2, 0, 1, 1, 1, 1628679520, 0, 0, 1, 1628680464, 1, 0, 0, '', 0, 0, 0, 0, 0, 'modDocument', 'web', 1, 'gallery/горы.html', 0, 0, 0, NULL),
(5, 'document', 'text/html', 'Горы', '', '', 'горы', 1, '', 1, 0, 0, 2, 0, '', 'img/hero_bgr.jpg', 1, 1, 1, 1, 1, 1, 1628680663, 1, 1628680933, 1, 1628683720, 1, 1628680933, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/горы.html', 0, 0, 0, NULL),
(6, 'document', 'text/html', 'Цветущий сад', '', '', 'flowering-garden', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 2, 1, 1, 1, 1628684552, 1, 1628685815, 1, 1628687107, 1, 1628684520, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/flowering-garden.html', 0, 0, 0, NULL),
(7, 'document', 'text/html', 'Знойная Африка', '', '', 'абстракция', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 3, 1, 1, 1, 1628685241, 1, 1628685688, 1, 1628687116, 1, 1628685240, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/абстракция.html', 0, 0, 0, NULL),
(8, 'document', 'text/html', 'Краски Турули', '', '', 'краски-турули', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 4, 1, 1, 1, 1628685425, 1, 1628685723, 1, 1628687112, 1, 1628685723, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/краски-турули.html', 0, 0, 0, NULL),
(9, 'document', 'text/html', 'Петушок', '', '', 'петушок', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 5, 1, 1, 1, 1628687314, 1, 1628687320, 0, 0, 0, 1628687320, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/петушок.html', 0, 0, 0, NULL),
(10, 'document', 'text/html', 'Ромашки', '', '', 'ромашки', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 6, 1, 1, 1, 1628687422, 0, 0, 0, 0, 0, 1628687422, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/ромашки.html', 0, 0, 0, NULL),
(11, 'document', 'text/html', 'Осеннее солнце', '', '', 'осеннее-солнце', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 7, 1, 1, 1, 1628687515, 0, 0, 0, 0, 0, 1628687515, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/осеннее-солнце.html', 0, 0, 0, NULL),
(12, 'document', 'text/html', 'Знойная Африка', '', '', 'знойная-африка', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 8, 1, 1, 1, 1628687618, 0, 0, 0, 0, 0, 1628687618, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/знойная-африка.html', 0, 0, 0, NULL),
(13, 'document', 'text/html', 'Осенний лес', '', '', 'осенний-лес', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 9, 1, 1, 1, 1628687686, 0, 0, 0, 0, 0, 1628687686, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/осенний-лес.html', 0, 0, 0, NULL),
(14, 'document', 'text/html', 'Краски Турули', '', '', 'краски-турули', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 10, 1, 1, 1, 1628687817, 1, 1628687823, 0, 0, 0, 1628687823, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/краски-турули.html', 0, 0, 0, NULL),
(15, 'document', 'text/html', 'Натюрморт с синей вазой', '', '', 'натюрморт-с-синей-вазой', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 11, 1, 1, 1, 1628687935, 0, 0, 0, 0, 0, 1628687935, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/натюрморт-с-синей-вазой.html', 0, 0, 0, NULL),
(16, 'document', 'text/html', 'Три тополя в лунном свете', '', '', 'три-тополя-в-лунном-свете', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 12, 1, 1, 1, 1628688070, 0, 0, 0, 0, 0, 1628688070, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/три-тополя-в-лунном-свете.html', 0, 0, 0, NULL),
(17, 'document', 'text/html', 'Астры', '', '', 'астры', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 13, 1, 1, 1, 1628688142, 1, 1628688163, 0, 0, 0, 1628688163, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/астры.html', 0, 0, 0, NULL),
(18, 'document', 'text/html', 'Закат', '', '', 'закат', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 14, 1, 1, 1, 1628688240, 0, 0, 0, 0, 0, 1628688240, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/закат.html', 0, 0, 0, NULL),
(19, 'document', 'text/html', 'Розовый букет', '', '', 'розовый-букет', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 15, 1, 1, 1, 1628688305, 1, 1628688315, 0, 0, 0, 1628688315, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/розовый-букет.html', 0, 0, 0, NULL),
(20, 'document', 'text/html', 'Лестница', '', '', 'лестница', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 16, 1, 1, 1, 1628688534, 0, 0, 0, 0, 0, 1628688534, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/лестница.html', 0, 0, 0, NULL),
(21, 'document', 'text/html', 'Озеро', '', '', 'le-lac', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 17, 1, 1, 1, 1628688604, 1, 1628688661, 0, 0, 0, 1628688600, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/le-lac.html', 0, 0, 0, NULL),
(22, 'document', 'text/html', 'На чёрном море', '', '', 'на-чёрном-море', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 18, 1, 1, 1, 1628688775, 1, 1628688811, 0, 0, 0, 1628688720, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/на-чёрном-море.html', 0, 0, 0, NULL),
(23, 'document', 'text/html', 'Маленькая лошадка', '', '', 'маленькая-лошадка', 1, '', 0, 0, 0, 2, 0, '', '', 1, 4, 19, 1, 1, 1, 1628688924, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/маленькая-лошадка.html', 0, 0, 0, NULL),
(24, 'document', 'text/html', 'Лотосы', '', '', 'лотосы', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 20, 1, 1, 1, 1628689018, 0, 0, 0, 0, 0, 1628689018, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/лотосы.html', 0, 0, 0, NULL),
(25, 'document', 'text/html', 'Красные цветы', '', '', 'красные-цветы', 1, '', 0, 0, 0, 2, 0, '', '', 1, 4, 21, 1, 1, 1, 1628689137, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/красные-цветы.html', 0, 0, 0, NULL),
(26, 'document', 'text/html', 'Кошка с котятами', '', '', 'кошка-с-котятами', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 22, 1, 1, 1, 1628689219, 0, 0, 0, 0, 0, 1628689219, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/кошка-с-котятами.html', 0, 0, 0, NULL),
(27, 'document', 'text/html', 'Гора «кошка»', '', '', 'гора-«кошка»', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 23, 1, 1, 1, 1628689528, 0, 0, 0, 0, 0, 1628689528, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/гора-«кошка».html', 0, 0, 0, NULL),
(28, 'document', 'text/html', 'Космос', '', '', 'космос', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 24, 1, 1, 1, 1628689592, 0, 0, 0, 0, 0, 1628689592, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/космос.html', 0, 0, 0, NULL),
(29, 'document', 'text/html', 'Сомнения', '', '', 'сомнения', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 25, 1, 1, 1, 1628689687, 0, 0, 0, 0, 0, 1628689687, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/сомнения.html', 0, 0, 0, NULL),
(30, 'document', 'text/html', 'Водопад', '', '', 'водопад', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 26, 1, 1, 1, 1628689746, 0, 0, 0, 0, 0, 1628689746, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/водопад.html', 0, 0, 0, NULL),
(31, 'document', 'text/html', 'Дом в саду', '', '', 'дом-в-саду', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 27, 1, 1, 1, 1628689822, 0, 0, 0, 0, 0, 1628689822, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/дом-в-саду.html', 0, 0, 0, NULL),
(32, 'document', 'text/html', 'Декоративный натюрморт', '', '', 'декоративный-натюрморт', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 28, 1, 1, 1, 1628689934, 0, 0, 0, 0, 0, 1628689934, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/декоративный-натюрморт.html', 0, 0, 0, NULL),
(33, 'document', 'text/html', 'Весеннее настроение', '', '', 'весеннее-настроение', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 29, 1, 1, 1, 1628690011, 0, 0, 0, 0, 0, 1628690011, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/весеннее-настроение.html', 0, 0, 0, NULL),
(34, 'document', 'text/html', 'Берёзы', '', '', 'берёзы', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 30, 1, 1, 1, 1628690106, 0, 0, 0, 0, 0, 1628690106, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/берёзы.html', 0, 0, 0, NULL),
(35, 'document', 'text/html', 'Цветущий сад', '', '', 'цветущий-сад', 1, '', 1, 0, 0, 2, 0, '', 'img/gallery/blooming-garden.jpg', 1, 4, 31, 1, 1, 1, 1628690211, 1, 1628693442, 0, 0, 0, 1628690160, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/цветущий-сад.html', 0, 0, 0, NULL),
(36, 'document', 'text/html', 'Море на закате', '', '', 'море-на-закате', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 32, 1, 1, 1, 1628690295, 0, 0, 0, 0, 0, 1628690295, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/море-на-закате.html', 0, 0, 0, NULL),
(37, 'document', 'text/html', 'Рыбаки', '', '', 'рыбаки', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 33, 1, 1, 1, 1628690385, 1, 1628691195, 0, 0, 0, 1628690340, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/рыбаки.html', 0, 0, 0, NULL),
(38, 'document', 'text/html', 'Что скрывает лунный свет?', '', '', 'что-скрывает-лунный-свет', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 34, 1, 1, 1, 1628691365, 1, 1628691395, 0, 0, 0, 1628691360, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/что-скрывает-лунный-свет.html', 0, 0, 0, NULL),
(39, 'document', 'text/html', 'Шторм', '', '', 'шторм', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 35, 1, 1, 1, 1628691485, 0, 0, 0, 0, 0, 1628691485, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/шторм.html', 0, 0, 0, NULL),
(40, 'document', 'text/html', 'Чанг-Ан, Вьетнам', '', '', 'чанг-ан,-вьетнам', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 36, 1, 1, 1, 1628691574, 0, 0, 0, 0, 0, 1628691574, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/чанг-ан,-вьетнам.html', 0, 0, 0, NULL),
(41, 'document', 'text/html', 'Странник', '', '', 'странник', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 37, 1, 1, 1, 1628691705, 0, 0, 0, 0, 0, 1628691705, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/странник.html', 0, 0, 0, NULL),
(42, 'document', 'text/html', 'Прощание', '', '', 'прощание', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 38, 1, 1, 1, 1628691783, 0, 0, 0, 0, 0, 1628691783, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/прощание.html', 0, 0, 0, NULL),
(43, 'document', 'text/html', 'Птичка на ветке', '', '', 'птичка-на-ветке', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 39, 1, 1, 1, 1628691880, 0, 0, 0, 0, 0, 1628691880, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/птичка-на-ветке.html', 0, 0, 0, NULL),
(44, 'document', 'text/html', 'Острова', '', '', 'острова', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 40, 1, 1, 1, 1628691930, 1, 1628691962, 0, 0, 0, 1628691900, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/острова.html', 0, 0, 0, NULL),
(45, 'document', 'text/html', 'Пылающий закат', '', '', 'пылающий-закат', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 41, 1, 1, 1, 1628692024, 0, 0, 0, 0, 0, 1628692024, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/пылающий-закат.html', 0, 0, 0, NULL),
(46, 'document', 'text/html', 'Восход в горах', '', '', 'восход-в-горах', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 42, 1, 1, 1, 1628692107, 0, 0, 0, 0, 0, 1628692107, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/восход-в-горах.html', 0, 0, 0, NULL),
(47, 'document', 'text/html', 'Вечерний свет', '', '', 'вечерний-свет', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 43, 1, 1, 1, 1628692260, 0, 0, 0, 0, 0, 1628692260, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/вечерний-свет.html', 0, 0, 0, NULL),
(48, 'document', 'text/html', 'Цветы', '', '', 'цветы', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 44, 1, 1, 1, 1628692326, 0, 0, 0, 0, 0, 1628692326, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/цветы.html', 0, 0, 0, NULL),
(49, 'document', 'text/html', 'Лес', '', '', 'лес', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 45, 1, 1, 1, 1628692398, 0, 0, 0, 0, 0, 1628692398, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/лес.html', 0, 0, 0, NULL),
(50, 'document', 'text/html', 'Ветка сакуры', '', '', 'ветка-сакуры', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 46, 1, 1, 1, 1628692555, 0, 0, 0, 0, 0, 1628692555, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/ветка-сакуры.html', 0, 0, 0, NULL),
(51, 'document', 'text/html', 'Ангел', '', '', 'ангел', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 47, 1, 1, 1, 1628692633, 0, 0, 0, 0, 0, 1628692633, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/ангел.html', 0, 0, 0, NULL),
(52, 'document', 'text/html', 'Маки', '', '', 'маки', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 48, 1, 1, 1, 1628692721, 0, 0, 0, 0, 0, 1628692721, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/маки.html', 0, 0, 0, NULL),
(53, 'document', 'text/html', 'Альпийский луг', '', '', 'альпийские-луга', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 49, 1, 1, 1, 1628692801, 1, 1628692892, 0, 0, 0, 1628692800, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/альпийские-луга.html', 0, 0, 0, NULL),
(54, 'document', 'text/html', 'Два лотоса', '', '', 'два-лотоса', 1, '', 1, 0, 0, 2, 0, '', '', 1, 4, 50, 1, 1, 1, 1628692940, 1, 1628693078, 0, 0, 0, 1628692920, 1, '', 0, 0, 0, 0, 0, 'modStaticResource', 'web', 1, 'gallery/два-лотоса.html', 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_htmlsnippets`
--

CREATE TABLE `modx_site_htmlsnippets` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(191) NOT NULL DEFAULT 'Chunk',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `snippet` mediumtext,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_htmlsnippets`
--

INSERT INTO `modx_site_htmlsnippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `static`, `static_file`) VALUES
(1, 1, 0, 'head', '', 0, 0, 0, '<link rel=\"stylesheet\" href=\"/css/master.css\">\n<title>[[++site_name]] – [[*pagetitle]]</title>\n<meta charset=\"UTF-8\">\n<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">', 0, 'a:0:{}', 0, ''),
(2, 1, 0, 'header', '', 0, 0, 0, '<header>\n    <div class=\"logo-wrapper\">\n        <a href=\"/\" class=\"logo\" style=\"background-image:url(/img/logo-[[!lingua.cultureKey?]].svg)\">&nbsp;</a>\n    </div>\n    <div class=\"menu-wrapper\">\n        [[!lingua.selector?\n            &tplWrapper=`linguaWrapper`\n            &tplItem=`linguaItem`\n        ]]\n    </div>\n    <div class=\"burger-wrapper\">\n        <a class=\"menu-trigger\"></a>\n        <div class=\"menu-background\"></div>\n    </div>\n    <nav>\n        [[Wayfinder? &level=`1` &startId=`0` &rowTpl=`wfRow` & outerTpl=`wfTpl`]]\n    </nav>\n    <div class=\"divider\"></div>\n</header>', 0, 'a:0:{}', 0, ''),
(3, 1, 0, 'linguaWrapper', '', 0, 0, 0, '<ul>\n    <li class=\"language_selector\">\n        <span class=\"hide-m-down\">[[!currentCulture]]</span><span class=\"hide-m-up\">[[+lingua.cultureKey]]</span>\n        <ul class=\"available-langs\">\n            [[+lingua.languages]]\n        </ul>\n    </li>\n</ul>', 0, 'a:0:{}', 0, ''),
(4, 1, 0, 'linguaItem', '', 0, 0, 0, '[[+lingua.cultureKey:is=`[[+lingua.lang_code]]`:then=``:else=`<li>\n    <a href=\"[[+lingua.url]]\" title=\"[[+lingua.local_name]]\">\n        <span class=\"hide-m-down\">[[+lingua.local_name]]</span>\n        <span class=\"hide-m-up\">[[+lingua.lang_code]]</span>\n    </a>\n</li>`]]', 0, 'a:0:{}', 0, ''),
(5, 1, 0, 'scripts', '', 0, 0, 0, '<script src=\"/js/jquery.min.js\"></script>\n<script src=\"/js/jquery.lazy.min.js\"></script>\n<script src=\"/js/materialize.min.js\"></script>\n<script src=\"/js/swiper-bundle.js\"></script>\n<script src=\"/js/master.js\"></script>', 0, 'a:0:{}', 0, ''),
(6, 1, 0, 'modal-ru', '', 0, 0, 0, '    <div class=\"modal\" id=\"quiz\" data-lang=\"ru\">\n        <form class=\"modal-content quiz-form\">\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <h3>Выберите, какую из работ нарисовала Маша?</h3>\n                </div>\n            </div>\n            <div class=\"row quiz-container no-margin\">\n                <div class=\"col s6\">\n                    <input type=\"radio\" name=\"answer\" value=\"1\" id=\"quiz-var1\">\n                    <label for=\"quiz-var1\" id=\"label-var1\"></label>\n                </div>\n                <div class=\"col s6\">\n                    <input type=\"radio\" name=\"answer\" value=\"2\" id=\"quiz-var2\">\n                    <label for=\"quiz-var2\" id=\"label-var2\"></label>\n                </div>\n            </div>\n            <div class=\"row results-container no-margin hidden\">\n                <div class=\"col m6 s12\">\n                    Иллюстрация\n                </div>\n                <div class=\"col m6 s12\">\n                    <p class=\"scores\"><b>Итак, Ваши результаты:</b> <br> вы угадали: <span id=\"quiz-right\" class=\"quiz-result\"></span> из <span id=\"quiz-total\" class=\"quiz-result\"></span> (<span id=\"quiz-percent\" class=\"quiz-result\"></span>)</p>\n                    <p>\n                       <span id=\"quiz-conclusion\"></span> Надеемся, Вам понравилось наше небольшое испытание. Вы можете ознакомиться \n                       с другими картинами Маши в <a href=\"/gallery.html\">галерее работ</a>.\n                    </p>\n                </div>\n            </div>\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <ul id=\"quiz-steps\"></ul>\n                </div>\n            </div>\n        </form>\n        <div class=\"modal-footer\">\n            <a class=\"btn-flat waves-effect waves-dark left modal-close\">Закрыть</a>\n            <a class=\"btn waves-effect waves-light\" id=\"quiz-next\" data-repeat=\"Повторить\" data-next=\"Далее\">Далее</a>\n        </div>\n    </div>', 0, 'a:0:{}', 0, ''),
(7, 1, 0, 'modal-en', '', 0, 0, 0, '    <div class=\"modal\" id=\"quiz\" data-lang=\"en\">\n        <form class=\"modal-content quiz-form\">\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <h3>Please, choose a picture you think is made by Mary</h3>\n                </div>\n            </div>\n            <div class=\"row quiz-container no-margin\">\n                <div class=\"col s6\">\n                    <input type=\"radio\" name=\"answer\" value=\"1\" id=\"quiz-var1\">\n                    <label for=\"quiz-var1\" id=\"label-var1\"></label>\n                </div>\n                <div class=\"col s6\">\n                    <input type=\"radio\" name=\"answer\" value=\"2\" id=\"quiz-var2\">\n                    <label for=\"quiz-var2\" id=\"label-var2\"></label>\n                </div>\n            </div>\n            <div class=\"row results-container no-margin hidden\">\n                <div class=\"col m6 s12\">\n                    Illustration\n                </div>\n                <div class=\"col m6 s12\">\n                    <p class=\"scores\"><b>So, your results are:</b> <br> you\'ve got: <span id=\"quiz-right\" class=\"quiz-result\"></span> from <span id=\"quiz-total\" class=\"quiz-result\"></span> (<span id=\"quiz-percent\" class=\"quiz-result\"></span>)</p>\n                    <p>\n                       <span id=\"quiz-conclusion\"></span> We hope you enjoyed our little challenge. You can check out\n                       other Mary\'s works at the <a href=\"/gallery.html\">image gallery</a>.\n                    </p>\n                </div>\n            </div>\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <ul id=\"quiz-steps\"></ul>\n                </div>\n            </div>\n        </form>\n        <div class=\"modal-footer\">\n            <a class=\"btn-flat waves-effect waves-dark left modal-close\">Close</a>\n            <a class=\"btn waves-effect waves-light\" id=\"quiz-next\" data-repeat=\"Repeat\" data-next=\"Next\">Next</a>\n        </div>\n    </div>', 0, 'a:0:{}', 0, ''),
(8, 1, 0, 'modal-fr', '', 0, 0, 0, '    <div class=\"modal\" id=\"quiz\" data-lang=\"fr\">\n        <form class=\"modal-content quiz-form\">\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <h3>S\'il vous plaît, choisissez une image que vous pensez être faite par Marie</h3>\n                </div>\n            </div>\n            <div class=\"row quiz-container no-margin\">\n                <div class=\"col s6\">\n                    <input type=\"radio\" name=\"answer\" value=\"1\" id=\"quiz-var1\">\n                    <label for=\"quiz-var1\" id=\"label-var1\"></label>\n                </div>\n                <div class=\"col s6\">\n                    <input type=\"radio\" name=\"answer\" value=\"2\" id=\"quiz-var2\">\n                    <label for=\"quiz-var2\" id=\"label-var2\"></label>\n                </div>\n            </div>\n            <div class=\"row results-container no-margin hidden\">\n                <div class=\"col m6 s12\">\n                    Illustration\n                </div>\n                <div class=\"col m6 s12\">\n                    <p class=\"scores\"><b>Ainsi, vos résultats sont:</b> <br> vous l\'avez deviné: <span id=\"quiz-right\" class=\"quiz-result\"></span> sur <span id=\"quiz-total\" class=\"quiz-result\"></span> (<span id=\"quiz-percent\" class=\"quiz-result\"></span>)</p>\n                    <p>\n                       <span id=\"quiz-conclusion\"></span> Nous espérons que vous avez apprécié notre petit défi. Vous pouvez consulter d\'autres œuvres de Marie au <a href=\"/gallery.html\">Galerie d\'images</a>.\n                    </p>\n                </div>\n            </div>\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <ul id=\"quiz-steps\"></ul>\n                </div>\n            </div>\n        </form>\n        <div class=\"modal-footer\">\n            <a class=\"btn-flat waves-effect waves-dark left modal-close\">Fermer</a>\n            <a class=\"btn waves-effect waves-light\" id=\"quiz-next\" data-repeat=\"Répéter\" data-next=\"Davantage\">Davantage</a>\n        </div>\n    </div>', 0, 'a:0:{}', 0, ''),
(9, 1, 0, 'footer', '', 0, 0, 0, '<footer class=\"center-align\">\n    <a href=\"/\" class=\"footer-logo lazy\" data-src=\"/img/logo-[[!lingua.cultureKey]].svg\"></a>\n    [[Wayfinder? &level=`1` &startId=`0` &rowTpl=`wfRow`]]\n</footer>', 0, 'a:0:{}', 0, ''),
(10, 1, 0, 'wfRow', '', 0, 0, 0, '<li[[+wf.id]][[+wf.classes]]>\n    <a href=\"[[+wf.link]]\" title=\"[[lingua.getValue:default=`[[+wf.title]]`? &id=`[[+id]]` &field=`longtitle`]]\" [[+wf.attributes]]>\n        <!-- [[-+wf.linktext]] -->\n        [[lingua.getValue:default=`[[+wf.linktext]]`? &id=`[[+id]]` &field=`pagetitle`]]\n    </a>\n    [[+wf.wrapper]]\n</li>', 0, 'a:0:{}', 0, ''),
(11, 1, 0, 'wfTpl', '', 0, 0, 0, '<ul id=\"topnav\"[+wf.classes+]>\n    [[+wf.wrapper]]\n    <li>\n        <div class=\"divider\"></div>\n    </li>\n    <li class=\"networks\"><a href=\"https://www.instagram.com/mordvintsevamariia/\" rel=\"nofollow\"><i class=\"mdi mdi-instagram\"></i></a></li>\n</ul>', 0, 'a:0:{}', 0, ''),
(18, 1, 0, 'collectionItemTpl', '', 0, 0, 0, '<div class=\"picture\">\n    <div class=\"picture-image lazy materialboxed\" data-src=\"/[[+tv.image]]\" style=\"padding-top: [[!paddingTop? &file=`[[+tv.image]]`]]%\"></div>\n    <div class=\"picture-name\">\n        [[lingua.getValue:default=`[[+pagetitle]]`? &id=`[[+id]]` &field=`pagetitle`]]\n    </div>\n</div>', 0, 'a:0:{}', 0, ''),
(19, 1, 0, 'mainPage_galleryTpl', '', 0, 0, 0, '<div class=\"picture\">\n    <div class=\"picture-image lazy materialboxed\" data-src=\"/[[+img-url]]\" style=\"padding-top: [[+padding-top]]%\"></div>\n    <div class=\"picture-name\">\n        [[+title]]\n    </div>\n</div>', 0, 'a:0:{}', 0, ''),
(20, 1, 0, 'quiz_en', '', 0, 0, 0, '    <div id=\"quiz\" data-lang=\"en\">\n        <form class=\"quiz-form\">\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <h3 class=\"quiz-header\">Please, choose a picture you think is made by Mary</h3>\n                </div>\n            </div>\n            <div class=\"row quiz-container no-margin\">\n                <div class=\"col m6 s12\">\n                    <input type=\"radio\" name=\"answer\" value=\"1\" id=\"quiz-var1\">\n                    <label for=\"quiz-var1\" id=\"label-var1\"></label>\n                </div>\n                <div class=\"col m6 s12\">\n                    <input type=\"radio\" name=\"answer\" value=\"2\" id=\"quiz-var2\">\n                    <label for=\"quiz-var2\" id=\"label-var2\"></label>\n                </div>\n            </div>\n            <div class=\"row results-container no-margin hidden\">\n                <div class=\"col m6 s12\">\n                    Illustration\n                </div>\n                <div class=\"col m6 s12\">\n                    <p class=\"scores\"><b>So, your results are:</b> <br> you\'ve got: <span id=\"quiz-right\" class=\"quiz-result\"></span> from <span id=\"quiz-total\" class=\"quiz-result\"></span> (<span id=\"quiz-percent\" class=\"quiz-result\"></span>)</p>\n                    <p>\n                       <span id=\"quiz-conclusion\"></span> We hope you enjoyed our little challenge. You can check out\n                       other Mary\'s works at the <a href=\"/gallery.html\">image gallery</a>.\n                    </p>\n                </div>\n            </div>\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <ul id=\"quiz-steps\"></ul>\n                </div>\n            </div>\n            <div class=\"row\">\n                <div class=\"col s12\">\n                    <p>\n                        Try to figure, which works belongs <br> to brush of professional artists, <br>\n                        and which – to Mary\'s one! \n                    </p>\n                </div>\n            </div>\n        </form>\n        <div class=\"quiz-footer\">\n            <a class=\"btn waves-effect waves-light\" id=\"quiz-next\" data-repeat=\"Repeat\" data-next=\"Next\">Next</a>\n        </div>\n    </div>', 0, 'a:0:{}', 0, ''),
(21, 1, 0, 'quiz_fr', '', 0, 0, 0, '    <div id=\"quiz\" data-lang=\"fr\">\n        <form class=\"quiz-form\">\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <h3 class=\"quiz-header\">S\'il vous plaît, choisissez une image que vous pensez être faite par Marie</h3>\n                </div>\n            </div>\n            <div class=\"row quiz-container no-margin\">\n                <div class=\"col m6 s12\">\n                    <input type=\"radio\" name=\"answer\" value=\"1\" id=\"quiz-var1\">\n                    <label for=\"quiz-var1\" id=\"label-var1\"></label>\n                </div>\n                <div class=\"col m6 s12\">\n                    <input type=\"radio\" name=\"answer\" value=\"2\" id=\"quiz-var2\">\n                    <label for=\"quiz-var2\" id=\"label-var2\"></label>\n                </div>\n            </div>\n            <div class=\"row results-container no-margin hidden\">\n                <div class=\"col m6 s12\">\n                    Illustration\n                </div>\n                <div class=\"col m6 s12\">\n                    <p class=\"scores\"><b>Ainsi, vos résultats sont:</b> <br> vous l\'avez deviné: <span id=\"quiz-right\" class=\"quiz-result\"></span> sur <span id=\"quiz-total\" class=\"quiz-result\"></span> (<span id=\"quiz-percent\" class=\"quiz-result\"></span>)</p>\n                    <p>\n                       <span id=\"quiz-conclusion\"></span> Nous espérons que vous avez apprécié notre petit défi. Vous pouvez consulter d\'autres œuvres de Marie au <a href=\"/gallery.html\">Galerie d\'images</a>.\n                    </p>\n                </div>\n            </div>\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <ul id=\"quiz-steps\"></ul>\n                </div>\n            </div>\n            <div class=\"row\">\n                <div class=\"col s12\">\n                    <p>\n                        Essayez de deviner, quelles œuvres appartiennent <br> au pinceau des artistes professionnels, <br> et lesquelles – à celle de Marie! \n                    </p>\n                </div>\n            </div>\n        </form>\n        <div class=\"quiz-footer\">\n            <a class=\"btn waves-effect waves-light\" id=\"quiz-next\" data-repeat=\"Répéter\" data-next=\"Davantage\">Davantage</a>\n        </div>\n    </div>', 0, 'a:0:{}', 0, ''),
(22, 1, 0, 'quiz_ru', '', 0, 0, 0, '    <div id=\"quiz\" data-lang=\"ru\">\n        <form class=\"quiz-form\">\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <h3 class=\"quiz-header\">Выберите, какую из работ нарисовала Маша?</h3>\n                </div>\n            </div>\n            <div class=\"row quiz-container no-margin\">\n                <div class=\"col m6 s12\">\n                    <input type=\"radio\" name=\"answer\" value=\"1\" id=\"quiz-var1\">\n                    <label for=\"quiz-var1\" id=\"label-var1\"></label>\n                </div>\n                <div class=\"col m6 s12\">\n                    <input type=\"radio\" name=\"answer\" value=\"2\" id=\"quiz-var2\">\n                    <label for=\"quiz-var2\" id=\"label-var2\"></label>\n                </div>\n            </div>\n            <div class=\"row results-container no-margin hidden\">\n                <div class=\"col m6 s12\">\n                    Иллюстрация\n                </div>\n                <div class=\"col m6 s12\">\n                    <p class=\"scores\"><b>Итак, Ваши результаты:</b> <br> вы угадали: <span id=\"quiz-right\" class=\"quiz-result\"></span> из <span id=\"quiz-total\" class=\"quiz-result\"></span> (<span id=\"quiz-percent\" class=\"quiz-result\"></span>)</p>\n                    <p>\n                       <span id=\"quiz-conclusion\"></span> Надеемся, Вам понравилось наше небольшое испытание. Вы можете ознакомиться \n                       с другими картинами Маши в <a href=\"/gallery.html\">галерее работ</a>.\n                    </p>\n                </div>\n            </div>\n            <div class=\"row no-margin\">\n                <div class=\"col s12\">\n                    <ul id=\"quiz-steps\"></ul>\n                </div>\n            </div>\n            <div class=\"row\">\n                <div class=\"col s12\">\n                    <p>\n                        Попробуйте угадать, какие работы принадлежат<br>кисти профессиональных художников, <br>\n                        а какие – результат творчества Маши! \n                    </p>\n                </div>\n            </div>\n        </form>\n        <div class=\"quiz-footer\">\n            <a class=\"btn waves-effect waves-light\" id=\"quiz-next\" data-repeat=\"Повторить\" data-next=\"Далее\">Далее</a>\n        </div>\n    </div>', 0, 'a:0:{}', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_plugins`
--

CREATE TABLE `modx_site_plugins` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(191) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `plugincode` mediumtext NOT NULL,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `disabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `moduleguid` varchar(32) NOT NULL DEFAULT '',
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_plugins`
--

INSERT INTO `modx_site_plugins` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `plugincode`, `locked`, `properties`, `disabled`, `moduleguid`, `static`, `static_file`) VALUES
(6, 0, 0, 'Collections', '', 0, 5, 0, '/**\n * Collections\n *\n * DESCRIPTION\n *\n * This plugin inject JS to handle proper working of close buttons in Resource\'s panel (OnDocFormPrerender)\n * This plugin handles setting proper show_in_tree parameter (OnBeforeDocFormSave, OnResourceSort)\n *\n * @var modX $modx\n * @var array $scriptProperties\n */\n$corePath = $modx->getOption(\'collections.core_path\', null, $modx->getOption(\'core_path\', null, MODX_CORE_PATH) . \'components/collections/\');\n/** @var Collections $collections */\n$collections = $modx->getService(\n    \'collections\',\n    \'Collections\',\n    $corePath . \'model/collections/\',\n    array(\n        \'core_path\' => $corePath\n    )\n);\n\nif (!($collections instanceof Collections)) return \'\';\n\n$className = \"\\\\Collections\\\\Events\\\\{$modx->event->name}\";\nif (class_exists($className)) {\n    /** @var \\Collections\\Events\\Event $handler */\n    $handler = new $className($modx, $scriptProperties);\n    $handler->run();\n}\n\nreturn;', 0, 'a:0:{}', 0, '', 0, ''),
(7, 1, 0, 'pdoTools', '', 0, 6, 0, '/** @var modX $modx */\nswitch ($modx->event->name) {\n\n    case \'OnMODXInit\':\n        $fqn = $modx->getOption(\'pdoTools.class\', null, \'pdotools.pdotools\', true);\n        $path = $modx->getOption(\'pdotools_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\n        $modx->loadClass($fqn, $path, false, true);\n\n        $fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n        $path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\n        $modx->loadClass($fqn, $path, false, true);\n        break;\n\n    case \'OnSiteRefresh\':\n        /** @var pdoTools $pdoTools */\n        if ($pdoTools = $modx->getService(\'pdoTools\')) {\n            if ($pdoTools->clearFileCache()) {\n                $modx->log(modX::LOG_LEVEL_INFO, $modx->lexicon(\'refresh_default\') . \': pdoTools\');\n            }\n        }\n        break;\n\n    case \'OnWebPagePrerender\':\n        $parser = $modx->getParser();\n        if ($parser instanceof pdoParser) {\n            foreach ($parser->pdoTools->ignores as $key => $val) {\n                $modx->resource->_output = str_replace($key, $val, $modx->resource->_output);\n            }\n        }\n        break;\n}', 0, NULL, 0, '', 0, 'core/components/pdotools/elements/plugins/plugin.pdotools.php'),
(8, 0, 0, 'Ace', 'Ace code editor plugin for MODx Revolution', 0, 0, 0, '/**\n * Ace Source Editor Plugin\n *\n * Events: OnManagerPageBeforeRender, OnRichTextEditorRegister, OnSnipFormPrerender,\n * OnTempFormPrerender, OnChunkFormPrerender, OnPluginFormPrerender,\n * OnFileCreateFormPrerender, OnFileEditFormPrerender, OnDocFormPrerender\n *\n * @author Danil Kostin <danya.postfactum(at)gmail.com>\n *\n * @package ace\n *\n * @var array $scriptProperties\n * @var Ace $ace\n */\nif ($modx->event->name == \'OnRichTextEditorRegister\') {\n    $modx->event->output(\'Ace\');\n    return;\n}\n\nif ($modx->getOption(\'which_element_editor\', null, \'Ace\') !== \'Ace\') {\n    return;\n}\n\n$ace = $modx->getService(\'ace\', \'Ace\', $modx->getOption(\'ace.core_path\', null, $modx->getOption(\'core_path\').\'components/ace/\').\'model/ace/\');\n$ace->initialize();\n\n$extensionMap = array(\n    \'tpl\'   => \'text/x-smarty\',\n    \'htm\'   => \'text/html\',\n    \'html\'  => \'text/html\',\n    \'css\'   => \'text/css\',\n    \'scss\'  => \'text/x-scss\',\n    \'less\'  => \'text/x-less\',\n    \'svg\'   => \'image/svg+xml\',\n    \'xml\'   => \'application/xml\',\n    \'xsl\'   => \'application/xml\',\n    \'js\'    => \'application/javascript\',\n    \'json\'  => \'application/json\',\n    \'php\'   => \'application/x-php\',\n    \'sql\'   => \'text/x-sql\',\n    \'md\'    => \'text/x-markdown\',\n    \'txt\'   => \'text/plain\',\n    \'twig\'  => \'text/x-twig\'\n);\n\n// Define default mime for html elements(templates, chunks and html resources)\n$html_elements_mime=$modx->getOption(\'ace.html_elements_mime\',null,false);\nif(!$html_elements_mime){\n    // this may deprecated in future because components may set ace.html_elements_mime option now\n    switch (true) {\n        case $modx->getOption(\'twiggy_class\'):\n            $html_elements_mime = \'text/x-twig\';\n            break;\n        case $modx->getOption(\'pdotools_fenom_parser\'):\n            $html_elements_mime = \'text/x-smarty\';\n            break;\n        default:\n            $html_elements_mime = \'text/html\';\n    }\n}\n\n// Defines wether we should highlight modx tags\n$modxTags = false;\nswitch ($modx->event->name) {\n    case \'OnSnipFormPrerender\':\n        $field = \'modx-snippet-snippet\';\n        $mimeType = \'application/x-php\';\n        break;\n    case \'OnTempFormPrerender\':\n        $field = \'modx-template-content\';\n        $modxTags = true;\n        $mimeType = $html_elements_mime;\n        break;\n    case \'OnChunkFormPrerender\':\n        $field = \'modx-chunk-snippet\';\n        if ($modx->controller->chunk && $modx->controller->chunk->isStatic()) {\n            $extension = pathinfo($modx->controller->chunk->name, PATHINFO_EXTENSION);\n            if(!$extension||!isset($extensionMap[$extension])){\n                $extension = pathinfo($modx->controller->chunk->getSourceFile(), PATHINFO_EXTENSION);\n            }\n            $mimeType = isset($extensionMap[$extension]) ? $extensionMap[$extension] : \'text/plain\';\n        } else {\n            $mimeType = $html_elements_mime;\n        }\n        $modxTags = true;\n        break;\n    case \'OnPluginFormPrerender\':\n        $field = \'modx-plugin-plugincode\';\n        $mimeType = \'application/x-php\';\n        break;\n    case \'OnFileCreateFormPrerender\':\n        $field = \'modx-file-content\';\n        $mimeType = \'text/plain\';\n        break;\n    case \'OnFileEditFormPrerender\':\n        $field = \'modx-file-content\';\n        $extension = pathinfo($scriptProperties[\'file\'], PATHINFO_EXTENSION);\n        $mimeType = isset($extensionMap[$extension])\n            ? $extensionMap[$extension]\n            : (\'@FILE:\'.pathinfo($scriptProperties[\'file\'], PATHINFO_BASENAME));\n        $modxTags = $extension == \'tpl\';\n        break;\n    case \'OnDocFormPrerender\':\n        if (!$modx->controller->resourceArray) {\n            return;\n        }\n        $field = \'ta\';\n        $mimeType = $modx->getObject(\'modContentType\', $modx->controller->resourceArray[\'content_type\'])->get(\'mime_type\');\n\n        if($mimeType == \'text/html\')$mimeType = $html_elements_mime;\n\n        if ($modx->getOption(\'use_editor\')){\n            $richText = $modx->controller->resourceArray[\'richtext\'];\n            $classKey = $modx->controller->resourceArray[\'class_key\'];\n            if ($richText || in_array($classKey, array(\'modStaticResource\',\'modSymLink\',\'modWebLink\',\'modXMLRPCResource\'))) {\n                $field = false;\n            }\n        }\n        $modxTags = true;\n        break;\n    default:\n        return;\n}\n\n$modxTags = (int) $modxTags;\n$script = \'\';\nif ($field) {\n    $script .= \"MODx.ux.Ace.replaceComponent(\'$field\', \'$mimeType\', $modxTags);\";\n}\n\nif ($modx->event->name == \'OnDocFormPrerender\' && !$modx->getOption(\'use_editor\')) {\n    $script .= \"MODx.ux.Ace.replaceTextAreas(Ext.query(\'.modx-richtext\'));\";\n}\n\nif ($script) {\n    $modx->controller->addHtml(\'<script>Ext.onReady(function() {\' . $script . \'});</script>\');\n}', 0, NULL, 0, '', 0, 'ace/elements/plugins/ace.plugin.php'),
(9, 0, 1, 'Lingua', '', 0, 7, 0, 'header(\'Content-Type: text/html; charset=utf-8\');\r\n/**\r\n * Lingua\r\n *\r\n * Copyright 2013-2015 by goldsky <goldsky@virtudraft.com>\r\n *\r\n * This file is part of Lingua, a MODX\'s Lexicon switcher for front-end interface\r\n *\r\n * Lingua is free software; you can redistribute it and/or modify it under the\r\n * terms of the GNU General Public License as published by the Free Software\r\n * Foundation version 3.\r\n *\r\n * Lingua is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * Lingua; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package lingua\r\n * @subpackage lingua_plugin\r\n */\r\n$event = $modx->event->name;\r\nswitch ($event) {\r\n    case \'OnHandleRequest\': // for global\r\n        break;\r\n\r\n    case \'OnInitCulture\':   // for request class\r\n        if ($modx->context->key === \'mgr\') {\r\n            return;\r\n        }\r\n        $lingua = $modx->getService(\'lingua\', \'Lingua\', MODX_CORE_PATH . \'components/lingua/model/lingua/\');\r\n        if (!($lingua instanceof Lingua)) {\r\n            return;\r\n        }\r\n        $modx->lexicon->load(\'lingua:default\');\r\n        $langGetKey = $modx->getOption(\'lingua.request_key\', $scriptProperties, \'lang\');\r\n        $langGetKeyValue = filter_input(INPUT_GET, $langGetKey, FILTER_SANITIZE_STRING);\r\n        $langGetKeyValue = strtolower($langGetKeyValue);\r\n        $langCookieValue = filter_input(INPUT_COOKIE, \'modx_lingua_switcher\', FILTER_SANITIZE_STRING);\r\n        $langCookieValue = strtolower($langCookieValue);\r\n        if (!empty($langGetKeyValue) &&\r\n                $langGetKeyValue !== $modx->cultureKey &&\r\n                strlen($langGetKeyValue) === 2\r\n        ) {\r\n            $lingua->setCultureKey($langGetKeyValue);\r\n        } else if (!empty($langCookieValue) &&\r\n                $langCookieValue !== $modx->cultureKey &&\r\n                strlen($langCookieValue) === 2\r\n        ) {\r\n            $lingua->setCultureKey($langCookieValue);\r\n        } else if(empty($langGetKeyValue) &&\r\n                empty($langCookieValue)\r\n        ){\r\n            $detectBrowser = $modx->getOption(\'lingua.detect_browser\');\r\n            if ($detectBrowser === \'1\') {\r\n                $languages = explode(\',\', filter_input(INPUT_SERVER, \'HTTP_ACCEPT_LANGUAGE\', FILTER_SANITIZE_STRING));\r\n                $sortedLangs = array();\r\n                foreach ($languages as $language) {\r\n                    $language = strtolower($language);\r\n                    $parts = @explode(\';\', $language);\r\n                    if (!isset($parts[1])) {\r\n                        $sort = 1.0;\r\n                    } else {\r\n                        $x = @explode(\'=\', $parts[1]);\r\n                        $sort = $x[1] - 0;\r\n                    }\r\n                    $sortedLangs[$parts[0]] = $sort;\r\n                }\r\n                arsort($sortedLangs);\r\n                $langs = array_keys($sortedLangs);\r\n                $linguaLangs = $modx->getCollection(\'linguaLangs\', array(\r\n                    \'active\' => 1\r\n                ));\r\n                $c = $modx->newQuery(\'linguaLangs\');\r\n                $c->where(\'active=1\');\r\n                $contextLangs = $modx->context->config[\'lingua.langs\'];\r\n                if (!empty($contextLangs)) {\r\n                    $contextLangs = array_map(\'trim\', @explode(\',\', $contextLangs));\r\n                    $c->where(array(\r\n                        \'lang_code:IN\' => $contextLangs\r\n                    ));\r\n                }\r\n                $linguaLangs = $modx->getCollection(\'linguaLangs\', $c);\r\n                $existingLangs = array();\r\n                if ($linguaLangs) {\r\n                    foreach ($linguaLangs as $linguaLang) {\r\n                        $existingLangs[] = $linguaLang->get(\'lang_code\');\r\n                    }\r\n                }\r\n\r\n                $acceptedLangs = array_intersect($existingLangs, $langs);\r\n                $acceptedLangs = array_values($acceptedLangs); // reset index\r\n\r\n                if (!empty($acceptedLangs) && is_array($acceptedLangs)) {\r\n                    $lingua->setCultureKey($acceptedLangs[0]);\r\n                }\r\n            }\r\n        }\r\n        $modx->cultureKey = $lingua->getCultureKey();\r\n        if ($modx->cultureKey !== $modx->getOption(\'cultureKey\')) {\r\n            $modx->setOption(\'cultureKey\', $modx->cultureKey);\r\n            $modx->context->config[\'cultureKey\'] = $modx->cultureKey;\r\n        }\r\n        $modx->setPlaceholder(\'lingua.cultureKey\', $modx->cultureKey);\r\n        $modx->setPlaceholder(\'lingua.language\', $modx->cultureKey);\r\n\r\n        break;\r\n\r\n    /**\r\n     * /////////////////// MANAGER SIDE ///////////////////\r\n     */\r\n    case \'OnDocFormPrerender\':\r\n        $contexts = $modx->getOption(\'lingua.contexts\', $scriptProperties, \'web\');\r\n        if (!empty($contexts)) {\r\n            $contexts = array_map(\'trim\', @explode(\',\', $contexts));\r\n            if ($resource) {\r\n                $currentContext = $resource->get(\'context_key\');\r\n            } else {\r\n                $currentContext = filter_input(INPUT_GET, \'context_key\', FILTER_SANITIZE_STRING);\r\n            }\r\n            if (!in_array($currentContext, $contexts)) {\r\n                return;\r\n            }\r\n        }\r\n        $parents = $modx->getOption(\'lingua.parents\', $scriptProperties);\r\n        if (!empty($parents)) {\r\n            $parents = array_map(\'trim\', @explode(\',\', $parents));\r\n            if ($resource) {\r\n                $currentParent = $resource->get(\'parent\');\r\n            } else {\r\n                $currentParent = filter_input(INPUT_GET, \'parent\', FILTER_SANITIZE_NUMBER_INT);\r\n            }\r\n            if (!in_array($currentParent, $parents)) {\r\n                return;\r\n            }\r\n        }\r\n        if (is_object($resource)) {\r\n            $ids = $modx->getOption(\'lingua.ids\', $scriptProperties);\r\n            if (!empty($ids)) {\r\n                $ids = array_map(\'trim\', @explode(\',\', $ids));\r\n                $currentId = $resource->get(\'id\');\r\n                if (!in_array($currentId, $ids)) {\r\n                    return;\r\n                }\r\n            }\r\n        }\r\n\r\n        $lingua = $modx->getService(\'lingua\', \'Lingua\', MODX_CORE_PATH . \'components/lingua/model/lingua/\');\r\n        if (!($lingua instanceof Lingua)) {\r\n            return;\r\n        }\r\n\r\n        $modx->lexicon->load(\'lingua:default\');\r\n        $languages = $lingua->getLanguages();\r\n        if (empty($languages)) {\r\n            return;\r\n        }\r\n        $modx->regClientCSS(MODX_BASE_URL . \'assets/components/lingua/css/mgr.css\');\r\n        $modx->controller->addLastJavascript(MODX_BASE_URL . \'assets/components/lingua/js/mgr/resource.js\');\r\n        // $modx->getOption(\'cultureKey\') doesn\'t work!\r\n        $modCultureKey = $modx->getObject(\'modSystemSetting\', array(\'key\' => \'cultureKey\'));\r\n        $cultureKey = $modCultureKey->get(\'value\');\r\n        $storeData = array();\r\n        $storeDefaultData = array();\r\n        $configLang = array();\r\n        $linguaSiteContentArray = array();\r\n        $createHiddenFields = array();\r\n        foreach ($languages as $language) {\r\n            $configLang[$language[\'lang_code\']] = array(\r\n                \'lang_code\' => $language[\'lang_code\'],\r\n                \'local_name\' => $language[\'local_name\'],\r\n                \'flag\' => $language[\'flag\'],\r\n            );\r\n            if ($language[\'lang_code\'] === $cultureKey) {\r\n                $storeDefaultData[] = array(\r\n                    $language[\'lang_code\'],\r\n                    $language[\'local_name\'],\r\n                    $language[\'flag\'],\r\n                );\r\n                continue;\r\n            }\r\n            $storeData[] = array(\r\n                $language[\'lang_code\'],\r\n                $language[\'local_name\'],\r\n                $language[\'flag\'],\r\n            );\r\n            if ($mode === modSystemEvent::MODE_UPD) {\r\n                $linguaSiteContent = $modx->getObject(\'linguaSiteContent\', array(\r\n                    \'resource_id\' => $resource->get(\'id\'),\r\n                    \'lang_id\' => $language[\'id\']\r\n                ));\r\n                if ($linguaSiteContent) {\r\n                    $linguaSiteContentArray[$language[\'lang_code\']] = $linguaSiteContent->toArray();\r\n                } else {\r\n                    $linguaSiteContentArray[$language[\'lang_code\']] = array();\r\n                }\r\n            } else {\r\n                $linguaSiteContentArray[$language[\'lang_code\']] = array();\r\n            }\r\n            $modx->regClientStartupHTMLBlock(\'<style>.icon-lingua-flag-\' . $language[\'lcid_string\'] . \' {background-image: url(\\\'../\' . $language[\'flag\'] . \'\\\'); background-repeat: no-repeat;}</style>\');\r\n            $createHiddenFields[] = $language;\r\n        } // foreach ($languages as $language)\r\n        //------------------------------------------------------------------\r\n        $formCustomized = $modx->getOption(\'lingua.form_customization\');\r\n        $modx->controller->addHtml(\'\r\n<script type=\"text/javascript\">\r\nExt.onReady(function() {\r\n    window.lingua = new Lingua({\r\n        defaultLang: \"\' . $cultureKey . \'\",\r\n        langs: \' . json_encode($configLang) . \',\r\n        siteContent: \' . json_encode($linguaSiteContentArray) . \',\r\n        formCustomized: \' . $formCustomized . \'\r\n    });\r\n    lingua.flagDefaultFields();\r\n    lingua.createHiddenFields(\' . json_encode($createHiddenFields) . \');\r\n    lingua.getMenu({\r\n        storeData: \' . json_encode(array_merge($storeDefaultData, $storeData)) . \'\r\n    });\r\n});\r\n</script>\');\r\n        if ($formCustomized) {\r\n            $modx->controller->addLastJavascript(MODX_BASE_URL . \'assets/components/lingua/js/mgr/fcinit.js\');\r\n        }\r\n        //------------------------------------------------------------------\r\n        break;\r\n\r\n    case \'OnResourceTVFormRender\':\r\n        if (!is_object($resource) && is_numeric($resource)) {\r\n            $resourceId = $resource;\r\n            $resource = $modx->getObject(\'modResource\', $resource);\r\n        }\r\n        $contexts = $modx->getOption(\'lingua.contexts\', $scriptProperties, \'web\');\r\n        if (!empty($contexts)) {\r\n            $contexts = array_map(\'trim\', @explode(\',\', $contexts));\r\n            if ($resource) {\r\n                $currentContext = $resource->get(\'context_key\');\r\n            } else {\r\n                $currentContext = filter_input(INPUT_GET, \'context_key\', FILTER_SANITIZE_STRING);\r\n            }\r\n            if (!in_array($currentContext, $contexts)) {\r\n                return;\r\n            }\r\n        }\r\n        $parents = $modx->getOption(\'lingua.parents\', $scriptProperties);\r\n        if (!empty($parents)) {\r\n            $parents = array_map(\'trim\', @explode(\',\', $parents));\r\n            if ($resource) {\r\n                $currentParent = $resource->get(\'parent\');\r\n            } else {\r\n                $currentParent = filter_input(INPUT_GET, \'parent\', FILTER_SANITIZE_NUMBER_INT);\r\n            }\r\n            if (!in_array($currentParent, $parents)) {\r\n                return;\r\n            }\r\n        }\r\n        if (is_object($resource)) {\r\n            $ids = $modx->getOption(\'lingua.ids\', $scriptProperties);\r\n            if (!empty($ids)) {\r\n                $ids = array_map(\'trim\', @explode(\',\', $ids));\r\n                $currentId = $resource->get(\'id\');\r\n                if (!in_array($currentId, $ids)) {\r\n                    return;\r\n                }\r\n            }\r\n        }\r\n\r\n        $lingua = $modx->getService(\'lingua\', \'Lingua\', MODX_CORE_PATH . \'components/lingua/model/lingua/\');\r\n        if (!($lingua instanceof Lingua)) {\r\n            return;\r\n        }\r\n        $languages = $lingua->getLanguages(true, false);\r\n        if (empty($languages)) {\r\n            return;\r\n        }\r\n        $initAllClonedTVFields = array();\r\n        foreach ($languages as $language) {\r\n            $initAllClonedTVFields[] = $language;\r\n        }\r\n\r\n        if ($resource) {\r\n            $tvs = $resource->getTemplateVars();\r\n        } else {\r\n            $templateId = $template;\r\n            $template = $modx->getObject(\'modTemplate\', $templateId);\r\n            $tvs = $template->getTemplateVars();\r\n        }\r\n        if (!$tvs) {\r\n            return;\r\n        }\r\n\r\n        $tvIds = array();\r\n        $tvOutputs = array();\r\n        foreach ($tvs as $tv) {\r\n            $tvIds[] = $tv->get(\'id\');\r\n        }\r\n        $c = $modx->newQuery(\'linguaSiteTmplvars\');\r\n        $c->where(array(\r\n            \'tmplvarid:IN\' => $tvIds\r\n        ));\r\n        $linguaSiteTmplvars = $modx->getCollection(\'linguaSiteTmplvars\', $c);\r\n        if (!$linguaSiteTmplvars) {\r\n            return;\r\n        }\r\n\r\n        $formElements = array();\r\n        foreach ($scriptProperties[\'categories\'] as $category) {\r\n            foreach ($category[\'tvs\'] as $tv) {\r\n                $formElements[$tv->get(\'id\')] = $tv;\r\n            }\r\n        }\r\n\r\n        if (!empty($modx->controller->scriptProperties[\'showCheckbox\'])) {\r\n            $showCheckbox = 1;\r\n        }\r\n\r\n        $tmplvars = array();\r\n        $cloneTVFields = array();\r\n        $count = 0;\r\n        // $modx->getOption(\'cultureKey\') doesn\'t work!\r\n        $modCultureKey = $modx->getObject(\'modSystemSetting\', array(\'key\' => \'cultureKey\'));\r\n        $cultureKey = $modCultureKey->get(\'value\');\r\n        foreach ($linguaSiteTmplvars as $linguaTv) {\r\n            $tvId = $linguaTv->get(\'tmplvarid\');\r\n            if (!isset($formElements[$tvId])) {\r\n                continue;\r\n            }\r\n            $tv = $formElements[$tvId];\r\n            $tmplvars[] = array(\r\n                \'id\' => $tvId,\r\n                \'type\' => $tv->get(\'type\'),\r\n            );\r\n            $tvArray = $tv->toArray(\'tv.\');\r\n            foreach ($languages as $language) {\r\n                if ($language[\'lang_code\'] === $cultureKey) {\r\n                    continue;\r\n                }\r\n                $linguaTVContent = $modx->getObject(\'linguaSiteTmplvarContentvalues\', array(\r\n                    \'tmplvarid\' => $tvId,\r\n                    \'contentid\' => $resourceId,\r\n                    \'lang_id\' => $language[\'id\']\r\n                ));\r\n                // Start to manipulate the ID to parse hidden TVs\r\n                $content = \'\';\r\n                if ($linguaTVContent) {\r\n                    $content = $linguaTVContent->get(\'value\');\r\n                }\r\n                // Hack TV\'s value because renderInput ignores empty value\r\n                $tv->set(\'value\', $content);\r\n                $inputForm = $tv->renderInput($resource, array(\r\n                    \'value\' => $content\r\n                ));\r\n                if (empty($inputForm)) {\r\n                    continue;\r\n                }\r\n                $tvCloneId = $tvId . \'_\' . $language[\'lang_code\'] . \'_lingua_tv\';\r\n                // basic replacements\r\n                $cloneInputForm = $inputForm;\r\n                $cloneInputForm = preg_replace(\'/(\"|\\\'){1}tv\' . $tvId . \'(\"|\\\'){1}/\', \'${1}tv\' . $tvCloneId . \'${2}\', $cloneInputForm);\r\n                $cloneInputForm = preg_replace(\'/(\"|\\\'){1}tv\' . $tvId . \'\\[\\](\"|\\\'){1}/\', \'${1}tv\' . $tvCloneId . \'[]${2}\', $cloneInputForm);\r\n                // advanced replacements\r\n                $linguaSiteTmplvarsPatterns = $modx->getCollection(\'linguaSiteTmplvarsPatterns\', array(\r\n                    \'type\' => $tv->get(\'type\')\r\n                ));\r\n                if ($linguaSiteTmplvarsPatterns) {\r\n                    foreach ($linguaSiteTmplvarsPatterns as $pattern) {\r\n                        $search = $pattern->get(\'search\');\r\n                        $search = str_replace(\'{{tvId}}\', $tvId, $search);\r\n                        $replacement = $pattern->get(\'replacement\');\r\n                        $replacement = str_replace(\'{{tvCloneId}}\', $tvCloneId, $replacement);\r\n                        $cloneInputForm = preg_replace($search, $replacement, $cloneInputForm);\r\n                    }\r\n                }\r\n                $count++;\r\n                $phs = $tvArray;\r\n                $phs[\'tv.id\'] = $tvCloneId;\r\n                $phs[\'tv.formElement\'] = $cloneInputForm;\r\n                $phs[\'tv.showCheckbox\'] = $showCheckbox;\r\n                $cloneTVFields[] = $lingua->processElementTags($lingua->parseTpl(\'lingua.resourcetv.row\', $phs));\r\n            }\r\n        }\r\n\r\n        // reset any left out output after rendering TV forms above\r\n        if ($modx->event->name === \'OnTVInputRenderList\') {\r\n            $modx->event->_output = \'\';\r\n        }\r\n        $modx->event->output(@implode(\"\\n\", $cloneTVFields));\r\n        $jsHTML = \"\r\n<script>\r\n    Ext.onReady(function() {\r\n        lingua.config.tmplvars = \" . json_encode($tmplvars) . \";\r\n        lingua.initAllClonedTVFields(\" . json_encode($initAllClonedTVFields) . \");\r\n        lingua.flagDefaultTVFields();\r\n    });\r\n</script>\";\r\n        $modx->event->output($jsHTML);\r\n\r\n        break;\r\n\r\n    case \'OnDocFormSave\':\r\n        $contexts = $modx->getOption(\'lingua.contexts\', $scriptProperties, \'web\');\r\n        if (!empty($contexts)) {\r\n            $contexts = array_map(\'trim\', @explode(\',\', $contexts));\r\n            $currentContext = $resource->get(\'context_key\');\r\n            if (!in_array($currentContext, $contexts)) {\r\n                return;\r\n            }\r\n        }\r\n        $parents = $modx->getOption(\'lingua.parents\', $scriptProperties);\r\n        if (!empty($parents)) {\r\n            $parents = array_map(\'trim\', @explode(\',\', $parents));\r\n            $currentParent = $resource->get(\'parent\');\r\n            if (!in_array($currentParent, $parents)) {\r\n                return;\r\n            }\r\n        }\r\n        $ids = $modx->getOption(\'lingua.ids\', $scriptProperties);\r\n        if (!empty($ids)) {\r\n            $ids = array_map(\'trim\', @explode(\',\', $ids));\r\n            $currentId = $resource->get(\'id\');\r\n            if (!in_array($currentId, $ids)) {\r\n                return;\r\n            }\r\n        }\r\n\r\n        $lingua = $modx->getService(\'lingua\', \'Lingua\', MODX_CORE_PATH . \'components/lingua/model/lingua/\');\r\n        if (!($lingua instanceof Lingua)) {\r\n            return;\r\n        }\r\n\r\n        // update linguaSiteContent\r\n        $reverting = array();\r\n        $clearKeys = array();\r\n        // $modx->getOption(\'cultureKey\') doesn\'t work!\r\n        $modCultureKey = $modx->getObject(\'modSystemSetting\', array(\'key\' => \'cultureKey\'));\r\n        $cultureKey = $modCultureKey->get(\'value\');\r\n        foreach ($resource->_fields as $k => $v) {\r\n            if (!preg_match(\'/_lingua$/\', $k)) {\r\n                continue;\r\n            }\r\n            foreach ($v as $a => $b) {\r\n                if ($a === $cultureKey) {\r\n                    continue;\r\n                }\r\n                $reverting[$a][preg_replace(\'/_lingua$/\', \'\', $k)] = $b;\r\n            }\r\n            $clearKeys[] = $k;\r\n        }\r\n\r\n        $resourceId = $resource->get(\'id\');\r\n        foreach ($reverting as $k => $v) {\r\n            $lingua->setContentTranslation($resourceId, $k, $v);\r\n        }\r\n\r\n        // update linguaSiteTmplvarContentvalues\r\n        $reverting = array();\r\n        foreach ($resource->_fields as $k => $value) {\r\n            if (!preg_match(\'/_lingua_tv$/\', $k)) {\r\n                continue;\r\n            }\r\n            $tvKey = preg_replace(\'/_lingua_tv$/\', \'\', $k);\r\n            $tvKeys = @explode(\'_\', $tvKey);\r\n            $tvId = str_replace(\'tv\', \'\', $tvKeys[0]);\r\n            if (!is_numeric($tvId)) {\r\n                continue;\r\n            }\r\n            $reverse = array_reverse($tvKeys);\r\n            $lang = $reverse[0];\r\n            if ($lang === $cultureKey) {\r\n                continue;\r\n            }\r\n            $tv = $modx->getObject(\'modTemplateVar\', $tvId);\r\n            $tvKey = $tvKeys[0];\r\n            /* validation for different types */\r\n            switch ($tv->get(\'type\')) {\r\n                case \'url\':\r\n                    // tv16_prefix_id_lingua_tv\r\n                    $prefix = $resource->_fields[$tvKey . \'_prefix_\' . $lang . \'_lingua_tv\'];\r\n                    if ($prefix != \'--\') {\r\n                        $value = str_replace(array(\'ftp://\', \'http://\', \'https://\', \'ftp://\', \'mailto:\'), \'\', $value);\r\n                        $value = $prefix . $value;\r\n                    }\r\n                    $reverting[$lang][$tvId] = $value;\r\n\r\n                    break;\r\n                case \'date\':\r\n                    $value = empty($value) ? \'\' : strftime(\'%Y-%m-%d %H:%M:%S\', strtotime($value));\r\n\r\n                    break;\r\n                /* ensure tag types trim whitespace from tags */\r\n                case \'tag\':\r\n                case \'autotag\':\r\n                    $tags = explode(\',\', $value);\r\n                    $newTags = array();\r\n                    foreach ($tags as $tag) {\r\n                        $newTags[] = trim($tag);\r\n                    }\r\n                    $value = implode(\',\', $newTags);\r\n\r\n                    break;\r\n                default:\r\n                    /* handles checkboxes & multiple selects elements */\r\n                    if (is_array($value)) {\r\n                        $featureInsert = array();\r\n                        while (list($featureValue, $featureItem) = each($value)) {\r\n                            if (empty($featureItem)) {\r\n                                continue;\r\n                            }\r\n                            $featureInsert[count($featureInsert)] = $featureItem;\r\n                        }\r\n                        $value = implode(\'||\', $featureInsert);\r\n                    }\r\n\r\n                    break;\r\n            }\r\n            $reverting[$lang][$tvId] = $value;\r\n            $clearKeys[] = $k;\r\n        }\r\n\r\n        /**\r\n         * json seems to have number of characters limit;\r\n         * that makes saving success report truncated and output modal hangs,\r\n         * TV\'s proccessing does this outside of reverting\'s loops\r\n         */\r\n        if (!empty($clearKeys)) {\r\n            foreach ($clearKeys as $k) {\r\n                $resource->set($k, \'\');\r\n            }\r\n        }\r\n\r\n        foreach ($reverting as $k => $tmplvars) {\r\n            foreach ($tmplvars as $key => $val) {\r\n                $lingua->setTVTranslation($resourceId, $k, $key, $val);\r\n            }\r\n        }\r\n\r\n        // clear cache\r\n        $contexts = array($resource->get(\'context_key\'));\r\n        $cacheManager = $modx->getCacheManager();\r\n        $cacheManager->refresh(array(\r\n            \'lingua/resource\' => array(\'contexts\' => $contexts),\r\n        ));\r\n        break;\r\n\r\n    case \'OnResourceDuplicate\':\r\n        $contexts = $modx->getOption(\'lingua.contexts\', $scriptProperties, \'web\');\r\n        if (!empty($contexts)) {\r\n            $contexts = array_map(\'trim\', @explode(\',\', $contexts));\r\n            $currentContext = $oldResource->get(\'context_key\');\r\n            if (!in_array($currentContext, $contexts)) {\r\n                return;\r\n            }\r\n        }\r\n        $parents = $modx->getOption(\'lingua.parents\', $scriptProperties);\r\n        if (!empty($parents)) {\r\n            $parents = array_map(\'trim\', @explode(\',\', $parents));\r\n            $currentParent = $oldResource->get(\'parent\');\r\n            if (!in_array($currentParent, $parents)) {\r\n                return;\r\n            }\r\n        }\r\n        $ids = $modx->getOption(\'lingua.ids\', $scriptProperties);\r\n        if (!empty($ids)) {\r\n            $ids = array_map(\'trim\', @explode(\',\', $ids));\r\n            $currentId = $oldResource->get(\'id\');\r\n            if (!in_array($currentId, $ids)) {\r\n                return;\r\n            }\r\n        }\r\n\r\n        $linguaSiteContents = $modx->getCollection(\'linguaSiteContent\', array(\r\n            \'resource_id\' => $oldResource->get(\'id\')\r\n        ));\r\n        if ($linguaSiteContents) {\r\n            foreach ($linguaSiteContents as $linguaSiteContent) {\r\n                $params = $linguaSiteContent->toArray();\r\n                unset($params[\'id\']);\r\n                $params[\'resource_id\'] = $newResource->get(\'id\');\r\n                $newLinguaSiteContent = $modx->newObject(\'linguaSiteContent\');\r\n                $newLinguaSiteContent->fromArray($params);\r\n                $newLinguaSiteContent->save();\r\n            }\r\n        }\r\n        break;\r\n\r\n    case \'OnEmptyTrash\':\r\n        if (!empty($ids) && is_array($ids)) {\r\n            $collection = $modx->getCollection(\'linguaSiteContent\', array(\r\n                \'resource_id:IN\' => $ids\r\n            ));\r\n            if ($collection) {\r\n                foreach ($collection as $item) {\r\n                    $item->remove();\r\n                }\r\n            }\r\n        }\r\n        break;\r\n\r\n    case \'OnTemplateSave\':\r\n    case \'OnTempFormSave\':\r\n    case \'OnTVFormSave\':\r\n    case \'OnSnipFormSave\':\r\n    case \'OnPluginFormSave\':\r\n    case \'OnMediaSourceFormSave\':\r\n    case \'OnChunkFormSave\':\r\n    case \'OnSiteRefresh\':\r\n        $cacheManager = $modx->getCacheManager();\r\n        $cacheManager->refresh(array(\r\n            \'lingua/resource\' => array(),\r\n        ));\r\n        break;\r\n\r\n    default:\r\n        break;\r\n}\r\nreturn;', 0, NULL, 0, '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_plugin_events`
--

CREATE TABLE `modx_site_plugin_events` (
  `pluginid` int(10) NOT NULL DEFAULT '0',
  `event` varchar(191) NOT NULL DEFAULT '',
  `priority` int(10) NOT NULL DEFAULT '0',
  `propertyset` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_plugin_events`
--

INSERT INTO `modx_site_plugin_events` (`pluginid`, `event`, `priority`, `propertyset`) VALUES
(6, 'FredBeforeRender', 0, 0),
(6, 'FredOnBeforeGetResourceTree', 0, 0),
(6, 'OnBeforeDocFormSave', 0, 0),
(6, 'OnBeforeEmptyTrash', 0, 0),
(6, 'OnDocFormPrerender', 0, 0),
(6, 'OnDocFormRender', 0, 0),
(6, 'OnManagerPageBeforeRender', 0, 0),
(6, 'OnManagerPageInit', 0, 0),
(6, 'OnResourceBeforeSort', 0, 0),
(6, 'OnResourceDuplicate', 0, 0),
(7, 'OnMODXInit', -100, 0),
(7, 'OnSiteRefresh', 0, 0),
(7, 'OnWebPagePrerender', -100, 0),
(8, 'OnChunkFormPrerender', 0, 0),
(8, 'OnDocFormPrerender', 0, 0),
(8, 'OnFileCreateFormPrerender', 0, 0),
(8, 'OnFileEditFormPrerender', 0, 0),
(8, 'OnManagerPageBeforeRender', 0, 0),
(8, 'OnPluginFormPrerender', 0, 0),
(8, 'OnRichTextEditorRegister', 0, 0),
(8, 'OnSnipFormPrerender', 0, 0),
(8, 'OnTempFormPrerender', 0, 0),
(9, 'OnChunkFormSave', 0, 0),
(9, 'OnDocFormPrerender', 0, 0),
(9, 'OnDocFormSave', 0, 0),
(9, 'OnEmptyTrash', 0, 0),
(9, 'OnHandleRequest', 0, 0),
(9, 'OnInitCulture', 0, 0),
(9, 'OnMediaSourceFormSave', 0, 0),
(9, 'OnPluginFormSave', 0, 0),
(9, 'OnResourceDuplicate', 0, 0),
(9, 'OnResourceTVFormRender', 0, 0),
(9, 'OnSiteRefresh', 0, 0),
(9, 'OnSnipFormSave', 0, 0),
(9, 'OnTempFormSave', 0, 0),
(9, 'OnTemplateSave', 0, 0),
(9, 'OnTVFormSave', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_snippets`
--

CREATE TABLE `modx_site_snippets` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(191) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `snippet` mediumtext,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `moduleguid` varchar(32) NOT NULL DEFAULT '',
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_snippets`
--

INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(5, 1, 0, 'currentCulture', '', 0, 0, 0, '$defaultLinguaCorePath = $modx->getOption(\'core_path\') . \'components/lingua/\';\n$linguaCorePath = $modx->getOption(\'lingua.core_path\', null, $defaultLinguaCorePath);\n$lingua = $modx->getService(\'lingua\', \'Lingua\', $linguaCorePath . \'model/lingua/\', $scriptProperties);\n\n$activeOnly = $modx->getOption(\'activeOnly\', $scriptProperties, \'1\');\n$defaultLinguaCorePath = $modx->getOption(\'core_path\') . \'components/lingua/\';\n$linguaCorePath = $modx->getOption(\'lingua.core_path\', null, $defaultLinguaCorePath);\n$lingua = $modx->getService(\'lingua\', \'Lingua\', $linguaCorePath . \'model/lingua/\', $scriptProperties);\n$languages = $lingua->getLanguages($activeOnly);\n\nreturn $languages[$modx->cultureKey][\'local_name\'];', 0, 'a:0:{}', '', 0, ''),
(6, 0, 0, 'Wayfinder', 'Wayfinder for MODx Revolution 2.0.0-beta-5 and later.', 0, 0, 0, '/**\n * Wayfinder Snippet to build site navigation menus\n *\n * Totally refactored from original DropMenu nav builder to make it easier to\n * create custom navigation by using chunks as output templates. By using\n * templates, many of the paramaters are no longer needed for flexible output\n * including tables, unordered- or ordered-lists (ULs or OLs), definition lists\n * (DLs) or in any other format you desire.\n *\n * @version 2.1.1-beta5\n * @author Garry Nutting (collabpad.com)\n * @author Kyle Jaebker (muddydogpaws.com)\n * @author Ryan Thrash (modx.com)\n * @author Shaun McCormick (modx.com)\n * @author Jason Coward (modx.com)\n *\n * @example [[Wayfinder? &startId=`0`]]\n *\n * @var modX $modx\n * @var array $scriptProperties\n * \n * @package wayfinder\n */\n$wayfinder_base = $modx->getOption(\'wayfinder.core_path\',$scriptProperties,$modx->getOption(\'core_path\').\'components/wayfinder/\');\n\n/* include a custom config file if specified */\nif (isset($scriptProperties[\'config\'])) {\n    $scriptProperties[\'config\'] = str_replace(\'../\',\'\',$scriptProperties[\'config\']);\n    $scriptProperties[\'config\'] = $wayfinder_base.\'configs/\'.$scriptProperties[\'config\'].\'.config.php\';\n} else {\n    $scriptProperties[\'config\'] = $wayfinder_base.\'configs/default.config.php\';\n}\nif (file_exists($scriptProperties[\'config\'])) {\n    include $scriptProperties[\'config\'];\n}\n\n/* include wayfinder class */\ninclude_once $wayfinder_base.\'wayfinder.class.php\';\nif (!$modx->loadClass(\'Wayfinder\',$wayfinder_base,true,true)) {\n    return \'error: Wayfinder class not found\';\n}\n$wf = new Wayfinder($modx,$scriptProperties);\n\n/* get user class definitions\n * TODO: eventually move these into config parameters */\n$wf->_css = array(\n    \'first\' => isset($firstClass) ? $firstClass : \'\',\n    \'last\' => isset($lastClass) ? $lastClass : \'last\',\n    \'here\' => isset($hereClass) ? $hereClass : \'active\',\n    \'parent\' => isset($parentClass) ? $parentClass : \'\',\n    \'row\' => isset($rowClass) ? $rowClass : \'\',\n    \'outer\' => isset($outerClass) ? $outerClass : \'\',\n    \'inner\' => isset($innerClass) ? $innerClass : \'\',\n    \'level\' => isset($levelClass) ? $levelClass: \'\',\n    \'self\' => isset($selfClass) ? $selfClass : \'\',\n    \'weblink\' => isset($webLinkClass) ? $webLinkClass : \'\'\n);\n\n/* get user templates\n * TODO: eventually move these into config parameters */\n$wf->_templates = array(\n    \'outerTpl\' => isset($outerTpl) ? $outerTpl : \'\',\n    \'rowTpl\' => isset($rowTpl) ? $rowTpl : \'\',\n    \'parentRowTpl\' => isset($parentRowTpl) ? $parentRowTpl : \'\',\n    \'parentRowHereTpl\' => isset($parentRowHereTpl) ? $parentRowHereTpl : \'\',\n    \'hereTpl\' => isset($hereTpl) ? $hereTpl : \'\',\n    \'innerTpl\' => isset($innerTpl) ? $innerTpl : \'\',\n    \'innerRowTpl\' => isset($innerRowTpl) ? $innerRowTpl : \'\',\n    \'innerHereTpl\' => isset($innerHereTpl) ? $innerHereTpl : \'\',\n    \'activeParentRowTpl\' => isset($activeParentRowTpl) ? $activeParentRowTpl : \'\',\n    \'categoryFoldersTpl\' => isset($categoryFoldersTpl) ? $categoryFoldersTpl : \'\',\n    \'startItemTpl\' => isset($startItemTpl) ? $startItemTpl : \'\'\n);\n\n/* process Wayfinder */\n$output = $wf->run();\nif ($wf->_config[\'debug\']) {\n    $output .= $wf->renderDebugOutput();\n}\n\n/* output results */\nif ($wf->_config[\'ph\']) {\n    $modx->setPlaceholder($wf->_config[\'ph\'],$output);\n} else {\n    return $output;\n}', 0, 'a:48:{s:5:\"level\";a:6:{s:4:\"name\";s:5:\"level\";s:4:\"desc\";s:25:\"prop_wayfinder.level_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:11:\"includeDocs\";a:6:{s:4:\"name\";s:11:\"includeDocs\";s:4:\"desc\";s:31:\"prop_wayfinder.includeDocs_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:11:\"excludeDocs\";a:6:{s:4:\"name\";s:11:\"excludeDocs\";s:4:\"desc\";s:31:\"prop_wayfinder.excludeDocs_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:8:\"contexts\";a:6:{s:4:\"name\";s:8:\"contexts\";s:4:\"desc\";s:28:\"prop_wayfinder.contexts_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"cacheResults\";a:6:{s:4:\"name\";s:12:\"cacheResults\";s:4:\"desc\";s:32:\"prop_wayfinder.cacheResults_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:1;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:9:\"cacheTime\";a:6:{s:4:\"name\";s:9:\"cacheTime\";s:4:\"desc\";s:29:\"prop_wayfinder.cacheTime_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";i:3600;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:2:\"ph\";a:6:{s:4:\"name\";s:2:\"ph\";s:4:\"desc\";s:22:\"prop_wayfinder.ph_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:5:\"debug\";a:6:{s:4:\"name\";s:5:\"debug\";s:4:\"desc\";s:25:\"prop_wayfinder.debug_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"ignoreHidden\";a:6:{s:4:\"name\";s:12:\"ignoreHidden\";s:4:\"desc\";s:32:\"prop_wayfinder.ignoreHidden_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"hideSubMenus\";a:6:{s:4:\"name\";s:12:\"hideSubMenus\";s:4:\"desc\";s:32:\"prop_wayfinder.hideSubMenus_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:13:\"useWeblinkUrl\";a:6:{s:4:\"name\";s:13:\"useWeblinkUrl\";s:4:\"desc\";s:33:\"prop_wayfinder.useWeblinkUrl_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:1;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:8:\"fullLink\";a:6:{s:4:\"name\";s:8:\"fullLink\";s:4:\"desc\";s:28:\"prop_wayfinder.fullLink_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:6:\"scheme\";a:6:{s:4:\"name\";s:6:\"scheme\";s:4:\"desc\";s:26:\"prop_wayfinder.scheme_desc\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:3:{i:0;a:2:{s:4:\"text\";s:23:\"prop_wayfinder.relative\";s:5:\"value\";s:0:\"\";}i:1;a:2:{s:4:\"text\";s:23:\"prop_wayfinder.absolute\";s:5:\"value\";s:3:\"abs\";}i:2;a:2:{s:4:\"text\";s:19:\"prop_wayfinder.full\";s:5:\"value\";s:4:\"full\";}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:9:\"sortOrder\";a:6:{s:4:\"name\";s:9:\"sortOrder\";s:4:\"desc\";s:29:\"prop_wayfinder.sortOrder_desc\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:24:\"prop_wayfinder.ascending\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:25:\"prop_wayfinder.descending\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:3:\"ASC\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:6:\"sortBy\";a:6:{s:4:\"name\";s:6:\"sortBy\";s:4:\"desc\";s:26:\"prop_wayfinder.sortBy_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:9:\"menuindex\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:5:\"limit\";a:6:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:25:\"prop_wayfinder.limit_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:6:\"cssTpl\";a:6:{s:4:\"name\";s:6:\"cssTpl\";s:4:\"desc\";s:26:\"prop_wayfinder.cssTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:5:\"jsTpl\";a:6:{s:4:\"name\";s:5:\"jsTpl\";s:4:\"desc\";s:25:\"prop_wayfinder.jsTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:11:\"rowIdPrefix\";a:6:{s:4:\"name\";s:11:\"rowIdPrefix\";s:4:\"desc\";s:31:\"prop_wayfinder.rowIdPrefix_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:11:\"textOfLinks\";a:6:{s:4:\"name\";s:11:\"textOfLinks\";s:4:\"desc\";s:31:\"prop_wayfinder.textOfLinks_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:9:\"menutitle\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"titleOfLinks\";a:6:{s:4:\"name\";s:12:\"titleOfLinks\";s:4:\"desc\";s:32:\"prop_wayfinder.titleOfLinks_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:9:\"pagetitle\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"displayStart\";a:6:{s:4:\"name\";s:12:\"displayStart\";s:4:\"desc\";s:32:\"prop_wayfinder.displayStart_desc\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:10:\"firstClass\";a:6:{s:4:\"name\";s:10:\"firstClass\";s:4:\"desc\";s:30:\"prop_wayfinder.firstClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:5:\"first\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:9:\"lastClass\";a:6:{s:4:\"name\";s:9:\"lastClass\";s:4:\"desc\";s:29:\"prop_wayfinder.lastClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:4:\"last\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:9:\"hereClass\";a:6:{s:4:\"name\";s:9:\"hereClass\";s:4:\"desc\";s:29:\"prop_wayfinder.hereClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:6:\"active\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:11:\"parentClass\";a:6:{s:4:\"name\";s:11:\"parentClass\";s:4:\"desc\";s:31:\"prop_wayfinder.parentClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:8:\"rowClass\";a:6:{s:4:\"name\";s:8:\"rowClass\";s:4:\"desc\";s:28:\"prop_wayfinder.rowClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:10:\"outerClass\";a:6:{s:4:\"name\";s:10:\"outerClass\";s:4:\"desc\";s:30:\"prop_wayfinder.outerClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:10:\"innerClass\";a:6:{s:4:\"name\";s:10:\"innerClass\";s:4:\"desc\";s:30:\"prop_wayfinder.innerClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:10:\"levelClass\";a:6:{s:4:\"name\";s:10:\"levelClass\";s:4:\"desc\";s:30:\"prop_wayfinder.levelClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:9:\"selfClass\";a:6:{s:4:\"name\";s:9:\"selfClass\";s:4:\"desc\";s:29:\"prop_wayfinder.selfClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"webLinkClass\";a:6:{s:4:\"name\";s:12:\"webLinkClass\";s:4:\"desc\";s:32:\"prop_wayfinder.webLinkClass_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:8:\"outerTpl\";a:6:{s:4:\"name\";s:8:\"outerTpl\";s:4:\"desc\";s:28:\"prop_wayfinder.outerTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:6:\"rowTpl\";a:6:{s:4:\"name\";s:6:\"rowTpl\";s:4:\"desc\";s:26:\"prop_wayfinder.rowTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"parentRowTpl\";a:6:{s:4:\"name\";s:12:\"parentRowTpl\";s:4:\"desc\";s:32:\"prop_wayfinder.parentRowTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:16:\"parentRowHereTpl\";a:6:{s:4:\"name\";s:16:\"parentRowHereTpl\";s:4:\"desc\";s:36:\"prop_wayfinder.parentRowHereTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:7:\"hereTpl\";a:6:{s:4:\"name\";s:7:\"hereTpl\";s:4:\"desc\";s:27:\"prop_wayfinder.hereTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:8:\"innerTpl\";a:6:{s:4:\"name\";s:8:\"innerTpl\";s:4:\"desc\";s:28:\"prop_wayfinder.innerTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:11:\"innerRowTpl\";a:6:{s:4:\"name\";s:11:\"innerRowTpl\";s:4:\"desc\";s:31:\"prop_wayfinder.innerRowTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"innerHereTpl\";a:6:{s:4:\"name\";s:12:\"innerHereTpl\";s:4:\"desc\";s:32:\"prop_wayfinder.innerHereTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:18:\"activeParentRowTpl\";a:6:{s:4:\"name\";s:18:\"activeParentRowTpl\";s:4:\"desc\";s:38:\"prop_wayfinder.activeParentRowTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:18:\"categoryFoldersTpl\";a:6:{s:4:\"name\";s:18:\"categoryFoldersTpl\";s:4:\"desc\";s:38:\"prop_wayfinder.categoryFoldersTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:12:\"startItemTpl\";a:6:{s:4:\"name\";s:12:\"startItemTpl\";s:4:\"desc\";s:32:\"prop_wayfinder.startItemTpl_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:11:\"permissions\";a:6:{s:4:\"name\";s:11:\"permissions\";s:4:\"desc\";s:31:\"prop_wayfinder.permissions_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:4:\"list\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:6:\"hereId\";a:6:{s:4:\"name\";s:6:\"hereId\";s:4:\"desc\";s:26:\"prop_wayfinder.hereId_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:5:\"where\";a:6:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:25:\"prop_wayfinder.where_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:9:\"templates\";a:6:{s:4:\"name\";s:9:\"templates\";s:4:\"desc\";s:29:\"prop_wayfinder.templates_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}s:18:\"previewUnpublished\";a:6:{s:4:\"name\";s:18:\"previewUnpublished\";s:4:\"desc\";s:38:\"prop_wayfinder.previewunpublished_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:20:\"wayfinder:properties\";}}', '', 0, ''),
(16, 0, 0, 'getSelections', '', 0, 5, 0, '/**\n * getSelections\n *\n * DESCRIPTION\n *\n * This snippet is a helper for getResources call.\n * It will allows you to select all linked resources under specific Selection with a usage of getResources snippet.\n * Returns distinct list of linked Resources for given Selections\n *\n * getResources are required\n *\n * PROPERTIES:\n *\n * &sortdir                 string  optional    Direction of sorting by linked resource\'s menuindex. Default: ASC\n * &selections              string  optional    Comma separated list of Selection IDs for which should be retrieved linked resources. Default: empty string\n * &getResourcesSnippet     string  optional    Name of getResources snippet. Default: getResources\n *\n * USAGE:\n *\n * [[getSelections? &selections=`1` &tpl=`rowTpl`]]\n * [[getSelections? &selections=`1` &tpl=`rowTpl` &sortby=`RAND()`]]\n *\n */\n\n$collections = $modx->getService(\'collections\',\'Collections\',$modx->getOption(\'collections.core_path\',null,$modx->getOption(\'core_path\').\'components/collections/\').\'model/collections/\',$scriptProperties);\nif (!($collections instanceof Collections)) return \'\';\n\n$getResourcesSnippet = $modx->getOption(\'getResourcesSnippet\', $scriptProperties, \'getResources\');\n\n$getResourcesExists = $modx->getCount(\'modSnippet\', array(\'name\' => $getResourcesSnippet));\nif ($getResourcesExists == 0) return \'getResources not found\';\n\n$sortDir = strtolower($modx->getOption(\'sortdir\', $scriptProperties, \'asc\'));\n$selections = $modx->getOption(\'selections\', $scriptProperties, \'\');\n$sortBy = $modx->getOption(\'sortby\', $scriptProperties, \'\');\n$excludeToPlaceholder = $modx->getOption(\'excludeToPlaceholder\', $scriptProperties, \'\');\n\n$selections = $modx->collections->explodeAndClean($selections);\n\nif ($sortDir != \'asc\') {\n    $sortDir = \'desc\';\n}\n\n$linkedResourcesQuery = $modx->newQuery(\'CollectionSelection\');\n\nif (!empty($selections)) {\n    $linkedResourcesQuery->where(array(\n        \'collection:IN\' => $selections\n    ));\n}\n\nif ($sortBy == \'\') {\n    $linkedResourcesQuery->sortby(\'menuindex\', $sortDir);\n}\n\n$linkedResourcesQuery->select(array(\n    \'resource\' => \'DISTINCT(resource)\',\n    \'menuindex\' => \'menuindex\'\n));\n\n$linkedResourcesQuery->prepare();\n\n$linkedResourcesQuery->stmt->execute();\n\n$linkedResources = $linkedResourcesQuery->stmt->fetchAll(PDO::FETCH_COLUMN, 0);\n\nif (!empty($excludeToPlaceholder)) {\n    $excludeResources = array();\n    foreach($linkedResources as $res) {\n        $excludeResources[] = \'-\' . $res;\n    }\n    $excludeResources = implode(\',\', $excludeResources);\n    $modx->setPlaceholder($excludeToPlaceholder, $excludeResources);\n}\n\n$linkedResources = implode(\',\', $linkedResources);\n\n$properties = $scriptProperties;\nunset($properties[\'selections\']);\n\n$properties[\'resources\'] = $linkedResources;\n$properties[\'parents\'] = ($properties[\'getResourcesSnippet\'] == \'pdoResources\') ? 0 : -1;\n\nif ($sortBy == \'\') {\n    $properties[\'sortby\'] = \'FIELD(modResource.id, \' . $linkedResources . \' )\';\n    $properties[\'sortdir\'] = \'asc\';\n}\n\nreturn $modx->runSnippet($getResourcesSnippet, $properties);', 0, 'a:0:{}', '', 0, ''),
(17, 1, 0, 'pdoResources', '', 0, 6, 0, '/** @var array $scriptProperties */\nif (isset($parents) && $parents === \'\') {\n    $scriptProperties[\'parents\'] = $modx->resource->id;\n}\nif (!empty($returnIds)) {\n    $scriptProperties[\'return\'] = \'ids\';\n}\n\n// Adding extra parameters into special place so we can put them in a results\n/** @var modSnippet $snippet */\n$additionalPlaceholders = $properties = array();\nif (isset($this) && $this instanceof modSnippet && $this->get(\'properties\')) {\n    $properties = $this->get(\'properties\');\n}\nelseif ($snippet = $modx->getObject(\'modSnippet\', array(\'name\' => \'pdoResources\'))) {\n    $properties = $snippet->get(\'properties\');\n}\nif (!empty($properties)) {\n    foreach ($scriptProperties as $k => $v) {\n        if (!isset($properties[$k])) {\n            $additionalPlaceholders[$k] = $v;\n        }\n    }\n}\n$scriptProperties[\'additionalPlaceholders\'] = $additionalPlaceholders;\n\n/** @var pdoFetch $pdoFetch */\n$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoFetch = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoFetch->addTime(\'pdoTools loaded\');\n$output = $pdoFetch->run();\n\n$log = \'\';\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $log .= \'<pre class=\"pdoResourcesLog\">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';\n}\n\n// Return output\nif (!empty($returnIds)) {\n    $modx->setPlaceholder(\'pdoResources.log\', $log);\n    if (!empty($toPlaceholder)) {\n        $modx->setPlaceholder($toPlaceholder, $output);\n    } else {\n        return $output;\n    }\n} elseif (!empty($toSeparatePlaceholders)) {\n    $output[\'log\'] = $log;\n    $modx->setPlaceholders($output, $toSeparatePlaceholders);\n} else {\n    $output .= $log;\n\n    if (!empty($tplWrapper) && (!empty($wrapIfEmpty) || !empty($output))) {\n        $output = $pdoFetch->getChunk($tplWrapper, array_merge($additionalPlaceholders, array(\'output\' => $output)),\n            $pdoFetch->config[\'fastMode\']);\n    }\n\n    if (!empty($toPlaceholder)) {\n        $modx->setPlaceholder($toPlaceholder, $output);\n    } else {\n        return $output;\n    }\n}', 0, 'a:47:{s:3:\"tpl\";a:7:{s:4:\"name\";s:3:\"tpl\";s:4:\"desc\";s:17:\"pdotools_prop_tpl\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"returnIds\";a:7:{s:4:\"name\";s:9:\"returnIds\";s:4:\"desc\";s:23:\"pdotools_prop_returnIds\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"showLog\";a:7:{s:4:\"name\";s:7:\"showLog\";s:4:\"desc\";s:21:\"pdotools_prop_showLog\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"fastMode\";a:7:{s:4:\"name\";s:8:\"fastMode\";s:4:\"desc\";s:22:\"pdotools_prop_fastMode\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:20:\"pdotools_prop_sortby\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:11:\"publishedon\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"sortbyTV\";a:7:{s:4:\"name\";s:8:\"sortbyTV\";s:4:\"desc\";s:22:\"pdotools_prop_sortbyTV\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"sortbyTVType\";a:7:{s:4:\"name\";s:12:\"sortbyTVType\";s:4:\"desc\";s:26:\"pdotools_prop_sortbyTVType\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:21:\"pdotools_prop_sortdir\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:4:\"DESC\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"sortdirTV\";a:7:{s:4:\"name\";s:9:\"sortdirTV\";s:4:\"desc\";s:23:\"pdotools_prop_sortdirTV\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:3:\"ASC\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:19:\"pdotools_prop_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:10;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"offset\";a:7:{s:4:\"name\";s:6:\"offset\";s:4:\"desc\";s:20:\"pdotools_prop_offset\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"depth\";a:7:{s:4:\"name\";s:5:\"depth\";s:4:\"desc\";s:19:\"pdotools_prop_depth\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:10;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"outputSeparator\";a:7:{s:4:\"name\";s:15:\"outputSeparator\";s:4:\"desc\";s:29:\"pdotools_prop_outputSeparator\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"\n\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"parents\";a:7:{s:4:\"name\";s:7:\"parents\";s:4:\"desc\";s:21:\"pdotools_prop_parents\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"includeContent\";a:7:{s:4:\"name\";s:14:\"includeContent\";s:4:\"desc\";s:28:\"pdotools_prop_includeContent\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"includeTVs\";a:7:{s:4:\"name\";s:10:\"includeTVs\";s:4:\"desc\";s:24:\"pdotools_prop_includeTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"prepareTVs\";a:7:{s:4:\"name\";s:10:\"prepareTVs\";s:4:\"desc\";s:24:\"pdotools_prop_prepareTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"1\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"processTVs\";a:7:{s:4:\"name\";s:10:\"processTVs\";s:4:\"desc\";s:24:\"pdotools_prop_processTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tvPrefix\";a:7:{s:4:\"name\";s:8:\"tvPrefix\";s:4:\"desc\";s:22:\"pdotools_prop_tvPrefix\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\"tv.\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"tvFilters\";a:7:{s:4:\"name\";s:9:\"tvFilters\";s:4:\"desc\";s:23:\"pdotools_prop_tvFilters\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:21:\"tvFiltersAndDelimiter\";a:7:{s:4:\"name\";s:21:\"tvFiltersAndDelimiter\";s:4:\"desc\";s:35:\"pdotools_prop_tvFiltersAndDelimiter\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\",\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:20:\"tvFiltersOrDelimiter\";a:7:{s:4:\"name\";s:20:\"tvFiltersOrDelimiter\";s:4:\"desc\";s:34:\"pdotools_prop_tvFiltersOrDelimiter\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:2:\"||\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:19:\"pdotools_prop_where\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"showUnpublished\";a:7:{s:4:\"name\";s:15:\"showUnpublished\";s:4:\"desc\";s:29:\"pdotools_prop_showUnpublished\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showDeleted\";a:7:{s:4:\"name\";s:11:\"showDeleted\";s:4:\"desc\";s:25:\"pdotools_prop_showDeleted\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"showHidden\";a:7:{s:4:\"name\";s:10:\"showHidden\";s:4:\"desc\";s:24:\"pdotools_prop_showHidden\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"hideContainers\";a:7:{s:4:\"name\";s:14:\"hideContainers\";s:4:\"desc\";s:28:\"pdotools_prop_hideContainers\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"context\";a:7:{s:4:\"name\";s:7:\"context\";s:4:\"desc\";s:21:\"pdotools_prop_context\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:3:\"idx\";a:7:{s:4:\"name\";s:3:\"idx\";s:4:\"desc\";s:17:\"pdotools_prop_idx\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"first\";a:7:{s:4:\"name\";s:5:\"first\";s:4:\"desc\";s:19:\"pdotools_prop_first\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:4:\"last\";a:7:{s:4:\"name\";s:4:\"last\";s:4:\"desc\";s:18:\"pdotools_prop_last\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tplFirst\";a:7:{s:4:\"name\";s:8:\"tplFirst\";s:4:\"desc\";s:22:\"pdotools_prop_tplFirst\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplLast\";a:7:{s:4:\"name\";s:7:\"tplLast\";s:4:\"desc\";s:21:\"pdotools_prop_tplLast\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"tplOdd\";a:7:{s:4:\"name\";s:6:\"tplOdd\";s:4:\"desc\";s:20:\"pdotools_prop_tplOdd\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:24:\"pdotools_prop_tplWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"wrapIfEmpty\";a:7:{s:4:\"name\";s:11:\"wrapIfEmpty\";s:4:\"desc\";s:25:\"pdotools_prop_wrapIfEmpty\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"totalVar\";a:7:{s:4:\"name\";s:8:\"totalVar\";s:4:\"desc\";s:22:\"pdotools_prop_totalVar\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:5:\"total\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"resources\";a:7:{s:4:\"name\";s:9:\"resources\";s:4:\"desc\";s:23:\"pdotools_prop_resources\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"tplCondition\";a:7:{s:4:\"name\";s:12:\"tplCondition\";s:4:\"desc\";s:26:\"pdotools_prop_tplCondition\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"tplOperator\";a:7:{s:4:\"name\";s:11:\"tplOperator\";s:4:\"desc\";s:25:\"pdotools_prop_tplOperator\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:10:{i:0;a:2:{s:4:\"text\";s:11:\"is equal to\";s:5:\"value\";s:2:\"==\";}i:1;a:2:{s:4:\"text\";s:15:\"is not equal to\";s:5:\"value\";s:2:\"!=\";}i:2;a:2:{s:4:\"text\";s:9:\"less than\";s:5:\"value\";s:1:\"<\";}i:3;a:2:{s:4:\"text\";s:21:\"less than or equal to\";s:5:\"value\";s:2:\"<=\";}i:4;a:2:{s:4:\"text\";s:24:\"greater than or equal to\";s:5:\"value\";s:2:\">=\";}i:5;a:2:{s:4:\"text\";s:8:\"is empty\";s:5:\"value\";s:5:\"empty\";}i:6;a:2:{s:4:\"text\";s:12:\"is not empty\";s:5:\"value\";s:6:\"!empty\";}i:7;a:2:{s:4:\"text\";s:7:\"is null\";s:5:\"value\";s:4:\"null\";}i:8;a:2:{s:4:\"text\";s:11:\"is in array\";s:5:\"value\";s:7:\"inarray\";}i:9;a:2:{s:4:\"text\";s:10:\"is between\";s:5:\"value\";s:7:\"between\";}}s:5:\"value\";s:2:\"==\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"conditionalTpls\";a:7:{s:4:\"name\";s:15:\"conditionalTpls\";s:4:\"desc\";s:29:\"pdotools_prop_conditionalTpls\";s:4:\"type\";s:8:\"textarea\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"select\";a:7:{s:4:\"name\";s:6:\"select\";s:4:\"desc\";s:20:\"pdotools_prop_select\";s:4:\"type\";s:8:\"textarea\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:22:\"toSeparatePlaceholders\";a:7:{s:4:\"name\";s:22:\"toSeparatePlaceholders\";s:4:\"desc\";s:36:\"pdotools_prop_toSeparatePlaceholders\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"loadModels\";a:7:{s:4:\"name\";s:10:\"loadModels\";s:4:\"desc\";s:24:\"pdotools_prop_loadModels\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"scheme\";a:7:{s:4:\"name\";s:6:\"scheme\";s:4:\"desc\";s:20:\"pdotools_prop_scheme\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:6:{i:0;a:2:{s:5:\"value\";s:0:\"\";s:4:\"text\";s:14:\"System default\";}i:1;a:2:{s:5:\"value\";i:-1;s:4:\"text\";s:25:\"-1 (relative to site_url)\";}i:2;a:2:{s:5:\"value\";s:4:\"full\";s:4:\"text\";s:40:\"full (absolute, prepended with site_url)\";}i:3;a:2:{s:5:\"value\";s:3:\"abs\";s:4:\"text\";s:39:\"abs (absolute, prepended with base_url)\";}i:4;a:2:{s:5:\"value\";s:4:\"http\";s:4:\"text\";s:38:\"http (absolute, forced to http scheme)\";}i:5;a:2:{s:5:\"value\";s:5:\"https\";s:4:\"text\";s:40:\"https (absolute, forced to https scheme)\";}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"useWeblinkUrl\";a:7:{s:4:\"name\";s:13:\"useWeblinkUrl\";s:4:\"desc\";s:27:\"pdotools_prop_useWeblinkUrl\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdoresources.php'),
(18, 1, 0, 'pdoUsers', '', 0, 6, 0, '/** @var array $scriptProperties */\n/** @var pdoFetch $pdoFetch */\n$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoFetch = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoFetch->addTime(\'pdoTools loaded\');\n\n$class = \'modUser\';\n$profile = \'modUserProfile\';\n$member = \'modUserGroupMember\';\n\n// Start building \"Where\" expression\n$where = array();\nif (empty($showInactive)) {\n    $where[$class . \'.active\'] = 1;\n}\nif (empty($showBlocked)) {\n    $where[$profile . \'.blocked\'] = 0;\n}\n\n// Add users profiles and groups\n$innerJoin = array(\n    $profile => array(\'alias\' => $profile, \'on\' => \"$class.id = $profile.internalKey\"),\n);\n\n// Filter by users, groups and roles\n$tmp = array(\n    \'users\' => array(\n        \'class\' => $class,\n        \'name\' => \'username\',\n        \'join\' => $class . \'.id\',\n    ),\n    \'groups\' => array(\n        \'class\' => \'modUserGroup\',\n        \'name\' => \'name\',\n        \'join\' => $member . \'.user_group\',\n    ),\n    \'roles\' => array(\n        \'class\' => \'modUserGroupRole\',\n        \'name\' => \'name\',\n        \'join\' => $member . \'.role\',\n    ),\n);\nforeach ($tmp as $k => $p) {\n    if (!empty($$k)) {\n        $$k = array_map(\'trim\', explode(\',\', $$k));\n        ${$k . \'_in\'} = ${$k . \'_out\'} = $fetch_in = $fetch_out = array();\n        foreach ($$k as $v) {\n            if (is_numeric($v)) {\n                if ($v[0] == \'-\') {\n                    ${$k . \'_out\'}[] = abs($v);\n                } else {\n                    ${$k . \'_in\'}[] = abs($v);\n                }\n            } else {\n                if ($v[0] == \'-\') {\n                    $fetch_out[] = $v;\n                } else {\n                    $fetch_in[] = $v;\n                }\n            }\n        }\n\n        if (!empty($fetch_in) || !empty($fetch_out)) {\n            $q = $modx->newQuery($p[\'class\'], array($p[\'name\'] . \':IN\' => array_merge($fetch_in, $fetch_out)));\n            $q->select(\'id,\' . $p[\'name\']);\n            $tstart = microtime(true);\n            if ($q->prepare() && $q->stmt->execute()) {\n                $modx->queryTime += microtime(true) - $tstart;\n                $modx->executedQueries++;\n                while ($row = $q->stmt->fetch(PDO::FETCH_ASSOC)) {\n                    if (in_array($row[$p[\'name\']], $fetch_in)) {\n                        ${$k . \'_in\'}[] = $row[\'id\'];\n                    } else {\n                        ${$k . \'_out\'}[] = $row[\'id\'];\n                    }\n                }\n            }\n        }\n\n        if (!empty(${$k . \'_in\'})) {\n            $where[$p[\'join\'] . \':IN\'] = ${$k . \'_in\'};\n        }\n        if (!empty(${$k . \'_out\'})) {\n            $where[$p[\'join\'] . \':NOT IN\'] = ${$k . \'_out\'};\n        }\n    }\n}\n\nif (!empty($groups_in) || !empty($groups_out) || !empty($roles_in) || !empty($roles_out)) {\n    $innerJoin[$member] = array(\'alias\' => $member, \'on\' => \"$class.id = $member.member\");\n}\n\n// Fields to select\n$select = array(\n    $profile => implode(\',\', array_keys($modx->getFieldMeta($profile))),\n    $class => implode(\',\', array_keys($modx->getFieldMeta($class))),\n);\n\n// Add custom parameters\nforeach (array(\'where\', \'innerJoin\', \'select\') as $v) {\n    if (!empty($scriptProperties[$v])) {\n        $tmp = $scriptProperties[$v];\n        if (!is_array($tmp)) {\n            $tmp = json_decode($tmp, true);\n        }\n        if (is_array($tmp)) {\n            $$v = array_merge($$v, $tmp);\n        }\n    }\n    unset($scriptProperties[$v]);\n}\n$pdoFetch->addTime(\'Conditions prepared\');\n\n$default = array(\n    \'class\' => $class,\n    \'innerJoin\' => json_encode($innerJoin),\n    \'where\' => json_encode($where),\n    \'select\' => json_encode($select),\n    \'groupby\' => $class . \'.id\',\n    \'sortby\' => $class . \'.id\',\n    \'sortdir\' => \'ASC\',\n    \'fastMode\' => false,\n    \'return\' => !empty($returnIds) ? \'ids\' : \'chunks\',\n    \'disableConditions\' => true,\n);\n\nif (!empty($users_in) && (empty($scriptProperties[\'sortby\']) || $scriptProperties[\'sortby\'] == $class . \'.id\')) {\n    $scriptProperties[\'sortby\'] = \"find_in_set(`$class`.`id`,\'\" . implode(\',\', $users_in) . \"\')\";\n    $scriptProperties[\'sortdir\'] = \'\';\n}\n\n// Merge all properties and run!\n$pdoFetch->addTime(\'Query parameters ready\');\n$pdoFetch->setConfig(array_merge($default, $scriptProperties), false);\n$output = $pdoFetch->run();\n\n$log = \'\';\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $log .= \'<pre class=\"pdoUsersLog\">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';\n}\n\n// Return output\nif (!empty($returnIds)) {\n    $modx->setPlaceholder(\'pdoUsers.log\', $log);\n    if (!empty($toPlaceholder)) {\n        $modx->setPlaceholder($toPlaceholder, $output);\n    } else {\n        return $output;\n    }\n} elseif (!empty($toSeparatePlaceholders)) {\n    $output[\'log\'] = $log;\n    $modx->setPlaceholders($output, $toSeparatePlaceholders);\n} else {\n    $output .= $log;\n\n    if (!empty($tplWrapper) && (!empty($wrapIfEmpty) || !empty($output))) {\n        $output = $pdoFetch->getChunk($tplWrapper, array(\'output\' => $output), $pdoFetch->config[\'fastMode\']);\n    }\n\n    if (!empty($toPlaceholder)) {\n        $modx->setPlaceholder($toPlaceholder, $output);\n    } else {\n        return $output;\n    }\n}', 0, 'a:30:{s:3:\"tpl\";a:7:{s:4:\"name\";s:3:\"tpl\";s:4:\"desc\";s:17:\"pdotools_prop_tpl\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"returnIds\";a:7:{s:4:\"name\";s:9:\"returnIds\";s:4:\"desc\";s:23:\"pdotools_prop_returnIds\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"showLog\";a:7:{s:4:\"name\";s:7:\"showLog\";s:4:\"desc\";s:21:\"pdotools_prop_showLog\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"fastMode\";a:7:{s:4:\"name\";s:8:\"fastMode\";s:4:\"desc\";s:22:\"pdotools_prop_fastMode\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:20:\"pdotools_prop_sortby\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:10:\"modUser.id\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:21:\"pdotools_prop_sortdir\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:3:\"ASC\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:19:\"pdotools_prop_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:10;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"offset\";a:7:{s:4:\"name\";s:6:\"offset\";s:4:\"desc\";s:20:\"pdotools_prop_offset\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"outputSeparator\";a:7:{s:4:\"name\";s:15:\"outputSeparator\";s:4:\"desc\";s:29:\"pdotools_prop_outputSeparator\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"\n\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"groups\";a:7:{s:4:\"name\";s:6:\"groups\";s:4:\"desc\";s:20:\"pdotools_prop_groups\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"roles\";a:7:{s:4:\"name\";s:5:\"roles\";s:4:\"desc\";s:19:\"pdotools_prop_roles\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"users\";a:7:{s:4:\"name\";s:5:\"users\";s:4:\"desc\";s:19:\"pdotools_prop_users\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:19:\"pdotools_prop_where\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"showInactive\";a:7:{s:4:\"name\";s:12:\"showInactive\";s:4:\"desc\";s:26:\"pdotools_prop_showInactive\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showBlocked\";a:7:{s:4:\"name\";s:11:\"showBlocked\";s:4:\"desc\";s:25:\"pdotools_prop_showBlocked\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:3:\"idx\";a:7:{s:4:\"name\";s:3:\"idx\";s:4:\"desc\";s:17:\"pdotools_prop_idx\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"first\";a:7:{s:4:\"name\";s:5:\"first\";s:4:\"desc\";s:19:\"pdotools_prop_first\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:4:\"last\";a:7:{s:4:\"name\";s:4:\"last\";s:4:\"desc\";s:18:\"pdotools_prop_last\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tplFirst\";a:7:{s:4:\"name\";s:8:\"tplFirst\";s:4:\"desc\";s:22:\"pdotools_prop_tplFirst\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplLast\";a:7:{s:4:\"name\";s:7:\"tplLast\";s:4:\"desc\";s:21:\"pdotools_prop_tplLast\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"tplOdd\";a:7:{s:4:\"name\";s:6:\"tplOdd\";s:4:\"desc\";s:20:\"pdotools_prop_tplOdd\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:24:\"pdotools_prop_tplWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"wrapIfEmpty\";a:7:{s:4:\"name\";s:11:\"wrapIfEmpty\";s:4:\"desc\";s:25:\"pdotools_prop_wrapIfEmpty\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"totalVar\";a:7:{s:4:\"name\";s:8:\"totalVar\";s:4:\"desc\";s:22:\"pdotools_prop_totalVar\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:5:\"total\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"tplCondition\";a:7:{s:4:\"name\";s:12:\"tplCondition\";s:4:\"desc\";s:26:\"pdotools_prop_tplCondition\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"tplOperator\";a:7:{s:4:\"name\";s:11:\"tplOperator\";s:4:\"desc\";s:25:\"pdotools_prop_tplOperator\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:10:{i:0;a:2:{s:4:\"text\";s:11:\"is equal to\";s:5:\"value\";s:2:\"==\";}i:1;a:2:{s:4:\"text\";s:15:\"is not equal to\";s:5:\"value\";s:2:\"!=\";}i:2;a:2:{s:4:\"text\";s:9:\"less than\";s:5:\"value\";s:1:\"<\";}i:3;a:2:{s:4:\"text\";s:21:\"less than or equal to\";s:5:\"value\";s:2:\"<=\";}i:4;a:2:{s:4:\"text\";s:24:\"greater than or equal to\";s:5:\"value\";s:2:\">=\";}i:5;a:2:{s:4:\"text\";s:8:\"is empty\";s:5:\"value\";s:5:\"empty\";}i:6;a:2:{s:4:\"text\";s:12:\"is not empty\";s:5:\"value\";s:6:\"!empty\";}i:7;a:2:{s:4:\"text\";s:7:\"is null\";s:5:\"value\";s:4:\"null\";}i:8;a:2:{s:4:\"text\";s:11:\"is in array\";s:5:\"value\";s:7:\"inarray\";}i:9;a:2:{s:4:\"text\";s:10:\"is between\";s:5:\"value\";s:7:\"between\";}}s:5:\"value\";s:2:\"==\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"conditionalTpls\";a:7:{s:4:\"name\";s:15:\"conditionalTpls\";s:4:\"desc\";s:29:\"pdotools_prop_conditionalTpls\";s:4:\"type\";s:8:\"textarea\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"select\";a:7:{s:4:\"name\";s:6:\"select\";s:4:\"desc\";s:20:\"pdotools_prop_select\";s:4:\"type\";s:8:\"textarea\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:22:\"toSeparatePlaceholders\";a:7:{s:4:\"name\";s:22:\"toSeparatePlaceholders\";s:4:\"desc\";s:36:\"pdotools_prop_toSeparatePlaceholders\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdousers.php');
INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(19, 1, 0, 'pdoCrumbs', '', 0, 6, 0, '/** @var array $scriptProperties */\n/** @var pdoFetch $pdoFetch */\n$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoFetch = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoFetch->addTime(\'pdoTools loaded\');\n\nif (!isset($from) || $from == \'\') {\n    $from = 0;\n}\nif (empty($to)) {\n    $to = $modx->resource->id;\n}\nif (empty($direction)) {\n    $direction = \'ltr\';\n}\nif ($outputSeparator == \'&nbsp;&rarr;&nbsp;\' && $direction == \'rtl\') {\n    $outputSeparator = \'&nbsp;&larr;&nbsp;\';\n}\nif ($limit == \'\') {\n    $limit = 10;\n}\n// For compatibility with BreadCrumb\nif (!empty($maxCrumbs)) {\n    $limit = $maxCrumbs;\n}\nif (!empty($containerTpl)) {\n    $tplWrapper = $containerTpl;\n}\nif (!empty($currentCrumbTpl)) {\n    $tplCurrent = $currentCrumbTpl;\n}\nif (!empty($linkCrumbTpl)) {\n    $scriptProperties[\'tpl\'] = $linkCrumbTpl;\n}\nif (!empty($maxCrumbTpl)) {\n    $tplMax = $maxCrumbTpl;\n}\nif (isset($showBreadCrumbsAtHome)) {\n    $showAtHome = $showBreadCrumbsAtHome;\n}\nif (isset($showHomeCrumb)) {\n    $showHome = $showHomeCrumb;\n}\nif (isset($showCurrentCrumb)) {\n    $showCurrent = $showCurrentCrumb;\n}\n// --\n$fastMode = !empty($fastMode);\n$siteStart = $modx->getOption(\'siteStart\', $scriptProperties, $modx->getOption(\'site_start\'));\n\nif (empty($showAtHome) && $modx->resource->id == $siteStart) {\n    return \'\';\n}\n\n$class = $modx->getOption(\'class\', $scriptProperties, \'modResource\');\n// Start building \"Where\" expression\n$where = array();\nif (empty($showUnpublished) && empty($showUnPub)) {\n    $where[\'published\'] = 1;\n}\nif (empty($showHidden)) {\n    $where[\'hidemenu\'] = 0;\n}\nif (empty($showDeleted)) {\n    $where[\'deleted\'] = 0;\n}\nif (!empty($hideContainers) && empty($showContainer)) {\n    $where[\'isfolder\'] = 0;\n}\n\n$resource = ($to == $modx->resource->id)\n    ? $modx->resource\n    : $modx->getObject($class, $to);\n\nif (!$resource) {\n    $message = \'Could not build breadcrumbs to resource \"\' . $to . \'\"\';\n\n    return \'\';\n}\n\nif (!empty($customParents)) {\n    $customParents = is_array($customParents) ? $customParents : array_map(\'trim\', explode(\',\', $customParents));\n    $parents = is_array($customParents) ? array_reverse($customParents) : array();\n}\nif (empty($parents)) {\n    $parents = $modx->getParentIds($resource->id, $limit, array(\'context\' => $resource->get(\'context_key\')));\n}\nif (!empty($showHome)) {\n    $parents[] = $siteStart;\n}\n\n$ids = array($resource->id);\nforeach ($parents as $parent) {\n    if (!empty($parent)) {\n        $ids[] = $parent;\n    }\n    if (!empty($from) && $parent == $from) {\n        break;\n    }\n}\n$where[\'id:IN\'] = $ids;\n\nif (!empty($exclude)) {\n    $where[\'id:NOT IN\'] = array_map(\'trim\', explode(\',\', $exclude));\n}\n\n// Fields to select\n$resourceColumns = array_keys($modx->getFieldMeta($class));\n$select = array($class => implode(\',\', $resourceColumns));\n\n// Add custom parameters\nforeach (array(\'where\', \'select\') as $v) {\n    if (!empty($scriptProperties[$v])) {\n        $tmp = $scriptProperties[$v];\n        if (!is_array($tmp)) {\n            $tmp = json_decode($tmp, true);\n        }\n        if (is_array($tmp)) {\n            $$v = array_merge($$v, $tmp);\n        }\n    }\n    unset($scriptProperties[$v]);\n}\n$pdoFetch->addTime(\'Conditions prepared\');\n\n// Default parameters\n$default = array(\n    \'class\' => $class,\n    \'where\' => json_encode($where),\n    \'select\' => json_encode($select),\n    \'groupby\' => $class . \'.id\',\n    \'sortby\' => \"find_in_set(`$class`.`id`,\'\" . implode(\',\', $ids) . \"\')\",\n    \'sortdir\' => \'\',\n    \'return\' => \'data\',\n    \'totalVar\' => \'pdocrumbs.total\',\n    \'disableConditions\' => true,\n);\n\n// Merge all properties and run!\n$pdoFetch->addTime(\'Query parameters ready\');\n$pdoFetch->setConfig(array_merge($default, $scriptProperties), false);\n$rows = $pdoFetch->run();\n\n$output = array();\nif (!empty($rows) && is_array($rows)) {\n    if (strtolower($direction) == \'ltr\') {\n        $rows = array_reverse($rows);\n    }\n\n    foreach ($rows as $row) {\n        if (!empty($useWeblinkUrl) && $row[\'class_key\'] == \'modWebLink\') {\n            $row[\'link\'] = is_numeric(trim($row[\'content\'], \'[]~ \'))\n                ? $pdoFetch->makeUrl(intval(trim($row[\'content\'], \'[]~ \')), $row)\n                : $row[\'content\'];\n        } else {\n            $row[\'link\'] = $pdoFetch->makeUrl($row[\'id\'], $row);\n        }\n\n        $row = array_merge(\n            $scriptProperties,\n            $row,\n            array(\'idx\' => $pdoFetch->idx++)\n        );\n        if (empty($row[\'menutitle\'])) {\n            $row[\'menutitle\'] = $row[\'pagetitle\'];\n        }\n\n        if ($row[\'id\'] == $resource->id && empty($showCurrent)) {\n            continue;\n        } elseif ($row[\'id\'] == $resource->id && !empty($tplCurrent)) {\n            $tpl = $tplCurrent;\n        } elseif ($row[\'id\'] == $siteStart && !empty($tplHome)) {\n            $tpl = $tplHome;\n        } else {\n            $tpl = $pdoFetch->defineChunk($row);\n        }\n        $output[] = empty($tpl)\n            ? \'<pre>\' . $pdoFetch->getChunk(\'\', $row) . \'</pre>\'\n            : $pdoFetch->getChunk($tpl, $row, $fastMode);\n    }\n}\n$pdoFetch->addTime(\'Chunks processed\');\n\nif (count($output) == 1 && !empty($hideSingle)) {\n    $pdoFetch->addTime(\'The only result was hidden, because the parameter \"hideSingle\" activated\');\n    $output = array();\n}\n\n$log = \'\';\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $log .= \'<pre class=\"pdoCrumbsLog\">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';\n}\n\nif (!empty($toSeparatePlaceholders)) {\n    $output[\'log\'] = $log;\n    $modx->setPlaceholders($output, $toSeparatePlaceholders);\n} else {\n    $output = implode($outputSeparator, $output);\n    if ($pdoFetch->idx >= $limit && !empty($tplMax) && !empty($output)) {\n        $output = ($direction == \'ltr\')\n            ? $pdoFetch->getChunk($tplMax, array(), $fastMode) . $output\n            : $output . $pdoFetch->getChunk($tplMax, array(), $fastMode);\n    }\n    $output .= $log;\n\n    if (!empty($tplWrapper) && (!empty($wrapIfEmpty) || !empty($output))) {\n        $output = $pdoFetch->getChunk($tplWrapper, array(\'output\' => $output, \'crumbs\' => $output), $fastMode);\n    }\n\n    if (!empty($toPlaceholder)) {\n        $modx->setPlaceholder($toPlaceholder, $output);\n    } else {\n        return $output;\n    }\n}', 0, 'a:31:{s:7:\"showLog\";a:7:{s:4:\"name\";s:7:\"showLog\";s:4:\"desc\";s:21:\"pdotools_prop_showLog\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"fastMode\";a:7:{s:4:\"name\";s:8:\"fastMode\";s:4:\"desc\";s:22:\"pdotools_prop_fastMode\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:4:\"from\";a:7:{s:4:\"name\";s:4:\"from\";s:4:\"desc\";s:18:\"pdotools_prop_from\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:2:\"to\";a:7:{s:4:\"name\";s:2:\"to\";s:4:\"desc\";s:16:\"pdotools_prop_to\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"customParents\";a:7:{s:4:\"name\";s:13:\"customParents\";s:4:\"desc\";s:27:\"pdotools_prop_customParents\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:19:\"pdotools_prop_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:10;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"exclude\";a:7:{s:4:\"name\";s:7:\"exclude\";s:4:\"desc\";s:21:\"pdotools_prop_exclude\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"outputSeparator\";a:7:{s:4:\"name\";s:15:\"outputSeparator\";s:4:\"desc\";s:29:\"pdotools_prop_outputSeparator\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"\n\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"includeTVs\";a:7:{s:4:\"name\";s:10:\"includeTVs\";s:4:\"desc\";s:24:\"pdotools_prop_includeTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"prepareTVs\";a:7:{s:4:\"name\";s:10:\"prepareTVs\";s:4:\"desc\";s:24:\"pdotools_prop_prepareTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"1\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"processTVs\";a:7:{s:4:\"name\";s:10:\"processTVs\";s:4:\"desc\";s:24:\"pdotools_prop_processTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tvPrefix\";a:7:{s:4:\"name\";s:8:\"tvPrefix\";s:4:\"desc\";s:22:\"pdotools_prop_tvPrefix\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\"tv.\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:19:\"pdotools_prop_where\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"showUnpublished\";a:7:{s:4:\"name\";s:15:\"showUnpublished\";s:4:\"desc\";s:29:\"pdotools_prop_showUnpublished\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showDeleted\";a:7:{s:4:\"name\";s:11:\"showDeleted\";s:4:\"desc\";s:25:\"pdotools_prop_showDeleted\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"showHidden\";a:7:{s:4:\"name\";s:10:\"showHidden\";s:4:\"desc\";s:24:\"pdotools_prop_showHidden\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"hideContainers\";a:7:{s:4:\"name\";s:14:\"hideContainers\";s:4:\"desc\";s:28:\"pdotools_prop_hideContainers\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:3:\"tpl\";a:7:{s:4:\"name\";s:3:\"tpl\";s:4:\"desc\";s:17:\"pdotools_prop_tpl\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:79:\"@INLINE <li class=\"breadcrumb-item\"><a href=\"[[+link]]\">[[+menutitle]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"tplCurrent\";a:7:{s:4:\"name\";s:10:\"tplCurrent\";s:4:\"desc\";s:24:\"pdotools_prop_tplCurrent\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:62:\"@INLINE <li class=\"breadcrumb-item active\">[[+menutitle]]</li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"tplMax\";a:7:{s:4:\"name\";s:6:\"tplMax\";s:4:\"desc\";s:20:\"pdotools_prop_tplMax\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:65:\"@INLINE <li class=\"breadcrumb-item disabled\">&nbsp;...&nbsp;</li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplHome\";a:7:{s:4:\"name\";s:7:\"tplHome\";s:4:\"desc\";s:21:\"pdotools_prop_tplHome\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:24:\"pdotools_prop_tplWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:47:\"@INLINE <ol class=\"breadcrumb\">[[+output]]</ol>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"wrapIfEmpty\";a:7:{s:4:\"name\";s:11:\"wrapIfEmpty\";s:4:\"desc\";s:25:\"pdotools_prop_wrapIfEmpty\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showCurrent\";a:7:{s:4:\"name\";s:11:\"showCurrent\";s:4:\"desc\";s:25:\"pdotools_prop_showCurrent\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"showHome\";a:7:{s:4:\"name\";s:8:\"showHome\";s:4:\"desc\";s:22:\"pdotools_prop_showHome\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"showAtHome\";a:7:{s:4:\"name\";s:10:\"showAtHome\";s:4:\"desc\";s:24:\"pdotools_prop_showAtHome\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"hideSingle\";a:7:{s:4:\"name\";s:10:\"hideSingle\";s:4:\"desc\";s:24:\"pdotools_prop_hideSingle\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"direction\";a:7:{s:4:\"name\";s:9:\"direction\";s:4:\"desc\";s:23:\"pdotools_prop_direction\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:5:\"value\";s:3:\"ltr\";s:4:\"text\";s:19:\"Left To Right (ltr)\";}i:1;a:2:{s:5:\"value\";s:3:\"rtl\";s:4:\"text\";s:19:\"Right To Left (rtl)\";}}s:5:\"value\";s:3:\"ltr\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"scheme\";a:7:{s:4:\"name\";s:6:\"scheme\";s:4:\"desc\";s:20:\"pdotools_prop_scheme\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:6:{i:0;a:2:{s:5:\"value\";s:0:\"\";s:4:\"text\";s:14:\"System default\";}i:1;a:2:{s:5:\"value\";i:-1;s:4:\"text\";s:25:\"-1 (relative to site_url)\";}i:2;a:2:{s:5:\"value\";s:4:\"full\";s:4:\"text\";s:40:\"full (absolute, prepended with site_url)\";}i:3;a:2:{s:5:\"value\";s:3:\"abs\";s:4:\"text\";s:39:\"abs (absolute, prepended with base_url)\";}i:4;a:2:{s:5:\"value\";s:4:\"http\";s:4:\"text\";s:38:\"http (absolute, forced to http scheme)\";}i:5;a:2:{s:5:\"value\";s:5:\"https\";s:4:\"text\";s:40:\"https (absolute, forced to https scheme)\";}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"useWeblinkUrl\";a:7:{s:4:\"name\";s:13:\"useWeblinkUrl\";s:4:\"desc\";s:27:\"pdotools_prop_useWeblinkUrl\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdocrumbs.php'),
(20, 1, 0, 'pdoField', '', 0, 6, 0, '/** @var array $scriptProperties */\nif (!empty($input)) {\n    $id = $input;\n}\nif (!isset($default)) {\n    $default = \'\';\n}\nif (!isset($output)) {\n    $output = \'\';\n}\n$class = $modx->getOption(\'class\', $scriptProperties, \'modResource\', true);\n$isResource = $class == \'modResource\' || in_array($class, $modx->getDescendants(\'modResource\'));\n\nif (empty($field)) {\n    $field = \'pagetitle\';\n}\n$top = isset($top) ? intval($top) : 0;\n$topLevel = isset($topLevel) ? intval($topLevel) : 0;\nif (!empty($options)) {\n    $options = trim($options);\n    if ($options[0] == \'{\') {\n        $tmp = json_decode($options, true);\n        if (is_array($tmp)) {\n            extract($tmp);\n            $scriptProperties = array_merge($scriptProperties, $tmp);\n        }\n    } else {\n        $field = $options;\n    }\n}\nif (empty($id)) {\n    if (!empty($modx->resource)) {\n        $id = $modx->resource->id;\n    } else {\n        return \'You must specify an id of \' . $class;\n    }\n}\nif (!isset($context)) {\n    $context = \'\';\n}\n\n// Gets the parent from root of context, if specified\nif ($isResource && $id && ($top || $topLevel)) {\n    // Select needed context for parents functionality\n    if (empty($context)) {\n        $q = $modx->newQuery($class, $id);\n        $q->select(\'context_key\');\n        $tstart = microtime(true);\n        if ($q->prepare() && $q->stmt->execute()) {\n            $modx->queryTime += microtime(true) - $tstart;\n            $modx->executedQueries++;\n            $context = $q->stmt->fetch(PDO::FETCH_COLUMN);\n        }\n    }\n    // Original pdoField logic\n    if (empty($ultimate)) {\n        if ($topLevel) {\n            $pids = $modx->getChildIds(0, $topLevel, array(\'context\' => $context));\n            $pid = $id;\n            while (true) {\n                $tmp = $modx->getParentIds($pid, 1, array(\'context\' => $context));\n                if (!$pid = current($tmp)) {\n                    break;\n                } elseif (in_array($pid, $pids)) {\n                    $id = $pid;\n                    break;\n                }\n            }\n        } elseif ($top) {\n            $pid = $id;\n            for ($i = 1; $i <= $top; $i++) {\n                $tmp = $modx->getParentIds($pid, 1, array(\'context\' => $context));\n                if (!$pid = current($tmp)) {\n                    break;\n                }\n                $id = $pid;\n            }\n        }\n    }\n    // UltimateParent logic\n    // https://github.com/splittingred/UltimateParent/blob/develop/core/components/ultimateparent/snippet.ultimateparent.php\n    elseif ($id != $top) {\n        $pid = $id;\n        $pids = $modx->getParentIds($id, 10, array(\'context\' => $context));\n        if (!$topLevel || count($pids) >= $topLevel) {\n            while ($parentIds = $modx->getParentIds($id, 1, array(\'context\' => $context))) {\n                $pid = array_pop($parentIds);\n                if ($pid == $top) {\n                    break;\n                }\n                $id = $pid;\n                $parentIds = $modx->getParentIds($id, 10, array(\'context\' => $context));\n                if ($topLevel && count($parentIds) < $topLevel) {\n                    break;\n                }\n            }\n        }\n    }\n}\n\n/** @var pdoFetch $pdoFetch */\n$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoFetch = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoFetch->addTime(\'pdoTools loaded\');\n\n$where = array($class . \'.id\' => $id);\n// Add custom parameters\nforeach (array(\'where\') as $v) {\n    if (!empty($scriptProperties[$v])) {\n        $tmp = $scriptProperties[$v];\n        if (!is_array($tmp)) {\n            $tmp = json_decode($tmp, true);\n        }\n        if (is_array($tmp)) {\n            $$v = array_merge($$v, $tmp);\n        }\n    }\n    unset($scriptProperties[$v]);\n}\n$pdoFetch->addTime(\'Conditions prepared\');\n\n// Fields to select\n$resourceColumns = array_keys($modx->getFieldMeta($class));\n$field = strtolower($field);\nif (in_array($field, $resourceColumns)) {\n    $scriptProperties[\'select\'] = array($class => $field);\n    $scriptProperties[\'includeTVs\'] = \'\';\n} elseif ($isResource) {\n    $scriptProperties[\'select\'] = array($class => \'id\');\n    $scriptProperties[\'includeTVs\'] = $field;\n}\n// Additional default field\nif (!empty($default)) {\n    $default = strtolower($default);\n    if (in_array($default, $resourceColumns)) {\n        $scriptProperties[\'select\'][$class] .= \',\' . $default;\n    } elseif ($isResource) {\n        $scriptProperties[\'includeTVs\'] = empty($scriptProperties[\'includeTVs\'])\n            ? $default\n            : $scriptProperties[\'includeTVs\'] . \',\' . $default;\n    }\n}\n\n$scriptProperties[\'disableConditions\'] = true;\nif ($row = $pdoFetch->getObject($class, $where, $scriptProperties)) {\n    foreach ($row as $k => $v) {\n        if (strtolower($k) == $field && $v != \'\') {\n            $output = $v;\n            break;\n        }\n    }\n\n    if (empty($output) && !empty($default)) {\n        foreach ($row as $k => $v) {\n            if (strtolower($k) == $default && $v != \'\') {\n                $output = $v;\n                break;\n            }\n        }\n    }\n}\n\nif (!empty($toPlaceholder)) {\n    $modx->setPlaceholder($toPlaceholder, $output);\n} else {\n    return $output;\n}', 0, 'a:12:{s:2:\"id\";a:7:{s:4:\"name\";s:2:\"id\";s:4:\"desc\";s:16:\"pdotools_prop_id\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"field\";a:7:{s:4:\"name\";s:5:\"field\";s:4:\"desc\";s:19:\"pdotools_prop_field\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"pagetitle\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"prepareTVs\";a:7:{s:4:\"name\";s:10:\"prepareTVs\";s:4:\"desc\";s:24:\"pdotools_prop_prepareTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"1\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"processTVs\";a:7:{s:4:\"name\";s:10:\"processTVs\";s:4:\"desc\";s:24:\"pdotools_prop_processTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:19:\"pdotools_prop_where\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"context\";a:7:{s:4:\"name\";s:7:\"context\";s:4:\"desc\";s:27:\"pdotools_prop_field_context\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:3:\"top\";a:7:{s:4:\"name\";s:3:\"top\";s:4:\"desc\";s:17:\"pdotools_prop_top\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"topLevel\";a:7:{s:4:\"name\";s:8:\"topLevel\";s:4:\"desc\";s:22:\"pdotools_prop_topLevel\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"default\";a:7:{s:4:\"name\";s:7:\"default\";s:4:\"desc\";s:27:\"pdotools_prop_field_default\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"output\";a:7:{s:4:\"name\";s:6:\"output\";s:4:\"desc\";s:26:\"pdotools_prop_field_output\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"ultimate\";a:7:{s:4:\"name\";s:8:\"ultimate\";s:4:\"desc\";s:22:\"pdotools_prop_ultimate\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdofield.php'),
(21, 1, 0, 'pdoSitemap', '', 0, 6, 0, '/** @var array $scriptProperties */\n/** @var pdoFetch $pdoFetch */\n$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoFetch = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoFetch->addTime(\'pdoTools loaded\');\n\n// Default variables\nif (empty($tpl)) {\n    $tpl = \"@INLINE \\n<url>\\n\\t<loc>[[+url]]</loc>\\n\\t<lastmod>[[+date]]</lastmod>\\n\\t<changefreq>[[+update]]</changefreq>\\n\\t<priority>[[+priority]]</priority>\\n</url>\";\n}\nif (empty($tplWrapper)) {\n    $tplWrapper = \"@INLINE <?xml version=\\\"1.0\\\" encoding=\\\"[[++modx_charset]]\\\"?>\\n<urlset xmlns=\\\"[[+schema]]\\\">\\n[[+output]]\\n</urlset>\";\n}\nif (empty($sitemapSchema)) {\n    $sitemapSchema = \'http://www.sitemaps.org/schemas/sitemap/0.9\';\n}\nif (empty($outputSeparator)) {\n    $outputSeparator = \"\\n\";\n}\nif (empty($cacheKey)) {\n    $scriptProperties[\'cacheKey\'] = \'sitemap/\' . substr(md5(json_encode($scriptProperties)), 0, 6);\n}\n\n// Convert parameters from GoogleSiteMap if exists\nif (!empty($itemTpl)) {\n    $tpl = $itemTpl;\n}\nif (!empty($containerTpl)) {\n    $tplWrapper = $containerTpl;\n}\nif (!empty($allowedtemplates)) {\n    $scriptProperties[\'templates\'] = $allowedtemplates;\n}\nif (!empty($maxDepth)) {\n    $scriptProperties[\'depth\'] = $maxDepth;\n}\nif (isset($hideDeleted)) {\n    $scriptProperties[\'showDeleted\'] = !$hideDeleted;\n}\nif (isset($published)) {\n    $scriptProperties[\'showUnpublished\'] = !$published;\n}\nif (isset($searchable)) {\n    $scriptProperties[\'showUnsearchable\'] = !$searchable;\n}\nif (!empty($googleSchema)) {\n    $sitemapSchema = $googleSchema;\n}\nif (!empty($excludeResources)) {\n    $tmp = array_map(\'trim\', explode(\',\', $excludeResources));\n    foreach ($tmp as $v) {\n        if (!empty($scriptProperties[\'resources\'])) {\n            $scriptProperties[\'resources\'] .= \',-\' . $v;\n        } else {\n            $scriptProperties[\'resources\'] = \'-\' . $v;\n        }\n    }\n}\nif (!empty($excludeChildrenOf)) {\n    $tmp = array_map(\'trim\', explode(\',\', $excludeChildrenOf));\n    foreach ($tmp as $v) {\n        if (!empty($scriptProperties[\'parents\'])) {\n            $scriptProperties[\'parents\'] .= \',-\' . $v;\n        } else {\n            $scriptProperties[\'parents\'] = \'-\' . $v;\n        }\n    }\n}\nif (!empty($startId)) {\n    if (!empty($scriptProperties[\'parents\'])) {\n        $scriptProperties[\'parents\'] .= \',\' . $startId;\n    } else {\n        $scriptProperties[\'parents\'] = $startId;\n    }\n}\nif (!empty($sortBy)) {\n    $scriptProperties[\'sortby\'] = $sortBy;\n}\nif (!empty($sortDir)) {\n    $scriptProperties[\'sortdir\'] = $sortDir;\n}\nif (!empty($priorityTV)) {\n    if (!empty($scriptProperties[\'includeTVs\'])) {\n        $scriptProperties[\'includeTVs\'] .= \',\' . $priorityTV;\n    } else {\n        $scriptProperties[\'includeTVs\'] = $priorityTV;\n    }\n}\nif (!empty($itemSeparator)) {\n    $outputSeparator = $itemSeparator;\n}\n//---\n\n\n$class = \'modResource\';\n$where = array();\nif (empty($showHidden)) {\n    $where[] = array(\n        $class . \'.hidemenu\' => 0,\n        \'OR:\' . $class . \'.class_key:IN\' => array(\'Ticket\', \'Article\'),\n    );\n}\nif (empty($context)) {\n    $scriptProperties[\'context\'] = $modx->context->key;\n}\n\n$select = array($class => \'id,editedon,createdon,context_key,class_key,uri\');\nif (!empty($useWeblinkUrl)) {\n    $select[$class] .= \',content\';\n}\n// Add custom parameters\nforeach (array(\'where\', \'select\') as $v) {\n    if (!empty($scriptProperties[$v])) {\n        $tmp = $scriptProperties[$v];\n        if (!is_array($tmp)) {\n            $tmp = json_decode($tmp, true);\n        }\n        if (is_array($tmp)) {\n            $$v = array_merge($$v, $tmp);\n        }\n    }\n    unset($scriptProperties[$v]);\n}\n$pdoFetch->addTime(\'Conditions prepared\');\n\n// Default parameters\n$default = array(\n    \'class\' => $class,\n    \'where\' => json_encode($where),\n    \'select\' => json_encode($select),\n    \'sortby\' => \"{$class}.parent ASC, {$class}.menuindex\",\n    \'sortdir\' => \'ASC\',\n    \'return\' => \'data\',\n    \'scheme\' => \'full\',\n    \'limit\' => 0,\n);\n// Merge all properties and run!\n$pdoFetch->addTime(\'Query parameters ready\');\n$pdoFetch->setConfig(array_merge($default, $scriptProperties), false);\n\nif (!empty($cache)) {\n    $data = $pdoFetch->getCache($scriptProperties);\n}\nif (empty($data)) {\n    $now = time();\n    $data = $urls = array();\n    $rows = $pdoFetch->run();\n    foreach ($rows as $row) {\n        if (!empty($useWeblinkUrl) && $row[\'class_key\'] == \'modWebLink\') {\n            $row[\'url\'] = is_numeric(trim($row[\'content\'], \'[]~ \'))\n                ? $pdoFetch->makeUrl(intval(trim($row[\'content\'], \'[]~ \')), $row)\n                : $row[\'content\'];\n        } else {\n            $row[\'url\'] = $pdoFetch->makeUrl($row[\'id\'], $row);\n        }\n\n        $time = !empty($row[\'editedon\'])\n            ? $row[\'editedon\']\n            : $row[\'createdon\'];\n        $row[\'date\'] = date(\'c\', $time);\n\n        $datediff = floor(($now - $time) / 86400);\n        if ($datediff <= 1) {\n            $row[\'priority\'] = \'1.0\';\n            $row[\'update\'] = \'daily\';\n        } elseif (($datediff > 1) && ($datediff <= 7)) {\n            $row[\'priority\'] = \'0.75\';\n            $row[\'update\'] = \'weekly\';\n        } elseif (($datediff > 7) && ($datediff <= 30)) {\n            $row[\'priority\'] = \'0.50\';\n            $row[\'update\'] = \'weekly\';\n        } else {\n            $row[\'priority\'] = \'0.25\';\n            $row[\'update\'] = \'monthly\';\n        }\n        if (!empty($priorityTV) && !empty($row[$priorityTV])) {\n            $row[\'priority\'] = $row[$priorityTV];\n        }\n\n        // Fix possible duplicates made by modWebLink\n        if (!empty($urls[$row[\'url\']])) {\n            if ($urls[$row[\'url\']] > $row[\'date\']) {\n                continue;\n            }\n        }\n        $urls[$row[\'url\']] = $row[\'date\'];\n\n        // Add item to output\n        $data[$row[\'url\']] = $pdoFetch->parseChunk($tpl, $row);\n        if (strpos($data[$row[\'url\']], \'[[\') !== false) {\n            $modx->parser->processElementTags(\'\', $data[$row[\'url\']], true, true, \'[[\', \']]\', array(), 10);\n        }\n    }\n    $pdoFetch->addTime(\'Rows processed\');\n    if (!empty($cache)) {\n        $pdoFetch->setCache($data, $scriptProperties);\n    }\n}\n\n$output = implode($outputSeparator, $data);\n$output = $pdoFetch->getChunk($tplWrapper, array(\n    \'schema\' => $sitemapSchema,\n    \'output\' => $output,\n    \'items\' => $output,\n));\n$pdoFetch->addTime(\'Rows wrapped\');\n\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $output .= \'<pre class=\"pdoSitemapLog\">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';\n}\n\nif (!empty($forceXML)) {\n    header(\"Content-Type:text/xml\");\n    @session_write_close();\n    exit($output);\n} else {\n    return $output;\n}', 0, 'a:24:{s:3:\"tpl\";a:7:{s:4:\"name\";s:3:\"tpl\";s:4:\"desc\";s:17:\"pdotools_prop_tpl\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:145:\"@INLINE <url>\n	<loc>[[+url]]</loc>\n	<lastmod>[[+date]]</lastmod>\n	<changefreq>[[+update]]</changefreq>\n	<priority>[[+priority]]</priority>\n</url>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:24:\"pdotools_prop_tplWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:110:\"@INLINE <?xml version=\"1.0\" encoding=\"[[++modx_charset]]\"?>\n<urlset xmlns=\"[[+schema]]\">\n[[+output]]\n</urlset>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"templates\";a:7:{s:4:\"name\";s:9:\"templates\";s:4:\"desc\";s:23:\"pdotools_prop_templates\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"context\";a:7:{s:4:\"name\";s:7:\"context\";s:4:\"desc\";s:21:\"pdotools_prop_context\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"depth\";a:7:{s:4:\"name\";s:5:\"depth\";s:4:\"desc\";s:19:\"pdotools_prop_depth\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:10;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showDeleted\";a:7:{s:4:\"name\";s:11:\"showDeleted\";s:4:\"desc\";s:25:\"pdotools_prop_showDeleted\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"showHidden\";a:7:{s:4:\"name\";s:10:\"showHidden\";s:4:\"desc\";s:24:\"pdotools_prop_showHidden\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"sitemapSchema\";a:7:{s:4:\"name\";s:13:\"sitemapSchema\";s:4:\"desc\";s:27:\"pdotools_prop_sitemapSchema\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:43:\"http://www.sitemaps.org/schemas/sitemap/0.9\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"showUnpublished\";a:7:{s:4:\"name\";s:15:\"showUnpublished\";s:4:\"desc\";s:29:\"pdotools_prop_showUnpublished\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:16:\"hideUnsearchable\";a:7:{s:4:\"name\";s:16:\"hideUnsearchable\";s:4:\"desc\";s:30:\"pdotools_prop_hideUnsearchable\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"resources\";a:7:{s:4:\"name\";s:9:\"resources\";s:4:\"desc\";s:23:\"pdotools_prop_resources\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"parents\";a:7:{s:4:\"name\";s:7:\"parents\";s:4:\"desc\";s:21:\"pdotools_prop_parents\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:20:\"pdotools_prop_sortby\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"menuindex\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:21:\"pdotools_prop_sortdir\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\"asc\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:19:\"pdotools_prop_where\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"includeTVs\";a:7:{s:4:\"name\";s:10:\"includeTVs\";s:4:\"desc\";s:24:\"pdotools_prop_includeTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"prepareTVs\";a:7:{s:4:\"name\";s:10:\"prepareTVs\";s:4:\"desc\";s:24:\"pdotools_prop_prepareTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"1\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"processTVs\";a:7:{s:4:\"name\";s:10:\"processTVs\";s:4:\"desc\";s:24:\"pdotools_prop_processTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"outputSeparator\";a:7:{s:4:\"name\";s:15:\"outputSeparator\";s:4:\"desc\";s:29:\"pdotools_prop_outputSeparator\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"\n\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"forceXML\";a:7:{s:4:\"name\";s:8:\"forceXML\";s:4:\"desc\";s:22:\"pdotools_prop_forceXML\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"useWeblinkUrl\";a:7:{s:4:\"name\";s:13:\"useWeblinkUrl\";s:4:\"desc\";s:27:\"pdotools_prop_useWeblinkUrl\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"cache\";a:7:{s:4:\"name\";s:5:\"cache\";s:4:\"desc\";s:19:\"pdotools_prop_cache\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"cacheKey\";a:7:{s:4:\"name\";s:8:\"cacheKey\";s:4:\"desc\";s:22:\"pdotools_prop_cacheKey\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"cacheTime\";a:7:{s:4:\"name\";s:9:\"cacheTime\";s:4:\"desc\";s:23:\"pdotools_prop_cacheTime\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:600;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdositemap.php');
INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(22, 1, 0, 'pdoNeighbors', '', 0, 6, 0, '/** @var array $scriptProperties */\n/** @var pdoFetch $pdoFetch */\n$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoFetch = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoFetch->addTime(\'pdoTools loaded\');\n\nif (empty($id)) {\n    $id = $modx->resource->id;\n}\nif (empty($limit)) {\n    $limit = 1;\n}\nif (!isset($outputSeparator)) {\n    $outputSeparator = \"\\n\";\n}\n$fastMode = !empty($fastMode);\n\n$class = \'modResource\';\n$resource = ($id == $modx->resource->id)\n    ? $modx->resource\n    : $modx->getObject($class, $id);\nif (!$resource) {\n    return \'\';\n}\n\n// We need to determine ids of neighbors\n$params = $scriptProperties;\n$params[\'select\'] = \'id\';\n$params[\'limit\'] = 0;\nif (!empty($parents) && is_string($parents)) {\n    $parents = array_map(\'trim\', explode(\',\', $parents));\n    if (!in_array($resource->parent, $parents)) {\n        $parents[] = $resource->parent;\n    }\n    $key = array_search($resource->parent * -1, $parents);\n    if ($key !== false) {\n        unset($parents[$key]);\n    }\n    $params[\'parents\'] = implode(\',\', $parents);\n    $ids = $pdoFetch->getCollection(\'modResource\', array(), $params);\n    unset($scriptProperties[\'parents\']);\n} else {\n    $ids = $pdoFetch->getCollection(\'modResource\', array(\'parent\' => $resource->parent), $params);\n}\n\n$found = false;\n$prev = $next = array();\nforeach ($ids as $v) {\n    if ($v[\'id\'] == $id) {\n        $found = true;\n        continue;\n    } elseif (!$found) {\n        $prev[] = $v[\'id\'];\n    } else {\n        $next[] = $v[\'id\'];\n        if (count($next) >= $limit) {\n            break;\n        }\n    }\n}\n$prev = array_splice($prev, $limit * -1);\nif (!empty($loop)) {\n    if (!count($prev)) {\n        $v = end($ids);\n        $prev[] = $v[\'id\'];\n    } else {\n        if (!count($next)) {\n            $v = reset($ids);\n            $next[] = $v[\'id\'];\n        }\n    }\n}\n$ids = array_merge($prev, $next, array($resource->parent));\n$pdoFetch->addTime(\'Found ids of neighbors: \' . implode(\',\', $ids));\n\n// Query conditions\n$where = array($class . \'.id:IN\' => $ids);\n\n// Fields to select\n$resourceColumns = array_keys($modx->getFieldMeta($class));\nif (empty($includeContent) && empty($useWeblinkUrl)) {\n    $key = array_search(\'content\', $resourceColumns);\n    unset($resourceColumns[$key]);\n}\n$select = array($class => implode(\',\', $resourceColumns));\n\n// Add custom parameters\nforeach (array(\'where\', \'select\') as $v) {\n    if (!empty($scriptProperties[$v])) {\n        $tmp = $scriptProperties[$v];\n        if (!is_array($tmp)) {\n            $tmp = json_decode($tmp, true);\n        }\n        if (is_array($tmp)) {\n            $$v = array_merge($$v, $tmp);\n        }\n    }\n    unset($scriptProperties[$v]);\n}\n$pdoFetch->addTime(\'Conditions prepared\');\n\n// Default parameters\n$default = array(\n    \'class\' => $class,\n    \'where\' => json_encode($where),\n    \'select\' => json_encode($select),\n    //\'groupby\' => $class.\'.id\',\n    \'sortby\' => $class . \'.menuindex\',\n    \'sortdir\' => \'ASC\',\n    \'return\' => \'data\',\n    \'limit\' => 0,\n    \'totalVar\' => \'pdoneighbors.total\',\n);\n\n// Merge all properties and run!\nunset($scriptProperties[\'limit\']);\n$pdoFetch->addTime(\'Query parameters ready\');\n$pdoFetch->setConfig(array_merge($default, $scriptProperties), false);\n\n$rows = $pdoFetch->run();\n$prev = array_flip($prev);\n$next = array_flip($next);\n\n$output = array(\'prev\' => array(), \'up\' => array(), \'next\' => array());\nforeach ($rows as $row) {\n    if (empty($row[\'menutitle\'])) {\n        $row[\'menutitle\'] = $row[\'pagetitle\'];\n    }\n    if (!empty($useWeblinkUrl) && $row[\'class_key\'] == \'modWebLink\') {\n        $row[\'link\'] = is_numeric(trim($row[\'content\'], \'[]~ \'))\n            ? $pdoFetch->makeUrl(intval(trim($row[\'content\'], \'[]~ \')), $row)\n            : $row[\'content\'];\n    } else {\n        $row[\'link\'] = $pdoFetch->makeUrl($row[\'id\'], $row);\n    }\n\n    if (isset($prev[$row[\'id\']])) {\n        $output[\'prev\'][] = !empty($tplPrev)\n            ? $pdoFetch->getChunk($tplPrev, $row, $fastMode)\n            : $pdoFetch->getChunk(\'\', $row);\n    } elseif (isset($next[$row[\'id\']])) {\n        $output[\'next\'][] = !empty($tplNext)\n            ? $pdoFetch->getChunk($tplNext, $row, $fastMode)\n            : $pdoFetch->getChunk(\'\', $row);\n    } else {\n        $output[\'up\'][] = !empty($tplUp)\n            ? $pdoFetch->getChunk($tplUp, $row, $fastMode)\n            : $pdoFetch->getChunk(\'\', $row);\n    }\n}\n$pdoFetch->addTime(\'Chunks processed\');\n\n$log = \'\';\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $log .= \'<pre class=\"pdoNeighborsLog\">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';\n}\n\nforeach ($output as &$row) {\n    $row = implode($outputSeparator, $row);\n}\n\nif (!empty($toSeparatePlaceholders)) {\n    $output[\'log\'] = $log;\n    $modx->setPlaceholders($output, $toSeparatePlaceholders);\n} else {\n    if (!empty($rows) || !empty($wrapIfEmpty)) {\n        $output = !empty($tplWrapper)\n            ? $pdoFetch->getChunk($tplWrapper, $output, $fastMode)\n            : $pdoFetch->getChunk(\'\', $output);\n    } else {\n        $output = \'\';\n    }\n    $output .= $log;\n\n    if (!empty($toPlaceholder)) {\n        $modx->setPlaceholder($toPlaceholder, $output);\n    } else {\n        return $output;\n    }\n}', 0, 'a:27:{s:2:\"id\";a:7:{s:4:\"name\";s:2:\"id\";s:4:\"desc\";s:16:\"pdotools_prop_id\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:29:\"pdotools_prop_neighbors_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:20:\"pdotools_prop_sortby\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"menuindex\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:21:\"pdotools_prop_sortdir\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\"asc\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"depth\";a:7:{s:4:\"name\";s:5:\"depth\";s:4:\"desc\";s:19:\"pdotools_prop_depth\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplPrev\";a:7:{s:4:\"name\";s:7:\"tplPrev\";s:4:\"desc\";s:21:\"pdotools_prop_tplPrev\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:106:\"@INLINE <span class=\"link-prev\"><a href=\"[[+link]]\" class=\"btn btn-light\">&larr; [[+menutitle]]</a></span>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"tplUp\";a:7:{s:4:\"name\";s:5:\"tplUp\";s:4:\"desc\";s:19:\"pdotools_prop_tplUp\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:104:\"@INLINE <span class=\"link-up\"><a href=\"[[+link]]\" class=\"btn btn-light\">&uarr; [[+menutitle]]</a></span>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplNext\";a:7:{s:4:\"name\";s:7:\"tplNext\";s:4:\"desc\";s:21:\"pdotools_prop_tplNext\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:106:\"@INLINE <span class=\"link-next\"><a href=\"[[+link]]\" class=\"btn btn-light\">[[+menutitle]] &rarr;</a></span>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:34:\"pdotools_prop_neighbors_tplWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:93:\"@INLINE <div class=\"neighbors d-flex justify-content-between\">[[+prev]][[+up]][[+next]]</div>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"wrapIfEmpty\";a:7:{s:4:\"name\";s:11:\"wrapIfEmpty\";s:4:\"desc\";s:25:\"pdotools_prop_wrapIfEmpty\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"showUnpublished\";a:7:{s:4:\"name\";s:15:\"showUnpublished\";s:4:\"desc\";s:29:\"pdotools_prop_showUnpublished\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showDeleted\";a:7:{s:4:\"name\";s:11:\"showDeleted\";s:4:\"desc\";s:25:\"pdotools_prop_showDeleted\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"showHidden\";a:7:{s:4:\"name\";s:10:\"showHidden\";s:4:\"desc\";s:24:\"pdotools_prop_showHidden\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"hideContainers\";a:7:{s:4:\"name\";s:14:\"hideContainers\";s:4:\"desc\";s:28:\"pdotools_prop_hideContainers\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:22:\"toSeparatePlaceholders\";a:7:{s:4:\"name\";s:22:\"toSeparatePlaceholders\";s:4:\"desc\";s:36:\"pdotools_prop_toSeparatePlaceholders\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"parents\";a:7:{s:4:\"name\";s:7:\"parents\";s:4:\"desc\";s:21:\"pdotools_prop_parents\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"outputSeparator\";a:7:{s:4:\"name\";s:15:\"outputSeparator\";s:4:\"desc\";s:29:\"pdotools_prop_outputSeparator\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"\n\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"showLog\";a:7:{s:4:\"name\";s:7:\"showLog\";s:4:\"desc\";s:21:\"pdotools_prop_showLog\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"fastMode\";a:7:{s:4:\"name\";s:8:\"fastMode\";s:4:\"desc\";s:22:\"pdotools_prop_fastMode\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"includeTVs\";a:7:{s:4:\"name\";s:10:\"includeTVs\";s:4:\"desc\";s:24:\"pdotools_prop_includeTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"prepareTVs\";a:7:{s:4:\"name\";s:10:\"prepareTVs\";s:4:\"desc\";s:24:\"pdotools_prop_prepareTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"1\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"processTVs\";a:7:{s:4:\"name\";s:10:\"processTVs\";s:4:\"desc\";s:24:\"pdotools_prop_processTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tvPrefix\";a:7:{s:4:\"name\";s:8:\"tvPrefix\";s:4:\"desc\";s:22:\"pdotools_prop_tvPrefix\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\"tv.\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"scheme\";a:7:{s:4:\"name\";s:6:\"scheme\";s:4:\"desc\";s:20:\"pdotools_prop_scheme\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:6:{i:0;a:2:{s:5:\"value\";s:0:\"\";s:4:\"text\";s:14:\"System default\";}i:1;a:2:{s:5:\"value\";i:-1;s:4:\"text\";s:25:\"-1 (relative to site_url)\";}i:2;a:2:{s:5:\"value\";s:4:\"full\";s:4:\"text\";s:40:\"full (absolute, prepended with site_url)\";}i:3;a:2:{s:5:\"value\";s:3:\"abs\";s:4:\"text\";s:39:\"abs (absolute, prepended with base_url)\";}i:4;a:2:{s:5:\"value\";s:4:\"http\";s:4:\"text\";s:38:\"http (absolute, forced to http scheme)\";}i:5;a:2:{s:5:\"value\";s:5:\"https\";s:4:\"text\";s:40:\"https (absolute, forced to https scheme)\";}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"useWeblinkUrl\";a:7:{s:4:\"name\";s:13:\"useWeblinkUrl\";s:4:\"desc\";s:27:\"pdotools_prop_useWeblinkUrl\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:4:\"loop\";a:7:{s:4:\"name\";s:4:\"loop\";s:4:\"desc\";s:18:\"pdotools_prop_loop\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdoneighbors.php'),
(23, 1, 0, 'pdoPage', '', 0, 6, 0, '/** @var array $scriptProperties */\n// Default variables\nif (empty($pageVarKey)) {\n    $pageVarKey = \'page\';\n}\nif (empty($pageNavVar)) {\n    $pageNavVar = \'page.nav\';\n}\nif (empty($pageCountVar)) {\n    $pageCountVar = \'pageCount\';\n}\nif (empty($totalVar)) {\n    $totalVar = \'total\';\n}\nif (empty($page)) {\n    $page = 1;\n}\nif (empty($pageLimit)) {\n    $pageLimit = 5;\n} else {\n    $pageLimit = (integer)$pageLimit;\n}\nif (!isset($plPrefix)) {\n    $plPrefix = \'\';\n}\nif (!empty($scriptProperties[\'ajaxMode\'])) {\n    $scriptProperties[\'ajax\'] = 1;\n}\n\n// Convert parameters from getPage if exists\nif (!empty($namespace)) {\n    $plPrefix = $namespace;\n}\nif (!empty($pageNavTpl)) {\n    $scriptProperties[\'tplPage\'] = $pageNavTpl;\n}\nif (!empty($pageNavOuterTpl)) {\n    $scriptProperties[\'tplPageWrapper\'] = $pageNavOuterTpl;\n}\nif (!empty($pageActiveTpl)) {\n    $scriptProperties[\'tplPageActive\'] = $pageActiveTpl;\n}\nif (!empty($pageFirstTpl)) {\n    $scriptProperties[\'tplPageFirst\'] = $pageFirstTpl;\n}\nif (!empty($pagePrevTpl)) {\n    $scriptProperties[\'tplPagePrev\'] = $pagePrevTpl;\n}\nif (!empty($pageNextTpl)) {\n    $scriptProperties[\'tplPageNext\'] = $pageNextTpl;\n}\nif (!empty($pageLastTpl)) {\n    $scriptProperties[\'tplPageLast\'] = $pageLastTpl;\n}\nif (!empty($pageSkipTpl)) {\n    $scriptProperties[\'tplPageSkip\'] = $pageSkipTpl;\n}\nif (!empty($pageNavScheme)) {\n    $scriptProperties[\'scheme\'] = $pageNavScheme;\n}\nif (!empty($cache_expires)) {\n    $scriptProperties[\'cacheTime\'] = $cache_expires;\n}\n//---\n$strictMode = !empty($strictMode);\n\n$isAjax = !empty($scriptProperties[\'ajax\']) && !empty($_SERVER[\'HTTP_X_REQUESTED_WITH\']) && $_SERVER[\'HTTP_X_REQUESTED_WITH\'] == \'XMLHttpRequest\';\nif ($isAjax && !isset($_REQUEST[$pageVarKey])) {\n    return;\n}\n\n/** @var pdoPage $pdoPage */\n$fqn = $modx->getOption(\'pdoPage.class\', null, \'pdotools.pdopage\', true);\n$path = $modx->getOption(\'pdopage_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoPage = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoPage->pdoTools->addTime(\'pdoTools loaded\');\n\n// Script and styles\nif (!$isAjax && !empty($scriptProperties[\'ajaxMode\'])) {\n    $pdoPage->loadJsCss();\n}\n// Removing of default scripts and styles so they do not overwrote nested snippet parameters\nif ($snippet = $modx->getObject(\'modSnippet\', array(\'name\' => \'pdoPage\'))) {\n    $properties = $snippet->get(\'properties\');\n    if ($scriptProperties[\'frontend_js\'] == $properties[\'frontend_js\'][\'value\']) {\n        unset($scriptProperties[\'frontend_js\']);\n    }\n    if ($scriptProperties[\'frontend_css\'] == $properties[\'frontend_css\'][\'value\']) {\n        unset($scriptProperties[\'frontend_css\']);\n    }\n}\n\n// Page\nif (isset($_REQUEST[$pageVarKey]) && $strictMode && (!is_numeric($_REQUEST[$pageVarKey]) || ($_REQUEST[$pageVarKey] <= 1 && !$isAjax))) {\n    return $pdoPage->redirectToFirst($isAjax);\n} elseif (!empty($_REQUEST[$pageVarKey])) {\n    $page = (integer)$_REQUEST[$pageVarKey];\n}\n$scriptProperties[\'page\'] = $page;\n$scriptProperties[\'request\'] = $_REQUEST;\n$scriptProperties[\'setTotal\'] = true;\n\n// Limit\nif (isset($_REQUEST[\'limit\'])) {\n    if (is_numeric($_REQUEST[\'limit\']) && abs($_REQUEST[\'limit\']) > 0) {\n        $scriptProperties[\'limit\'] = abs($_REQUEST[\'limit\']);\n    } elseif ($strictMode) {\n        unset($_GET[\'limit\']);\n\n        return $pdoPage->redirectToFirst($isAjax);\n    }\n}\nif (!empty($maxLimit) && !empty($scriptProperties[\'limit\']) && $scriptProperties[\'limit\'] > $maxLimit) {\n    $scriptProperties[\'limit\'] = $maxLimit;\n}\n\n// Offset\n$offset = !empty($scriptProperties[\'offset\']) && $scriptProperties[\'offset\'] > 0\n    ? (int)$scriptProperties[\'offset\']\n    : 0;\n$scriptProperties[\'offset\'] = $page > 1\n    ? $scriptProperties[\'limit\'] * ($page - 1) + $offset\n    : $offset;\nif (!empty($scriptProperties[\'offset\']) && empty($scriptProperties[\'limit\'])) {\n    $scriptProperties[\'limit\'] = 10000000;\n}\n\n$cache = !empty($cache) || (!$modx->user->id && !empty($cacheAnonymous));\n$url = $pdoPage->getBaseUrl();\n$output = $pagination = $total = $pageCount = \'\';\n\n$data = $cache\n    ? $pdoPage->pdoTools->getCache($scriptProperties)\n    : array();\n\nif (empty($data)) {\n    $output = $pdoPage->pdoTools->runSnippet($scriptProperties[\'element\'], $scriptProperties);\n    if ($output === false) {\n        return \'\';\n    } elseif (!empty($toPlaceholder)) {\n        $output = $modx->getPlaceholder($toPlaceholder);\n    }\n\n    // Pagination\n    $total = (int)$modx->getPlaceholder($totalVar);\n    $pageCount = !empty($scriptProperties[\'limit\']) && $total > $offset\n        ? ceil(($total - $offset) / $scriptProperties[\'limit\'])\n        : 0;\n\n    // Redirect to start if somebody specified incorrect page\n    if ($page > 1 && $page > $pageCount && $strictMode) {\n        return $pdoPage->redirectToFirst($isAjax);\n    }\n    if (!empty($pageCount) && $pageCount > 1) {\n        $pagination = array(\n            \'first\' => $page > 1 && !empty($tplPageFirst)\n                ? $pdoPage->makePageLink($url, 1, $tplPageFirst)\n                : \'\',\n            \'prev\' => $page > 1 && !empty($tplPagePrev)\n                ? $pdoPage->makePageLink($url, $page - 1, $tplPagePrev)\n                : \'\',\n            \'pages\' => $pageLimit >= 7 && empty($disableModernPagination)\n                ? $pdoPage->buildModernPagination($page, $pageCount, $url)\n                : $pdoPage->buildClassicPagination($page, $pageCount, $url),\n            \'next\' => $page < $pageCount && !empty($tplPageNext)\n                ? $pdoPage->makePageLink($url, $page + 1, $tplPageNext)\n                : \'\',\n            \'last\' => $page < $pageCount && !empty($tplPageLast)\n                ? $pdoPage->makePageLink($url, $pageCount, $tplPageLast)\n                : \'\',\n        );\n\n        if (!empty($pageCount)) {\n            foreach (array(\'first\', \'prev\', \'next\', \'last\') as $v) {\n                $tpl = \'tplPage\' . ucfirst($v) . \'Empty\';\n                if (!empty(${$tpl}) && empty($pagination[$v])) {\n                    $pagination[$v] = $pdoPage->pdoTools->getChunk(${$tpl});\n                }\n            }\n        }\n    } else {\n        $pagination = array(\n            \'first\' => \'\',\n            \'prev\' => \'\',\n            \'pages\' => \'\',\n            \'next\' => \'\',\n            \'last\' => \'\'\n        );\n    }\n\n    $data = array(\n        \'output\' => $output,\n        $pageVarKey => $page,\n        $pageCountVar => $pageCount,\n        $pageNavVar => !empty($tplPageWrapper)\n            ? $pdoPage->pdoTools->getChunk($tplPageWrapper, $pagination)\n            : $pdoPage->pdoTools->parseChunk(\'\', $pagination),\n        $totalVar => $total,\n    );\n    if ($cache) {\n        $pdoPage->pdoTools->setCache($data, $scriptProperties);\n    }\n}\n\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $data[\'output\'] .= \'<pre class=\"pdoPageLog\">\' . print_r($pdoPage->pdoTools->getTime(), 1) . \'</pre>\';\n}\n\nif ($isAjax) {\n    if ($pageNavVar != \'pagination\') {\n        $data[\'pagination\'] = $data[$pageNavVar];\n        unset($data[$pageNavVar]);\n    }\n    if ($pageCountVar != \'pages\') {\n        $data[\'pages\'] = (int)$data[$pageCountVar];\n        unset($data[$pageCountVar]);\n    }\n    if ($pageVarKey != \'page\') {\n        $data[\'page\'] = (int)$data[$pageVarKey];\n        unset($data[$pageVarKey]);\n    }\n    if ($totalVar != \'total\') {\n        $data[\'total\'] = (int)$data[$totalVar];\n        unset($data[$totalVar]);\n    }\n\n    $maxIterations = (integer)$modx->getOption(\'parser_max_iterations\', null, 10);\n    $modx->getParser()->processElementTags(\'\', $data[\'output\'], false, false, \'[[\', \']]\', array(), $maxIterations);\n    $modx->getParser()->processElementTags(\'\', $data[\'output\'], true, true, \'[[\', \']]\', array(), $maxIterations);\n\n    @session_write_close();\n    exit(json_encode($data));\n} else {\n    if (!empty($setMeta)) {\n        $charset = $modx->getOption(\'modx_charset\', null, \'UTF-8\');\n        $canurl = $pdoPage->pdoTools->config[\'scheme\'] !== \'full\'\n            ? rtrim($modx->getOption(\'site_url\'), \'/\') . \'/\' . ltrim($url, \'/\')\n            : $url;\n        $modx->regClientStartupHTMLBlock(\'<link rel=\"canonical\" href=\"\' . htmlentities($canurl, ENT_QUOTES, $charset) . \'\"/>\');\n        if ($data[$pageVarKey] > 1) {\n            $prevUrl = $pdoPage->makePageLink($canurl, $data[$pageVarKey] - 1);\n            $modx->regClientStartupHTMLBlock(\n                \'<link rel=\"prev\" href=\"\' . htmlentities($prevUrl, ENT_QUOTES, $charset) . \'\"/>\'\n            );\n        }\n        if ($data[$pageVarKey] < $data[$pageCountVar]) {\n            $nextUrl = $pdoPage->makePageLink($canurl, $data[$pageVarKey] + 1);\n            $modx->regClientStartupHTMLBlock(\n                \'<link rel=\"next\" href=\"\' . htmlentities($nextUrl, ENT_QUOTES, $charset) . \'\"/>\'\n            );\n        }\n    }\n\n    $modx->setPlaceholders($data, $plPrefix);\n    if (!empty($toPlaceholder)) {\n        $modx->setPlaceholder($toPlaceholder, $data[\'output\']);\n    } else {\n        return $data[\'output\'];\n    }\n}', 0, 'a:41:{s:8:\"plPrefix\";a:7:{s:4:\"name\";s:8:\"plPrefix\";s:4:\"desc\";s:22:\"pdotools_prop_plPrefix\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:19:\"pdotools_prop_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:10;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"maxLimit\";a:7:{s:4:\"name\";s:8:\"maxLimit\";s:4:\"desc\";s:22:\"pdotools_prop_maxLimit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:100;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"offset\";a:7:{s:4:\"name\";s:6:\"offset\";s:4:\"desc\";s:20:\"pdotools_prop_offset\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:4:\"page\";a:7:{s:4:\"name\";s:4:\"page\";s:4:\"desc\";s:18:\"pdotools_prop_page\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"pageVarKey\";a:7:{s:4:\"name\";s:10:\"pageVarKey\";s:4:\"desc\";s:24:\"pdotools_prop_pageVarKey\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:4:\"page\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"totalVar\";a:7:{s:4:\"name\";s:8:\"totalVar\";s:4:\"desc\";s:22:\"pdotools_prop_totalVar\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:10:\"page.total\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"pageLimit\";a:7:{s:4:\"name\";s:9:\"pageLimit\";s:4:\"desc\";s:23:\"pdotools_prop_pageLimit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:5;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"element\";a:7:{s:4:\"name\";s:7:\"element\";s:4:\"desc\";s:21:\"pdotools_prop_element\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:12:\"pdoResources\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"pageNavVar\";a:7:{s:4:\"name\";s:10:\"pageNavVar\";s:4:\"desc\";s:24:\"pdotools_prop_pageNavVar\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:8:\"page.nav\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"pageCountVar\";a:7:{s:4:\"name\";s:12:\"pageCountVar\";s:4:\"desc\";s:26:\"pdotools_prop_pageCountVar\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"pageCount\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"pageLinkScheme\";a:7:{s:4:\"name\";s:14:\"pageLinkScheme\";s:4:\"desc\";s:28:\"pdotools_prop_pageLinkScheme\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplPage\";a:7:{s:4:\"name\";s:7:\"tplPage\";s:4:\"desc\";s:21:\"pdotools_prop_tplPage\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:88:\"@INLINE <li class=\"page-item\"><a class=\"page-link\" href=\"[[+href]]\">[[+pageNo]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"tplPageWrapper\";a:7:{s:4:\"name\";s:14:\"tplPageWrapper\";s:4:\"desc\";s:28:\"pdotools_prop_tplPageWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:83:\"@INLINE <ul class=\"pagination\">[[+first]][[+prev]][[+pages]][[+next]][[+last]]</ul>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"tplPageActive\";a:7:{s:4:\"name\";s:13:\"tplPageActive\";s:4:\"desc\";s:27:\"pdotools_prop_tplPageActive\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:95:\"@INLINE <li class=\"page-item active\"><a class=\"page-link\" href=\"[[+href]]\">[[+pageNo]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"tplPageFirst\";a:7:{s:4:\"name\";s:12:\"tplPageFirst\";s:4:\"desc\";s:26:\"pdotools_prop_tplPageFirst\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:95:\"@INLINE <li class=\"page-item\"><a class=\"page-link\" href=\"[[+href]]\">[[%pdopage_first]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"tplPageLast\";a:7:{s:4:\"name\";s:11:\"tplPageLast\";s:4:\"desc\";s:25:\"pdotools_prop_tplPageLast\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:94:\"@INLINE <li class=\"page-item\"><a class=\"page-link\" href=\"[[+href]]\">[[%pdopage_last]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"tplPagePrev\";a:7:{s:4:\"name\";s:11:\"tplPagePrev\";s:4:\"desc\";s:25:\"pdotools_prop_tplPagePrev\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:84:\"@INLINE <li class=\"page-item\"><a class=\"page-link\" href=\"[[+href]]\">&laquo;</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"tplPageNext\";a:7:{s:4:\"name\";s:11:\"tplPageNext\";s:4:\"desc\";s:25:\"pdotools_prop_tplPageNext\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:84:\"@INLINE <li class=\"page-item\"><a class=\"page-link\" href=\"[[+href]]\">&raquo;</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"tplPageSkip\";a:7:{s:4:\"name\";s:11:\"tplPageSkip\";s:4:\"desc\";s:25:\"pdotools_prop_tplPageSkip\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:81:\"@INLINE <li class=\"page-item disabled\"><a class=\"page-link\" href=\"#\">...</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:17:\"tplPageFirstEmpty\";a:7:{s:4:\"name\";s:17:\"tplPageFirstEmpty\";s:4:\"desc\";s:31:\"pdotools_prop_tplPageFirstEmpty\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:96:\"@INLINE <li class=\"page-item disabled\"><a class=\"page-link\" href=\"#\">[[%pdopage_first]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:16:\"tplPageLastEmpty\";a:7:{s:4:\"name\";s:16:\"tplPageLastEmpty\";s:4:\"desc\";s:30:\"pdotools_prop_tplPageLastEmpty\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:95:\"@INLINE <li class=\"page-item disabled\"><a class=\"page-link\" href=\"#\">[[%pdopage_last]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:16:\"tplPagePrevEmpty\";a:7:{s:4:\"name\";s:16:\"tplPagePrevEmpty\";s:4:\"desc\";s:30:\"pdotools_prop_tplPagePrevEmpty\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:85:\"@INLINE <li class=\"page-item disabled\"><a class=\"page-link\" href=\"#\">&laquo;</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:16:\"tplPageNextEmpty\";a:7:{s:4:\"name\";s:16:\"tplPageNextEmpty\";s:4:\"desc\";s:30:\"pdotools_prop_tplPageNextEmpty\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:85:\"@INLINE <li class=\"page-item disabled\"><a class=\"page-link\" href=\"#\">&raquo;</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"cache\";a:7:{s:4:\"name\";s:5:\"cache\";s:4:\"desc\";s:19:\"pdotools_prop_cache\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"cacheTime\";a:7:{s:4:\"name\";s:9:\"cacheTime\";s:4:\"desc\";s:23:\"pdotools_prop_cacheTime\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:3600;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"cacheAnonymous\";a:7:{s:4:\"name\";s:14:\"cacheAnonymous\";s:4:\"desc\";s:28:\"pdotools_prop_cacheAnonymous\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:4:\"ajax\";a:7:{s:4:\"name\";s:4:\"ajax\";s:4:\"desc\";s:18:\"pdotools_prop_ajax\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"ajaxMode\";a:7:{s:4:\"name\";s:8:\"ajaxMode\";s:4:\"desc\";s:22:\"pdotools_prop_ajaxMode\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:4:{i:0;a:2:{s:4:\"text\";s:4:\"None\";s:5:\"value\";s:0:\"\";}i:1;a:2:{s:4:\"text\";s:7:\"Default\";s:5:\"value\";s:7:\"default\";}i:2;a:2:{s:4:\"text\";s:6:\"Scroll\";s:5:\"value\";s:6:\"scroll\";}i:3;a:2:{s:4:\"text\";s:6:\"Button\";s:5:\"value\";s:6:\"button\";}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"ajaxElemWrapper\";a:7:{s:4:\"name\";s:15:\"ajaxElemWrapper\";s:4:\"desc\";s:29:\"pdotools_prop_ajaxElemWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:8:\"#pdopage\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"ajaxElemRows\";a:7:{s:4:\"name\";s:12:\"ajaxElemRows\";s:4:\"desc\";s:26:\"pdotools_prop_ajaxElemRows\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:14:\"#pdopage .rows\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:18:\"ajaxElemPagination\";a:7:{s:4:\"name\";s:18:\"ajaxElemPagination\";s:4:\"desc\";s:32:\"pdotools_prop_ajaxElemPagination\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:20:\"#pdopage .pagination\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"ajaxElemLink\";a:7:{s:4:\"name\";s:12:\"ajaxElemLink\";s:4:\"desc\";s:26:\"pdotools_prop_ajaxElemLink\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:22:\"#pdopage .pagination a\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"ajaxElemMore\";a:7:{s:4:\"name\";s:12:\"ajaxElemMore\";s:4:\"desc\";s:26:\"pdotools_prop_ajaxElemMore\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:18:\"#pdopage .btn-more\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"ajaxTplMore\";a:7:{s:4:\"name\";s:11:\"ajaxTplMore\";s:4:\"desc\";s:25:\"pdotools_prop_ajaxTplMore\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:75:\"@INLINE <button class=\"btn btn-primary btn-more\">[[%pdopage_more]]</button>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"ajaxHistory\";a:7:{s:4:\"name\";s:11:\"ajaxHistory\";s:4:\"desc\";s:25:\"pdotools_prop_ajaxHistory\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:3:{i:0;a:2:{s:4:\"text\";s:4:\"Auto\";s:5:\"value\";s:0:\"\";}i:1;a:2:{s:4:\"text\";s:7:\"Enabled\";s:5:\"value\";i:1;}i:2;a:2:{s:4:\"text\";s:8:\"Disabled\";s:5:\"value\";i:0;}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"frontend_js\";a:7:{s:4:\"name\";s:11:\"frontend_js\";s:4:\"desc\";s:25:\"pdotools_prop_frontend_js\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:31:\"[[+assetsUrl]]js/pdopage.min.js\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"frontend_css\";a:7:{s:4:\"name\";s:12:\"frontend_css\";s:4:\"desc\";s:26:\"pdotools_prop_frontend_css\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:33:\"[[+assetsUrl]]css/pdopage.min.css\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"setMeta\";a:7:{s:4:\"name\";s:7:\"setMeta\";s:4:\"desc\";s:21:\"pdotools_prop_setMeta\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"strictMode\";a:7:{s:4:\"name\";s:10:\"strictMode\";s:4:\"desc\";s:24:\"pdotools_prop_strictMode\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdopage.php');
INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(24, 1, 0, 'pdoMenu', '', 0, 6, 0, '/** @var array $scriptProperties */\n\n// Convert parameters from Wayfinder if exists\nif (isset($startId)) {\n    $scriptProperties[\'parents\'] = $startId;\n}\nif (!empty($includeDocs)) {\n    $tmp = array_map(\'trim\', explode(\',\', $includeDocs));\n    foreach ($tmp as $v) {\n        if (!empty($scriptProperties[\'resources\'])) {\n            $scriptProperties[\'resources\'] .= \',\' . $v;\n        } else {\n            $scriptProperties[\'resources\'] = $v;\n        }\n    }\n}\nif (!empty($excludeDocs)) {\n    $tmp = array_map(\'trim\', explode(\',\', $excludeDocs));\n    foreach ($tmp as $v) {\n        if (!empty($scriptProperties[\'resources\'])) {\n            $scriptProperties[\'resources\'] .= \',-\' . $v;\n        } else {\n            $scriptProperties[\'resources\'] = \'-\' . $v;\n        }\n    }\n}\n\nif (!empty($previewUnpublished) && $modx->hasPermission(\'view_unpublished\')) {\n    $scriptProperties[\'showUnpublished\'] = 1;\n}\n\n$scriptProperties[\'depth\'] = empty($level) ? 100 : abs($level) - 1;\nif (!empty($contexts)) {\n    $scriptProperties[\'context\'] = $contexts;\n}\nif (empty($scriptProperties[\'context\'])) {\n    $scriptProperties[\'context\'] = $modx->resource->context_key;\n}\n\n// Save original parents specified by user\n$specified_parents = array_map(\'trim\', explode(\',\', $scriptProperties[\'parents\']));\n\nif ($scriptProperties[\'parents\'] === \'\') {\n    $scriptProperties[\'parents\'] = $modx->resource->id;\n} elseif ($scriptProperties[\'parents\'] === 0 || $scriptProperties[\'parents\'] === \'0\') {\n    if ($scriptProperties[\'depth\'] !== \'\' && $scriptProperties[\'depth\'] !== 100) {\n        $contexts = array_map(\'trim\', explode(\',\', $scriptProperties[\'context\']));\n        $parents = array();\n        if (!empty($scriptProperties[\'showDeleted\'])) {\n            $pdoFetch = $modx->getService(\'pdoFetch\');\n            foreach ($contexts as $ctx) {\n                $parents = array_merge($parents,\n                    $pdoFetch->getChildIds(\'modResource\', 0, $scriptProperties[\'depth\'], array(\'context\' => $ctx)));\n            }\n        } else {\n            foreach ($contexts as $ctx) {\n                $parents = array_merge($parents,\n                    $modx->getChildIds(0, $scriptProperties[\'depth\'], array(\'context\' => $ctx)));\n            }\n        }\n        $scriptProperties[\'parents\'] = !empty($parents) ? implode(\',\', $parents) : \'+0\';\n        $scriptProperties[\'depth\'] = 0;\n    }\n    $scriptProperties[\'includeParents\'] = 1;\n    $scriptProperties[\'displayStart\'] = 0;\n} else {\n    $parents = array_map(\'trim\', explode(\',\', $scriptProperties[\'parents\']));\n    $parents_in = $parents_out = array();\n    foreach ($parents as $v) {\n        if (!is_numeric($v)) {\n            continue;\n        }\n        if ($v[0] == \'-\') {\n            $parents_out[] = abs($v);\n        } else {\n            $parents_in[] = abs($v);\n        }\n    }\n\n    if (empty($parents_in)) {\n        $scriptProperties[\'includeParents\'] = 1;\n        $scriptProperties[\'displayStart\'] = 0;\n    }\n}\n\nif (!empty($displayStart)) {\n    $scriptProperties[\'includeParents\'] = 1;\n}\nif (!empty($ph)) {\n    $toPlaceholder = $ph;\n}\nif (!empty($sortOrder)) {\n    $scriptProperties[\'sortdir\'] = $sortOrder;\n}\nif (!empty($sortBy)) {\n    $scriptProperties[\'sortby\'] = $sortBy;\n}\nif (!empty($permissions)) {\n    $scriptProperties[\'checkPermissions\'] = $permissions;\n}\nif (!empty($cacheResults)) {\n    $scriptProperties[\'cache\'] = $cacheResults;\n}\nif (!empty($ignoreHidden)) {\n    $scriptProperties[\'showHidden\'] = $ignoreHidden;\n}\n\n$wfTemplates = array(\n    \'outerTpl\' => \'tplOuter\',\n    \'rowTpl\' => \'tpl\',\n    \'parentRowTpl\' => \'tplParentRow\',\n    \'parentRowHereTpl\' => \'tplParentRowHere\',\n    \'hereTpl\' => \'tplHere\',\n    \'innerTpl\' => \'tplInner\',\n    \'innerRowTpl\' => \'tplInnerRow\',\n    \'innerHereTpl\' => \'tplInnerHere\',\n    \'activeParentRowTpl\' => \'tplParentRowActive\',\n    \'categoryFoldersTpl\' => \'tplCategoryFolder\',\n    \'startItemTpl\' => \'tplStart\',\n);\nforeach ($wfTemplates as $k => $v) {\n    if (isset(${$k})) {\n        $scriptProperties[$v] = ${$k};\n    }\n}\n//---\n\n/** @var pdoMenu $pdoMenu */\n$fqn = $modx->getOption(\'pdoMenu.class\', null, \'pdotools.pdomenu\', true);\n$path = $modx->getOption(\'pdomenu_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoMenu = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoMenu->pdoTools->addTime(\'pdoTools loaded\');\n\n$cache = !empty($cache) || (!$modx->user->id && !empty($cacheAnonymous));\nif (empty($scriptProperties[\'cache_key\'])) {\n    $scriptProperties[\'cache_key\'] = \'pdomenu/\' . sha1(serialize($scriptProperties));\n}\n\n$output = \'\';\n$tree = array();\nif ($cache) {\n    $tree = $pdoMenu->pdoTools->getCache($scriptProperties);\n}\nif (empty($tree)) {\n    $data = $pdoMenu->pdoTools->run();\n    $data = $pdoMenu->pdoTools->buildTree($data, \'id\', \'parent\', $specified_parents);\n    $tree = array();\n    foreach ($data as $k => $v) {\n        if (empty($v[\'id\'])) {\n            if (!in_array($k, $specified_parents) && !$pdoMenu->checkResource($k)) {\n                continue;\n            } else {\n                $tree = array_merge($tree, $v[\'children\']);\n            }\n        } else {\n            $tree[$k] = $v;\n        }\n    }\n    if ($cache) {\n        $pdoMenu->pdoTools->setCache($tree, $scriptProperties);\n    }\n}\nif (!empty($tree)) {\n    $output = $pdoMenu->templateTree($tree);\n}\n\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $output .= \'<pre class=\"pdoMenuLog\">\' . print_r($pdoMenu->pdoTools->getTime(), 1) . \'</pre>\';\n}\n\nif (!empty($toPlaceholder)) {\n    $modx->setPlaceholder($toPlaceholder, $output);\n} else {\n    return $output;\n}', 0, 'a:51:{s:7:\"showLog\";a:7:{s:4:\"name\";s:7:\"showLog\";s:4:\"desc\";s:21:\"pdotools_prop_showLog\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"fastMode\";a:7:{s:4:\"name\";s:8:\"fastMode\";s:4:\"desc\";s:22:\"pdotools_prop_fastMode\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"level\";a:7:{s:4:\"name\";s:5:\"level\";s:4:\"desc\";s:19:\"pdotools_prop_level\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"parents\";a:7:{s:4:\"name\";s:7:\"parents\";s:4:\"desc\";s:21:\"pdotools_prop_parents\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"displayStart\";a:7:{s:4:\"name\";s:12:\"displayStart\";s:4:\"desc\";s:26:\"pdotools_prop_displayStart\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"resources\";a:7:{s:4:\"name\";s:9:\"resources\";s:4:\"desc\";s:23:\"pdotools_prop_resources\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"templates\";a:7:{s:4:\"name\";s:9:\"templates\";s:4:\"desc\";s:23:\"pdotools_prop_templates\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"context\";a:7:{s:4:\"name\";s:7:\"context\";s:4:\"desc\";s:21:\"pdotools_prop_context\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"cache\";a:7:{s:4:\"name\";s:5:\"cache\";s:4:\"desc\";s:19:\"pdotools_prop_cache\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"cacheTime\";a:7:{s:4:\"name\";s:9:\"cacheTime\";s:4:\"desc\";s:23:\"pdotools_prop_cacheTime\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:3600;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"cacheAnonymous\";a:7:{s:4:\"name\";s:14:\"cacheAnonymous\";s:4:\"desc\";s:28:\"pdotools_prop_cacheAnonymous\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"plPrefix\";a:7:{s:4:\"name\";s:8:\"plPrefix\";s:4:\"desc\";s:22:\"pdotools_prop_plPrefix\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\"wf.\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"showHidden\";a:7:{s:4:\"name\";s:10:\"showHidden\";s:4:\"desc\";s:24:\"pdotools_prop_showHidden\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"showUnpublished\";a:7:{s:4:\"name\";s:15:\"showUnpublished\";s:4:\"desc\";s:29:\"pdotools_prop_showUnpublished\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showDeleted\";a:7:{s:4:\"name\";s:11:\"showDeleted\";s:4:\"desc\";s:25:\"pdotools_prop_showDeleted\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:18:\"previewUnpublished\";a:7:{s:4:\"name\";s:18:\"previewUnpublished\";s:4:\"desc\";s:32:\"pdotools_prop_previewUnpublished\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"hideSubMenus\";a:7:{s:4:\"name\";s:12:\"hideSubMenus\";s:4:\"desc\";s:26:\"pdotools_prop_hideSubMenus\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"useWeblinkUrl\";a:7:{s:4:\"name\";s:13:\"useWeblinkUrl\";s:4:\"desc\";s:27:\"pdotools_prop_useWeblinkUrl\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:21:\"pdotools_prop_sortdir\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:3:\"ASC\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:20:\"pdotools_prop_sortby\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"menuindex\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:19:\"pdotools_prop_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"offset\";a:7:{s:4:\"name\";s:6:\"offset\";s:4:\"desc\";s:20:\"pdotools_prop_offset\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"rowIdPrefix\";a:7:{s:4:\"name\";s:11:\"rowIdPrefix\";s:4:\"desc\";s:25:\"pdotools_prop_rowIdPrefix\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"firstClass\";a:7:{s:4:\"name\";s:10:\"firstClass\";s:4:\"desc\";s:24:\"pdotools_prop_firstClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:5:\"first\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"lastClass\";a:7:{s:4:\"name\";s:9:\"lastClass\";s:4:\"desc\";s:23:\"pdotools_prop_lastClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:4:\"last\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"hereClass\";a:7:{s:4:\"name\";s:9:\"hereClass\";s:4:\"desc\";s:23:\"pdotools_prop_hereClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:6:\"active\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"parentClass\";a:7:{s:4:\"name\";s:11:\"parentClass\";s:4:\"desc\";s:25:\"pdotools_prop_parentClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"rowClass\";a:7:{s:4:\"name\";s:8:\"rowClass\";s:4:\"desc\";s:22:\"pdotools_prop_rowClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"outerClass\";a:7:{s:4:\"name\";s:10:\"outerClass\";s:4:\"desc\";s:24:\"pdotools_prop_outerClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"innerClass\";a:7:{s:4:\"name\";s:10:\"innerClass\";s:4:\"desc\";s:24:\"pdotools_prop_innerClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"levelClass\";a:7:{s:4:\"name\";s:10:\"levelClass\";s:4:\"desc\";s:24:\"pdotools_prop_levelClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"selfClass\";a:7:{s:4:\"name\";s:9:\"selfClass\";s:4:\"desc\";s:23:\"pdotools_prop_selfClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"webLinkClass\";a:7:{s:4:\"name\";s:12:\"webLinkClass\";s:4:\"desc\";s:26:\"pdotools_prop_webLinkClass\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tplOuter\";a:7:{s:4:\"name\";s:8:\"tplOuter\";s:4:\"desc\";s:22:\"pdotools_prop_tplOuter\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:41:\"@INLINE <ul[[+classes]]>[[+wrapper]]</ul>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:3:\"tpl\";a:7:{s:4:\"name\";s:3:\"tpl\";s:4:\"desc\";s:17:\"pdotools_prop_tpl\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:95:\"@INLINE <li[[+classes]]><a href=\"[[+link]]\" [[+attributes]]>[[+menutitle]]</a>[[+wrapper]]</li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"tplParentRow\";a:7:{s:4:\"name\";s:12:\"tplParentRow\";s:4:\"desc\";s:26:\"pdotools_prop_tplParentRow\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:16:\"tplParentRowHere\";a:7:{s:4:\"name\";s:16:\"tplParentRowHere\";s:4:\"desc\";s:30:\"pdotools_prop_tplParentRowHere\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplHere\";a:7:{s:4:\"name\";s:7:\"tplHere\";s:4:\"desc\";s:21:\"pdotools_prop_tplHere\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tplInner\";a:7:{s:4:\"name\";s:8:\"tplInner\";s:4:\"desc\";s:22:\"pdotools_prop_tplInner\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"tplInnerRow\";a:7:{s:4:\"name\";s:11:\"tplInnerRow\";s:4:\"desc\";s:25:\"pdotools_prop_tplInnerRow\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"tplInnerHere\";a:7:{s:4:\"name\";s:12:\"tplInnerHere\";s:4:\"desc\";s:26:\"pdotools_prop_tplInnerHere\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:18:\"tplParentRowActive\";a:7:{s:4:\"name\";s:18:\"tplParentRowActive\";s:4:\"desc\";s:32:\"pdotools_prop_tplParentRowActive\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:17:\"tplCategoryFolder\";a:7:{s:4:\"name\";s:17:\"tplCategoryFolder\";s:4:\"desc\";s:31:\"pdotools_prop_tplCategoryFolder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tplStart\";a:7:{s:4:\"name\";s:8:\"tplStart\";s:4:\"desc\";s:22:\"pdotools_prop_tplStart\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:55:\"@INLINE <h2[[+classes]]>[[+menutitle]]</h2>[[+wrapper]]\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:16:\"checkPermissions\";a:7:{s:4:\"name\";s:16:\"checkPermissions\";s:4:\"desc\";s:30:\"pdotools_prop_checkPermissions\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"hereId\";a:7:{s:4:\"name\";s:6:\"hereId\";s:4:\"desc\";s:20:\"pdotools_prop_hereId\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:19:\"pdotools_prop_where\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"select\";a:7:{s:4:\"name\";s:6:\"select\";s:4:\"desc\";s:20:\"pdotools_prop_select\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"scheme\";a:7:{s:4:\"name\";s:6:\"scheme\";s:4:\"desc\";s:20:\"pdotools_prop_scheme\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:6:{i:0;a:2:{s:5:\"value\";s:0:\"\";s:4:\"text\";s:14:\"System default\";}i:1;a:2:{s:5:\"value\";i:-1;s:4:\"text\";s:25:\"-1 (relative to site_url)\";}i:2;a:2:{s:5:\"value\";s:4:\"full\";s:4:\"text\";s:40:\"full (absolute, prepended with site_url)\";}i:3;a:2:{s:5:\"value\";s:3:\"abs\";s:4:\"text\";s:39:\"abs (absolute, prepended with base_url)\";}i:4;a:2:{s:5:\"value\";s:4:\"http\";s:4:\"text\";s:38:\"http (absolute, forced to http scheme)\";}i:5;a:2:{s:5:\"value\";s:5:\"https\";s:4:\"text\";s:40:\"https (absolute, forced to https scheme)\";}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"countChildren\";a:7:{s:4:\"name\";s:13:\"countChildren\";s:4:\"desc\";s:27:\"pdotools_prop_countChildren\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdomenu.php'),
(25, 1, 0, 'pdoTitle', '', 0, 6, 0, '/** @var array $scriptProperties */\nif (empty($outputSeparator)) {\n    $outputSeparator = \' / \';\n}\nif (empty($titleField)) {\n    $titleField = \'longtitle\';\n}\nif (!isset($pageVarKey)) {\n    $pageVarKey = \'page\';\n}\nif (!isset($queryVarKey)) {\n    $queryVarKey = \'query\';\n}\nif (empty($tplPages)) {\n    $tplPages = \'@INLINE [[%pdopage_page]] [[+page]] [[%pdopage_from]] [[+pageCount]]\';\n}\nif (empty($tplSearch)) {\n    $tplSearch = \'@INLINE «[[+mse2_query]]»\';\n}\nif (empty($minQuery)) {\n    $minQuery = 3;\n}\nif (empty($id)) {\n    $id = $modx->resource->id;\n}\nif (empty($cacheKey)) {\n    $cacheKey = \'title_crumbs\';\n}\nif (!isset($cacheTime)) {\n    $cacheTime = 0;\n}\n/** @var pdoTools $pdoTools */\n$fqn = $modx->getOption(\'pdoTools.class\', null, \'pdotools.pdotools\', true);\n$path = $modx->getOption(\'pdotools_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoTools = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$modx->lexicon->load(\'pdotools:pdopage\');\n\n/** @var modResource $resource */\n$resource = ($id == $modx->resource->id)\n    ? $modx->resource\n    : $modx->getObject(\'modResource\', $id);\nif (!$resource) {\n    return \'\';\n}\n\n$title = array();\n$pagetitle = trim($resource->get($titleField));\nif (empty($pagetitle)) {\n    $pagetitle = $resource->get(\'pagetitle\');\n}\n\n// Add search request if exists\nif (!empty($_GET[$queryVarKey]) && strlen($_GET[$queryVarKey]) >= $minQuery && !empty($tplSearch)) {\n    $pagetitle .= \' \' . $pdoTools->getChunk($tplSearch, array(\n            $queryVarKey => $modx->stripTags($_GET[$queryVarKey]),\n        ));\n}\n$title[] = $pagetitle;\n\n// Add pagination if exists\nif (!empty($_GET[$pageVarKey]) && !empty($tplPages)) {\n    $title[] = $pdoTools->getChunk($tplPages, array(\n        \'page\' => intval($_GET[$pageVarKey]),\n    ));\n}\n\n// Add parents\n$cacheKey = $resource->getCacheKey() . \'/\' . $cacheKey;\n$cacheOptions = array(\'cache_key\' => $modx->getOption(\'cache_resource_key\', null, \'resource\'));\n$crumbs = \'\';\nif (empty($cache) || !$crumbs = $modx->cacheManager->get($cacheKey, $cacheOptions)) {\n    $crumbs = $pdoTools->runSnippet(\'pdoCrumbs\', array_merge(\n        array(\n            \'to\' => $resource->id,\n            \'outputSeparator\' => $outputSeparator,\n            \'showHome\' => 0,\n            \'showAtHome\' => 0,\n            \'showCurrent\' => 0,\n            \'direction\' => \'rtl\',\n            \'tpl\' => \'@INLINE [[+menutitle]]\',\n            \'tplCurrent\' => \'@INLINE [[+menutitle]]\',\n            \'tplWrapper\' => \'@INLINE [[+output]]\',\n            \'tplMax\' => \'\',\n            \'tplHome\' => \'\',\n        ), $scriptProperties\n    ));\n}\nif (!empty($crumbs)) {\n    if (!empty($cache)) {\n        $modx->cacheManager->set($cacheKey, $crumbs, $cacheTime, $cacheOptions);\n    }\n    $title[] = $crumbs;\n}\n\nif (!empty($registerJs)) {\n    $config = array(\n        \'separator\' => $outputSeparator,\n        \'tpl\' => str_replace(array(\'[[+\', \']]\'), array(\'{\', \'}\'), $pdoTools->getChunk($tplPages)),\n    );\n    /** @noinspection Annotator */\n    $modx->regClientStartupScript(\'<script type=\"text/javascript\">pdoTitle = \' . json_encode($config) . \';</script>\',\n        true);\n}\n\nreturn implode($outputSeparator, $title);', 0, 'a:13:{s:2:\"id\";a:7:{s:4:\"name\";s:2:\"id\";s:4:\"desc\";s:16:\"pdotools_prop_id\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"exclude\";a:7:{s:4:\"name\";s:7:\"exclude\";s:4:\"desc\";s:21:\"pdotools_prop_exclude\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:25:\"pdotools_prop_title_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:3;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"titleField\";a:7:{s:4:\"name\";s:10:\"titleField\";s:4:\"desc\";s:24:\"pdotools_prop_titleField\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"longtitle\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"cache\";a:7:{s:4:\"name\";s:5:\"cache\";s:4:\"desc\";s:25:\"pdotools_prop_title_cache\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"cacheTime\";a:7:{s:4:\"name\";s:9:\"cacheTime\";s:4:\"desc\";s:23:\"pdotools_prop_cacheTime\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tplPages\";a:7:{s:4:\"name\";s:8:\"tplPages\";s:4:\"desc\";s:22:\"pdotools_prop_tplPages\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:68:\"@INLINE [[%pdopage_page]] [[+page]] [[%pdopage_from]] [[+pageCount]]\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"pageVarKey\";a:7:{s:4:\"name\";s:10:\"pageVarKey\";s:4:\"desc\";s:24:\"pdotools_prop_pageVarKey\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:4:\"page\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"tplSearch\";a:7:{s:4:\"name\";s:9:\"tplSearch\";s:4:\"desc\";s:23:\"pdotools_prop_tplSearch\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:27:\"@INLINE «[[+mse2_query]]»\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"queryVarKey\";a:7:{s:4:\"name\";s:11:\"queryVarKey\";s:4:\"desc\";s:25:\"pdotools_prop_queryVarKey\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:5:\"query\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"minQuery\";a:7:{s:4:\"name\";s:8:\"minQuery\";s:4:\"desc\";s:22:\"pdotools_prop_minQuery\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:3;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"outputSeparator\";a:7:{s:4:\"name\";s:15:\"outputSeparator\";s:4:\"desc\";s:35:\"pdotools_prop_title_outputSeparator\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\" / \";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"registerJs\";a:7:{s:4:\"name\";s:10:\"registerJs\";s:4:\"desc\";s:24:\"pdotools_prop_registerJs\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdotitle.php'),
(26, 1, 0, 'pdoArchive', '', 0, 6, 0, '$modx->lexicon->load(\'pdotools:pdoarchive\');\n\n/** @var array $scriptProperties */\n$tplWrapper = $modx->getOption(\'tplWrapper\', $scriptProperties);\n$tplYear = $modx->getOption(\'tplYear\', $scriptProperties);\n$tplMonth = $modx->getOption(\'tplMonth\', $scriptProperties);\n$tplDay = $modx->getOption(\'tplDay\', $scriptProperties);\n$tpl = $modx->getOption(\'tpl\', $scriptProperties);\n$dateField = $modx->getOption(\'dateField\', $scriptProperties, \'createdon\', true);\n$dateFormat = $modx->getOption(\'dateFormat\', $scriptProperties, \'H:i\', true);\n$outputSeparator = $modx->getOption(\'outputSeparator\', $scriptProperties, \"\\n\");\n\n// Adding extra parameters into special place so we can put them in a results\n/** @var modSnippet $snippet */\n$additionalPlaceholders = $properties = array();\nif (isset($this) && $this instanceof modSnippet) {\n    $properties = $this->get(\'properties\');\n} elseif ($snippet = $modx->getObject(\'modSnippet\', array(\'name\' => \'pdoResources\'))) {\n    $properties = $snippet->get(\'properties\');\n}\nif (!empty($properties)) {\n    foreach ($scriptProperties as $k => $v) {\n        if (!isset($properties[$k])) {\n            $additionalPlaceholders[$k] = $v;\n        }\n    }\n}\n$scriptProperties[\'additionalPlaceholders\'] = $additionalPlaceholders;\nif (isset($parents) && $parents === \'\') {\n    $scriptProperties[\'parents\'] = $modx->resource->id;\n}\n$scriptProperties[\'return\'] = \'data\';\n/** @var pdoFetch $pdoFetch */\n$fqn = $modx->getOption(\'pdoFetch.class\', null, \'pdotools.pdofetch\', true);\n$path = $modx->getOption(\'pdofetch_class_path\', null, MODX_CORE_PATH . \'components/pdotools/model/\', true);\nif ($pdoClass = $modx->loadClass($fqn, $path, false, true)) {\n    $pdoFetch = new $pdoClass($modx, $scriptProperties);\n} else {\n    return false;\n}\n$pdoFetch->addTime(\'pdoTools loaded\');\n$rows = $pdoFetch->run();\n\n// Process rows\n$tree = array();\nforeach ($rows as $row) {\n    $tmp = $row[$dateField];\n    if (!is_numeric($tmp)) {\n        $tmp = strtotime($tmp);\n    }\n    $year = date(\'Y\', $tmp);\n    $month = date(\'m\', $tmp);\n    $day = date(\'d\', $tmp);\n    $tree[$year][$month][$day][] = $row;\n}\n\n$output = \'\';\nforeach ($tree as $year => $months) {\n    $rows_year = \'\';\n    $count_year = 0;\n\n    foreach ($months as $month => $days) {\n        $rows_month = \'\';\n        $count_month = 0;\n\n        foreach ($days as $day => $resources) {\n            $rows_day = array();\n            $count_day = 0;\n            $idx = 1;\n\n            foreach ($resources as $resource) {\n                $resource[\'day\'] = $day;\n                $resource[\'month\'] = $month;\n                $resource[\'year\'] = $year;\n                $resource[\'date\'] = strftime($dateFormat, $resource[$dateField]);\n                $resource[\'idx\'] = $idx++;\n                $resource[\'menutitle\'] = !empty($resource[\'menutitle\'])\n                    ? $resource[\'menutitle\']\n                    : $resource[\'pagetitle\'];\n                // Add placeholder [[+link]] if specified\n                if (!empty($scriptProperties[\'useWeblinkUrl\'])) {\n                    if (!isset($resource[\'context_key\'])) {\n                        $resource[\'context_key\'] = \'\';\n                    }\n                    if (isset($resource[\'class_key\']) && ($resource[\'class_key\'] == \'modWebLink\')) {\n                        $resource[\'link\'] = isset($resource[\'content\']) && is_numeric(trim($resource[\'content\'], \'[]~ \'))\n                            ? $pdoFetch->makeUrl(intval(trim($resource[\'content\'], \'[]~ \')), $resource)\n                            : (isset($resource[\'content\']) ? $resource[\'content\'] : \'\');\n                    } else {\n                        $resource[\'link\'] = $pdoFetch->makeUrl($resource[\'id\'], $resource);\n                    }\n                } else {\n                    $resource[\'link\'] = \'\';\n                }\n                $tpl = $pdoFetch->defineChunk($resource);\n                $rows_day[] = $pdoFetch->getChunk($tpl, $resource);\n                $count_year++;\n                $count_month++;\n                $count_day++;\n            }\n\n            $rows_month .= !empty($tplDay)\n                ? $pdoFetch->getChunk($tplDay, array(\n                    \'day\' => $day,\n                    \'month\' => $month,\n                    \'year\' => $year,\n                    \'count\' => $count_day,\n                    \'wrapper\' => implode($outputSeparator, $rows_day),\n                ), $pdoFetch->config[\'fastMode\'])\n                : implode($outputSeparator, $rows_day);\n        }\n\n        $rows_year .= !empty($tplMonth)\n            ? $pdoFetch->getChunk($tplMonth, array(\n                \'month\' => $month,\n                \'month_name\' => $modx->lexicon(\'pdoarchive_month_\' . $month),\n                \'year\' => $year,\n                \'count\' => $count_month,\n                \'wrapper\' => $rows_month,\n            ), $pdoFetch->config[\'fastMode\'])\n            : $rows_month;\n    }\n\n    $output .= !empty($tplYear)\n        ? $pdoFetch->getChunk($tplYear, array(\n            \'year\' => $year,\n            \'count\' => $count_year,\n            \'wrapper\' => $rows_year,\n        ), $pdoFetch->config[\'fastMode\'])\n        : $rows_year;\n}\n$pdoFetch->addTime(\'Rows processed\');\n\n// Return output\nif (!empty($tplWrapper) && (!empty($wrapIfEmpty) || !empty($output))) {\n    $output = $pdoFetch->getChunk(\n        $tplWrapper,\n        array_merge($additionalPlaceholders, array(\'output\' => $output)),\n        $pdoFetch->config[\'fastMode\']\n    );\n    $pdoFetch->addTime(\'Rows wrapped\');\n}\n\nif ($modx->user->hasSessionContext(\'mgr\') && !empty($showLog)) {\n    $output .= \'<pre class=\"pdoArchiveLog\">\' . print_r($pdoFetch->getTime(), 1) . \'</pre>\';\n}\n\nif (!empty($toPlaceholder)) {\n    $modx->setPlaceholder($toPlaceholder, $output);\n} else {\n    return $output;\n}', 0, 'a:36:{s:3:\"tpl\";a:7:{s:4:\"name\";s:3:\"tpl\";s:4:\"desc\";s:17:\"pdotools_prop_tpl\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:65:\"@INLINE <li>[[+date]] <a href=\"[[+link]]\">[[+menutitle]]</a></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"tplYear\";a:7:{s:4:\"name\";s:7:\"tplYear\";s:4:\"desc\";s:21:\"pdotools_prop_tplYear\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:71:\"@INLINE <h3>[[+year]] <sup>([[+count]])</sup></h3><ul>[[+wrapper]]</ul>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tplMonth\";a:7:{s:4:\"name\";s:8:\"tplMonth\";s:4:\"desc\";s:22:\"pdotools_prop_tplMonth\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:86:\"@INLINE <li><h4>[[+month_name]] <sup>([[+count]])</sup></h4><ul>[[+wrapper]]</ul></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"tplDay\";a:7:{s:4:\"name\";s:6:\"tplDay\";s:4:\"desc\";s:20:\"pdotools_prop_tplDay\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:79:\"@INLINE <li><h5>[[+day]] <sup>([[+count]])</sup></h5><ul>[[+wrapper]]</ul></li>\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:24:\"pdotools_prop_tplWrapper\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"wrapIfEmpty\";a:7:{s:4:\"name\";s:11:\"wrapIfEmpty\";s:4:\"desc\";s:25:\"pdotools_prop_wrapIfEmpty\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"dateField\";a:7:{s:4:\"name\";s:9:\"dateField\";s:4:\"desc\";s:23:\"pdotools_prop_dateField\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"createdon\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"dateFormat\";a:7:{s:4:\"name\";s:10:\"dateFormat\";s:4:\"desc\";s:24:\"pdotools_prop_dateFormat\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:5:\"%H:%M\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"showLog\";a:7:{s:4:\"name\";s:7:\"showLog\";s:4:\"desc\";s:21:\"pdotools_prop_showLog\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:20:\"pdotools_prop_sortby\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:9:\"createdon\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"sortbyTV\";a:7:{s:4:\"name\";s:8:\"sortbyTV\";s:4:\"desc\";s:22:\"pdotools_prop_sortbyTV\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:12:\"sortbyTVType\";a:7:{s:4:\"name\";s:12:\"sortbyTVType\";s:4:\"desc\";s:26:\"pdotools_prop_sortbyTVType\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:21:\"pdotools_prop_sortdir\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:4:\"DESC\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"sortdirTV\";a:7:{s:4:\"name\";s:9:\"sortdirTV\";s:4:\"desc\";s:23:\"pdotools_prop_sortdirTV\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:3:\"ASC\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:19:\"pdotools_prop_limit\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"offset\";a:7:{s:4:\"name\";s:6:\"offset\";s:4:\"desc\";s:20:\"pdotools_prop_offset\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"depth\";a:7:{s:4:\"name\";s:5:\"depth\";s:4:\"desc\";s:19:\"pdotools_prop_depth\";s:4:\"type\";s:11:\"numberfield\";s:7:\"options\";a:0:{}s:5:\"value\";i:10;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"outputSeparator\";a:7:{s:4:\"name\";s:15:\"outputSeparator\";s:4:\"desc\";s:29:\"pdotools_prop_outputSeparator\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"\n\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:27:\"pdotools_prop_toPlaceholder\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"parents\";a:7:{s:4:\"name\";s:7:\"parents\";s:4:\"desc\";s:21:\"pdotools_prop_parents\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"includeContent\";a:7:{s:4:\"name\";s:14:\"includeContent\";s:4:\"desc\";s:28:\"pdotools_prop_includeContent\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"includeTVs\";a:7:{s:4:\"name\";s:10:\"includeTVs\";s:4:\"desc\";s:24:\"pdotools_prop_includeTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"prepareTVs\";a:7:{s:4:\"name\";s:10:\"prepareTVs\";s:4:\"desc\";s:24:\"pdotools_prop_prepareTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:1:\"1\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"processTVs\";a:7:{s:4:\"name\";s:10:\"processTVs\";s:4:\"desc\";s:24:\"pdotools_prop_processTVs\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"tvPrefix\";a:7:{s:4:\"name\";s:8:\"tvPrefix\";s:4:\"desc\";s:22:\"pdotools_prop_tvPrefix\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:3:\"tv.\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:19:\"pdotools_prop_where\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:15:\"showUnpublished\";a:7:{s:4:\"name\";s:15:\"showUnpublished\";s:4:\"desc\";s:29:\"pdotools_prop_showUnpublished\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:11:\"showDeleted\";a:7:{s:4:\"name\";s:11:\"showDeleted\";s:4:\"desc\";s:25:\"pdotools_prop_showDeleted\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:10:\"showHidden\";a:7:{s:4:\"name\";s:10:\"showHidden\";s:4:\"desc\";s:24:\"pdotools_prop_showHidden\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:14:\"hideContainers\";a:7:{s:4:\"name\";s:14:\"hideContainers\";s:4:\"desc\";s:28:\"pdotools_prop_hideContainers\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:0;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:7:\"context\";a:7:{s:4:\"name\";s:7:\"context\";s:4:\"desc\";s:21:\"pdotools_prop_context\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:8:\"totalVar\";a:7:{s:4:\"name\";s:8:\"totalVar\";s:4:\"desc\";s:22:\"pdotools_prop_totalVar\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:5:\"total\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:9:\"resources\";a:7:{s:4:\"name\";s:9:\"resources\";s:4:\"desc\";s:23:\"pdotools_prop_resources\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"select\";a:7:{s:4:\"name\";s:6:\"select\";s:4:\"desc\";s:20:\"pdotools_prop_select\";s:4:\"type\";s:8:\"textarea\";s:7:\"options\";a:0:{}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:6:\"scheme\";a:7:{s:4:\"name\";s:6:\"scheme\";s:4:\"desc\";s:20:\"pdotools_prop_scheme\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:6:{i:0;a:2:{s:5:\"value\";s:0:\"\";s:4:\"text\";s:14:\"System default\";}i:1;a:2:{s:5:\"value\";i:-1;s:4:\"text\";s:25:\"-1 (relative to site_url)\";}i:2;a:2:{s:5:\"value\";s:4:\"full\";s:4:\"text\";s:40:\"full (absolute, prepended with site_url)\";}i:3;a:2:{s:5:\"value\";s:3:\"abs\";s:4:\"text\";s:39:\"abs (absolute, prepended with base_url)\";}i:4;a:2:{s:5:\"value\";s:4:\"http\";s:4:\"text\";s:38:\"http (absolute, forced to http scheme)\";}i:5;a:2:{s:5:\"value\";s:5:\"https\";s:4:\"text\";s:40:\"https (absolute, forced to https scheme)\";}}s:5:\"value\";s:0:\"\";s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}s:13:\"useWeblinkUrl\";a:7:{s:4:\"name\";s:13:\"useWeblinkUrl\";s:4:\"desc\";s:27:\"pdotools_prop_useWeblinkUrl\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";a:0:{}s:5:\"value\";b:1;s:7:\"lexicon\";s:19:\"pdotools:properties\";s:4:\"area\";s:0:\"\";}}', '', 0, 'core/components/pdotools/elements/snippets/snippet.pdoarchive.php');
INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(27, 0, 0, 'getResources', '<strong>1.7.0-pl</strong> A general purpose Resource listing and summarization snippet for MODX Revolution', 0, 0, 0, '/**\n * getResources\n *\n * A general purpose Resource listing and summarization snippet for MODX 2.x.\n *\n * @author Jason Coward\n * @copyright Copyright 2010-2015, Jason Coward\n *\n * TEMPLATES\n *\n * tpl - Name of a chunk serving as a resource template\n * [NOTE: if not provided, properties are dumped to output for each resource]\n *\n * tplOdd - (Opt) Name of a chunk serving as resource template for resources with an odd idx value\n * (see idx property)\n * tplFirst - (Opt) Name of a chunk serving as resource template for the first resource (see first\n * property)\n * tplLast - (Opt) Name of a chunk serving as resource template for the last resource (see last\n * property)\n * tpl_{n} - (Opt) Name of a chunk serving as resource template for the nth resource\n *\n * tplCondition - (Opt) Defines a field of the resource to evaluate against keys defined in the\n * conditionalTpls property. Must be a resource field; does not work with Template Variables.\n * conditionalTpls - (Opt) A JSON object defining a map of field values and the associated tpl to\n * use when the field defined by tplCondition matches the value. [NOTE: tplOdd, tplFirst, tplLast,\n * and tpl_{n} will take precedence over any defined conditionalTpls]\n *\n * tplWrapper - (Opt) Name of a chunk serving as a wrapper template for the output\n * [NOTE: Does not work with toSeparatePlaceholders]\n *\n * SELECTION\n *\n * parents - Comma-delimited list of ids serving as parents\n *\n * context - (Opt) Comma-delimited list of context keys to limit results by; if empty, contexts for all specified\n * parents will be used (all contexts if 0 is specified) [default=]\n *\n * depth - (Opt) Integer value indicating depth to search for resources from each parent [default=10]\n *\n * tvFilters - (Opt) Delimited-list of TemplateVar values to filter resources by. Supports two\n * delimiters and two value search formats. The first delimiter || represents a logical OR and the\n * primary grouping mechanism.  Within each group you can provide a comma-delimited list of values.\n * These values can be either tied to a specific TemplateVar by name, e.g. myTV==value, or just the\n * value, indicating you are searching for the value in any TemplateVar tied to the Resource. An\n * example would be &tvFilters=`filter2==one,filter1==bar%||filter1==foo`\n * [NOTE: filtering by values uses a LIKE query and % is considered a wildcard.]\n * [NOTE: this only looks at the raw value set for specific Resource, i. e. there must be a value\n * specifically set for the Resource and it is not evaluated.]\n *\n * tvFiltersAndDelimiter - (Opt) Custom delimiter for logical AND, default \',\', in case you want to\n * match a literal comma in the tvFilters. E.g. &tvFiltersAndDelimiter=`&&`\n * &tvFilters=`filter1==foo,bar&&filter2==baz` [default=,]\n *\n * tvFiltersOrDelimiter - (Opt) Custom delimiter for logical OR, default \'||\', in case you want to\n * match a literal \'||\' in the tvFilters. E.g. &tvFiltersOrDelimiter=`|OR|`\n * &tvFilters=`filter1==foo||bar|OR|filter2==baz` [default=||]\n *\n * where - (Opt) A JSON expression of criteria to build any additional where clauses from. An example would be\n * &where=`{{\"alias:LIKE\":\"foo%\", \"OR:alias:LIKE\":\"%bar\"},{\"OR:pagetitle:=\":\"foobar\", \"AND:description:=\":\"raboof\"}}`\n *\n * sortby - (Opt) Field to sort by or a JSON array, e.g. {\"publishedon\":\"ASC\",\"createdon\":\"DESC\"} [default=publishedon]\n * sortbyTV - (opt) A Template Variable name to sort by (if supplied, this precedes the sortby value) [default=]\n * sortbyTVType - (Opt) A data type to CAST a TV Value to in order to sort on it properly [default=string]\n * sortbyAlias - (Opt) Query alias for sortby field [default=]\n * sortbyEscaped - (Opt) Escapes the field name(s) specified in sortby [default=0]\n * sortdir - (Opt) Order which to sort by [default=DESC]\n * sortdirTV - (Opt) Order which to sort by a TV [default=DESC]\n * limit - (Opt) Limits the number of resources returned [default=5]\n * offset - (Opt) An offset of resources returned by the criteria to skip [default=0]\n * dbCacheFlag - (Opt) Controls caching of db queries; 0|false = do not cache result set; 1 = cache result set\n * according to cache settings, any other integer value = number of seconds to cache result set [default=0]\n *\n * OPTIONS\n *\n * includeContent - (Opt) Indicates if the content of each resource should be returned in the\n * results [default=0]\n * includeTVs - (Opt) Indicates if TemplateVar values should be included in the properties available\n * to each resource template [default=0]\n * includeTVList - (Opt) Limits the TemplateVars that are included if includeTVs is true to those specified\n * by name in a comma-delimited list [default=]\n * prepareTVs - (Opt) Prepares media-source dependent TemplateVar values [default=1]\n * prepareTVList - (Opt) Limits the TVs that are prepared to those specified by name in a comma-delimited\n * list [default=]\n * processTVs - (Opt) Indicates if TemplateVar values should be rendered as they would on the\n * resource being summarized [default=0]\n * processTVList - (opt) Limits the TemplateVars that are processed if included to those specified\n * by name in a comma-delimited list [default=]\n * tvPrefix - (Opt) The prefix for TemplateVar properties [default=tv.]\n * idx - (Opt) You can define the starting idx of the resources, which is an property that is\n * incremented as each resource is rendered [default=1]\n * first - (Opt) Define the idx which represents the first resource (see tplFirst) [default=1]\n * last - (Opt) Define the idx which represents the last resource (see tplLast) [default=# of\n * resources being summarized + first - 1]\n * outputSeparator - (Opt) An optional string to separate each tpl instance [default=\"\\n\"]\n * wrapIfEmpty - (Opt) Indicates if the tplWrapper should be applied if the output is empty [default=0]\n *\n */\n$output = array();\n$outputSeparator = isset($outputSeparator) ? $outputSeparator : \"\\n\";\n\n/* set default properties */\n$tpl = !empty($tpl) ? $tpl : \'\';\n$includeContent = !empty($includeContent) ? true : false;\n$includeTVs = !empty($includeTVs) ? true : false;\n$includeTVList = !empty($includeTVList) ? explode(\',\', $includeTVList) : array();\n$processTVs = !empty($processTVs) ? true : false;\n$processTVList = !empty($processTVList) ? explode(\',\', $processTVList) : array();\n$prepareTVs = !empty($prepareTVs) ? true : false;\n$prepareTVList = !empty($prepareTVList) ? explode(\',\', $prepareTVList) : array();\n$tvPrefix = isset($tvPrefix) ? $tvPrefix : \'tv.\';\n$parents = (!empty($parents) || $parents === \'0\') ? explode(\',\', $parents) : array($modx->resource->get(\'id\'));\narray_walk($parents, \'trim\');\n$parents = array_unique($parents);\n$depth = isset($depth) ? (integer) $depth : 10;\n\n$tvFiltersOrDelimiter = isset($tvFiltersOrDelimiter) ? $tvFiltersOrDelimiter : \'||\';\n$tvFiltersAndDelimiter = isset($tvFiltersAndDelimiter) ? $tvFiltersAndDelimiter : \',\';\n$tvFilters = !empty($tvFilters) ? explode($tvFiltersOrDelimiter, $tvFilters) : array();\n\n$where = !empty($where) ? $modx->fromJSON($where) : array();\n$showUnpublished = !empty($showUnpublished) ? true : false;\n$showDeleted = !empty($showDeleted) ? true : false;\n\n$sortby = isset($sortby) ? $sortby : \'publishedon\';\n$sortbyTV = isset($sortbyTV) ? $sortbyTV : \'\';\n$sortbyAlias = isset($sortbyAlias) ? $sortbyAlias : \'modResource\';\n$sortbyEscaped = !empty($sortbyEscaped) ? true : false;\n$sortdir = isset($sortdir) ? $sortdir : \'DESC\';\n$sortdirTV = isset($sortdirTV) ? $sortdirTV : \'DESC\';\n$limit = isset($limit) ? (integer) $limit : 5;\n$offset = isset($offset) ? (integer) $offset : 0;\n$totalVar = !empty($totalVar) ? $totalVar : \'total\';\n\n$dbCacheFlag = !isset($dbCacheFlag) ? false : $dbCacheFlag;\nif (is_string($dbCacheFlag) || is_numeric($dbCacheFlag)) {\n    if ($dbCacheFlag == \'0\') {\n        $dbCacheFlag = false;\n    } elseif ($dbCacheFlag == \'1\') {\n        $dbCacheFlag = true;\n    } else {\n        $dbCacheFlag = (integer) $dbCacheFlag;\n    }\n}\n\n/* multiple context support */\n$contextArray = array();\n$contextSpecified = false;\nif (!empty($context)) {\n    $contextArray = explode(\',\',$context);\n    array_walk($contextArray, \'trim\');\n    $contexts = array();\n    foreach ($contextArray as $ctx) {\n        $contexts[] = $modx->quote($ctx);\n    }\n    $context = implode(\',\',$contexts);\n    $contextSpecified = true;\n    unset($contexts,$ctx);\n} else {\n    $context = $modx->quote($modx->context->get(\'key\'));\n}\n\n$pcMap = array();\n$pcQuery = $modx->newQuery(\'modResource\', array(\'id:IN\' => $parents), $dbCacheFlag);\n$pcQuery->select(array(\'id\', \'context_key\'));\nif ($pcQuery->prepare() && $pcQuery->stmt->execute()) {\n    foreach ($pcQuery->stmt->fetchAll(PDO::FETCH_ASSOC) as $pcRow) {\n        $pcMap[(integer) $pcRow[\'id\']] = $pcRow[\'context_key\'];\n    }\n}\n\n$children = array();\n$parentArray = array();\nforeach ($parents as $parent) {\n    $parent = (integer) $parent;\n    if ($parent === 0) {\n        $pchildren = array();\n        if ($contextSpecified) {\n            foreach ($contextArray as $pCtx) {\n                if (!in_array($pCtx, $contextArray)) {\n                    continue;\n                }\n                $options = $pCtx !== $modx->context->get(\'key\') ? array(\'context\' => $pCtx) : array();\n                $pcchildren = $modx->getChildIds($parent, $depth, $options);\n                if (!empty($pcchildren)) $pchildren = array_merge($pchildren, $pcchildren);\n            }\n        } else {\n            $cQuery = $modx->newQuery(\'modContext\', array(\'key:!=\' => \'mgr\'));\n            $cQuery->select(array(\'key\'));\n            if ($cQuery->prepare() && $cQuery->stmt->execute()) {\n                foreach ($cQuery->stmt->fetchAll(PDO::FETCH_COLUMN) as $pCtx) {\n                    $options = $pCtx !== $modx->context->get(\'key\') ? array(\'context\' => $pCtx) : array();\n                    $pcchildren = $modx->getChildIds($parent, $depth, $options);\n                    if (!empty($pcchildren)) $pchildren = array_merge($pchildren, $pcchildren);\n                }\n            }\n        }\n        $parentArray[] = $parent;\n    } else {\n        $pContext = array_key_exists($parent, $pcMap) ? $pcMap[$parent] : false;\n        if ($debug) $modx->log(modX::LOG_LEVEL_ERROR, \"context for {$parent} is {$pContext}\");\n        if ($pContext && $contextSpecified && !in_array($pContext, $contextArray, true)) {\n            $parent = next($parents);\n            continue;\n        }\n        $parentArray[] = $parent;\n        $options = !empty($pContext) && $pContext !== $modx->context->get(\'key\') ? array(\'context\' => $pContext) : array();\n        $pchildren = $modx->getChildIds($parent, $depth, $options);\n    }\n    if (!empty($pchildren)) $children = array_merge($children, $pchildren);\n    $parent = next($parents);\n}\n$parents = array_merge($parentArray, $children);\n\n/* build query */\n$criteria = array(\"modResource.parent IN (\" . implode(\',\', $parents) . \")\");\nif ($contextSpecified) {\n    $contextResourceTbl = $modx->getTableName(\'modContextResource\');\n    $criteria[] = \"(modResource.context_key IN ({$context}) OR EXISTS(SELECT 1 FROM {$contextResourceTbl} ctx WHERE ctx.resource = modResource.id AND ctx.context_key IN ({$context})))\";\n}\nif (empty($showDeleted)) {\n    $criteria[\'deleted\'] = \'0\';\n}\nif (empty($showUnpublished)) {\n    $criteria[\'published\'] = \'1\';\n}\nif (empty($showHidden)) {\n    $criteria[\'hidemenu\'] = \'0\';\n}\nif (!empty($hideContainers)) {\n    $criteria[\'isfolder\'] = \'0\';\n}\n$criteria = $modx->newQuery(\'modResource\', $criteria);\nif (!empty($tvFilters)) {\n    $tmplVarTbl = $modx->getTableName(\'modTemplateVar\');\n    $tmplVarResourceTbl = $modx->getTableName(\'modTemplateVarResource\');\n    $conditions = array();\n    $operators = array(\n        \'<=>\' => \'<=>\',\n        \'===\' => \'=\',\n        \'!==\' => \'!=\',\n        \'<>\' => \'<>\',\n        \'==\' => \'LIKE\',\n        \'!=\' => \'NOT LIKE\',\n        \'<<\' => \'<\',\n        \'<=\' => \'<=\',\n        \'=<\' => \'=<\',\n        \'>>\' => \'>\',\n        \'>=\' => \'>=\',\n        \'=>\' => \'=>\'\n    );\n    foreach ($tvFilters as $fGroup => $tvFilter) {\n        $filterGroup = array();\n        $filters = explode($tvFiltersAndDelimiter, $tvFilter);\n        $multiple = count($filters) > 0;\n        foreach ($filters as $filter) {\n            $operator = \'==\';\n            $sqlOperator = \'LIKE\';\n            foreach ($operators as $op => $opSymbol) {\n                if (strpos($filter, $op, 1) !== false) {\n                    $operator = $op;\n                    $sqlOperator = $opSymbol;\n                    break;\n                }\n            }\n            $tvValueField = \'tvr.value\';\n            $tvDefaultField = \'tv.default_text\';\n            $f = explode($operator, $filter);\n            if (count($f) >= 2) {\n                if (count($f) > 2) {\n                    $k = array_shift($f);\n                    $b = join($operator, $f);\n                    $f = array($k, $b);\n                }\n                $tvName = $modx->quote($f[0]);\n                if (is_numeric($f[1]) && !in_array($sqlOperator, array(\'LIKE\', \'NOT LIKE\'))) {\n                    $tvValue = $f[1];\n                    if ($f[1] == (integer)$f[1]) {\n                        $tvValueField = \"CAST({$tvValueField} AS SIGNED INTEGER)\";\n                        $tvDefaultField = \"CAST({$tvDefaultField} AS SIGNED INTEGER)\";\n                    } else {\n                        $tvValueField = \"CAST({$tvValueField} AS DECIMAL)\";\n                        $tvDefaultField = \"CAST({$tvDefaultField} AS DECIMAL)\";\n                    }\n                } else {\n                    $tvValue = $modx->quote($f[1]);\n                }\n                if ($multiple) {\n                    $filterGroup[] =\n                        \"(EXISTS (SELECT 1 FROM {$tmplVarResourceTbl} tvr JOIN {$tmplVarTbl} tv ON {$tvValueField} {$sqlOperator} {$tvValue} AND tv.name = {$tvName} AND tv.id = tvr.tmplvarid WHERE tvr.contentid = modResource.id) \" .\n                        \"OR EXISTS (SELECT 1 FROM {$tmplVarTbl} tv WHERE tv.name = {$tvName} AND {$tvDefaultField} {$sqlOperator} {$tvValue} AND tv.id NOT IN (SELECT tmplvarid FROM {$tmplVarResourceTbl} WHERE contentid = modResource.id)) \" .\n                        \")\";\n                } else {\n                    $filterGroup =\n                        \"(EXISTS (SELECT 1 FROM {$tmplVarResourceTbl} tvr JOIN {$tmplVarTbl} tv ON {$tvValueField} {$sqlOperator} {$tvValue} AND tv.name = {$tvName} AND tv.id = tvr.tmplvarid WHERE tvr.contentid = modResource.id) \" .\n                        \"OR EXISTS (SELECT 1 FROM {$tmplVarTbl} tv WHERE tv.name = {$tvName} AND {$tvDefaultField} {$sqlOperator} {$tvValue} AND tv.id NOT IN (SELECT tmplvarid FROM {$tmplVarResourceTbl} WHERE contentid = modResource.id)) \" .\n                        \")\";\n                }\n            } elseif (count($f) == 1) {\n                $tvValue = $modx->quote($f[0]);\n                if ($multiple) {\n                    $filterGroup[] = \"EXISTS (SELECT 1 FROM {$tmplVarResourceTbl} tvr JOIN {$tmplVarTbl} tv ON {$tvValueField} {$sqlOperator} {$tvValue} AND tv.id = tvr.tmplvarid WHERE tvr.contentid = modResource.id)\";\n                } else {\n                    $filterGroup = \"EXISTS (SELECT 1 FROM {$tmplVarResourceTbl} tvr JOIN {$tmplVarTbl} tv ON {$tvValueField} {$sqlOperator} {$tvValue} AND tv.id = tvr.tmplvarid WHERE tvr.contentid = modResource.id)\";\n                }\n            }\n        }\n        $conditions[] = $filterGroup;\n    }\n    if (!empty($conditions)) {\n        $firstGroup = true;\n        foreach ($conditions as $cGroup => $c) {\n            if (is_array($c)) {\n                $first = true;\n                foreach ($c as $cond) {\n                    if ($first && !$firstGroup) {\n                        $criteria->condition($criteria->query[\'where\'][0][1], $cond, xPDOQuery::SQL_OR, null, $cGroup);\n                    } else {\n                        $criteria->condition($criteria->query[\'where\'][0][1], $cond, xPDOQuery::SQL_AND, null, $cGroup);\n                    }\n                    $first = false;\n                }\n            } else {\n                $criteria->condition($criteria->query[\'where\'][0][1], $c, $firstGroup ? xPDOQuery::SQL_AND : xPDOQuery::SQL_OR, null, $cGroup);\n            }\n            $firstGroup = false;\n        }\n    }\n}\n/* include/exclude resources, via &resources=`123,-456` prop */\nif (!empty($resources)) {\n    $resourceConditions = array();\n    $resources = explode(\',\',$resources);\n    $include = array();\n    $exclude = array();\n    foreach ($resources as $resource) {\n        $resource = (int)$resource;\n        if ($resource == 0) continue;\n        if ($resource < 0) {\n            $exclude[] = abs($resource);\n        } else {\n            $include[] = $resource;\n        }\n    }\n    if (!empty($include)) {\n        $criteria->where(array(\'OR:modResource.id:IN\' => $include), xPDOQuery::SQL_OR);\n    }\n    if (!empty($exclude)) {\n        $criteria->where(array(\'modResource.id:NOT IN\' => $exclude), xPDOQuery::SQL_AND, null, 1);\n    }\n}\nif (!empty($where)) {\n    $criteria->where($where);\n}\n\n$total = $modx->getCount(\'modResource\', $criteria);\n$modx->setPlaceholder($totalVar, $total);\n\n$fields = array_keys($modx->getFields(\'modResource\'));\nif (empty($includeContent)) {\n    $fields = array_diff($fields, array(\'content\'));\n}\n$columns = $includeContent ? $modx->getSelectColumns(\'modResource\', \'modResource\') : $modx->getSelectColumns(\'modResource\', \'modResource\', \'\', array(\'content\'), true);\n$criteria->select($columns);\nif (!empty($sortbyTV)) {\n    $criteria->leftJoin(\'modTemplateVar\', \'tvDefault\', array(\n        \"tvDefault.name\" => $sortbyTV\n    ));\n    $criteria->leftJoin(\'modTemplateVarResource\', \'tvSort\', array(\n        \"tvSort.contentid = modResource.id\",\n        \"tvSort.tmplvarid = tvDefault.id\"\n    ));\n    if (empty($sortbyTVType)) $sortbyTVType = \'string\';\n    if ($modx->getOption(\'dbtype\') === \'mysql\') {\n        switch ($sortbyTVType) {\n            case \'integer\':\n                $criteria->select(\"CAST(IFNULL(tvSort.value, tvDefault.default_text) AS SIGNED INTEGER) AS sortTV\");\n                break;\n            case \'decimal\':\n                $criteria->select(\"CAST(IFNULL(tvSort.value, tvDefault.default_text) AS DECIMAL) AS sortTV\");\n                break;\n            case \'datetime\':\n                $criteria->select(\"CAST(IFNULL(tvSort.value, tvDefault.default_text) AS DATETIME) AS sortTV\");\n                break;\n            case \'string\':\n            default:\n                $criteria->select(\"IFNULL(tvSort.value, tvDefault.default_text) AS sortTV\");\n                break;\n        }\n    } elseif ($modx->getOption(\'dbtype\') === \'sqlsrv\') {\n        switch ($sortbyTVType) {\n            case \'integer\':\n                $criteria->select(\"CAST(ISNULL(tvSort.value, tvDefault.default_text) AS BIGINT) AS sortTV\");\n                break;\n            case \'decimal\':\n                $criteria->select(\"CAST(ISNULL(tvSort.value, tvDefault.default_text) AS DECIMAL) AS sortTV\");\n                break;\n            case \'datetime\':\n                $criteria->select(\"CAST(ISNULL(tvSort.value, tvDefault.default_text) AS DATETIME) AS sortTV\");\n                break;\n            case \'string\':\n            default:\n                $criteria->select(\"ISNULL(tvSort.value, tvDefault.default_text) AS sortTV\");\n                break;\n        }\n    }\n    $criteria->sortby(\"sortTV\", $sortdirTV);\n}\nif (!empty($sortby)) {\n    if (strpos($sortby, \'{\') === 0) {\n        $sorts = $modx->fromJSON($sortby);\n    } else {\n        $sorts = array($sortby => $sortdir);\n    }\n    if (is_array($sorts)) {\n        foreach($sorts as $sort => $dir){\n            if ($sort == \'resources\' && !empty($resources)) {\n                $sort = \'FIELD(modResource.id, \' . implode($resources,\',\') . \')\';\n            }\n            if ($sortbyEscaped) $sort = $modx->escape($sort);\n            if (!empty($sortbyAlias)) $sort = $modx->escape($sortbyAlias) . \".{$sort}\";\n            $criteria->sortby($sort, $dir);\n        }\n    }\n}\nif (!empty($limit)) $criteria->limit($limit, $offset);\n\nif (!empty($debug)) {\n    $criteria->prepare();\n    $modx->log(modX::LOG_LEVEL_ERROR, $criteria->toSQL());\n}\n$collection = $modx->getCollection(\'modResource\', $criteria, $dbCacheFlag);\n\n$idx = !empty($idx) || $idx === \'0\' ? (integer) $idx : 1;\n$first = empty($first) && $first !== \'0\' ? 1 : (integer) $first;\n$last = empty($last) ? (count($collection) + $idx - 1) : (integer) $last;\n\n/* include parseTpl */\ninclude_once $modx->getOption(\'getresources.core_path\',null,$modx->getOption(\'core_path\').\'components/getresources/\').\'include.parsetpl.php\';\n\n$templateVars = array();\nif (!empty($includeTVs) && !empty($includeTVList)) {\n    $templateVars = $modx->getCollection(\'modTemplateVar\', array(\'name:IN\' => $includeTVList));\n}\n/** @var modResource $resource */\nforeach ($collection as $resourceId => $resource) {\n    $tvs = array();\n    if (!empty($includeTVs)) {\n        if (empty($includeTVList)) {\n            $templateVars = $resource->getMany(\'TemplateVars\');\n        }\n        /** @var modTemplateVar $templateVar */\n        foreach ($templateVars as $tvId => $templateVar) {\n            if (!empty($includeTVList) && !in_array($templateVar->get(\'name\'), $includeTVList)) continue;\n            if ($processTVs && (empty($processTVList) || in_array($templateVar->get(\'name\'), $processTVList))) {\n                $tvs[$tvPrefix . $templateVar->get(\'name\')] = $templateVar->renderOutput($resource->get(\'id\'));\n            } else {\n                $value = $templateVar->getValue($resource->get(\'id\'));\n                if ($prepareTVs && method_exists($templateVar, \'prepareOutput\') && (empty($prepareTVList) || in_array($templateVar->get(\'name\'), $prepareTVList))) {\n                    $value = $templateVar->prepareOutput($value);\n                }\n                $tvs[$tvPrefix . $templateVar->get(\'name\')] = $value;\n            }\n        }\n    }\n    $odd = ($idx & 1);\n    $properties = array_merge(\n        $scriptProperties\n        ,array(\n            \'idx\' => $idx\n            ,\'first\' => $first\n            ,\'last\' => $last\n            ,\'odd\' => $odd\n        )\n        ,$includeContent ? $resource->toArray() : $resource->get($fields)\n        ,$tvs\n    );\n    $resourceTpl = false;\n    if ($idx == $first && !empty($tplFirst)) {\n        $resourceTpl = parseTpl($tplFirst, $properties);\n    }\n    if ($idx == $last && empty($resourceTpl) && !empty($tplLast)) {\n        $resourceTpl = parseTpl($tplLast, $properties);\n    }\n    $tplidx = \'tpl_\' . $idx;\n    if (empty($resourceTpl) && !empty($$tplidx)) {\n        $resourceTpl = parseTpl($$tplidx, $properties);\n    }\n    if ($idx > 1 && empty($resourceTpl)) {\n        $divisors = getDivisors($idx);\n        if (!empty($divisors)) {\n            foreach ($divisors as $divisor) {\n                $tplnth = \'tpl_n\' . $divisor;\n                if (!empty($$tplnth)) {\n                    $resourceTpl = parseTpl($$tplnth, $properties);\n                    if (!empty($resourceTpl)) {\n                        break;\n                    }\n                }\n            }\n        }\n    }\n    if ($odd && empty($resourceTpl) && !empty($tplOdd)) {\n        $resourceTpl = parseTpl($tplOdd, $properties);\n    }\n    if (!empty($tplCondition) && !empty($conditionalTpls) && empty($resourceTpl)) {\n        $conTpls = $modx->fromJSON($conditionalTpls);\n        $subject = $properties[$tplCondition];\n        $tplOperator = !empty($tplOperator) ? $tplOperator : \'=\';\n        $tplOperator = strtolower($tplOperator);\n        $tplCon = \'\';\n        foreach ($conTpls as $operand => $conditionalTpl) {\n            switch ($tplOperator) {\n                case \'!=\':\n                case \'neq\':\n                case \'not\':\n                case \'isnot\':\n                case \'isnt\':\n                case \'unequal\':\n                case \'notequal\':\n                    $tplCon = (($subject != $operand) ? $conditionalTpl : $tplCon);\n                    break;\n                case \'<\':\n                case \'lt\':\n                case \'less\':\n                case \'lessthan\':\n                    $tplCon = (($subject < $operand) ? $conditionalTpl : $tplCon);\n                    break;\n                case \'>\':\n                case \'gt\':\n                case \'greater\':\n                case \'greaterthan\':\n                    $tplCon = (($subject > $operand) ? $conditionalTpl : $tplCon);\n                    break;\n                case \'<=\':\n                case \'lte\':\n                case \'lessthanequals\':\n                case \'lessthanorequalto\':\n                    $tplCon = (($subject <= $operand) ? $conditionalTpl : $tplCon);\n                    break;\n                case \'>=\':\n                case \'gte\':\n                case \'greaterthanequals\':\n                case \'greaterthanequalto\':\n                    $tplCon = (($subject >= $operand) ? $conditionalTpl : $tplCon);\n                    break;\n                case \'isempty\':\n                case \'empty\':\n                    $tplCon = empty($subject) ? $conditionalTpl : $tplCon;\n                    break;\n                case \'!empty\':\n                case \'notempty\':\n                case \'isnotempty\':\n                    $tplCon = !empty($subject) && $subject != \'\' ? $conditionalTpl : $tplCon;\n                    break;\n                case \'isnull\':\n                case \'null\':\n                    $tplCon = $subject == null || strtolower($subject) == \'null\' ? $conditionalTpl : $tplCon;\n                    break;\n                case \'inarray\':\n                case \'in_array\':\n                case \'ia\':\n                    $operand = explode(\',\', $operand);\n                    $tplCon = in_array($subject, $operand) ? $conditionalTpl : $tplCon;\n                    break;\n                case \'between\':\n                case \'range\':\n                case \'>=<\':\n                case \'><\':\n                    $operand = explode(\',\', $operand);\n                    $tplCon = ($subject >= min($operand) && $subject <= max($operand)) ? $conditionalTpl : $tplCon;\n                    break;\n                case \'==\':\n                case \'=\':\n                case \'eq\':\n                case \'is\':\n                case \'equal\':\n                case \'equals\':\n                case \'equalto\':\n                default:\n                    $tplCon = (($subject == $operand) ? $conditionalTpl : $tplCon);\n                    break;\n            }\n        }\n        if (!empty($tplCon)) {\n            $resourceTpl = parseTpl($tplCon, $properties);\n        }\n    }\n    if (!empty($tpl) && empty($resourceTpl)) {\n        $resourceTpl = parseTpl($tpl, $properties);\n    }\n    if ($resourceTpl === false && !empty($debug)) {\n        $chunk = $modx->newObject(\'modChunk\');\n        $chunk->setCacheable(false);\n        $output[]= $chunk->process(array(), \'<pre>\' . print_r($properties, true) .\'</pre>\');\n    } else {\n        $output[]= $resourceTpl;\n    }\n    $idx++;\n}\n\n/* output */\n$toSeparatePlaceholders = $modx->getOption(\'toSeparatePlaceholders\', $scriptProperties, false);\nif (!empty($toSeparatePlaceholders)) {\n    $modx->setPlaceholders($output, $toSeparatePlaceholders);\n    return \'\';\n}\n\n$output = implode($outputSeparator, $output);\n\n$tplWrapper = $modx->getOption(\'tplWrapper\', $scriptProperties, false);\n$wrapIfEmpty = $modx->getOption(\'wrapIfEmpty\', $scriptProperties, false);\nif (!empty($tplWrapper) && ($wrapIfEmpty || !empty($output))) {\n    $output = parseTpl($tplWrapper, array_merge($scriptProperties, array(\'output\' => $output)));\n}\n\n$toPlaceholder = $modx->getOption(\'toPlaceholder\', $scriptProperties, false);\nif (!empty($toPlaceholder)) {\n    $modx->setPlaceholder($toPlaceholder, $output);\n    return \'\';\n}\nreturn $output;', 0, 'a:44:{s:3:\"tpl\";a:7:{s:4:\"name\";s:3:\"tpl\";s:4:\"desc\";s:121:\"Name of a chunk serving as a resource template. NOTE: if not provided, properties are dumped to output for each resource.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:6:\"tplOdd\";a:7:{s:4:\"name\";s:6:\"tplOdd\";s:4:\"desc\";s:100:\"Name of a chunk serving as resource template for resources with an odd idx value (see idx property).\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:8:\"tplFirst\";a:7:{s:4:\"name\";s:8:\"tplFirst\";s:4:\"desc\";s:89:\"Name of a chunk serving as resource template for the first resource (see first property).\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:7:\"tplLast\";a:7:{s:4:\"name\";s:7:\"tplLast\";s:4:\"desc\";s:87:\"Name of a chunk serving as resource template for the last resource (see last property).\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:115:\"Name of a chunk serving as wrapper template for the Snippet output. This does not work with toSeparatePlaceholders.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:11:\"wrapIfEmpty\";a:7:{s:4:\"name\";s:11:\"wrapIfEmpty\";s:4:\"desc\";s:95:\"Indicates if empty output should be wrapped by the tplWrapper, if specified. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:153:\"A field name to sort by or JSON object of field names and sortdir for each field, e.g. {\"publishedon\":\"ASC\",\"createdon\":\"DESC\"}. Defaults to publishedon.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:11:\"publishedon\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:8:\"sortbyTV\";a:7:{s:4:\"name\";s:8:\"sortbyTV\";s:4:\"desc\";s:65:\"Name of a Template Variable to sort by. Defaults to empty string.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:12:\"sortbyTVType\";a:7:{s:4:\"name\";s:12:\"sortbyTVType\";s:4:\"desc\";s:72:\"An optional type to indicate how to sort on the Template Variable value.\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:4:{i:0;a:2:{s:4:\"text\";s:6:\"string\";s:5:\"value\";s:6:\"string\";}i:1;a:2:{s:4:\"text\";s:7:\"integer\";s:5:\"value\";s:7:\"integer\";}i:2;a:2:{s:4:\"text\";s:7:\"decimal\";s:5:\"value\";s:7:\"decimal\";}i:3;a:2:{s:4:\"text\";s:8:\"datetime\";s:5:\"value\";s:8:\"datetime\";}}s:5:\"value\";s:6:\"string\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:11:\"sortbyAlias\";a:7:{s:4:\"name\";s:11:\"sortbyAlias\";s:4:\"desc\";s:58:\"Query alias for sortby field. Defaults to an empty string.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:13:\"sortbyEscaped\";a:7:{s:4:\"name\";s:13:\"sortbyEscaped\";s:4:\"desc\";s:82:\"Determines if the field name specified in sortby should be escaped. Defaults to 0.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:41:\"Order which to sort by. Defaults to DESC.\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:4:\"DESC\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:9:\"sortdirTV\";a:7:{s:4:\"name\";s:9:\"sortdirTV\";s:4:\"desc\";s:61:\"Order which to sort a Template Variable by. Defaults to DESC.\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"ASC\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"DESC\";}}s:5:\"value\";s:4:\"DESC\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:5:\"limit\";a:7:{s:4:\"name\";s:5:\"limit\";s:4:\"desc\";s:55:\"Limits the number of resources returned. Defaults to 5.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"5\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:6:\"offset\";a:7:{s:4:\"name\";s:6:\"offset\";s:4:\"desc\";s:56:\"An offset of resources returned by the criteria to skip.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:9:\"tvFilters\";a:7:{s:4:\"name\";s:9:\"tvFilters\";s:4:\"desc\";s:778:\"Delimited-list of TemplateVar values to filter resources by. Supports two delimiters and two value search formats. THe first delimiter || represents a logical OR and the primary grouping mechanism.  Within each group you can provide a comma-delimited list of values. These values can be either tied to a specific TemplateVar by name, e.g. myTV==value, or just the value, indicating you are searching for the value in any TemplateVar tied to the Resource. An example would be &tvFilters=`filter2==one,filter1==bar%||filter1==foo`. <br />NOTE: filtering by values uses a LIKE query and % is considered a wildcard. <br />ANOTHER NOTE: This only looks at the raw value set for specific Resource, i. e. there must be a value specifically set for the Resource and it is not evaluated.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:21:\"tvFiltersAndDelimiter\";a:7:{s:4:\"name\";s:21:\"tvFiltersAndDelimiter\";s:4:\"desc\";s:83:\"The delimiter to use to separate logical AND expressions in tvFilters. Default is ,\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\",\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:20:\"tvFiltersOrDelimiter\";a:7:{s:4:\"name\";s:20:\"tvFiltersOrDelimiter\";s:4:\"desc\";s:83:\"The delimiter to use to separate logical OR expressions in tvFilters. Default is ||\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:2:\"||\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:5:\"depth\";a:7:{s:4:\"name\";s:5:\"depth\";s:4:\"desc\";s:88:\"Integer value indicating depth to search for resources from each parent. Defaults to 10.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:2:\"10\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:7:\"parents\";a:7:{s:4:\"name\";s:7:\"parents\";s:4:\"desc\";s:57:\"Optional. Comma-delimited list of ids serving as parents.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:14:\"includeContent\";a:7:{s:4:\"name\";s:14:\"includeContent\";s:4:\"desc\";s:95:\"Indicates if the content of each resource should be returned in the results. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:10:\"includeTVs\";a:7:{s:4:\"name\";s:10:\"includeTVs\";s:4:\"desc\";s:124:\"Indicates if TemplateVar values should be included in the properties available to each resource template. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:13:\"includeTVList\";a:7:{s:4:\"name\";s:13:\"includeTVList\";s:4:\"desc\";s:96:\"Limits included TVs to those specified as a comma-delimited list of TV names. Defaults to empty.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:10:\"showHidden\";a:7:{s:4:\"name\";s:10:\"showHidden\";s:4:\"desc\";s:85:\"Indicates if Resources that are hidden from menus should be shown. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:15:\"showUnpublished\";a:7:{s:4:\"name\";s:15:\"showUnpublished\";s:4:\"desc\";s:79:\"Indicates if Resources that are unpublished should be shown. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:11:\"showDeleted\";a:7:{s:4:\"name\";s:11:\"showDeleted\";s:4:\"desc\";s:75:\"Indicates if Resources that are deleted should be shown. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:9:\"resources\";a:7:{s:4:\"name\";s:9:\"resources\";s:4:\"desc\";s:177:\"A comma-separated list of resource IDs to exclude or include. IDs with a - in front mean to exclude. Ex: 123,-456 means to include Resource 123, but always exclude Resource 456.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:10:\"processTVs\";a:7:{s:4:\"name\";s:10:\"processTVs\";s:4:\"desc\";s:117:\"Indicates if TemplateVar values should be rendered as they would on the resource being summarized. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:13:\"processTVList\";a:7:{s:4:\"name\";s:13:\"processTVList\";s:4:\"desc\";s:166:\"Limits processed TVs to those specified as a comma-delimited list of TV names; note only includedTVs will be available for processing if specified. Defaults to empty.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:10:\"prepareTVs\";a:7:{s:4:\"name\";s:10:\"prepareTVs\";s:4:\"desc\";s:120:\"Indicates if TemplateVar values that are not processed fully should be prepared before being returned. Defaults to true.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:1;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:13:\"prepareTVList\";a:7:{s:4:\"name\";s:13:\"prepareTVList\";s:4:\"desc\";s:164:\"Limits prepared TVs to those specified as a comma-delimited list of TV names; note only includedTVs will be available for preparing if specified. Defaults to empty.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:8:\"tvPrefix\";a:7:{s:4:\"name\";s:8:\"tvPrefix\";s:4:\"desc\";s:55:\"The prefix for TemplateVar properties. Defaults to: tv.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:3:\"tv.\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:3:\"idx\";a:7:{s:4:\"name\";s:3:\"idx\";s:4:\"desc\";s:120:\"You can define the starting idx of the resources, which is an property that is incremented as each resource is rendered.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:5:\"first\";a:7:{s:4:\"name\";s:5:\"first\";s:4:\"desc\";s:81:\"Define the idx which represents the first resource (see tplFirst). Defaults to 1.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:4:\"last\";a:7:{s:4:\"name\";s:4:\"last\";s:4:\"desc\";s:129:\"Define the idx which represents the last resource (see tplLast). Defaults to the number of resources being summarized + first - 1\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:13:\"toPlaceholder\";a:7:{s:4:\"name\";s:13:\"toPlaceholder\";s:4:\"desc\";s:85:\"If set, will assign the result to this placeholder instead of outputting it directly.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:22:\"toSeparatePlaceholders\";a:7:{s:4:\"name\";s:22:\"toSeparatePlaceholders\";s:4:\"desc\";s:130:\"If set, will assign EACH result to a separate placeholder named by this param suffixed with a sequential number (starting from 0).\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:5:\"debug\";a:7:{s:4:\"name\";s:5:\"debug\";s:4:\"desc\";s:68:\"If true, will send the SQL query to the MODX log. Defaults to false.\";s:4:\"type\";s:13:\"combo-boolean\";s:7:\"options\";s:0:\"\";s:5:\"value\";b:0;s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:5:\"where\";a:7:{s:4:\"name\";s:5:\"where\";s:4:\"desc\";s:193:\"A JSON expression of criteria to build any additional where clauses from, e.g. &where=`{{\"alias:LIKE\":\"foo%\", \"OR:alias:LIKE\":\"%bar\"},{\"OR:pagetitle:=\":\"foobar\", \"AND:description:=\":\"raboof\"}}`\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:11:\"dbCacheFlag\";a:7:{s:4:\"name\";s:11:\"dbCacheFlag\";s:4:\"desc\";s:218:\"Determines how result sets are cached if cache_db is enabled in MODX. 0|false = do not cache result set; 1 = cache result set according to cache settings, any other integer value = number of seconds to cache result set\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:1:\"0\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:7:\"context\";a:7:{s:4:\"name\";s:7:\"context\";s:4:\"desc\";s:116:\"A comma-delimited list of context keys for limiting results. Default is empty, i.e. do not limit results by context.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:12:\"tplCondition\";a:7:{s:4:\"name\";s:12:\"tplCondition\";s:4:\"desc\";s:129:\"A condition to compare against the conditionalTpls property to map Resources to different tpls based on custom conditional logic.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:11:\"tplOperator\";a:7:{s:4:\"name\";s:11:\"tplOperator\";s:4:\"desc\";s:125:\"An optional operator to use for the tplCondition when comparing against the conditionalTpls operands. Default is == (equals).\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:10:{i:0;a:2:{s:4:\"text\";s:11:\"is equal to\";s:5:\"value\";s:2:\"==\";}i:1;a:2:{s:4:\"text\";s:15:\"is not equal to\";s:5:\"value\";s:2:\"!=\";}i:2;a:2:{s:4:\"text\";s:9:\"less than\";s:5:\"value\";s:1:\"<\";}i:3;a:2:{s:4:\"text\";s:21:\"less than or equal to\";s:5:\"value\";s:2:\"<=\";}i:4;a:2:{s:4:\"text\";s:24:\"greater than or equal to\";s:5:\"value\";s:2:\">=\";}i:5;a:2:{s:4:\"text\";s:8:\"is empty\";s:5:\"value\";s:5:\"empty\";}i:6;a:2:{s:4:\"text\";s:12:\"is not empty\";s:5:\"value\";s:6:\"!empty\";}i:7;a:2:{s:4:\"text\";s:7:\"is null\";s:5:\"value\";s:4:\"null\";}i:8;a:2:{s:4:\"text\";s:11:\"is in array\";s:5:\"value\";s:7:\"inarray\";}i:9;a:2:{s:4:\"text\";s:10:\"is between\";s:5:\"value\";s:7:\"between\";}}s:5:\"value\";s:2:\"==\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}s:15:\"conditionalTpls\";a:7:{s:4:\"name\";s:15:\"conditionalTpls\";s:4:\"desc\";s:121:\"A JSON map of conditional operands and tpls to compare against the tplCondition property using the specified tplOperator.\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:0:\"\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}}', '', 0, ''),
(28, 1, 0, 'paddingTop', '', 0, 0, 0, '$imageFile = MODX_SITE_URL . $file;\n$info = getimagesize($imageFile);\n$width = (int)$info[0];\n$height = (int)$info[1];\n$padding_top = floor(( $height / $width ) * 100);\n\nreturn $padding_top;', 0, 'a:0:{}', '', 0, ''),
(29, 1, 0, 'galleryRand', '', 0, 0, 0, '// $count - Количество картин\n// $tpl - шаблон выдачи\n// $parent - относительный путь к директории\n\n$galleryDocs = $modx->getChildIds($parent, 1);\nshuffle($galleryDocs);\n$randDocs = array_slice($galleryDocs, 0, $count);\n\n$output = \'\';\n\nforeach($randDocs as $doc){\n    \n    $params = array(\n        \'id\' => $doc,\n        \'field\' => \'pagetitle\'\n    );\n    \n    $pagetitle = $modx->runSnippet(\'lingua.getValue\', $params);\n    $imageTv = $modx->getObject(\'modTemplateVarResource\', array(\n        \'tmplvarid\' => 2,\n        \'contentid\' => $doc\n    ));\n    \n    $image = \"\";\n    $padding = 0;\n    \n    if($imageTv){\n        $image = $imageTv->get(\'value\');\n    }\n    \n    \n    if($image){\n\n        $imageParams = getimagesize(MODX_SITE_URL . $image);\n        $width = $imageParams[0];\n        $height = $imageParams[1];\n        $padding = ((int)$height / (int)$width) * 100;\n    }\n    \n    $chunkParams = array(\n        \'img-url\' => $image,\n        \'title\' => $pagetitle,\n        \'padding-top\' => str_replace(\',\', \'.\', (string)$padding)\n    );\n    \n    $chunk = $modx->getChunk($tpl, $chunkParams);\n    $output .= $chunk;\n}\n\nreturn $output;', 0, 'a:0:{}', '', 0, '');
INSERT INTO `modx_site_snippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `moduleguid`, `static`, `static_file`) VALUES
(30, 0, 1, 'lingua.selector', 'Languages selector drop down.', 0, 7, 0, '/**\n * Lingua\n *\n * Copyright 2013-2015 by goldsky <goldsky@virtudraft.com>\n *\n * This file is part of Lingua, a MODX\'s Lexicon switcher for front-end interface\n *\n * Lingua is free software; you can redistribute it and/or modify it under the\n * terms of the GNU General Public License as published by the Free Software\n * Foundation version 3.\n *\n * Lingua is distributed in the hope that it will be useful, but WITHOUT ANY\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\n *\n * You should have received a copy of the GNU General Public License along with\n * Lingua; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\n * Suite 330, Boston, MA 02111-1307 USA\n *\n * @package lingua\n * @subpackage lingua_selector\n */\n$activeOnly = $modx->getOption(\'activeOnly\', $scriptProperties, \'1\');\n$tplWrapper = $modx->getOption(\'tplWrapper\', $scriptProperties, \'lingua.selector.wrapper\');\n$tplItem = $modx->getOption(\'tplItem\', $scriptProperties, \'lingua.selector.item\');\n$langKey = $modx->getOption(\'getKey\', $scriptProperties, $modx->getOption(\'lingua.get_key\', null, \'lang\'));\n$sortby = $modx->getOption(\'sortby\', $scriptProperties, \'id\');\n$sortdir = $modx->getOption(\'sortdir\', $scriptProperties, \'asc\');\n$phsPrefix = $modx->getOption(\'phsPrefix\', $scriptProperties, \'lingua.\');\n$codeField = $modx->getOption(\'codeField\', $scriptProperties, \'lang_code\');\n\n$defaultLinguaCorePath = $modx->getOption(\'core_path\') . \'components/lingua/\';\n$linguaCorePath = $modx->getOption(\'lingua.core_path\', null, $defaultLinguaCorePath);\n$lingua = $modx->getService(\'lingua\', \'Lingua\', $linguaCorePath . \'model/lingua/\', $scriptProperties);\n\nif (!($lingua instanceof Lingua)) {\n    return;\n}\n\n$allowedContexts = $modx->getOption(\'lingua.contexts\');\n$allowedContexts = array_map(\'trim\', @explode(\',\', $allowedContexts));\n$currentContext = $modx->context->get(\'key\');\nif (!in_array($currentContext, $allowedContexts)) {\n    return;\n}\n\n$pageURL = \'http\';\nif (isset($_SERVER[\"HTTPS\"]) && $_SERVER[\"HTTPS\"] == \"on\") {\n    $pageURL .= \"s\";\n}\n$pageURL .= \"://\";\nif ($_SERVER[\"SERVER_PORT\"] !== \"80\") {\n    $pageURL .= $_SERVER[\"SERVER_NAME\"] . \":\" . $_SERVER[\"SERVER_PORT\"] . $_SERVER[\"REQUEST_URI\"];\n} else {\n    $pageURL .= $_SERVER[\"SERVER_NAME\"] . $_SERVER[\"REQUEST_URI\"];\n}\n$parseUrl = parse_url($pageURL);\nif (!empty($parseUrl[\'query\'])) {\n    /**\n     * http://stackoverflow.com/a/7753154/1246646\n     */\n    if (!function_exists(\'http_build_url\')) {\n        define(\'HTTP_URL_REPLACE\', 1);              // Replace every part of the first URL when there\'s one of the second URL\n        define(\'HTTP_URL_JOIN_PATH\', 2);            // Join relative paths\n        define(\'HTTP_URL_JOIN_QUERY\', 4);           // Join query strings\n        define(\'HTTP_URL_STRIP_USER\', 8);           // Strip any user authentication information\n        define(\'HTTP_URL_STRIP_PASS\', 16);          // Strip any password authentication information\n        define(\'HTTP_URL_STRIP_AUTH\', 32);          // Strip any authentication information\n        define(\'HTTP_URL_STRIP_PORT\', 64);          // Strip explicit port numbers\n        define(\'HTTP_URL_STRIP_PATH\', 128);         // Strip complete path\n        define(\'HTTP_URL_STRIP_QUERY\', 256);        // Strip query string\n        define(\'HTTP_URL_STRIP_FRAGMENT\', 512);     // Strip any fragments (#identifier)\n        define(\'HTTP_URL_STRIP_ALL\', 1024);         // Strip anything but scheme and host\n\n        /**\n         * Build an URL<br>\n         * The parts of the second URL will be merged into the first according to the flags argument.<br><br>\n         *\n         * @param	mixed	$url	(Part(s) of) an URL in form of a string or associative array like parse_url() returns\n         * @param	mixed	$parts	Same as the first argument\n         * @param	int		$flags	A bitmask of binary or\'ed HTTP_URL constants (Optional)HTTP_URL_REPLACE is the default\n         * @param	array	$newUrl	If set, it will be filled with the parts of the composed url like parse_url() would return\n         * @return	string			Built URL\n         */\n        function http_build_url($url, $parts = array(), $flags = HTTP_URL_REPLACE, &$newUrl = false) {\n            $keys = array(\'user\', \'pass\', \'port\', \'path\', \'query\', \'fragment\');\n\n            // HTTP_URL_STRIP_ALL becomes all the HTTP_URL_STRIP_Xs\n            if ($flags & HTTP_URL_STRIP_ALL) {\n                $flags |= HTTP_URL_STRIP_USER;\n                $flags |= HTTP_URL_STRIP_PASS;\n                $flags |= HTTP_URL_STRIP_PORT;\n                $flags |= HTTP_URL_STRIP_PATH;\n                $flags |= HTTP_URL_STRIP_QUERY;\n                $flags |= HTTP_URL_STRIP_FRAGMENT;\n            }\n            // HTTP_URL_STRIP_AUTH becomes HTTP_URL_STRIP_USER and HTTP_URL_STRIP_PASS\n            else if ($flags & HTTP_URL_STRIP_AUTH) {\n                $flags |= HTTP_URL_STRIP_USER;\n                $flags |= HTTP_URL_STRIP_PASS;\n            }\n\n            // Parse the original URL\n            $parseUrl = parse_url($url);\n\n            // Scheme and Host are always replaced\n            if (isset($parts[\'scheme\']))\n                $parseUrl[\'scheme\'] = $parts[\'scheme\'];\n            if (isset($parts[\'host\']))\n                $parseUrl[\'host\'] = $parts[\'host\'];\n\n            // (If applicable) Replace the original URL with it\'s new parts\n            if ($flags & HTTP_URL_REPLACE) {\n                foreach ($keys as $key) {\n                    if (isset($parts[$key]))\n                        $parseUrl[$key] = $parts[$key];\n                }\n            }\n            else {\n                // Join the original URL path with the new path\n                if (isset($parts[\'path\']) && ($flags & HTTP_URL_JOIN_PATH)) {\n                    if (isset($parseUrl[\'path\']))\n                        $parseUrl[\'path\'] = rtrim(str_replace(basename($parseUrl[\'path\']), \'\', $parseUrl[\'path\']), \'/\') . \'/\' . ltrim($parts[\'path\'], \'/\');\n                    else\n                        $parseUrl[\'path\'] = $parts[\'path\'];\n                }\n\n                // Join the original query string with the new query string\n                if (isset($parts[\'query\']) && ($flags & HTTP_URL_JOIN_QUERY)) {\n                    if (isset($parseUrl[\'query\']))\n                        $parseUrl[\'query\'] .= \'&\' . $parts[\'query\'];\n                    else\n                        $parseUrl[\'query\'] = $parts[\'query\'];\n                }\n            }\n\n            // Strips all the applicable sections of the URL\n            // Note: Scheme and Host are never stripped\n            foreach ($keys as $key) {\n                if ($flags & (int) constant(\'HTTP_URL_STRIP_\' . strtoupper($key)))\n                    unset($parseUrl[$key]);\n            }\n\n            $newUrl = $parseUrl;\n\n            return\n                    ((isset($parseUrl[\'scheme\'])) ? $parseUrl[\'scheme\'] . \'://\' : \'\')\n                    . ((isset($parseUrl[\'user\'])) ? $parseUrl[\'user\'] . ((isset($parseUrl[\'pass\'])) ? \':\' . $parseUrl[\'pass\'] : \'\') . \'@\' : \'\')\n                    . ((isset($parseUrl[\'host\'])) ? $parseUrl[\'host\'] : \'\')\n                    . ((isset($parseUrl[\'port\'])) ? \':\' . $parseUrl[\'port\'] : \'\')\n                    . ((isset($parseUrl[\'path\'])) ? $parseUrl[\'path\'] : \'\')\n                    . ((isset($parseUrl[\'query\'])) ? \'?\' . $parseUrl[\'query\'] : \'\')\n                    . ((isset($parseUrl[\'fragment\'])) ? \'#\' . $parseUrl[\'fragment\'] : \'\')\n            ;\n        }\n\n    }\n\n    parse_str($parseUrl[\'query\'], $queries);\n    unset($queries[$langKey]);\n    $parseUrl[\'query\'] = http_build_query($queries);\n\n    $pageURL = http_build_url($pageURL, $parseUrl);\n    $pageURL = urldecode($pageURL);\n    // replace: &queryarray[0]=foo&queryarray[1]=bar\n    // to:		&queryarray[]=foo&queryarray[]=bar\n    $pageURL = preg_replace(\'/\\[+(\\d)+\\]+/\', \'[]\', $pageURL);\n}\n\n$pageURL = rtrim($pageURL, \'?\');\n$hasQuery = strstr($pageURL, \'?\');\n\n$originPageUrl = $pageURL;\n$requestUri = preg_replace(\'/^\'. preg_quote(MODX_BASE_URL, \'/\') . \'/i\', \'\', $parseUrl[\'path\']);\n\n// $modx->getOption(\'cultureKey\') is overriden by plugin!\n$modCultureKey = $modx->getObject(\'modSystemSetting\', array(\'key\' => \'cultureKey\'));\n$cultureKey = $modCultureKey->get(\'value\');\n\n$baseUrl = $modx->getOption(\'base_url\', $scriptProperties);\n$baseUrl = preg_replace(\'/^\'. preg_quote(MODX_BASE_URL, \'/\') . \'/i\', \'\', $baseUrl);\n$originResource = $modx->getObject(\'modResource\', $modx->resource->get(\'id\'));\n\n$languages = $lingua->getLanguages($activeOnly);\n$selections = array();\nforeach ($languages as $language) {\n    if ($language[\'lang_code\'] === $modx->cultureKey) {\n        continue;\n    }\n\n    $cloneSite = $modx->getObject(\'linguaSiteContent\', array(\n        \'resource_id\' => $modx->resource->get(\'id\'),\n        \'lang_id\' => $language[\'id\'],\n    ));\n    if ($modx->getOption(\'friendly_urls\')) {\n        $itemUri = \'\';\n        if ($language[\'lang_code\'] === $cultureKey) {\n            $itemUri = $originResource->get(\'uri\');\n        } elseif ($cloneSite) {\n            $itemUri = $cloneSite->get(\'uri\');\n        }\n        if (!empty($itemUri)) {\n            if ((int)$modx->getOption(\'site_start\') === $modx->resource->get(\'id\')) {\n                $pageURL = $parseUrl[\'scheme\'] . \'://\' . $parseUrl[\'host\'] . \'/\' . $parseUrl[\'path\'] . $itemUri;\n            } else {\n                $pageURL = preg_replace(\'/^\' . preg_quote($parseUrl[\'scheme\'] . \'://\' . $parseUrl[\'host\'] . \'/\' . $requestUri, \'/\') . \'/i\'\n                        , $parseUrl[\'scheme\'] . \'://\' . $parseUrl[\'host\'] . \'/\' . $baseUrl . $itemUri\n                        , $originPageUrl);\n            }\n        }\n    }\n\n    $language[\'url\'] = $pageURL . (!empty($hasQuery) ? \'&\' : \'?\') . $langKey . \'=\' . $language[$codeField];\n    $phs = $lingua->setPlaceholders($language, $phsPrefix, false);\n\n    if (!empty($toArray)) {\n        $selections[] = $phs;\n    } else {\n        $selections[] = $lingua->parseTpl($tplItem, $phs);\n    }\n}\n\nif (!empty($toArray)) {\n    $wrapper = array(\n        $phsPrefix . \'languages\' => $selections\n    );\n    $output = \'<pre>\' . print_r($wrapper, TRUE) . \'</pre>\';\n} else {\n    $selection = @implode(\"\\n\", $selections);\n    $wrapper = array($phsPrefix . \'languages\' => $selection);\n    $output = $lingua->parseTpl($tplWrapper, $wrapper);\n}\nif (!empty($toPlaceholder)) {\n    $modx->setPlaceholder($toPlaceholder, $output);\n    return;\n}\nreturn $output;', 0, 'a:7:{s:9:\"codeField\";a:7:{s:4:\"name\";s:9:\"codeField\";s:4:\"desc\";s:19:\"prop_codeField_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:9:\"lang_code\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:6:\"getKey\";a:7:{s:4:\"name\";s:6:\"getKey\";s:4:\"desc\";s:16:\"prop_getKey_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:4:\"lang\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:9:\"phsPrefix\";a:7:{s:4:\"name\";s:9:\"phsPrefix\";s:4:\"desc\";s:19:\"prop_phsPrefix_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:7:\"lingua.\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:16:\"prop_sortby_desc\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:2:\"ID\";s:5:\"value\";s:2:\"id\";}i:1;a:2:{s:4:\"text\";s:8:\"iso_code\";s:5:\"value\";s:8:\"iso_code\";}}s:5:\"value\";s:2:\"id\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:17:\"prop_sortdir_desc\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"asc\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"desc\";}}s:5:\"value\";s:3:\"asc\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:7:\"tplItem\";a:7:{s:4:\"name\";s:7:\"tplItem\";s:4:\"desc\";s:17:\"prop_tplItem_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:20:\"lingua.selector.item\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:20:\"prop_tplWrapper_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:23:\"lingua.selector.wrapper\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}}', '', 0, ''),
(31, 0, 1, 'lingua.cultureKey', 'Helper snippet to get the run time cultureKey, which is set by lingua\'s plugin.', 0, 7, 0, '/**\r\n * Lingua\r\n *\r\n * Copyright 2013-2015 by goldsky <goldsky@virtudraft.com>\r\n *\r\n * This file is part of Lingua, a MODX\'s Lexicon switcher for front-end interface\r\n *\r\n * Lingua is free software; you can redistribute it and/or modify it under the\r\n * terms of the GNU General Public License as published by the Free Software\r\n * Foundation version 3.\r\n *\r\n * Lingua is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * Lingua; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package lingua\r\n * @subpackage lingua_culture_key\r\n */\r\n\r\nreturn $modx->cultureKey;', 0, NULL, '', 0, ''),
(32, 0, 1, 'lingua.getField', 'Get the value of the given field for the run time culture key.', 0, 7, 0, '/**\r\n * Lingua\r\n *\r\n * Copyright 2013-2015 by goldsky <goldsky@virtudraft.com>\r\n *\r\n * This file is part of Lingua, a MODX\'s Lexicon switcher for front-end interface\r\n *\r\n * Lingua is free software; you can redistribute it and/or modify it under the\r\n * terms of the GNU General Public License as published by the Free Software\r\n * Foundation version 3.\r\n *\r\n * Lingua is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * Lingua; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package lingua\r\n * @subpackage lingua_getfield\r\n */\r\n\r\n$field = $modx->getOption(\'field\', $scriptProperties);\r\nif (empty($field)) {\r\n    return;\r\n}\r\n\r\n$langCodeField = $modx->getOption(\'codeField\', $scriptProperties, $modx->getOption(\'lingua.code_field\', null, \'lang_code\'));\r\n$defaultLinguaCorePath = $modx->getOption(\'core_path\') . \'components/lingua/\';\r\n$linguaCorePath = $modx->getOption(\'lingua.core_path\', null, $defaultLinguaCorePath);\r\n$lingua = $modx->getService(\'lingua\', \'Lingua\', $linguaCorePath . \'model/lingua/\', $scriptProperties);\r\n\r\nif (!($lingua instanceof Lingua)) {\r\n    return;\r\n}\r\n\r\n$langObj = $modx->getObject(\'linguaLangs\', array(\r\n    $langCodeField => $modx->cultureKey\r\n));\r\nif (!$langObj) {\r\n    return;\r\n}\r\n$output = $langObj->get($field);\r\nif (!$output) {\r\n    return;\r\n}\r\nreturn $output;', 0, NULL, '', 0, ''),
(33, 0, 1, 'lingua.getValue', 'Get the value of the clone\'s field for the run time culture key.', 0, 7, 0, '/**\r\n * Lingua\r\n *\r\n * Copyright 2013-2015 by goldsky <goldsky@virtudraft.com>\r\n *\r\n * This file is part of Lingua, a MODX\'s Lexicon switcher for front-end interface\r\n *\r\n * Lingua is free software; you can redistribute it and/or modify it under the\r\n * terms of the GNU General Public License as published by the Free Software\r\n * Foundation version 3.\r\n *\r\n * Lingua is distributed in the hope that it will be useful, but WITHOUT ANY\r\n * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR\r\n * A PARTICULAR PURPOSE. See the GNU General Public License for more details.\r\n *\r\n * You should have received a copy of the GNU General Public License along with\r\n * Lingua; if not, write to the Free Software Foundation, Inc., 59 Temple Place,\r\n * Suite 330, Boston, MA 02111-1307 USA\r\n *\r\n * @package lingua\r\n * @subpackage lingua_getfield\r\n */\r\n\r\n$field = $modx->getOption(\'field\', $scriptProperties);\r\nif (empty($field)) {\r\n    return;\r\n}\r\n\r\n$id = $modx->getOption(\'id\', $scriptProperties, $modx->resource->get(\'id\'));\r\n$emptyReturnsDefault = $modx->getOption(\'emptyReturnsDefault\', $scriptProperties, $modx->getOption(\'lingua.empty_returns_default\', null, false));\r\n\r\n$defaultLinguaCorePath = $modx->getOption(\'core_path\') . \'components/lingua/\';\r\n$linguaCorePath = $modx->getOption(\'lingua.core_path\', null, $defaultLinguaCorePath);\r\n$lingua = $modx->getService(\'lingua\', \'Lingua\', $linguaCorePath . \'model/lingua/\', $scriptProperties);\r\n$debug = $modx->getOption(\'lingua.debug\');\r\nif (!($lingua instanceof Lingua)) {\r\n    $modx->log(modX::LOG_LEVEL_ERROR, \'[lingua.getValue]: !($lingua instanceof Lingua)\');\r\n    return;\r\n}\r\n\r\n$langObj = $modx->getObject(\'linguaLangs\', array(\r\n    \'lang_code\' => $modx->cultureKey\r\n));\r\nif (!$langObj) {\r\n    if ($debug) {\r\n        $modx->log(modX::LOG_LEVEL_ERROR, \'[lingua.getValue]: Missing field\\\'s value for \' . $field . \' in \' . $modx->cultureKey);\r\n    }\r\n    return;\r\n}\r\n$c = $modx->newQuery(\'linguaSiteContent\');\r\n$c->where(array(\r\n    \'resource_id\' => $id,\r\n    \'lang_id\' => $langObj->get(\'id\'),\r\n));\r\n$linguaSiteContent = $modx->getObject(\'linguaSiteContent\', $c);\r\n$resource = $modx->getObject(\'modResource\', $id);\r\nif (!$resource) {\r\n    if ($debug) {\r\n        $modx->log(modX::LOG_LEVEL_ERROR, \'[lingua.getValue]: Missing resource for \' . $field . \' in \' . $modx->cultureKey);\r\n    }\r\n    return;\r\n}\r\n\r\n$tableFields = array(\'pagetitle\', \'longtitle\', \'description\', \'alias\',\r\n    \'link_attributes\', \'introtext\', \'content\', \'menutitle\', \'uri\', \'uri_override\',\r\n    \'properties\');\r\n$output = \'\';\r\nif (in_array($field, $tableFields)) {\r\n    if ($linguaSiteContent) {\r\n        $output = $linguaSiteContent->get($field);\r\n        if (empty($output)) {\r\n            if ($emptyReturnsDefault) {\r\n                $output = $resource->get($field); // return default language\'s value\r\n            }\r\n        }\r\n    } else {\r\n        $output = $resource->get($field); // return default language\'s value\r\n    }\r\n}\r\n// try TV\r\nelse {\r\n    $tv = $modx->getObject(\'modTemplateVar\', array(\r\n        \'name\' => $field,\r\n    ));\r\n    if ($tv) {\r\n        $linguaSiteTmplvarContentvalues = $modx->getObject(\'linguaSiteTmplvarContentvalues\', array(\r\n            \'lang_id\' => $langObj->get(\'id\'),\r\n            \'tmplvarid\' => $tv->get(\'id\'),\r\n            \'contentid\' => $id,\r\n        ));\r\n        if ($linguaSiteTmplvarContentvalues) {\r\n            $value = $linguaSiteTmplvarContentvalues->get(\'value\');\r\n            $tv->set(\'resourceId\', $id);\r\n            if (empty($value) && !$emptyReturnsDefault) {\r\n                $tv->set(\'value\', $value); // return empty value\r\n            } else {\r\n                $tv->set(\'value\', $value);\r\n            }\r\n        }\r\n        $output = $tv->renderOutput($resource->get(\'id\'));\r\n    }\r\n}\r\n\r\nreturn $output;', 0, 'a:7:{s:9:\"codeField\";a:7:{s:4:\"name\";s:9:\"codeField\";s:4:\"desc\";s:19:\"prop_codeField_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:9:\"lang_code\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:6:\"getKey\";a:7:{s:4:\"name\";s:6:\"getKey\";s:4:\"desc\";s:16:\"prop_getKey_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:4:\"lang\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:9:\"phsPrefix\";a:7:{s:4:\"name\";s:9:\"phsPrefix\";s:4:\"desc\";s:19:\"prop_phsPrefix_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:7:\"lingua.\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:6:\"sortby\";a:7:{s:4:\"name\";s:6:\"sortby\";s:4:\"desc\";s:16:\"prop_sortby_desc\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:2:\"ID\";s:5:\"value\";s:2:\"id\";}i:1;a:2:{s:4:\"text\";s:8:\"iso_code\";s:5:\"value\";s:8:\"iso_code\";}}s:5:\"value\";s:2:\"id\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:7:\"sortdir\";a:7:{s:4:\"name\";s:7:\"sortdir\";s:4:\"desc\";s:17:\"prop_sortdir_desc\";s:4:\"type\";s:4:\"list\";s:7:\"options\";a:2:{i:0;a:2:{s:4:\"text\";s:3:\"ASC\";s:5:\"value\";s:3:\"asc\";}i:1;a:2:{s:4:\"text\";s:4:\"DESC\";s:5:\"value\";s:4:\"desc\";}}s:5:\"value\";s:3:\"asc\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:7:\"tplItem\";a:7:{s:4:\"name\";s:7:\"tplItem\";s:4:\"desc\";s:17:\"prop_tplItem_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:20:\"lingua.selector.item\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}s:10:\"tplWrapper\";a:7:{s:4:\"name\";s:10:\"tplWrapper\";s:4:\"desc\";s:20:\"prop_tplWrapper_desc\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";s:0:\"\";s:5:\"value\";s:23:\"lingua.selector.wrapper\";s:7:\"lexicon\";s:15:\"lingua:property\";s:4:\"area\";s:0:\"\";}}', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_templates`
--

CREATE TABLE `modx_site_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `templatename` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(191) NOT NULL DEFAULT 'Template',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `icon` varchar(191) NOT NULL DEFAULT '',
  `template_type` int(11) NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_templates`
--

INSERT INTO `modx_site_templates` (`id`, `source`, `property_preprocess`, `templatename`, `description`, `editor_type`, `category`, `icon`, `template_type`, `content`, `locked`, `properties`, `static`, `static_file`) VALUES
(1, 0, 0, 'Начальный шаблон', 'Template', 0, 0, '', 0, '<!doctype html>\n<html lang=\"[[!lingua.cultureKey]]\">\n<head>\n    [[$head]]\n</head>\n<body>\n    [[$header]]\n    <main id=\"[[*alias]]\">\n        [[*content]]\n    </main>\n    [[$footer]]\n    [[$scripts]]\n    [[$modal-[[!lingua.cultureKey]]]]\n</body>\n</html>', 0, 'a:0:{}', 0, ''),
(3, 0, 0, 'Галерея', 'Template', 0, 0, '', 0, '<!doctype html>\n<html lang=\"[[!lingua.cultureKey]]\">\n<head>\n    [[$head]]\n</head>\n<body>\n    [[$header]]\n    <main id=\"[[*alias]]\">\n        <section>\n            <div class=\"container\">\n                <div class=\"col s12\">\n                    <h1>[[*pagetitle]]</h1>\n                </div>\n                <div class=\"col s12\">\n                    <div class=\"gallery\">\n                        [[!pdoPage?\n                            &element=`pdoResources`\n                            &tpl=`collectionItemTpl`\n                            &includeContent=`1`\n                            &includeTVs=`image`\n                            &processTVs=`1`\n                            &limit=`0`\n                        ]]\n                    </div>\n                </div>\n            </div>\n        </section>\n    </main>\n    [[$footer]]\n    [[$scripts]]\n</body>\n</html>', 0, 'a:0:{}', 0, ''),
(4, 0, 0, 'Картина', 'Template', 0, 0, '', 0, '<!doctype html>\n<html lang=\"[[!lingua.cultureKey]]\">\n<head>\n    [[$head]]\n</head>\n<body>\n    [[$header]]\n    <main id=\"[[*alias]]\">\n        [[*content]]\n    </main>\n    [[$footer]]\n    [[$scripts]]\n    [[$modal-[[!lingua.cultureKey]]]]\n</body>\n</html>', 0, 'a:0:{}', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvars`
--

CREATE TABLE `modx_site_tmplvars` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `caption` varchar(80) NOT NULL DEFAULT '',
  `description` varchar(191) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `elements` text,
  `rank` int(11) NOT NULL DEFAULT '0',
  `display` varchar(20) NOT NULL DEFAULT '',
  `default_text` mediumtext,
  `properties` text,
  `input_properties` text,
  `output_properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_tmplvars`
--

INSERT INTO `modx_site_tmplvars` (`id`, `source`, `property_preprocess`, `type`, `name`, `caption`, `description`, `editor_type`, `category`, `locked`, `elements`, `rank`, `display`, `default_text`, `properties`, `input_properties`, `output_properties`, `static`, `static_file`) VALUES
(2, 1, 0, 'image', 'image', 'Картинка', '', 0, 0, 0, '', 0, 'default', '', 'a:0:{}', 'a:1:{s:10:\"allowBlank\";s:4:\"true\";}', 'a:0:{}', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvar_access`
--

CREATE TABLE `modx_site_tmplvar_access` (
  `id` int(10) UNSIGNED NOT NULL,
  `tmplvarid` int(10) NOT NULL DEFAULT '0',
  `documentgroup` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvar_contentvalues`
--

CREATE TABLE `modx_site_tmplvar_contentvalues` (
  `id` int(10) UNSIGNED NOT NULL,
  `tmplvarid` int(10) NOT NULL DEFAULT '0',
  `contentid` int(10) NOT NULL DEFAULT '0',
  `value` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_tmplvar_contentvalues`
--

INSERT INTO `modx_site_tmplvar_contentvalues` (`id`, `tmplvarid`, `contentid`, `value`) VALUES
(2, 2, 6, 'img/gallery/large/flowering-garden.jpg'),
(3, 2, 7, 'img/gallery/large/abstration.jpg'),
(4, 2, 8, 'img/gallery/large/turuli-paints.jpg'),
(5, 2, 9, 'img/gallery/cockerel.jpg'),
(6, 2, 10, 'img/gallery/chamomiles.jpg'),
(7, 2, 11, 'img/gallery/autumn-sun.jpg'),
(8, 2, 12, 'img/gallery/sultry-africa.jpg'),
(9, 2, 13, 'img/gallery/autumn-forest.jpg'),
(10, 2, 14, 'img/gallery/turuli-paints.jpg'),
(11, 2, 15, 'img/gallery/still-life-with-blue-vase.jpg'),
(12, 2, 16, 'img/gallery/three-poplars.jpg'),
(13, 2, 17, 'img/gallery/asters.jpg'),
(14, 2, 18, 'img/gallery/sunset.jpg'),
(15, 2, 19, 'img/gallery/pink-bouquet.jpg'),
(16, 2, 20, 'img/gallery/stairway.jpg'),
(17, 2, 21, 'img/gallery/the-lake.jpg'),
(18, 2, 22, 'img/gallery/in-black-sea.jpg'),
(19, 2, 23, 'img/gallery/little-horse.jpg'),
(20, 2, 24, 'img/gallery/lotuses.jpg'),
(21, 2, 25, 'img/gallery/red-flowers.jpg'),
(22, 2, 26, 'img/gallery/cat-with-kitties.jpg'),
(23, 2, 27, 'img/gallery/mountain-cat.jpg'),
(24, 2, 28, 'img/gallery/outer-space.jpg'),
(25, 2, 29, 'img/gallery/doubts.jpg'),
(26, 2, 30, 'img/gallery/waterfall.jpg'),
(27, 2, 31, 'img/gallery/house-in-in-the-garden.jpg'),
(28, 2, 32, 'img/gallery/decorative-still-life.jpg'),
(29, 2, 33, 'img/gallery/spring-mood.jpg'),
(30, 2, 34, 'img/gallery/birch-trees.jpg'),
(31, 2, 36, 'img/gallery/sunset-sea.jpg'),
(32, 2, 37, 'img/gallery/fishers.jpg'),
(33, 2, 38, 'img/gallery/what-hiding-moonlight.jpg'),
(34, 2, 39, 'img/gallery/storm.jpg'),
(35, 2, 40, 'img/gallery/chang-an-vietnam.jpg'),
(36, 2, 41, 'img/gallery/wanderer.jpg'),
(37, 2, 42, 'img/gallery/farewell.jpg'),
(38, 2, 43, 'img/gallery/bird-on-branch.jpg'),
(39, 2, 44, 'img/gallery/islands.jpg'),
(40, 2, 45, 'img/gallery/flaming-sunset.jpg'),
(41, 2, 46, 'img/gallery/mountains-sunrise.jpg'),
(42, 2, 47, 'img/gallery/evening-light.jpg'),
(43, 2, 48, 'img/gallery/flowers.jpg'),
(44, 2, 49, 'img/gallery/forest.jpg'),
(45, 2, 50, 'img/gallery/branch-of-sakura.jpg'),
(46, 2, 51, 'img/gallery/angel.jpg'),
(47, 2, 52, 'img/gallery/poppies.jpg'),
(48, 2, 53, 'img/gallery/alpen-field.jpg'),
(49, 2, 54, 'img/gallery/two-lotuses.jpg'),
(50, 2, 35, 'img/gallery/blooming-garden.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvar_templates`
--

CREATE TABLE `modx_site_tmplvar_templates` (
  `tmplvarid` int(10) NOT NULL DEFAULT '0',
  `templateid` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_tmplvar_templates`
--

INSERT INTO `modx_site_tmplvar_templates` (`tmplvarid`, `templateid`, `rank`) VALUES
(2, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_system_eventnames`
--

CREATE TABLE `modx_system_eventnames` (
  `name` varchar(50) NOT NULL,
  `service` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `groupname` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_system_eventnames`
--

INSERT INTO `modx_system_eventnames` (`name`, `service`, `groupname`) VALUES
('CollectionsOnResourceSort', 6, 'Collections'),
('OnBeforeCacheUpdate', 4, 'System'),
('OnBeforeChunkFormDelete', 1, 'Chunks'),
('OnBeforeChunkFormSave', 1, 'Chunks'),
('OnBeforeDocFormDelete', 1, 'Resources'),
('OnBeforeDocFormSave', 1, 'Resources'),
('OnBeforeEmptyTrash', 1, 'Resources'),
('OnBeforeManagerLogin', 2, 'Security'),
('OnBeforeManagerLogout', 2, 'Security'),
('OnBeforeManagerPageInit', 2, 'System'),
('OnBeforePluginFormDelete', 1, 'Plugins'),
('OnBeforePluginFormSave', 1, 'Plugins'),
('OnBeforeRegisterClientScripts', 5, 'System'),
('OnBeforeSaveWebPageCache', 4, 'System'),
('OnBeforeSnipFormDelete', 1, 'Snippets'),
('OnBeforeSnipFormSave', 1, 'Snippets'),
('OnBeforeTempFormDelete', 1, 'Templates'),
('OnBeforeTempFormSave', 1, 'Templates'),
('OnBeforeTVFormDelete', 1, 'Template Variables'),
('OnBeforeTVFormSave', 1, 'Template Variables'),
('OnBeforeUserActivate', 1, 'Users'),
('OnBeforeUserDeactivate', 1, 'Users'),
('OnBeforeUserDuplicate', 1, 'Users'),
('OnBeforeUserFormDelete', 1, 'Users'),
('OnBeforeUserFormSave', 1, 'Users'),
('OnBeforeUserGroupFormRemove', 1, 'User Groups'),
('OnBeforeUserGroupFormSave', 1, 'User Groups'),
('OnBeforeWebLogin', 3, 'Security'),
('OnBeforeWebLogout', 3, 'Security'),
('OnCacheUpdate', 4, 'System'),
('OnCategoryBeforeRemove', 1, 'Categories'),
('OnCategoryBeforeSave', 1, 'Categories'),
('OnCategoryRemove', 1, 'Categories'),
('OnCategorySave', 1, 'Categories'),
('OnChunkBeforeRemove', 1, 'Chunks'),
('OnChunkBeforeSave', 1, 'Chunks'),
('OnChunkFormDelete', 1, 'Chunks'),
('OnChunkFormPrerender', 1, 'Chunks'),
('OnChunkFormRender', 1, 'Chunks'),
('OnChunkFormSave', 1, 'Chunks'),
('OnChunkRemove', 1, 'Chunks'),
('OnChunkSave', 1, 'Chunks'),
('OnContextBeforeRemove', 1, 'Contexts'),
('OnContextBeforeSave', 1, 'Contexts'),
('OnContextFormPrerender', 2, 'Contexts'),
('OnContextFormRender', 2, 'Contexts'),
('OnContextRemove', 1, 'Contexts'),
('OnContextSave', 1, 'Contexts'),
('OnDocFormDelete', 1, 'Resources'),
('OnDocFormPrerender', 1, 'Resources'),
('OnDocFormRender', 1, 'Resources'),
('OnDocFormSave', 1, 'Resources'),
('OnDocPublished', 5, 'Resources'),
('OnDocUnPublished', 5, 'Resources'),
('OnElementNotFound', 1, 'System'),
('OnEmptyTrash', 1, 'Resources'),
('OnFileCreateFormPrerender', 1, 'System'),
('OnFileEditFormPrerender', 1, 'System'),
('OnFileManagerBeforeUpload', 1, 'System'),
('OnFileManagerDirCreate', 1, 'System'),
('OnFileManagerDirRemove', 1, 'System'),
('OnFileManagerDirRename', 1, 'System'),
('OnFileManagerFileCreate', 1, 'System'),
('OnFileManagerFileRemove', 1, 'System'),
('OnFileManagerFileRename', 1, 'System'),
('OnFileManagerFileUpdate', 1, 'System'),
('OnFileManagerMoveObject', 1, 'System'),
('OnFileManagerUpload', 1, 'System'),
('OnHandleRequest', 5, 'System'),
('OnInitCulture', 1, 'Internationalization'),
('OnLoadWebDocument', 5, 'System'),
('OnLoadWebPageCache', 4, 'System'),
('OnManagerAuthentication', 2, 'Security'),
('OnManagerLogin', 2, 'Security'),
('OnManagerLoginFormPrerender', 2, 'Security'),
('OnManagerLoginFormRender', 2, 'Security'),
('OnManagerLogout', 2, 'Security'),
('OnManagerPageAfterRender', 2, 'System'),
('OnManagerPageBeforeRender', 2, 'System'),
('OnManagerPageInit', 2, 'System'),
('OnMediaSourceBeforeFormDelete', 1, 'Media Sources'),
('OnMediaSourceBeforeFormSave', 1, 'Media Sources'),
('OnMediaSourceDuplicate', 1, 'Media Sources'),
('OnMediaSourceFormDelete', 1, 'Media Sources'),
('OnMediaSourceFormSave', 1, 'Media Sources'),
('OnMediaSourceGetProperties', 1, 'Media Sources'),
('OnMODXInit', 5, 'System'),
('OnPackageInstall', 2, 'Package Manager'),
('OnPackageRemove', 2, 'Package Manager'),
('OnPackageUninstall', 2, 'Package Manager'),
('OnPageNotFound', 1, 'System'),
('OnPageUnauthorized', 1, 'Security'),
('OnParseDocument', 5, 'System'),
('OnPluginBeforeRemove', 1, 'Plugins'),
('OnPluginBeforeSave', 1, 'Plugins'),
('OnPluginEventBeforeRemove', 1, 'Plugin Events'),
('OnPluginEventBeforeSave', 1, 'Plugin Events'),
('OnPluginEventRemove', 1, 'Plugin Events'),
('OnPluginEventSave', 1, 'Plugin Events'),
('OnPluginFormDelete', 1, 'Plugins'),
('OnPluginFormPrerender', 1, 'Plugins'),
('OnPluginFormRender', 1, 'Plugins'),
('OnPluginFormSave', 1, 'Plugins'),
('OnPluginRemove', 1, 'Plugins'),
('OnPluginSave', 1, 'Plugins'),
('OnPropertySetBeforeRemove', 1, 'Property Sets'),
('OnPropertySetBeforeSave', 1, 'Property Sets'),
('OnPropertySetRemove', 1, 'Property Sets'),
('OnPropertySetSave', 1, 'Property Sets'),
('OnResourceAddToResourceGroup', 1, 'Resources'),
('OnResourceAutoPublish', 1, 'Resources'),
('OnResourceBeforeSort', 1, 'Resources'),
('OnResourceCacheUpdate', 1, 'Resources'),
('OnResourceDelete', 1, 'Resources'),
('OnResourceDuplicate', 1, 'Resources'),
('OnResourceGroupBeforeRemove', 1, 'Security'),
('OnResourceGroupBeforeSave', 1, 'Security'),
('OnResourceGroupRemove', 1, 'Security'),
('OnResourceGroupSave', 1, 'Security'),
('OnResourceRemoveFromResourceGroup', 1, 'Resources'),
('OnResourceSort', 1, 'Resources'),
('OnResourceToolbarLoad', 1, 'Resources'),
('OnResourceTVFormPrerender', 1, 'Resources'),
('OnResourceTVFormRender', 1, 'Resources'),
('OnResourceUndelete', 1, 'Resources'),
('OnRichTextBrowserInit', 1, 'RichText Editor'),
('OnRichTextEditorInit', 1, 'RichText Editor'),
('OnRichTextEditorRegister', 1, 'RichText Editor'),
('OnSiteRefresh', 1, 'System'),
('OnSiteSettingsRender', 1, 'Settings'),
('OnSnipFormDelete', 1, 'Snippets'),
('OnSnipFormPrerender', 1, 'Snippets'),
('OnSnipFormRender', 1, 'Snippets'),
('OnSnipFormSave', 1, 'Snippets'),
('OnSnippetBeforeRemove', 1, 'Snippets'),
('OnSnippetBeforeSave', 1, 'Snippets'),
('OnSnippetRemove', 1, 'Snippets'),
('OnSnippetSave', 1, 'Snippets'),
('OnTempFormDelete', 1, 'Templates'),
('OnTempFormPrerender', 1, 'Templates'),
('OnTempFormRender', 1, 'Templates'),
('OnTempFormSave', 1, 'Templates'),
('OnTemplateBeforeRemove', 1, 'Templates'),
('OnTemplateBeforeSave', 1, 'Templates'),
('OnTemplateRemove', 1, 'Templates'),
('OnTemplateSave', 1, 'Templates'),
('OnTemplateVarBeforeRemove', 1, 'Template Variables'),
('OnTemplateVarBeforeSave', 1, 'Template Variables'),
('OnTemplateVarRemove', 1, 'Template Variables'),
('OnTemplateVarSave', 1, 'Template Variables'),
('OnTVFormDelete', 1, 'Template Variables'),
('OnTVFormPrerender', 1, 'Template Variables'),
('OnTVFormRender', 1, 'Template Variables'),
('OnTVFormSave', 1, 'Template Variables'),
('OnTVInputPropertiesList', 1, 'Template Variables'),
('OnTVInputRenderList', 1, 'Template Variables'),
('OnTVOutputRenderList', 1, 'Template Variables'),
('OnTVOutputRenderPropertiesList', 1, 'Template Variables'),
('OnUserActivate', 1, 'Users'),
('OnUserAddToGroup', 1, 'User Groups'),
('OnUserBeforeAddToGroup', 1, 'User Groups'),
('OnUserBeforeRemove', 1, 'Users'),
('OnUserBeforeRemoveFromGroup', 1, 'User Groups'),
('OnUserBeforeSave', 1, 'Users'),
('OnUserChangePassword', 1, 'Users'),
('OnUserDeactivate', 1, 'Users'),
('OnUserDuplicate', 1, 'Users'),
('OnUserFormDelete', 1, 'Users'),
('OnUserFormPrerender', 1, 'Users'),
('OnUserFormRender', 1, 'Users'),
('OnUserFormSave', 1, 'Users'),
('OnUserGroupBeforeRemove', 1, 'User Groups'),
('OnUserGroupBeforeSave', 1, 'User Groups'),
('OnUserGroupFormSave', 1, 'User Groups'),
('OnUserGroupRemove', 1, 'User Groups'),
('OnUserGroupSave', 1, 'User Groups'),
('OnUserNotFound', 1, 'Users'),
('OnUserProfileBeforeRemove', 1, 'User Profiles'),
('OnUserProfileBeforeSave', 1, 'User Profiles'),
('OnUserProfileRemove', 1, 'User Profiles'),
('OnUserProfileSave', 1, 'User Profiles'),
('OnUserRemove', 1, 'Users'),
('OnUserRemoveFromGroup', 1, 'User Groups'),
('OnUserSave', 1, 'Users'),
('OnWebAuthentication', 3, 'Security'),
('OnWebLogin', 3, 'Security'),
('OnWebLogout', 3, 'Security'),
('OnWebPageComplete', 5, 'System'),
('OnWebPageInit', 5, 'System'),
('OnWebPagePrerender', 5, 'System'),
('pdoToolsOnFenomInit', 6, 'pdoTools');

-- --------------------------------------------------------

--
-- Table structure for table `modx_system_settings`
--

CREATE TABLE `modx_system_settings` (
  `key` varchar(50) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(191) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_system_settings`
--

INSERT INTO `modx_system_settings` (`key`, `value`, `xtype`, `namespace`, `area`, `editedon`) VALUES
('access_category_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('access_context_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('access_resource_group_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('ace.fold_widgets', '1', 'combo-boolean', 'ace', 'general', NULL),
('ace.font_size', '13px', 'textfield', 'ace', 'general', NULL),
('ace.grow', '', 'textfield', 'ace', 'general', NULL),
('ace.height', '', 'textfield', 'ace', 'general', NULL),
('ace.html_elements_mime', '', 'textfield', 'ace', 'general', NULL),
('ace.show_invisibles', '0', 'combo-boolean', 'ace', 'general', NULL),
('ace.snippets', '', 'textarea', 'ace', 'general', NULL),
('ace.soft_tabs', '1', 'combo-boolean', 'ace', 'general', NULL),
('ace.tab_size', '4', 'textfield', 'ace', 'general', NULL),
('ace.theme', 'chrome', 'textfield', 'ace', 'general', NULL),
('ace.word_wrap', '', 'combo-boolean', 'ace', 'general', NULL),
('allow_forward_across_contexts', '', 'combo-boolean', 'core', 'system', NULL),
('allow_manager_login_forgot_password', '1', 'combo-boolean', 'core', 'authentication', NULL),
('allow_multiple_emails', '1', 'combo-boolean', 'core', 'authentication', NULL),
('allow_tags_in_post', '', 'combo-boolean', 'core', 'system', NULL),
('allow_tv_eval', '1', 'combo-boolean', 'core', 'system', NULL),
('anonymous_sessions', '1', 'combo-boolean', 'core', 'session', NULL),
('archive_with', '', 'combo-boolean', 'core', 'system', NULL),
('automatic_alias', '1', 'combo-boolean', 'core', 'furls', NULL),
('automatic_template_assignment', 'parent', 'textfield', 'core', 'site', NULL),
('auto_check_pkg_updates', '1', 'combo-boolean', 'core', 'system', NULL),
('auto_check_pkg_updates_cache_expire', '15', 'textfield', 'core', 'system', NULL),
('auto_isfolder', '1', 'combo-boolean', 'core', 'site', NULL),
('auto_menuindex', '1', 'combo-boolean', 'core', 'site', NULL),
('base_help_url', '//docs.modx.com/help/', 'textfield', 'core', 'manager', NULL),
('blocked_minutes', '60', 'textfield', 'core', 'authentication', NULL),
('cache_action_map', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_alias_map', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_context_settings', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_db', '0', 'combo-boolean', 'core', 'caching', NULL),
('cache_db_expires', '0', 'textfield', 'core', 'caching', NULL),
('cache_db_session', '0', 'combo-boolean', 'core', 'caching', NULL),
('cache_db_session_lifetime', '', 'textfield', 'core', 'caching', NULL),
('cache_default', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_expires', '0', 'textfield', 'core', 'caching', NULL),
('cache_format', '0', 'textfield', 'core', 'caching', NULL),
('cache_handler', 'xPDOFileCache', 'textfield', 'core', 'caching', NULL),
('cache_lang_js', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_lexicon_topics', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_noncore_lexicon_topics', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource_clear_partial', '0', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource_expires', '0', 'textfield', 'core', 'caching', NULL),
('cache_scripts', '1', 'combo-boolean', 'core', 'caching', NULL),
('clear_cache_refresh_trees', '0', 'combo-boolean', 'core', 'caching', NULL),
('collections.mgr_datetime_format', 'M d, g:i a', 'textfield', 'collections', 'manager', NULL),
('collections.mgr_date_format', 'M d', 'textfield', 'collections', 'manager', NULL),
('collections.mgr_time_format', 'g:i a', 'textfield', 'collections', 'manager', NULL),
('collections.renderer_image_path', '', 'textfield', 'collections', 'manager', NULL),
('collections.tree_tbar_collection', '0', 'combo-boolean', 'collections', 'manager', NULL),
('collections.tree_tbar_selection', '0', 'combo-boolean', 'collections', 'manager', NULL),
('collections.user_css', '', 'textfield', 'collections', 'manager', NULL),
('collections.user_js', '', 'textfield', 'collections', 'manager', NULL),
('compress_css', '0', 'combo-boolean', 'core', 'manager', '2021-08-06 10:12:17'),
('compress_js', '0', 'combo-boolean', 'core', 'manager', '2021-08-06 10:12:17'),
('compress_js_max_files', '10', 'textfield', 'core', 'manager', NULL),
('confirm_navigation', '1', 'combo-boolean', 'core', 'manager', NULL),
('container_suffix', '/', 'textfield', 'core', 'furls', NULL),
('context_tree_sort', '1', 'combo-boolean', 'core', 'manager', NULL),
('context_tree_sortby', 'rank', 'textfield', 'core', 'manager', NULL),
('context_tree_sortdir', 'ASC', 'textfield', 'core', 'manager', NULL),
('cultureKey', 'ru', 'modx-combo-language', 'core', 'language', '2021-08-06 10:12:17'),
('date_timezone', '', 'textfield', 'core', 'system', NULL),
('debug', '', 'textfield', 'core', 'system', NULL),
('default_content_type', '1', 'modx-combo-content-type', 'core', 'site', NULL),
('default_context', 'web', 'modx-combo-context', 'core', 'site', NULL),
('default_duplicate_publish_option', 'preserve', 'textfield', 'core', 'manager', NULL),
('default_media_source', '1', 'modx-combo-source', 'core', 'manager', NULL),
('default_media_source_type', 'sources.modFileMediaSource', 'modx-combo-source-type', 'core', 'manager', NULL),
('default_per_page', '20', 'textfield', 'core', 'manager', NULL),
('default_template', '1', 'modx-combo-template', 'core', 'site', NULL),
('default_username', '(anonymous)', 'textfield', 'core', 'session', NULL),
('editor_css_path', '', 'textfield', 'core', 'editor', NULL),
('editor_css_selectors', '', 'textfield', 'core', 'editor', NULL),
('emailsender', 'masterkadaj@gmail.com', 'textfield', 'core', 'authentication', '2021-08-06 10:12:17'),
('emailsubject', 'Your login details', 'textfield', 'core', 'authentication', NULL),
('enable_dragdrop', '1', 'combo-boolean', 'core', 'manager', NULL),
('enable_gravatar', '1', 'combo-boolean', 'core', 'manager', NULL),
('error_log_filename', 'error.log', 'textfield', 'core', 'system', NULL),
('error_log_filepath', '', 'textfield', 'core', 'system', NULL),
('error_page', '1', 'textfield', 'core', 'site', NULL),
('extension_packages', '{\"1\":{\"collections\":{\"path\":\"[[++core_path]]components/collections/model/\"}},\"2\":{\"lingua\":{\"tablePrefix\":\"modx_lingua_\",\"path\":\"[[++core_path]]components/lingua/model/\"}}}', 'textfield', 'core', 'system', '2021-08-12 11:09:06'),
('failed_login_attempts', '5', 'textfield', 'core', 'authentication', NULL),
('feed_modx_news', 'https://feeds.feedburner.com/modx-announce', 'textfield', 'core', 'system', NULL),
('feed_modx_news_enabled', '1', 'combo-boolean', 'core', 'system', NULL),
('feed_modx_security', 'https://forums.modx.com/board.xml?board=294', 'textfield', 'core', 'system', NULL),
('feed_modx_security_enabled', '1', 'combo-boolean', 'core', 'system', NULL),
('fe_editor_lang', 'en', 'modx-combo-language', 'core', 'language', NULL),
('filemanager_path', '', 'textfield', 'core', 'file', NULL),
('filemanager_path_relative', '1', 'combo-boolean', 'core', 'file', NULL),
('filemanager_url', '', 'textfield', 'core', 'file', NULL),
('filemanager_url_relative', '1', 'combo-boolean', 'core', 'file', NULL),
('forgot_login_email', '<p>Hello [[+username]],</p>\n<p>A request for a password reset has been issued for your MODX user. If you sent this, you may follow this link and use this password to login. If you did not send this request, please ignore this email.</p>\n\n<p>\n    <strong>Activation Link:</strong> [[+url_scheme]][[+http_host]][[+manager_url]]?modahsh=[[+hash]]<br />\n    <strong>Username:</strong> [[+username]]<br />\n    <strong>Password:</strong> [[+password]]<br />\n</p>\n\n<p>After you log into the MODX Manager, you can change your password again, if you wish.</p>\n\n<p>Regards,<br />Site Administrator</p>', 'textarea', 'core', 'authentication', NULL),
('form_customization_use_all_groups', '', 'combo-boolean', 'core', 'manager', NULL),
('forward_merge_excludes', 'type,published,class_key', 'textfield', 'core', 'system', NULL),
('friendly_alias_lowercase_only', '1', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_max_length', '0', 'textfield', 'core', 'furls', NULL),
('friendly_alias_realtime', '0', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_restrict_chars', 'pattern', 'textfield', 'core', 'furls', NULL),
('friendly_alias_restrict_chars_pattern', '/[\\0\\x0B\\t\\n\\r\\f\\a&=+%#<>\"~:`@\\?\\[\\]\\{\\}\\|\\^\'\\\\]/', 'textfield', 'core', 'furls', NULL),
('friendly_alias_strip_element_tags', '1', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_translit', 'none', 'textfield', 'core', 'furls', NULL),
('friendly_alias_translit_class', 'translit.modTransliterate', 'textfield', 'core', 'furls', NULL),
('friendly_alias_translit_class_path', '{core_path}components/', 'textfield', 'core', 'furls', NULL),
('friendly_alias_trim_chars', '/.-_', 'textfield', 'core', 'furls', NULL),
('friendly_alias_word_delimiter', '-', 'textfield', 'core', 'furls', NULL),
('friendly_alias_word_delimiters', '-_', 'textfield', 'core', 'furls', NULL),
('friendly_urls', '1', 'combo-boolean', 'core', 'furls', '2021-08-10 14:31:26'),
('friendly_urls_strict', '0', 'combo-boolean', 'core', 'furls', '2021-08-10 14:48:35'),
('global_duplicate_uri_check', '1', 'combo-boolean', 'core', 'furls', '2021-08-10 14:48:43'),
('hidemenu_default', '0', 'combo-boolean', 'core', 'site', NULL),
('inline_help', '1', 'combo-boolean', 'core', 'manager', NULL),
('lingua.code_field', 'lang_code', 'textfield', 'lingua', 'URL', NULL),
('lingua.contexts', 'web', 'textfield', 'lingua', 'general', NULL),
('lingua.debug', '0', 'combo-boolean', 'lingua', 'general', NULL),
('lingua.detect_browser', '0', 'combo-boolean', 'lingua', 'general', NULL),
('lingua.empty_returns_default', '0', 'combo-boolean', 'lingua', 'general', NULL),
('lingua.form_customization', '0', 'combo-boolean', 'lingua', 'manager', NULL),
('lingua.get_key', 'lang', 'textfield', 'lingua', 'URL', NULL),
('lingua.ids', '', 'textfield', 'lingua', 'general', NULL),
('lingua.parents', '', 'textfield', 'lingua', 'general', NULL),
('link_tag_scheme', '-1', 'textfield', 'core', 'site', NULL),
('locale', 'ru_RU.utf8', 'textfield', 'core', 'language', '2021-08-12 10:07:01'),
('lock_ttl', '360', 'textfield', 'core', 'system', NULL),
('log_deprecated', '0', 'combo-boolean', 'core', 'system', '2021-08-12 08:15:59'),
('log_level', '1', 'textfield', 'core', 'system', NULL),
('log_snippet_not_found', '1', 'combo-boolean', 'core', 'site', NULL),
('log_target', 'FILE', 'textfield', 'core', 'system', NULL),
('mail_charset', 'UTF-8', 'modx-combo-charset', 'core', 'mail', NULL),
('mail_encoding', '8bit', 'textfield', 'core', 'mail', NULL),
('mail_smtp_auth', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_autotls', '1', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_helo', '', 'textfield', 'core', 'mail', NULL),
('mail_smtp_hosts', 'localhost', 'textfield', 'core', 'mail', NULL),
('mail_smtp_keepalive', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_pass', '', 'text-password', 'core', 'mail', NULL),
('mail_smtp_port', '587', 'textfield', 'core', 'mail', NULL),
('mail_smtp_prefix', '', 'textfield', 'core', 'mail', NULL),
('mail_smtp_single_to', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_timeout', '10', 'textfield', 'core', 'mail', NULL),
('mail_smtp_user', '', 'textfield', 'core', 'mail', NULL),
('mail_use_smtp', '', 'combo-boolean', 'core', 'mail', NULL),
('main_nav_parent', 'topnav', 'textfield', 'core', 'manager', NULL),
('manager_date_format', 'Y-m-d', 'textfield', 'core', 'manager', NULL),
('manager_direction', 'ltr', 'textfield', 'core', 'language', NULL),
('manager_favicon_url', '', 'textfield', 'core', 'manager', NULL),
('manager_js_cache_file_locking', '1', 'combo-boolean', 'core', 'manager', NULL),
('manager_js_cache_max_age', '3600', 'textfield', 'core', 'manager', NULL),
('manager_js_document_root', '', 'textfield', 'core', 'manager', NULL),
('manager_js_zlib_output_compression', '0', 'combo-boolean', 'core', 'manager', NULL),
('manager_language', 'ru', 'modx-combo-language', 'core', 'language', '2021-08-06 10:12:17'),
('manager_lang_attribute', 'ru', 'textfield', 'core', 'language', '2021-08-06 10:12:17'),
('manager_login_url_alternate', '', 'textfield', 'core', 'authentication', NULL),
('manager_theme', 'default', 'modx-combo-manager-theme', 'core', 'manager', NULL),
('manager_time_format', 'g:i a', 'textfield', 'core', 'manager', NULL),
('manager_use_fullname', '0', 'combo-boolean', 'core', 'manager', '2021-08-10 14:49:46'),
('manager_week_start', '0', 'textfield', 'core', 'manager', NULL),
('mgr_source_icon', 'icon-folder-open-o', 'textfield', 'core', 'manager', NULL),
('mgr_tree_icon_collectioncontainer', 'collectioncontainer', 'textfield', 'collections', 'manager', NULL),
('mgr_tree_icon_context', 'tree-context', 'textfield', 'core', 'manager', NULL),
('mgr_tree_icon_selectioncontainer', 'selectioncontainer', 'textfield', 'collections', 'manager', NULL),
('modx_browser_default_sort', 'name', 'textfield', 'core', 'manager', NULL),
('modx_browser_default_viewmode', 'grid', 'textfield', 'core', 'manager', NULL),
('modx_browser_tree_hide_files', '1', 'combo-boolean', 'core', 'manager', NULL),
('modx_browser_tree_hide_tooltips', '1', 'combo-boolean', 'core', 'manager', NULL),
('modx_charset', 'UTF-8', 'modx-combo-charset', 'core', 'language', NULL),
('parser_class', 'pdoParser', 'textfield', 'pdotools', 'pdotools_main', NULL),
('parser_class_path', '{core_path}components/pdotools/model/pdotools/', 'textfield', 'pdotools', 'pdotools_main', NULL),
('parser_recurse_uncacheable', '1', 'combo-boolean', 'core', 'system', NULL),
('password_generated_length', '10', 'textfield', 'core', 'authentication', NULL),
('password_min_length', '8', 'textfield', 'core', 'authentication', NULL),
('pdoFetch.class', 'pdotools.pdofetch', 'textfield', 'pdotools', 'pdotools_main', NULL),
('pdofetch_class_path', '{core_path}components/pdotools/model/', 'textfield', 'pdotools', 'pdotools_main', NULL),
('pdoTools.class', 'pdotools.pdotools', 'textfield', 'pdotools', 'pdotools_main', NULL),
('pdotools_class_path', '{core_path}components/pdotools/model/', 'textfield', 'pdotools', 'pdotools_main', NULL),
('pdotools_elements_path', '{core_path}elements/', 'textfield', 'pdotools', 'pdotools_main', NULL),
('pdotools_fenom_cache', '', 'combo-boolean', 'pdotools', 'pdotools_main', NULL),
('pdotools_fenom_default', '1', 'combo-boolean', 'pdotools', 'pdotools_main', NULL),
('pdotools_fenom_modx', '', 'combo-boolean', 'pdotools', 'pdotools_main', NULL),
('pdotools_fenom_options', '', 'textarea', 'pdotools', 'pdotools_main', NULL),
('pdotools_fenom_parser', '', 'combo-boolean', 'pdotools', 'pdotools_main', NULL),
('pdotools_fenom_php', '', 'combo-boolean', 'pdotools', 'pdotools_main', NULL),
('pdotools_fenom_save_on_errors', '', 'combo-boolean', 'pdotools', 'pdotools_main', NULL),
('phpthumb_allow_src_above_docroot', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxage', '30', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxfiles', '10000', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxsize', '100', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_source_enabled', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_document_root', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_error_bgcolor', 'CCCCFF', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_error_fontsize', '1', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_error_textcolor', 'FF0000', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_far', 'C', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_imagemagick_path', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_enabled', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_erase_image', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_text_message', 'Off-server thumbnailing is not allowed', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_valid_domains', '{http_host}', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_enabled', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_erase_image', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_require_refer', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_text_message', 'Off-server linking is not allowed', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_valid_domains', '{http_host}', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_watermark_src', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_zoomcrop', '0', 'textfield', 'core', 'phpthumb', NULL),
('preserve_menuindex', '1', 'combo-boolean', 'core', 'manager', NULL),
('principal_targets', 'modAccessContext,modAccessResourceGroup,modAccessCategory,sources.modAccessMediaSource,modAccessNamespace', 'textfield', 'core', 'authentication', NULL),
('proxy_auth_type', 'BASIC', 'textfield', 'core', 'proxy', NULL),
('proxy_host', '', 'textfield', 'core', 'proxy', NULL),
('proxy_password', '', 'text-password', 'core', 'proxy', NULL),
('proxy_port', '', 'textfield', 'core', 'proxy', NULL),
('proxy_username', '', 'textfield', 'core', 'proxy', NULL),
('publish_default', '', 'combo-boolean', 'core', 'site', NULL),
('rb_base_dir', '', 'textfield', 'core', 'file', NULL),
('rb_base_url', '', 'textfield', 'core', 'file', NULL),
('request_controller', 'index.php', 'textfield', 'core', 'gateway', NULL),
('request_method_strict', '0', 'combo-boolean', 'core', 'gateway', NULL),
('request_param_alias', 'q', 'textfield', 'core', 'gateway', NULL),
('request_param_id', 'id', 'textfield', 'core', 'gateway', NULL),
('resolve_hostnames', '0', 'combo-boolean', 'core', 'system', NULL),
('resource_static_allow_absolute', '0', 'combo-boolean', 'core', 'static_resources', NULL),
('resource_static_path', '{assets_path}', 'textfield', 'core', 'static_resources', NULL),
('resource_tree_node_name', 'pagetitle', 'textfield', 'core', 'manager', NULL),
('resource_tree_node_name_fallback', 'pagetitle', 'textfield', 'core', 'manager', NULL),
('resource_tree_node_tooltip', '', 'textfield', 'core', 'manager', NULL),
('richtext_default', '1', 'combo-boolean', 'core', 'manager', NULL),
('search_default', '1', 'combo-boolean', 'core', 'site', NULL),
('send_poweredby_header', '1', 'combo-boolean', 'core', 'system', '2021-08-06 10:12:17'),
('server_offset_time', '0', 'textfield', 'core', 'system', NULL),
('server_protocol', 'http', 'textfield', 'core', 'system', NULL),
('session_cookie_domain', '', 'textfield', 'core', 'session', NULL),
('session_cookie_httponly', '1', 'combo-boolean', 'core', 'session', NULL),
('session_cookie_lifetime', '604800', 'textfield', 'core', 'session', NULL),
('session_cookie_path', '', 'textfield', 'core', 'session', NULL),
('session_cookie_samesite', '', 'textfield', 'core', 'session', NULL),
('session_cookie_secure', '', 'combo-boolean', 'core', 'session', NULL),
('session_gc_maxlifetime', '604800', 'textfield', 'core', 'session', NULL),
('session_handler_class', 'modSessionHandler', 'textfield', 'core', 'session', NULL),
('session_name', '', 'textfield', 'core', 'session', NULL),
('settings_distro', 'traditional', 'textfield', 'core', 'system', NULL),
('settings_version', '2.8.3-pl', 'textfield', 'core', 'system', NULL),
('set_header', '1', 'combo-boolean', 'core', 'system', NULL),
('show_tv_categories_header', '1', 'combo-boolean', 'core', 'manager', NULL),
('signupemail_message', '<p>Hello [[+uid]],</p>\n    <p>Here are your login details for the [[+sname]] MODX Manager:</p>\n\n    <p>\n        <strong>Username:</strong> [[+uid]]<br />\n        <strong>Password:</strong> [[+pwd]]<br />\n    </p>\n\n    <p>Once you log into the MODX Manager at [[+surl]], you can change your password.</p>\n\n    <p>Regards,<br />Site Administrator</p>', 'textarea', 'core', 'authentication', NULL),
('site_name', 'MODX Revolution', 'textfield', 'core', 'site', NULL),
('site_start', '1', 'textfield', 'core', 'site', NULL),
('site_status', '1', 'combo-boolean', 'core', 'site', NULL),
('site_unavailable_message', 'The site is currently unavailable', 'textfield', 'core', 'site', NULL),
('site_unavailable_page', '0', 'textfield', 'core', 'site', NULL),
('static_elements_automate_chunks', '0', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_plugins', '0', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_snippets', '0', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_templates', '0', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_tvs', '0', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_basepath', '', 'textfield', 'core', 'static_elements', NULL),
('static_elements_default_category', '0', 'modx-combo-category', 'core', 'static_elements', NULL),
('static_elements_default_mediasource', '0', 'modx-combo-source', 'core', 'static_elements', NULL),
('strip_image_paths', '1', 'combo-boolean', 'core', 'file', NULL),
('symlink_merge_fields', '1', 'combo-boolean', 'core', 'site', NULL),
('syncsite_default', '1', 'combo-boolean', 'core', 'caching', NULL),
('topmenu_show_descriptions', '1', 'combo-boolean', 'core', 'manager', NULL),
('tree_default_sort', 'menuindex', 'textfield', 'core', 'manager', NULL),
('tree_root_id', '0', 'numberfield', 'core', 'manager', NULL),
('tvs_below_content', '0', 'combo-boolean', 'core', 'manager', NULL),
('udperms_allowroot', '', 'combo-boolean', 'core', 'authentication', NULL),
('unauthorized_page', '1', 'textfield', 'core', 'site', NULL),
('upload_check_exists', '1', 'combo-boolean', 'core', 'file', NULL),
('upload_files', 'txt,html,htm,xml,js,js.map,css,scss,less,css.map,zip,gz,rar,z,tgz,tar,mp3,mp4,aac,wav,au,wmv,avi,mpg,mpeg,pdf,doc,docx,xls,xlsx,ppt,pptx,jpg,jpeg,png,tiff,svg,svgz,gif,psd,ico,bmp,webp,odt,ods,odp,odb,odg,odf,md,ttf,woff,woff2,eot', 'textfield', 'core', 'file', NULL),
('upload_flash', 'swf,fla', 'textfield', 'core', 'file', NULL),
('upload_images', 'jpg,jpeg,png,gif,psd,ico,bmp,tiff,svg,svgz,webp', 'textfield', 'core', 'file', NULL),
('upload_maxsize', '33554432', 'textfield', 'core', 'file', '2021-08-06 10:12:17'),
('upload_media', 'mp3,wav,au,wmv,avi,mpg,mpeg', 'textfield', 'core', 'file', NULL),
('user_nav_parent', 'usernav', 'textfield', 'core', 'manager', NULL),
('use_alias_path', '1', 'combo-boolean', 'core', 'furls', '2021-08-10 14:31:55'),
('use_browser', '1', 'combo-boolean', 'core', 'file', NULL),
('use_context_resource_table', '1', 'combo-boolean', 'core', 'caching', NULL),
('use_editor', '0', 'combo-boolean', 'core', 'editor', '2021-08-06 10:46:54'),
('use_frozen_parent_uris', '0', 'combo-boolean', 'core', 'furls', NULL),
('use_multibyte', '1', 'combo-boolean', 'core', 'language', '2021-08-06 10:12:17'),
('use_weblink_target', '', 'combo-boolean', 'core', 'site', NULL),
('webpwdreminder_message', '<p>Hello [[+uid]],</p>\n\n    <p>To activate your new password click the following link:</p>\n\n    <p>[[+surl]]</p>\n\n    <p>If successful you can use the following password to login:</p>\n\n    <p><strong>Password:</strong> [[+pwd]]</p>\n\n    <p>If you did not request this email then please ignore it.</p>\n\n    <p>Regards,<br />\n    Site Administrator</p>', 'textarea', 'core', 'authentication', NULL),
('websignupemail_message', '<p>Hello [[+uid]],</p>\n\n    <p>Here are your login details for [[+sname]]:</p>\n\n    <p><strong>Username:</strong> [[+uid]]<br />\n    <strong>Password:</strong> [[+pwd]]</p>\n\n    <p>Once you log into [[+sname]] at [[+surl]], you can change your password.</p>\n\n    <p>Regards,<br />\n    Site Administrator</p>', 'textarea', 'core', 'authentication', NULL),
('welcome_action', 'welcome', 'textfield', 'core', 'manager', NULL),
('welcome_namespace', 'core', 'textfield', 'core', 'manager', NULL),
('welcome_screen', '', 'combo-boolean', 'core', 'manager', '2021-08-06 10:15:35'),
('welcome_screen_url', '//misc.modx.com/revolution/welcome.28.html', 'textfield', 'core', 'manager', NULL),
('which_editor', '', 'modx-combo-rte', 'core', 'editor', NULL),
('which_element_editor', 'Ace', 'modx-combo-rte', 'core', 'editor', '2021-08-12 10:04:07'),
('xhtml_urls', '1', 'combo-boolean', 'core', 'site', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_transport_packages`
--

CREATE TABLE `modx_transport_packages` (
  `signature` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `installed` datetime DEFAULT NULL,
  `state` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `workspace` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `provider` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `disabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `source` tinytext,
  `manifest` text,
  `attributes` mediumtext,
  `package_name` varchar(191) NOT NULL,
  `metadata` text,
  `version_major` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `version_minor` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `version_patch` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `release` varchar(100) NOT NULL DEFAULT '',
  `release_index` smallint(5) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_transport_packages`
--

INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('ace-1.9.1-pl', '2021-08-06 13:26:32', '2021-08-12 10:04:07', '2021-08-12 13:04:07', 0, 1, 1, 0, 'ace-1.9.1-pl.transport.zip', NULL, 'a:8:{s:7:\"license\";s:15218:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:271:\"--------------------\nExtra: Ace\n--------------------\nSince: March 29th, 2012\nAuthor: Danil Kostin <danya.postfactum@gmail.com>\nLicense: GNU GPLv2 (or later at your option)\n\nIntegrates Ace Code Editor into MODx Revolution.\n\nPress Ctrl+Alt+H to see all available shortcuts.\";s:9:\"changelog\";s:4306:\"Changelog for Ace integration into MODx Revolution.\n\nAce 1.9.1\n====================================\n- Fixed: Changed fonts\n- Updated: emmet.js with the support flex css styles and many other combinations\n\nAce 1.9.0\n====================================\n- Added: autodetecting file mode by modelist.js [#7]\n- Added: new modes from ace-builds for version 1.2.0\n\nAce 1.8.0\n====================================\n- Added: autocompletion for php functions.\n\nAce 1.7.0\n====================================\n- Added: new system setting \"ace.grow\".\n- Added: new system setting \"ace.html_elements_mime\".\n\nAce 1.6.5\n====================================\n- Added: \"Twig\" syntax for support of Twig in chunks.\n- Changed: Plugin is not static anymore.\n\nAce 1.6.4\n====================================\n- Fixed: Support of emmet in smarty mode. Again.\n\nAce 1.6.3\n====================================\n- Fixed: Support of emmet in smarty mode.\n\nAce 1.6.2\n====================================\n- Fixed: Editor mode handling.\n- Added: \"Markdown\" syntax for mime type \"text/x-markdown\".\n\nAce 1.6.1\n====================================\n- Fixed : Work with enabled system setting \"compress_js\".\n\nAce 1.6.0\n====================================\n- Added: \"Smarty\" syntax for support of Fenom in chunks.\n- Updated: Ace to version 1.2.0.\n\nAce 1.5.1\n====================================\n- Fixed: Bug with narrowing of the textarea.\n\nAce 1.5.0\n====================================\n- Changed: Assets are moved back to /assets/\n- Fixed: MODx tag completions (was completely broken)\n- Added: Editor height setting\n\nAce 1.4.3\n====================================\n- Added: MODx tag completions (Ctrl+Space)\n- Fixed: Issue caused AjaxManager (MODx Manager speed booster plugin) tree drag\'n\'drop bug\n\nAce 1.4.2\n====================================\n- Added: Undo coalescing\n- Changed: Mac fullscreen command is bound to Command+F12\n- Added: Drag delay (allow to start new selection inside current one) for Mac\n- Fixed: Use file extension of static chunks to detect code syntax\n\n\nAce 1.4.1\n====================================\n- Fixed: Tab handling\n- Fixed: Emmet shortcut listing by Ctr+Alt+H\n- Added: Expandable snippets support (see ace.snippets setting)\n- Added: Emmet wrap_with_abbreviation command (Alt+W)\n\nAce 1.4.0\n====================================\n- Added: Emmet (aka Zen Coding) support\n- Added: Terminal dark theme\n- Added: Hotkey table (Ctrl+Alt+H)\n- Fixed: Resource overview fatal error\n- Changed: Assets are moved to /manager/assets/components/\n\nAce 1.3.3\n====================================\n- Added: PHP live syntax check\n- Added: Chaos dark theme\n- Added: Setting show_invisibles\n\n\nAce 1.3.2\n====================================\n- Fixed: The bug while installing the Ace\n- Fixed: Broken word_wrap setting\n- Added: Tab settings (tab size, soft tab)\n- Added: Now completele compatible with AjaxManager extra\n\n\nAce 1.3.1\n====================================\n- Changed: Plugin content now is stored in static file\n\n\nAce 1.3.0\n====================================\n- Added: German translation\n- Added: MODx tags highlighting\n- Added: Ambiance and xcode themes\n- Added: less/scss syntax highlighting\n- Added: Fullwindow mode (Ctrl + F11)\n- Changed: Editor now ignores `wich_editor` setting. Set `use_editor` to false to use ACE for Resources.\n\n\nAce 1.2.1\n====================================\n- Changed: Assets are moved to manager folder\n- Added: Font size setting\n- Added: \"GitHub\" theme\n- Added: Support of html5 drag\'n\'drop (accepting of dropped text)\n- Added: XML / HTML tag autoclosing\n- Fixed: broken en lexicon and php 5.3 incompatibility\n\n\nAce 1.2.0\n====================================\n- Removed: Some unnecessary options\n- Changed: Editor options are moved to system settings\n- Fixed: Multiple little editor bugs\n- Added: Add missing \"OnFileEditFormPrerender\" event to MODx\n- Added: Multiline editing\n- Added: Advanced find/replace window\n\n\nAce 1.1.0\n====================================\n- Fixed: Fatal error on document create event\n- Fixed: Changing of properties has no effect\n- Added: File edition support\n- Added: MODx tree elements drag\'n\'drop support\n- Added: Auto-assigning which_element_editor to Ace\n\n\nAce 1.0.0\n====================================\n- Added: Plugin properties to adjust how Ace behaves\n- Initial commit\";s:9:\"signature\";s:12:\"ace-1.9.1-pl\";s:6:\"action\";s:26:\"workspace/packages/install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:40:\"/workspace/package/install/ace-1.9.1-pl/\";s:14:\"package_action\";i:0;}', 'Ace', 'a:38:{s:2:\"id\";s:24:\"5fa434b544f12b4f4e72dfc2\";s:7:\"package\";s:24:\"4f6e2782f245544fe8000014\";s:12:\"display_name\";s:12:\"ace-1.9.1-pl\";s:4:\"name\";s:3:\"Ace\";s:7:\"version\";s:5:\"1.9.1\";s:13:\"version_major\";s:1:\"1\";s:13:\"version_minor\";s:1:\"9\";s:13:\"version_patch\";s:1:\"1\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:0:\"\";s:6:\"author\";s:10:\"ibochkarev\";s:11:\"description\";s:376:\"<p>New feature: modx tag code autocompletion! Press Ctrl+Space to get code suggestions with descriptions.</p><p>Works for snippets, chunks, system settings, tvs and resource fields, filters and properties.</p><p>Property sets, lexicon entries are not supported. Unfortunately, I have no idea how to retrieve chunk-specific placeholders, so there is no placeholder support.</p>\";s:12:\"instructions\";s:341:\"<p></p><p>Install via Package Management.</p><p>Set editor theme you wish in system settings (change namespace to \"ace\").</p><p>If you want to use this editor for resources, just set system option <i>use_editor</i> to <b>false</b> (global usage), or <i>richtext</i> setting of certain resource to <b>false</b> (specific usage).</p><p></p>\";s:9:\"changelog\";s:4840:\"<p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p>Ace 1.8.0</p><p>====================================</p><p>- Added: autocompletion for php functions.</p><p></p><p>Ace 1.7.0</p><p>====================================</p><p>- Added: new system setting \"ace.grow\".</p><p>- Added: new system setting \"ace.html_elements_mime\".</p><p></p><p>Ace 1.6.5</p><p>====================================</p><p>- Added: \"Twig\" syntax for support of Twig in chunks.</p><p>- Changed: Plugin is not static anymore.</p><p></p><p>Ace 1.6.4</p><p>====================================</p><p>- Fixed: Support of emmet in smarty mode. Again.</p><p></p><p>Ace 1.6.3</p><p>====================================</p><p>- Fixed: Support of emmet in smarty mode.</p><p></p><p>Ace 1.6.2</p><p>====================================</p><p>- Fixed: Editor mode handling.</p><p>- Added: \"Markdown\" syntax for mime type \"text/x-markdown\".</p><p></p><p>Ace 1.6.1</p><p>====================================</p><p>- Fixed : Work with enabled system setting \"compress_js\".</p><p></p><p>Ace 1.6.0</p><p>====================================</p><p>- Added: \"Smarty\" syntax for support of Fenom in chunks.</p><p>- Updated: Ace to version 1.2.0.</p><p></p><p>Ace 1.5.1</p><p>====================================</p><p>- Fixed: Bug with narrowing of the textarea.</p><p></p><p>Ace 1.5.0</p><p>====================================</p><p>- Changed: Assets are moved back to /assets/</p><p>- Fixed: MODx tag completions (was completely broken)</p><p>- Added: Editor height setting</p><p></p><p>Ace 1.4.3</p><p>====================================</p><p>- Added: MODx tag completions (Ctrl+Space)</p><p>- Fixed: Issue caused AjaxManager (MODx Manager speed booster plugin) tree drag\'n\'drop bug</p><p></p><p>Ace 1.4.2</p><p>====================================</p><p>- Added: Undo coalescing</p><p>- Changed: Mac fullscreen command is bound to Command+F12</p><p>- Added: Drag delay (allow to start new selection inside current one) for Mac</p><p>- Fixed: Use file extension of static chunks to detect code syntax</p><p></p><p></p><p>Ace 1.4.1</p><p>====================================</p><p>- Fixed: Tab handling</p><p>- Fixed: Emmet shortcut listing by Ctr+Alt+H</p><p>- Added: Expandable snippets support (see ace.snippets setting)</p><p>- Added: Emmet wrap_with_abbreviation command (Alt+W)</p><p></p><p>Ace 1.4.0</p><p>====================================</p><p>- Added: Emmet (aka Zen Coding) support</p><p>- Added: Terminal dark theme</p><p>- Added: Hotkey table (Ctrl+Alt+H)</p><p>- Fixed: Resource overview fatal error</p><p>- Changed: Assets are moved to /manager/assets/components/</p><p></p><p>Ace 1.3.3</p><p>====================================</p><p>- Added: PHP live syntax check</p><p>- Added: Chaos dark theme</p><p>- Added: Setting show_invisibles</p><p></p><p></p><p>Ace 1.3.2</p><p>====================================</p><p>- Fixed: The bug while installing the Ace</p><p>- Fixed: Broken word_wrap setting</p><p>- Added: Tab settings (tab size, soft tab)</p><p>- Added: Now completele compatible with AjaxManager extra</p><p></p><p></p><p>Ace 1.3.1</p><p>====================================</p><p>- Changed: Plugin content now is stored in static file</p><p></p><p></p><p>Ace 1.3.0</p><p>====================================</p><p>- Added: German translation</p><p>- Added: MODx tags highlighting</p><p>- Added: Ambiance and xcode themes</p><p>- Added: less/scss syntax highlighting</p><p>- Added: Fullwindow mode (Ctrl + F11)</p><p>- Changed: Editor now ignores `wich_editor` setting. Set `use_editor` to false to use ACE for Resources.</p><p></p><p></p><p>Ace 1.2.1</p><p>====================================</p><p>- Changed: Assets are moved to manager folder</p><p>- Added: Font size setting</p><p>- Added: \"GitHub\" theme</p><p>- Added: Support of html5 drag\'n\'drop (accepting of dropped text)</p><p>- Added: XML / HTML tag autoclosing</p><p>- Fixed: broken en lexicon and php 5.3 incompatibility</p><p></p><p></p><p>Ace 1.2.0</p><p>====================================</p><p>- Removed: Some unnecessary options</p><p>- Changed: Editor options are moved to system settings</p><p>- Fixed: Multiple little editor bugs</p><p>- Added: Add missing \"OnFileEditFormPrerender\" event to MODx</p><p>- Added: Multiline editing</p><p>- Added: Advanced find/replace window</p><p></p><p></p><p>Ace 1.1.0</p><p>====================================</p><p>- Fixed: Fatal error on document create event</p><p>- Fixed: Changing of properties has no effect</p><p>- Added: File edition support</p><p>- Added: MODx tree elements drag\'n\'drop support</p><p>- Added: Auto-assigning which_element_editor to Ace</p><p></p><p></p><p>Ace 1.0.0</p><p>====================================</p><p>- Added: Plugin properties to adjust how Ace behaves</p><p>- Initial commit</p><p></p><p></p>\";s:9:\"createdon\";s:24:\"2020-11-05T17:21:57+0000\";s:9:\"createdby\";s:10:\"ibochkarev\";s:8:\"editedon\";s:24:\"2021-08-06T09:30:36+0000\";s:10:\"releasedon\";s:24:\"2020-11-12T13:01:24+0000\";s:9:\"downloads\";s:6:\"310263\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:5:\"false\";s:8:\"featured\";s:5:\"false\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:24:\"4d4c3fa6b2b0830da9000001\";s:8:\"supports\";s:3:\"2.2\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=5fa434b544f12b4f4e72dfc3\";s:9:\"signature\";s:12:\"ace-1.9.1-pl\";s:11:\"supports_db\";s:5:\"mysql\";s:16:\"minimum_supports\";s:3:\"2.2\";s:9:\"breaks_at\";s:8:\"10000000\";s:10:\"screenshot\";s:68:\"http://modx.s3.amazonaws.com/extras/4f6e2782f245544fe8000014/ace.png\";s:4:\"file\";a:7:{s:2:\"id\";s:24:\"5fa434b544f12b4f4e72dfc3\";s:7:\"version\";s:24:\"5fa434b544f12b4f4e72dfc2\";s:8:\"filename\";s:26:\"ace-1.9.1-pl.transport.zip\";s:9:\"downloads\";s:5:\"22492\";s:6:\"lastip\";s:13:\"37.48.119.219\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=5fa434b544f12b4f4e72dfc3\";}s:17:\"package-signature\";s:12:\"ace-1.9.1-pl\";s:10:\"categories\";s:15:\"richtexteditors\";s:4:\"tags\";s:0:\"\";}', 1, 9, 1, 'pl', 0);
INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('collections-3.7.1-pl', '2021-08-11 13:53:31', '2021-08-11 10:54:17', '2021-08-11 13:54:17', 0, 1, 1, 0, 'collections-3.7.1-pl.transport.zip', NULL, 'a:8:{s:7:\"license\";s:15218:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:222:\"=====================\n     Collections\n     3.7.1 pl\n\n      John Peca\n     john@modx.com\n=====================\n\nAn Extra for MODX Revolution that provides for Resource Collections managed by CollectionContainer Resources.\n\";s:9:\"changelog\";s:10509:\"Changelog for Collections.\n\nCollections 3.7.1\n===================\n- Fix lexicon typo\n- Fix editing from grid\n\nCollections 3.7.0\n===================\n- Make pagination stateful\n- Add CollectionsOnResourceSort custom event\n- Add quick create button\n- Sync with crowdin\n- Fred integration\n- Don\'t makeURL for deleted resources & hide view button\n- Allow duplicating children\n- Fix TV search in selections\n- Check permissions before rendering specific action button / context menu action\n- Handle edit and view child as classic link, allowing to cmd/ctrl click to open in new tab\n- Fix clear filter clearing current folder\n- Remove \'overflow: hidden\' to title on main column view to correct visual bug [#219]\n\nCollections 3.6.0\n===================\n- Add sync tables resolver\n- Added 3 options to speed up large child lists (+10K resources)\n- Fix D&D sort for Resources in depth > 1\n\nCollections 3.5.0\n===================\n- Add collections.renderer.boolean renderer\n- Add AjaxManager compatibility\n- Adjust position of other columns when creating/updating column with position specified\n- Add excludeResources option to getSelections snippet\n- Prevent Collection\'s view reset after quick resource update\n- Use lexicons for the Open button\n- Add overflow ellipse to the main-column\n- Add area to system settings\n\nCollections 3.4.2\n===================\n- Fix saving tv values from update from grid\n- Fix after save event fired on update from grid\n\nCollections 3.4.1\n===================\n- Fix Safari endless reloading\n- Fix Selections when sorting by menuindex\n\nCollections 3.4.0\n===================\n- Pass column name to snippet renderer\n- Prevent permanent sort breaking D&D sort\n- Add Collections.renderer.buttons renderer\n- Allow snippet renderer on non-existing column\n- Add event names to update from grid processor\n- Show folders under collections\n- Show breadcrumbs when browsing folders under collections\n- Import / Export collection views\n- Add quick update for collection & selection children\n- Prevent saving columns with snippet renderer from grid\n- Add new system settings to show create collection/selection button in tree tool bar\n- Display resource id in link resource window\n- Adjust colors in collections grid\n\nCollections 3.3.0\n===================\n- Show assigned templates in Collection\'s view grid\n- Fix ignore parents for pdoResources\n- Add \"Condition for Link resource window\" as a setting for Sellection view\n- Fix displaying ContentBlocks when content is in separate tab\n- Fix checking for template usage in views\n\nCollections 3.2.2\n===================\n- Fix D&D sort for Collection\'s view columns\n- Added Collections.renderer.pagetitleWithIcons\n- Improved handler for inline action buttons allowing icons\n- Fix D&D sort when menuindex is set as default sort field\n- Rename String sort type\n\nCollections 3.2.1\n===================\n- Fix update from previous versions\n\nCollections 3.2.0\n===================\n- Add sort type as a new Collection\'s template column setting\n- Add permanent sort\n- Auto set column label from TV caption or Tagger group name\n- Pass columns value as input to snippet renderer\n- Add sort type as a new Collection\'s view setting\n- Add content disposition as a new Collection\'s view setting\n- Add parent as a new Collection\'s view setting\n- Make TV columns searchable\n- Use modx->getTableName to get table names for Tagger tables\n- Show TV\'s default value in grid\n- Clear filter use sort field & dir from view\n- Prevent error while not passing Resource templates in Collection view\n\nCollections 3.1.1\n===================\n- Fixed showing (empty) template in child\'s template select box\n- Fixed renderer image path\n- Fixed D&D reorder children when element or file tree is selected\n- Fixed back to collection/selection button for static resources/weblinks/symlinks\n- Fixed back to collection/selection button on create new child page\n\nCollections 3.1.0\n===================\n- Fixed reset filter button in Selections\n- Added option to set default values for content type for new children\n- Added system setting to modify image path in image renderer\n- Allow children under Selections\n- Added an option to add quip column\n- Fixed selecting templates in Collection view in Revo 2.2.x\n- Added option to set default values for hidemenu,published,cacheable,searchable and richtext for new children\n- Added option to specify sortby for Selections Resource search query\n- Added option to set label for Back to Collection/Selection button\n- Fixed displaying selection grid with TVs\n- Pass whole row to snippet renderer\n- Fixed sorting by TV with dash in name\n\nCollections 3.0.2\n===================\n- Fixed saving Collections view from Resource\'s settings tab\n- Link Resource to Selection can be done by searching ID\n- Fixed passing sort dir int uppercase format to getSelections\n- Removed parents option from getSelections call\n\nCollections 3.0.1\n===================\n- Fixed update from grid\n\nCollections 3.0.0\n===================\n- Added validation for column name if contains a dot\n- Added PHP renderer (snippet) that will be used for a column\n- Added view option to define Resource Classes that will be available in resource type select\n- Added view option to define context menu items\n- Added view option to define buttons and their style\n- Fixed saving view options from not-activated tab\n- Changed default tree icon for Collections in Revo 2.3\n- Added getSelections snippet (works with getPage, getCache, etc.)\n- Updated view of Collection\'s settings tab\n- Updated Collections view\n- Added CRC for Selections\n- Added back button to Collection\'s children and revert close button to original functionality\n- Fire OnBeforeEmptyTrash and OnEmptyTrash when removing Resource via Collections\n\nCollections 2.2.2\n===================\n- Fixed rendering TV and Tagger columns with dash in name/alias\n\nCollections 2.2.1\n===================\n- Fixed PHP 5.2 compatibility\n\nCollections 2.2.0\n===================\n- Added an option to set position of Content field\n- Added an options to set Tab\'s and New child\'s button label\n- Added Collections.renderer.image for rendering images\n- Added tabs to Collection views to split its settings\n- Splitted Setting tab to vtabs for Resource settings and Collections settings\n- Improved close button in collection\'s childs\n- Fixed showing data in TV columns\n- Added an option to permanently remove deleted resource\n- Fixed duplicate action from context menu\n- Added data controller to show resource owerview page\n- Fix # being appended to manager url when clicking a button\n- Fix strict standards error (PHP 5.4+) in resource/getlist processor\n- Fix not working editlink on pagetitle click in grid\n\nCollections 2.1.0\n===================\n- Added option to duplicate Collection\'s view\n- Updated layout for create/update view\'s column\n- Added view,update,delete,duplicate,publish items to children\'s grid context menu\n- Added children default template, default resource type and allow resource type selection options to collection\'s templates\n- Fixed View button\n- Fixed logging messages from plugin\n\nCollections 2.0.2\n===================\n- Fixed datetime renderers\n\nCollections 2.0.1\n===================\n- Fixed saving collections container in Revolution 2.2.x\n\nCollections 2.0.0\n===================\n- Added collections templates\n- Added ability to create different child type from grid\n- Support for Revolution 2.3\n\nCollections 1.3.3\n===================\n- Remove debugger call :X\n\nCollections 1.3.2\n===================\n- Hotfix for confirm navigation dialog\n- Fixed selecting multiple rows\n- Fixed checking for Tagger\n\nCollections 1.3.1\n===================\n- Release with correct version number\n\nCollections 1.3.0\n===================\n- Support for Tagger in search field in Children tab\n- Added ability to drag and drop child to resource tree to change parent\n- English and German lexicon updates\n\nCollections 1.2.0\n===================\n- Added ability to search via created by full name\n- Added ability to search via created by username\n- Fixed switching child between two Collections\n- Fixed switching great parent to Collections when moving last child\n- Fixed child name after creating a duplicate\n- Added drag & drop sort by menuindex\n\nCollections 1.1.1\n===================\n- #20 Fixed after re-save child set show_in_tree 1\n\nCollections 1.1.0\n===================\n- #9 Added duplicate button\n- #10 Added icon for Collection into the Resource tree\n- #11 Make grid stateful and added some more columns (until clearing cache grid keeps showed/hidden columns and their order)\n- Renamed \"Collection container\" to \"Collection\"\n- #7 Added German translation (thanks to pepebe)\n- #12 Added Czech translation\n- #14 Added Dutch translation (thanks to @mark_hamstra)\n- #15 Added French translation (thanks to @rtripault)\n- #16 #17 Added Russian translation (thanks to vanchelo)\n- #18 Fixed show_in_tree conflict\n\nCollections 1.0.0\n===================\n- Published in MODX extras\n\nCollections 0.8.2\n===================\n- Finished renaming CollectionsContainer -> CollectionContainer\n- Removed chromephp log calls\n\nCollections 0.8.1\n===================\n- Fixed showing aliases in children grid\n\nCollections 0.8.0\n===================\n- Renamed CollectionsContainer to CollectionContainer\n- Fixed returning proper count of children under Collection Container\n\nCollections 0.7.0\n===================\n- Added switchback resolver that will switch all Collections Containers back to modDocument and set show_in_tree to 1 for all Collections children on uninstall\n- Added support for handle class_key switch from CollectionContainer and to CollectionContainer\n\nCollections 0.6.0\n===================\n- Fixed proper showing Collections Container under another Collections Container\n- Fixed proper showing normal containers with children under CRC\n- Added listener for Before Empty Trash event to hide Resources that are under Collections Container and that will not have other children after the trash will be cleaned\n\nCollections 0.5.0\n===================\n- Updated the plugin to inject JS for handling cancel button in Resource Update panel\n\nCollections 0.4.0\n===================\n- Added plugin that handles correct setting of show_in_tree parameter for Resources after creating a new Resource or sorting resources\n\nCollections 0.3.0\n===================\n- Visual improvements for grid with children\n\nCollections 0.2.0\n===================\n- Extended Resource Update panel with new Tab that contains grid with children\n\n\nCollections 0.1.0\n===================\n- Initial release.\n\";s:9:\"signature\";s:20:\"collections-3.7.1-pl\";s:6:\"action\";s:26:\"workspace/packages/install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:48:\"/workspace/package/install/collections-3.7.1-pl/\";s:14:\"package_action\";i:0;}', 'Collections', 'a:38:{s:2:\"id\";s:24:\"5da58b1d3425f947cb21add2\";s:7:\"package\";s:24:\"52aa418862cf2419b80014c5\";s:12:\"display_name\";s:20:\"collections-3.7.1-pl\";s:4:\"name\";s:11:\"Collections\";s:7:\"version\";s:5:\"3.7.1\";s:13:\"version_major\";s:1:\"3\";s:13:\"version_minor\";s:1:\"7\";s:13:\"version_patch\";s:1:\"1\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:0:\"\";s:6:\"author\";s:8:\"theboxer\";s:11:\"description\";s:487:\"<p>Collections is a MODX Revolution Extra that adds a custom CollectionContainer resource class with the following behaviour:</p>\n<ul>\n<li>Any direct child resource will be hidden from the Resource Tree in the Manager, and listed in a grid view (similar to Articles) under a dedicated \"Children\" tab.</li>\n<li>Any children that themselves have children will be shown in the Tree, to be managed normally.</li>\n</ul>\n<p>This project is on GitHub: https://github.com/modxcms/Collections</p>\";s:12:\"instructions\";s:547:\"<p>Install via Package Management</p>\n<p>Sub Collections</p>\n\n<p>Just like the MODX Resource Tree itself, Collections supports nesting. You can create a Collection within another Collection. Sub Collection Containers will be displayed in the resource tree and their children will be displayed in the grid view.</p>\n\n<p>Drag n Drop</p>\n\n<p>You can drag n drop Resources into a Collections container and if they don\'t have children of their own they will be listed in the grid. If they do have children, they\'ll just remain in the Tree as usual.</p>\";s:9:\"changelog\";s:44:\"- Fix lexicon typo  \n- Fix editing from grid\";s:9:\"createdon\";s:24:\"2019-10-15T09:02:21+0000\";s:9:\"createdby\";s:8:\"theboxer\";s:8:\"editedon\";s:24:\"2021-08-11T08:42:45+0000\";s:10:\"releasedon\";s:24:\"2019-10-15T09:02:21+0000\";s:9:\"downloads\";s:6:\"116406\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:4:\"true\";s:8:\"featured\";s:4:\"true\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:24:\"4d4c3fa6b2b0830da9000001\";s:8:\"supports\";s:3:\"2.3\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=5da58b1d3425f947cb21add3\";s:9:\"signature\";s:20:\"collections-3.7.1-pl\";s:11:\"supports_db\";s:5:\"mysql\";s:16:\"minimum_supports\";s:3:\"2.3\";s:9:\"breaks_at\";s:8:\"10000000\";s:10:\"screenshot\";s:80:\"http://modx.s3.amazonaws.com/extras%2F52aa418862cf2419b80014c5%2Fcollections.png\";s:4:\"file\";a:7:{s:2:\"id\";s:24:\"5da58b1d3425f947cb21add3\";s:7:\"version\";s:24:\"5da58b1d3425f947cb21add2\";s:8:\"filename\";s:34:\"collections-3.7.1-pl.transport.zip\";s:9:\"downloads\";s:5:\"20393\";s:6:\"lastip\";s:12:\"31.130.207.8\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=5da58b1d3425f947cb21add3\";}s:17:\"package-signature\";s:20:\"collections-3.7.1-pl\";s:10:\"categories\";s:31:\"administration,blogging,content\";s:4:\"tags\";s:0:\"\";}', 3, 7, 1, 'pl', 0);
INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('getresources-1.7.0-pl', '2021-08-11 14:34:29', '2021-08-11 11:34:40', '2021-08-11 14:34:40', 0, 1, 1, 0, 'getresources-1.7.0-pl.transport.zip', NULL, 'a:8:{s:7:\"license\";s:15218:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:335:\"--------------------\nSnippet: getResources\n--------------------\nVersion: 1.7.0-pl\nReleased: April 29, 2021\nSince: December 28, 2009\nAuthor: Jason Coward <jason@opengeek.com>\n\nA general purpose Resource listing and summarization snippet for MODX Revolution.\n\nOfficial Documentation:\nhttps://docs.modx.com/current/en/extras/getresources\n\";s:9:\"changelog\";s:3660:\"Changelog for getResources.\n\ngetResources 1.7.0-pl (April 29, 2021)\n====================================\n- [#104] Replace deprecated each() usage\n- [#97] Add sortby resources to apply input order\n\ngetResources 1.6.1-pl (December 30, 2013)\n====================================\n- Allow tvFilter values to contain filter operators\n- Allow 0-based idx\n- Pass scriptProperties to wrapperTpl\n- [#30][#80] Only dump properties for invalid tpl when debug enabled\n\ngetResources 1.6.0-pl (February 19, 2013)\n====================================\n- Add tplWrapper for specifying a wrapper template\n\ngetResources 1.5.1-pl (August 23, 2012)\n====================================\n- Add tplOperator property to default properties\n- [#73] Add between tplOperator to conditionalTpls\n\ngetResources 1.5.0-pl (June 15, 2012)\n====================================\n- [#58] Add tplCondition/conditionalTpls support\n- [#67] Add odd property\n- [#60] Allow custom delimiters for tvFilters\n- [#63] Give tplFirst/tplLast precedence over tpl_X/tpl_nX\n- Automatically prepare TV values for media-source dependent TVs\n\ngetResources 1.4.2-pl (December 9, 2011)\n====================================\n- [#25] Add new operators to tvFilters\n- [#37] Consider default values with tvFilters\n- [#57] Fix tpl overrides and improve order\n\ngetResources 1.4.1-pl (December 8, 2011)\n====================================\n- [#57] Add support for factor-based tpls\n- [#54], [#55] Fix processTVList feature\n\ngetResources 1.4.0-pl (September 21, 2011)\n====================================\n- [#50] Use children of parents from other contexts\n- [#45] Add dbCacheFlag to control db caching of getCollection, default to false\n- [#49] Allow comma-delimited list of TV names as includeTVList or processTVList\n\ngetResources 1.3.1-pl (July 14, 2011)\n====================================\n- [#43] Allow 0 as idx property\n- [#9] Fix tvFilters grouping\n- [#46] Fix criteria issue with &resources property\n\ngetResources 1.3.0-pl (March 28, 2011)\n====================================\n- [#33] sortbyTVType: Allow numeric and datetime TV sorting via SQL CAST()\n- [#24] Fix typos in list property options\n- [#4] Support multiple sortby fields via JSON object\n- Use get() instead to toArray() if includeContent is false\n- [#22] Add &toSeparatePlaceholders property for splitting output\n\ngetResources 1.2.2-pl (October 18, 2010)\n====================================\n- [#19] Fix sortbyTV returning duplicate rows\n\ngetResources 1.2.1-pl (October 11, 2010)\n====================================\n- Remove inadvertent call to modX::setLogTarget(\'ECHO\')\n\ngetResources 1.2.0-pl (September 25, 2010)\n====================================\n- Fix error when &parents is not set\n- Allow empty &sortby\n- Add ability to sort by a single Template Variable value (or default value)\n\ngetResources 1.1.0-pl (July 30, 2010)\n====================================\n- Added &toPlaceholder property for assigning results to a placeholder\n- Added &resources property for including/excluding specific resources\n- Added &showDeleted property\n- Allow multiple contexts to be passed into &context\n- Added &showUnpublish property\n- Added getresources.core_path reference for easier development\n- [#ADDON-135] Make output separator configurable via outputSeparator property\n- Add where property to allow ad hoc criteria in JSON format\n\ngetResources 1.0.0-ga (December 29, 2009)\n====================================\n- [#ADDON-81] Allow empty tvPrefix property.\n- [#ADDON-89] Allow parents property to have a value of 0.\n- Changed default value of sortbyAlias to empty string and added sortbyEscaped property with default of 0.\n- Added changelog, license, and readme.\n\";s:9:\"signature\";s:21:\"getresources-1.7.0-pl\";s:6:\"action\";s:26:\"workspace/packages/install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:49:\"/workspace/package/install/getresources-1.7.0-pl/\";s:14:\"package_action\";i:0;}', 'getResources', 'a:38:{s:2:\"id\";s:24:\"608ad48e5338cc65734841d2\";s:7:\"package\";s:24:\"4d556c3db2b083396d000abe\";s:12:\"display_name\";s:21:\"getresources-1.7.0-pl\";s:4:\"name\";s:12:\"getResources\";s:7:\"version\";s:5:\"1.7.0\";s:13:\"version_major\";s:1:\"1\";s:13:\"version_minor\";s:1:\"7\";s:13:\"version_patch\";s:1:\"0\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:1:\"0\";s:6:\"author\";s:8:\"opengeek\";s:11:\"description\";s:115:\"This release of getResources provides PHP 8 support and adds a sortby feature for resources to be sorted as listed.\";s:12:\"instructions\";s:31:\"Install via Package Management.\";s:9:\"changelog\";s:91:\"- [#104] Replace deprecated each() usage\n- [#97] Add sortby resources to apply input order\n\";s:9:\"createdon\";s:24:\"2021-04-29T15:45:18+0000\";s:9:\"createdby\";s:8:\"opengeek\";s:8:\"editedon\";s:24:\"2021-08-11T11:15:30+0000\";s:10:\"releasedon\";s:24:\"2021-04-29T15:45:18+0000\";s:9:\"downloads\";s:6:\"273341\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:4:\"true\";s:8:\"featured\";s:4:\"true\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:24:\"4d4c3fa6b2b0830da9000001\";s:8:\"supports\";s:1:\"2\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=608ad48e5338cc65734841d3\";s:9:\"signature\";s:21:\"getresources-1.7.0-pl\";s:11:\"supports_db\";s:12:\"mysql,sqlsrv\";s:16:\"minimum_supports\";s:1:\"2\";s:9:\"breaks_at\";s:8:\"10000000\";s:10:\"screenshot\";s:0:\"\";s:4:\"file\";a:7:{s:2:\"id\";s:24:\"608ad48e5338cc65734841d3\";s:7:\"version\";s:24:\"608ad48e5338cc65734841d2\";s:8:\"filename\";s:35:\"getresources-1.7.0-pl.transport.zip\";s:9:\"downloads\";s:4:\"4061\";s:6:\"lastip\";s:13:\"91.218.97.145\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=608ad48e5338cc65734841d3\";}s:17:\"package-signature\";s:21:\"getresources-1.7.0-pl\";s:10:\"categories\";s:32:\"blogging,content,navigation,news\";s:4:\"tags\";s:57:\"blog,blogging,resources,getr,getresource,resource,listing\";}', 1, 7, 0, 'pl', 0);
INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('lingua-2.1.0-beta4', '2021-08-06 13:16:18', '2021-08-12 11:09:06', '2021-08-12 14:09:06', 0, 1, 1, 0, 'lingua-2.1.0-beta4.transport.zip', NULL, 'a:8:{s:7:\"license\";s:35146:\"                    GNU GENERAL PUBLIC LICENSE\n                       Version 3, 29 June 2007\n\n Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>\n Everyone is permitted to copy and distribute verbatim copies\n of this license document, but changing it is not allowed.\n\n                            Preamble\n\n  The GNU General Public License is a free, copyleft license for\nsoftware and other kinds of works.\n\n  The licenses for most software and other practical works are designed\nto take away your freedom to share and change the works.  By contrast,\nthe GNU General Public License is intended to guarantee your freedom to\nshare and change all versions of a program--to make sure it remains free\nsoftware for all its users.  We, the Free Software Foundation, use the\nGNU General Public License for most of our software; it applies also to\nany other work released this way by its authors.  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthem if you wish), that you receive source code or can get it if you\nwant it, that you can change the software or use pieces of it in new\nfree programs, and that you know you can do these things.\n\n  To protect your rights, we need to prevent others from denying you\nthese rights or asking you to surrender the rights.  Therefore, you have\ncertain responsibilities if you distribute copies of the software, or if\nyou modify it: responsibilities to respect the freedom of others.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must pass on to the recipients the same\nfreedoms that you received.  You must make sure that they, too, receive\nor can get the source code.  And you must show them these terms so they\nknow their rights.\n\n  Developers that use the GNU GPL protect your rights with two steps:\n(1) assert copyright on the software, and (2) offer you this License\ngiving you legal permission to copy, distribute and/or modify it.\n\n  For the developers\' and authors\' protection, the GPL clearly explains\nthat there is no warranty for this free software.  For both users\' and\nauthors\' sake, the GPL requires that modified versions be marked as\nchanged, so that their problems will not be attributed erroneously to\nauthors of previous versions.\n\n  Some devices are designed to deny users access to install or run\nmodified versions of the software inside them, although the manufacturer\ncan do so.  This is fundamentally incompatible with the aim of\nprotecting users\' freedom to change the software.  The systematic\npattern of such abuse occurs in the area of products for individuals to\nuse, which is precisely where it is most unacceptable.  Therefore, we\nhave designed this version of the GPL to prohibit the practice for those\nproducts.  If such problems arise substantially in other domains, we\nstand ready to extend this provision to those domains in future versions\nof the GPL, as needed to protect the freedom of users.\n\n  Finally, every program is threatened constantly by software patents.\nStates should not allow patents to restrict development and use of\nsoftware on general-purpose computers, but in those that do, we wish to\navoid the special danger that patents applied to a free program could\nmake it effectively proprietary.  To prevent this, the GPL assures that\npatents cannot be used to render the program non-free.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n                       TERMS AND CONDITIONS\n\n  0. Definitions.\n\n  \"This License\" refers to version 3 of the GNU General Public License.\n\n  \"Copyright\" also means copyright-like laws that apply to other kinds of\nworks, such as semiconductor masks.\n\n  \"The Program\" refers to any copyrightable work licensed under this\nLicense.  Each licensee is addressed as \"you\".  \"Licensees\" and\n\"recipients\" may be individuals or organizations.\n\n  To \"modify\" a work means to copy from or adapt all or part of the work\nin a fashion requiring copyright permission, other than the making of an\nexact copy.  The resulting work is called a \"modified version\" of the\nearlier work or a work \"based on\" the earlier work.\n\n  A \"covered work\" means either the unmodified Program or a work based\non the Program.\n\n  To \"propagate\" a work means to do anything with it that, without\npermission, would make you directly or secondarily liable for\ninfringement under applicable copyright law, except executing it on a\ncomputer or modifying a private copy.  Propagation includes copying,\ndistribution (with or without modification), making available to the\npublic, and in some countries other activities as well.\n\n  To \"convey\" a work means any kind of propagation that enables other\nparties to make or receive copies.  Mere interaction with a user through\na computer network, with no transfer of a copy, is not conveying.\n\n  An interactive user interface displays \"Appropriate Legal Notices\"\nto the extent that it includes a convenient and prominently visible\nfeature that (1) displays an appropriate copyright notice, and (2)\ntells the user that there is no warranty for the work (except to the\nextent that warranties are provided), that licensees may convey the\nwork under this License, and how to view a copy of this License.  If\nthe interface presents a list of user commands or options, such as a\nmenu, a prominent item in the list meets this criterion.\n\n  1. Source Code.\n\n  The \"source code\" for a work means the preferred form of the work\nfor making modifications to it.  \"Object code\" means any non-source\nform of a work.\n\n  A \"Standard Interface\" means an interface that either is an official\nstandard defined by a recognized standards body, or, in the case of\ninterfaces specified for a particular programming language, one that\nis widely used among developers working in that language.\n\n  The \"System Libraries\" of an executable work include anything, other\nthan the work as a whole, that (a) is included in the normal form of\npackaging a Major Component, but which is not part of that Major\nComponent, and (b) serves only to enable use of the work with that\nMajor Component, or to implement a Standard Interface for which an\nimplementation is available to the public in source code form.  A\n\"Major Component\", in this context, means a major essential component\n(kernel, window system, and so on) of the specific operating system\n(if any) on which the executable work runs, or a compiler used to\nproduce the work, or an object code interpreter used to run it.\n\n  The \"Corresponding Source\" for a work in object code form means all\nthe source code needed to generate, install, and (for an executable\nwork) run the object code and to modify the work, including scripts to\ncontrol those activities.  However, it does not include the work\'s\nSystem Libraries, or general-purpose tools or generally available free\nprograms which are used unmodified in performing those activities but\nwhich are not part of the work.  For example, Corresponding Source\nincludes interface definition files associated with source files for\nthe work, and the source code for shared libraries and dynamically\nlinked subprograms that the work is specifically designed to require,\nsuch as by intimate data communication or control flow between those\nsubprograms and other parts of the work.\n\n  The Corresponding Source need not include anything that users\ncan regenerate automatically from other parts of the Corresponding\nSource.\n\n  The Corresponding Source for a work in source code form is that\nsame work.\n\n  2. Basic Permissions.\n\n  All rights granted under this License are granted for the term of\ncopyright on the Program, and are irrevocable provided the stated\nconditions are met.  This License explicitly affirms your unlimited\npermission to run the unmodified Program.  The output from running a\ncovered work is covered by this License only if the output, given its\ncontent, constitutes a covered work.  This License acknowledges your\nrights of fair use or other equivalent, as provided by copyright law.\n\n  You may make, run and propagate covered works that you do not\nconvey, without conditions so long as your license otherwise remains\nin force.  You may convey covered works to others for the sole purpose\nof having them make modifications exclusively for you, or provide you\nwith facilities for running those works, provided that you comply with\nthe terms of this License in conveying all material for which you do\nnot control copyright.  Those thus making or running the covered works\nfor you must do so exclusively on your behalf, under your direction\nand control, on terms that prohibit them from making any copies of\nyour copyrighted material outside their relationship with you.\n\n  Conveying under any other circumstances is permitted solely under\nthe conditions stated below.  Sublicensing is not allowed; section 10\nmakes it unnecessary.\n\n  3. Protecting Users\' Legal Rights From Anti-Circumvention Law.\n\n  No covered work shall be deemed part of an effective technological\nmeasure under any applicable law fulfilling obligations under article\n11 of the WIPO copyright treaty adopted on 20 December 1996, or\nsimilar laws prohibiting or restricting circumvention of such\nmeasures.\n\n  When you convey a covered work, you waive any legal power to forbid\ncircumvention of technological measures to the extent such circumvention\nis effected by exercising rights under this License with respect to\nthe covered work, and you disclaim any intention to limit operation or\nmodification of the work as a means of enforcing, against the work\'s\nusers, your or third parties\' legal rights to forbid circumvention of\ntechnological measures.\n\n  4. Conveying Verbatim Copies.\n\n  You may convey verbatim copies of the Program\'s source code as you\nreceive it, in any medium, provided that you conspicuously and\nappropriately publish on each copy an appropriate copyright notice;\nkeep intact all notices stating that this License and any\nnon-permissive terms added in accord with section 7 apply to the code;\nkeep intact all notices of the absence of any warranty; and give all\nrecipients a copy of this License along with the Program.\n\n  You may charge any price or no price for each copy that you convey,\nand you may offer support or warranty protection for a fee.\n\n  5. Conveying Modified Source Versions.\n\n  You may convey a work based on the Program, or the modifications to\nproduce it from the Program, in the form of source code under the\nterms of section 4, provided that you also meet all of these conditions:\n\n    a) The work must carry prominent notices stating that you modified\n    it, and giving a relevant date.\n\n    b) The work must carry prominent notices stating that it is\n    released under this License and any conditions added under section\n    7.  This requirement modifies the requirement in section 4 to\n    \"keep intact all notices\".\n\n    c) You must license the entire work, as a whole, under this\n    License to anyone who comes into possession of a copy.  This\n    License will therefore apply, along with any applicable section 7\n    additional terms, to the whole of the work, and all its parts,\n    regardless of how they are packaged.  This License gives no\n    permission to license the work in any other way, but it does not\n    invalidate such permission if you have separately received it.\n\n    d) If the work has interactive user interfaces, each must display\n    Appropriate Legal Notices; however, if the Program has interactive\n    interfaces that do not display Appropriate Legal Notices, your\n    work need not make them do so.\n\n  A compilation of a covered work with other separate and independent\nworks, which are not by their nature extensions of the covered work,\nand which are not combined with it such as to form a larger program,\nin or on a volume of a storage or distribution medium, is called an\n\"aggregate\" if the compilation and its resulting copyright are not\nused to limit the access or legal rights of the compilation\'s users\nbeyond what the individual works permit.  Inclusion of a covered work\nin an aggregate does not cause this License to apply to the other\nparts of the aggregate.\n\n  6. Conveying Non-Source Forms.\n\n  You may convey a covered work in object code form under the terms\nof sections 4 and 5, provided that you also convey the\nmachine-readable Corresponding Source under the terms of this License,\nin one of these ways:\n\n    a) Convey the object code in, or embodied in, a physical product\n    (including a physical distribution medium), accompanied by the\n    Corresponding Source fixed on a durable physical medium\n    customarily used for software interchange.\n\n    b) Convey the object code in, or embodied in, a physical product\n    (including a physical distribution medium), accompanied by a\n    written offer, valid for at least three years and valid for as\n    long as you offer spare parts or customer support for that product\n    model, to give anyone who possesses the object code either (1) a\n    copy of the Corresponding Source for all the software in the\n    product that is covered by this License, on a durable physical\n    medium customarily used for software interchange, for a price no\n    more than your reasonable cost of physically performing this\n    conveying of source, or (2) access to copy the\n    Corresponding Source from a network server at no charge.\n\n    c) Convey individual copies of the object code with a copy of the\n    written offer to provide the Corresponding Source.  This\n    alternative is allowed only occasionally and noncommercially, and\n    only if you received the object code with such an offer, in accord\n    with subsection 6b.\n\n    d) Convey the object code by offering access from a designated\n    place (gratis or for a charge), and offer equivalent access to the\n    Corresponding Source in the same way through the same place at no\n    further charge.  You need not require recipients to copy the\n    Corresponding Source along with the object code.  If the place to\n    copy the object code is a network server, the Corresponding Source\n    may be on a different server (operated by you or a third party)\n    that supports equivalent copying facilities, provided you maintain\n    clear directions next to the object code saying where to find the\n    Corresponding Source.  Regardless of what server hosts the\n    Corresponding Source, you remain obligated to ensure that it is\n    available for as long as needed to satisfy these requirements.\n\n    e) Convey the object code using peer-to-peer transmission, provided\n    you inform other peers where the object code and Corresponding\n    Source of the work are being offered to the general public at no\n    charge under subsection 6d.\n\n  A separable portion of the object code, whose source code is excluded\nfrom the Corresponding Source as a System Library, need not be\nincluded in conveying the object code work.\n\n  A \"User Product\" is either (1) a \"consumer product\", which means any\ntangible personal property which is normally used for personal, family,\nor household purposes, or (2) anything designed or sold for incorporation\ninto a dwelling.  In determining whether a product is a consumer product,\ndoubtful cases shall be resolved in favor of coverage.  For a particular\nproduct received by a particular user, \"normally used\" refers to a\ntypical or common use of that class of product, regardless of the status\nof the particular user or of the way in which the particular user\nactually uses, or expects or is expected to use, the product.  A product\nis a consumer product regardless of whether the product has substantial\ncommercial, industrial or non-consumer uses, unless such uses represent\nthe only significant mode of use of the product.\n\n  \"Installation Information\" for a User Product means any methods,\nprocedures, authorization keys, or other information required to install\nand execute modified versions of a covered work in that User Product from\na modified version of its Corresponding Source.  The information must\nsuffice to ensure that the continued functioning of the modified object\ncode is in no case prevented or interfered with solely because\nmodification has been made.\n\n  If you convey an object code work under this section in, or with, or\nspecifically for use in, a User Product, and the conveying occurs as\npart of a transaction in which the right of possession and use of the\nUser Product is transferred to the recipient in perpetuity or for a\nfixed term (regardless of how the transaction is characterized), the\nCorresponding Source conveyed under this section must be accompanied\nby the Installation Information.  But this requirement does not apply\nif neither you nor any third party retains the ability to install\nmodified object code on the User Product (for example, the work has\nbeen installed in ROM).\n\n  The requirement to provide Installation Information does not include a\nrequirement to continue to provide support service, warranty, or updates\nfor a work that has been modified or installed by the recipient, or for\nthe User Product in which it has been modified or installed.  Access to a\nnetwork may be denied when the modification itself materially and\nadversely affects the operation of the network or violates the rules and\nprotocols for communication across the network.\n\n  Corresponding Source conveyed, and Installation Information provided,\nin accord with this section must be in a format that is publicly\ndocumented (and with an implementation available to the public in\nsource code form), and must require no special password or key for\nunpacking, reading or copying.\n\n  7. Additional Terms.\n\n  \"Additional permissions\" are terms that supplement the terms of this\nLicense by making exceptions from one or more of its conditions.\nAdditional permissions that are applicable to the entire Program shall\nbe treated as though they were included in this License, to the extent\nthat they are valid under applicable law.  If additional permissions\napply only to part of the Program, that part may be used separately\nunder those permissions, but the entire Program remains governed by\nthis License without regard to the additional permissions.\n\n  When you convey a copy of a covered work, you may at your option\nremove any additional permissions from that copy, or from any part of\nit.  (Additional permissions may be written to require their own\nremoval in certain cases when you modify the work.)  You may place\nadditional permissions on material, added by you to a covered work,\nfor which you have or can give appropriate copyright permission.\n\n  Notwithstanding any other provision of this License, for material you\nadd to a covered work, you may (if authorized by the copyright holders of\nthat material) supplement the terms of this License with terms:\n\n    a) Disclaiming warranty or limiting liability differently from the\n    terms of sections 15 and 16 of this License; or\n\n    b) Requiring preservation of specified reasonable legal notices or\n    author attributions in that material or in the Appropriate Legal\n    Notices displayed by works containing it; or\n\n    c) Prohibiting misrepresentation of the origin of that material, or\n    requiring that modified versions of such material be marked in\n    reasonable ways as different from the original version; or\n\n    d) Limiting the use for publicity purposes of names of licensors or\n    authors of the material; or\n\n    e) Declining to grant rights under trademark law for use of some\n    trade names, trademarks, or service marks; or\n\n    f) Requiring indemnification of licensors and authors of that\n    material by anyone who conveys the material (or modified versions of\n    it) with contractual assumptions of liability to the recipient, for\n    any liability that these contractual assumptions directly impose on\n    those licensors and authors.\n\n  All other non-permissive additional terms are considered \"further\nrestrictions\" within the meaning of section 10.  If the Program as you\nreceived it, or any part of it, contains a notice stating that it is\ngoverned by this License along with a term that is a further\nrestriction, you may remove that term.  If a license document contains\na further restriction but permits relicensing or conveying under this\nLicense, you may add to a covered work material governed by the terms\nof that license document, provided that the further restriction does\nnot survive such relicensing or conveying.\n\n  If you add terms to a covered work in accord with this section, you\nmust place, in the relevant source files, a statement of the\nadditional terms that apply to those files, or a notice indicating\nwhere to find the applicable terms.\n\n  Additional terms, permissive or non-permissive, may be stated in the\nform of a separately written license, or stated as exceptions;\nthe above requirements apply either way.\n\n  8. Termination.\n\n  You may not propagate or modify a covered work except as expressly\nprovided under this License.  Any attempt otherwise to propagate or\nmodify it is void, and will automatically terminate your rights under\nthis License (including any patent licenses granted under the third\nparagraph of section 11).\n\n  However, if you cease all violation of this License, then your\nlicense from a particular copyright holder is reinstated (a)\nprovisionally, unless and until the copyright holder explicitly and\nfinally terminates your license, and (b) permanently, if the copyright\nholder fails to notify you of the violation by some reasonable means\nprior to 60 days after the cessation.\n\n  Moreover, your license from a particular copyright holder is\nreinstated permanently if the copyright holder notifies you of the\nviolation by some reasonable means, this is the first time you have\nreceived notice of violation of this License (for any work) from that\ncopyright holder, and you cure the violation prior to 30 days after\nyour receipt of the notice.\n\n  Termination of your rights under this section does not terminate the\nlicenses of parties who have received copies or rights from you under\nthis License.  If your rights have been terminated and not permanently\nreinstated, you do not qualify to receive new licenses for the same\nmaterial under section 10.\n\n  9. Acceptance Not Required for Having Copies.\n\n  You are not required to accept this License in order to receive or\nrun a copy of the Program.  Ancillary propagation of a covered work\noccurring solely as a consequence of using peer-to-peer transmission\nto receive a copy likewise does not require acceptance.  However,\nnothing other than this License grants you permission to propagate or\nmodify any covered work.  These actions infringe copyright if you do\nnot accept this License.  Therefore, by modifying or propagating a\ncovered work, you indicate your acceptance of this License to do so.\n\n  10. Automatic Licensing of Downstream Recipients.\n\n  Each time you convey a covered work, the recipient automatically\nreceives a license from the original licensors, to run, modify and\npropagate that work, subject to this License.  You are not responsible\nfor enforcing compliance by third parties with this License.\n\n  An \"entity transaction\" is a transaction transferring control of an\norganization, or substantially all assets of one, or subdividing an\norganization, or merging organizations.  If propagation of a covered\nwork results from an entity transaction, each party to that\ntransaction who receives a copy of the work also receives whatever\nlicenses to the work the party\'s predecessor in interest had or could\ngive under the previous paragraph, plus a right to possession of the\nCorresponding Source of the work from the predecessor in interest, if\nthe predecessor has it or can get it with reasonable efforts.\n\n  You may not impose any further restrictions on the exercise of the\nrights granted or affirmed under this License.  For example, you may\nnot impose a license fee, royalty, or other charge for exercise of\nrights granted under this License, and you may not initiate litigation\n(including a cross-claim or counterclaim in a lawsuit) alleging that\nany patent claim is infringed by making, using, selling, offering for\nsale, or importing the Program or any portion of it.\n\n  11. Patents.\n\n  A \"contributor\" is a copyright holder who authorizes use under this\nLicense of the Program or a work on which the Program is based.  The\nwork thus licensed is called the contributor\'s \"contributor version\".\n\n  A contributor\'s \"essential patent claims\" are all patent claims\nowned or controlled by the contributor, whether already acquired or\nhereafter acquired, that would be infringed by some manner, permitted\nby this License, of making, using, or selling its contributor version,\nbut do not include claims that would be infringed only as a\nconsequence of further modification of the contributor version.  For\npurposes of this definition, \"control\" includes the right to grant\npatent sublicenses in a manner consistent with the requirements of\nthis License.\n\n  Each contributor grants you a non-exclusive, worldwide, royalty-free\npatent license under the contributor\'s essential patent claims, to\nmake, use, sell, offer for sale, import and otherwise run, modify and\npropagate the contents of its contributor version.\n\n  In the following three paragraphs, a \"patent license\" is any express\nagreement or commitment, however denominated, not to enforce a patent\n(such as an express permission to practice a patent or covenant not to\nsue for patent infringement).  To \"grant\" such a patent license to a\nparty means to make such an agreement or commitment not to enforce a\npatent against the party.\n\n  If you convey a covered work, knowingly relying on a patent license,\nand the Corresponding Source of the work is not available for anyone\nto copy, free of charge and under the terms of this License, through a\npublicly available network server or other readily accessible means,\nthen you must either (1) cause the Corresponding Source to be so\navailable, or (2) arrange to deprive yourself of the benefit of the\npatent license for this particular work, or (3) arrange, in a manner\nconsistent with the requirements of this License, to extend the patent\nlicense to downstream recipients.  \"Knowingly relying\" means you have\nactual knowledge that, but for the patent license, your conveying the\ncovered work in a country, or your recipient\'s use of the covered work\nin a country, would infringe one or more identifiable patents in that\ncountry that you have reason to believe are valid.\n\n  If, pursuant to or in connection with a single transaction or\narrangement, you convey, or propagate by procuring conveyance of, a\ncovered work, and grant a patent license to some of the parties\nreceiving the covered work authorizing them to use, propagate, modify\nor convey a specific copy of the covered work, then the patent license\nyou grant is automatically extended to all recipients of the covered\nwork and works based on it.\n\n  A patent license is \"discriminatory\" if it does not include within\nthe scope of its coverage, prohibits the exercise of, or is\nconditioned on the non-exercise of one or more of the rights that are\nspecifically granted under this License.  You may not convey a covered\nwork if you are a party to an arrangement with a third party that is\nin the business of distributing software, under which you make payment\nto the third party based on the extent of your activity of conveying\nthe work, and under which the third party grants, to any of the\nparties who would receive the covered work from you, a discriminatory\npatent license (a) in connection with copies of the covered work\nconveyed by you (or copies made from those copies), or (b) primarily\nfor and in connection with specific products or compilations that\ncontain the covered work, unless you entered into that arrangement,\nor that patent license was granted, prior to 28 March 2007.\n\n  Nothing in this License shall be construed as excluding or limiting\nany implied license or other defenses to infringement that may\notherwise be available to you under applicable patent law.\n\n  12. No Surrender of Others\' Freedom.\n\n  If conditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot convey a\ncovered work so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you may\nnot convey it at all.  For example, if you agree to terms that obligate you\nto collect a royalty for further conveying from those to whom you convey\nthe Program, the only way you could satisfy both those terms and this\nLicense would be to refrain entirely from conveying the Program.\n\n  13. Use with the GNU Affero General Public License.\n\n  Notwithstanding any other provision of this License, you have\npermission to link or combine any covered work with a work licensed\nunder version 3 of the GNU Affero General Public License into a single\ncombined work, and to convey the resulting work.  The terms of this\nLicense will continue to apply to the part which is the covered work,\nbut the special requirements of the GNU Affero General Public License,\nsection 13, concerning interaction through a network will apply to the\ncombination as such.\n\n  14. Revised Versions of this License.\n\n  The Free Software Foundation may publish revised and/or new versions of\nthe GNU General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\n  Each version is given a distinguishing version number.  If the\nProgram specifies that a certain numbered version of the GNU General\nPublic License \"or any later version\" applies to it, you have the\noption of following the terms and conditions either of that numbered\nversion or of any later version published by the Free Software\nFoundation.  If the Program does not specify a version number of the\nGNU General Public License, you may choose any version ever published\nby the Free Software Foundation.\n\n  If the Program specifies that a proxy can decide which future\nversions of the GNU General Public License can be used, that proxy\'s\npublic statement of acceptance of a version permanently authorizes you\nto choose that version for the Program.\n\n  Later license versions may give you additional or different\npermissions.  However, no additional obligations are imposed on any\nauthor or copyright holder as a result of your choosing to follow a\nlater version.\n\n  15. Disclaimer of Warranty.\n\n  THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY\nAPPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT\nHOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY\nOF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,\nTHE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR\nPURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM\nIS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF\nALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n\n  16. Limitation of Liability.\n\n  IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS\nTHE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY\nGENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE\nUSE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF\nDATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD\nPARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),\nEVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF\nSUCH DAMAGES.\n\n  17. Interpretation of Sections 15 and 16.\n\n  If the disclaimer of warranty and limitation of liability provided\nabove cannot be given local legal effect according to their terms,\nreviewing courts shall apply local law that most closely approximates\nan absolute waiver of all civil liability in connection with the\nProgram, unless a warranty or assumption of liability accompanies a\ncopy of the Program in return for a fee.\n\n                     END OF TERMS AND CONDITIONS\n\n            How to Apply These Terms to Your New Programs\n\n  If you develop a new program, and you want it to be of the greatest\npossible use to the public, the best way to achieve this is to make it\nfree software which everyone can redistribute and change under these terms.\n\n  To do so, attach the following notices to the program.  It is safest\nto attach them to the start of each source file to most effectively\nstate the exclusion of warranty; and each file should have at least\nthe \"copyright\" line and a pointer to where the full notice is found.\n\n    <one line to give the program\'s name and a brief idea of what it does.>\n    Copyright (C) <year>  <name of author>\n\n    This program is free software: you can redistribute it and/or modify\n    it under the terms of the GNU General Public License as published by\n    the Free Software Foundation, either version 3 of the License, or\n    (at your option) any later version.\n\n    This program is distributed in the hope that it will be useful,\n    but WITHOUT ANY WARRANTY; without even the implied warranty of\n    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n    GNU General Public License for more details.\n\n    You should have received a copy of the GNU General Public License\n    along with this program.  If not, see <http://www.gnu.org/licenses/>.\n\nAlso add information on how to contact you by electronic and paper mail.\n\n  If the program does terminal interaction, make it output a short\nnotice like this when it starts in an interactive mode:\n\n    <program>  Copyright (C) <year>  <name of author>\n    This program comes with ABSOLUTELY NO WARRANTY; for details type `show w\'.\n    This is free software, and you are welcome to redistribute it\n    under certain conditions; type `show c\' for details.\n\nThe hypothetical commands `show w\' and `show c\' should show the appropriate\nparts of the General Public License.  Of course, your program\'s commands\nmight be different; for a GUI interface, you would use an \"about box\".\n\n  You should also get your employer (if you work as a programmer) or school,\nif any, to sign a \"copyright disclaimer\" for the program, if necessary.\nFor more information on this, and how to apply and follow the GNU GPL, see\n<http://www.gnu.org/licenses/>.\n\n  The GNU General Public License does not permit incorporating your program\ninto proprietary programs.  If your program is a subroutine library, you\nmay consider it more useful to permit linking proprietary applications with\nthe library.  If this is what you want to do, use the GNU Lesser General\nPublic License instead of this License.  But first, please read\n<http://www.gnu.org/philosophy/why-not-lgpl.html>.\";s:6:\"readme\";s:397:\"-----------------------\r\nPackage: Lingua\r\n-----------------------\r\nauthor:\r\ngoldsky <goldsky@virtudraft.com>\r\n\r\ncollaborators:\r\nAdam Wintle <adam@monogon.co>\r\n\r\nLingua is a multi-lingual plugin system for MODX Revolution.\r\n\r\nReferences:\r\n1. http://en.wikipedia.org/wiki/ISO_639-1_language_matrix\r\n2. http://www.science.co.il/language/locale-codes.asp\r\n3. http://www.php.net/manual/en/book.intl.php\";s:9:\"changelog\";s:4663:\"Lingua 2.1.0-beta4 (February 23, 2015)\r\n======================================\r\n- [#36] replace \"Select Node\" on linking resource with pagetitle type ahead\r\n- [#38] fix table resolver on creating \"linguaResourceScopes\"\r\n\r\nLingua 2.1.0-beta3 (February 11, 2015)\r\n======================================\r\n- revert language reset on LinguaRequest::findResource()\r\n\r\nLingua 2.1.0-beta2 (February 5, 2015)\r\n=================================\r\n- fix flag of the title of the main Content\'s field\r\n\r\nLingua 2.1.0-beta1 (February 4, 2015)\r\n=================================\r\n- [#30] batch synchronize translation for (eg.) imported resources\r\n- [#33] add option in System Settings to detect Form Customization\'s renderings\r\n- [#33] change how flag is appended to the original fields, to overcome Form Customization\'s rule on changing the field\'s name\r\n- [#31] Add optional different language settings based on Resource\r\n- Improve finding resource by translated URI\r\n- Improve default value selection\r\n- [#27] Add option to choose whether Lingua returns default value or not, if translated field is empty\r\n- Fix returning value of translated TV\r\n- [#32] Fix empty value of translated TV\r\n- [#28] Fix translated SymLink and WebLink\r\n- [#34] Fix translated Static Resource\r\n- [#23][#35] revert CKEditor\'s integration, since it\'s been updated to use MODx.loadRTE()\r\n- add JS\'s getMenu to generate menu\r\n\r\nLingua 2.0.2-pl (November 26, 2014)\r\n=================================\r\n- [#22] refactor getValue for TV, TV value does not switch with getResources\r\n- integrate CKEditor\r\n- [#20][#21] Fixes related to compatibility improvements with Articles extra\r\n- fix clones\' URIs on language selector drop down menu\r\n- set clones\' aliases from their own pagetitles instead of from original\'s alias\r\n\r\nLingua 2.0.1-pl (November 9, 2014)\r\n=================================\r\n- [#17] richtext-editor shows up for content, when resource-setting richtext is off\r\n- [#13][#15] fix custom TVs parsing on categories\r\n- [#11] Include country flag next to default fields that require translations\r\n- [#18] fix lingua.getValue on retrieving default TV\'s value\r\n\r\nLingua 2.0.0-pl (October 15, 2014)\r\n=================================\r\n- fix left out outputs after rendering TV forms\r\n\r\nLingua 2.0.0-rc5 (October 15, 2014)\r\n=================================\r\n- add cloning patterns database\r\n\r\nLingua 2.0.0-rc4 (September 30, 2014)\r\n=================================\r\n- remove OnWebPageInit event\r\n- check context key before responding to request handler\r\n- add baseUrl on language selector\r\n- slightly redefining schema\r\n- refactor cultureKey overrides\r\n- capture clone\'s URI to get resource\r\n- fix language selector of a slashed URI\r\n\r\nLingua 2.0.0-rc3 (September 16, 2014)\r\n=================================\r\n- add domain path on setcookie()\r\n- [#6][#9] Add TV Value to getValue snippet\r\n- [#6] process TV\r\n- [#8] detect browser language\r\n\r\nLingua 2.0.0-rc2 (July 23, 2014)\r\n=================================\r\n- add debug mode\r\n- add version checker on table alteration\r\n- fix cacheKey on LinguaRequest class\r\n- disable OnHandleRequest back, to avoid weird 2nd overriding\r\n- revert setOption, and use getObject to get original cultureKey data\r\n\r\nLingua 2.0.0-rc1 (July 21, 2014)\r\n=================================\r\n- [#3] move the plugin\'s setting into System Settings instead\r\n- [#5] fix update window\'s URL of language CMP\r\n- [#4] fix default lang value on manager\'s dropdown\r\n- fix uri update when alias/parent\'s alias is changed, including by adding some\r\n  fields to initiate the refreshment: parent, isfolder, context_key, content_type\r\n- add lingua.getValue snippet to switch placeholder\'s value on other snippet\r\n- fix default lang value on LinguaRequest\r\n\r\nLingua 2.0.0-beta3 (July 8, 2014)\r\n=================================\r\n- add OnHandleRequest event back to override global lexicon\'s language.\r\n- [#2] add redirector for translated alias\r\n\r\nLingua 2.0.0-beta2 (July 7, 2014)\r\n=================================\r\n- bugfix TVs\' values overriding on front-end\r\n- add cache clearing on all elements\' form saving actions.\r\n\r\nLingua 2.0.0-beta1 (July 6, 2014)\r\n=================================\r\n- Initialize manager language switcher\r\n- replace options: lingua.get.key to lingua.request_key, lingua.code.field to lingua.code_field\r\n- replace OnHandleRequest event to OnInitCulture instead\r\n- add more events\r\n- clone main contents\' and TVs\' values\r\n\r\nLingua 1.0.0-pl (June 6, 2013)\r\n=================================\r\n- initial public launch\r\n\r\nLingua 1.0.0-dev.2\r\n=================================\r\n- refactored\r\n\r\nLingua 1.0.0-dev.1\r\n=================================\r\n- initial setup\";s:9:\"signature\";s:18:\"lingua-2.1.0-beta4\";s:6:\"action\";s:26:\"workspace/packages/install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:46:\"/workspace/package/install/lingua-2.1.0-beta4/\";s:14:\"package_action\";i:0;}', 'Lingua', 'a:38:{s:2:\"id\";s:24:\"54eb68f3dc532f725a02c001\";s:7:\"package\";s:24:\"51b0621862cf2445310006ba\";s:12:\"display_name\";s:18:\"lingua-2.1.0-beta4\";s:4:\"name\";s:6:\"Lingua\";s:7:\"version\";s:5:\"2.1.0\";s:13:\"version_major\";s:1:\"2\";s:13:\"version_minor\";s:1:\"1\";s:13:\"version_patch\";s:1:\"0\";s:7:\"release\";s:5:\"beta4\";s:8:\"vrelease\";s:4:\"beta\";s:14:\"vrelease_index\";s:1:\"4\";s:6:\"author\";s:7:\"goldsky\";s:11:\"description\";s:49:\"<p>A multi-lingual plugin for MODX Revolution</p>\";s:12:\"instructions\";s:587:\"<p>Download this from Package Manager inside the Manager.</p><p>You need to define custom settings to the applied contexts:</p><ul><li>key: modRequest.class, value: LinguaRequest</li></ul><p>This setting extends MODX\'s request class for front-end.</p><p>If you upgrading, since version 2.0.0-rc2, all plugin\'s settings have been moved to System Settings instead to avoid overriding on upgrading. So please adjust the settings again if you need to:</p><ul><li>lingua.contexts,</li><li>lingua.parents,</li><li>lingua.ids</li></ul><p>On MODX 2.3.x, please CLEAR the CACHE after install.</p>\";s:9:\"changelog\";s:269:\"<p>Lingua 2.1.0-beta4 (February 23, 2015)</p><p>======================================</p><ul><li>- &#91;#36&#93; replace \"Select Node\" on linking resource with pagetitle type ahead</li><li>- &#91;#38&#93; fix table resolver on creating \"linguaResourceScopes\"</li></ul>\";s:9:\"createdon\";s:24:\"2015-02-23T17:52:51+0000\";s:9:\"createdby\";s:7:\"goldsky\";s:8:\"editedon\";s:24:\"2021-08-06T09:26:57+0000\";s:10:\"releasedon\";s:24:\"2015-02-23T17:52:51+0000\";s:9:\"downloads\";s:4:\"9844\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:5:\"false\";s:8:\"featured\";s:5:\"false\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv3\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:24:\"4d4c3fa6b2b0830da9000001\";s:8:\"supports\";s:3:\"2.2\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=54eb68f5dc532f725a02c003\";s:9:\"signature\";s:18:\"lingua-2.1.0-beta4\";s:11:\"supports_db\";s:5:\"mysql\";s:16:\"minimum_supports\";s:3:\"2.2\";s:9:\"breaks_at\";s:8:\"10000000\";s:10:\"screenshot\";s:80:\"http://modx.s3.amazonaws.com/extras/51b0621862cf2445310006ba/lingua.selector.png\";s:4:\"file\";a:7:{s:2:\"id\";s:24:\"54eb68f5dc532f725a02c003\";s:7:\"version\";s:24:\"54eb68f3dc532f725a02c001\";s:8:\"filename\";s:32:\"lingua-2.1.0-beta4.transport.zip\";s:9:\"downloads\";s:4:\"2548\";s:6:\"lastip\";s:12:\"147.12.240.4\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=54eb68f5dc532f725a02c003\";}s:17:\"package-signature\";s:18:\"lingua-2.1.0-beta4\";s:10:\"categories\";s:44:\"communication,internationalization,utilities\";s:4:\"tags\";s:0:\"\";}', 2, 1, 0, 'beta', 4);
INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('pdotools-2.12.10-pl', '2021-08-11 14:29:25', '2021-08-11 11:29:35', '2021-08-11 14:29:35', 0, 1, 1, 0, 'pdotools-2.12.10-pl.transport.zip', NULL, 'a:8:{s:9:\"changelog\";s:28329:\"Changelog for pdoTools.\n\n2.12.10 pl\n==============\n- [#308] [pdoPage] Fixed the type of snippet property \"field\"\n\n2.12.9 pl\n==============\n- [Fenom] Update to version 2.12.0\n\n2.12.8 pl\n==============\n- [pdoPage] Fix reflected XSS in generated meta links\n\n2.12.7 pl\n==============\n- Make pdoTools canonical url work with Babel #304\n\n2.12.6 pl\n==============\n- [pdoPage] Reverted back #287\n\n2.12.5 pl\n==============\n- [Fenom] Added caching dinamic properties to prevent speed degradation.\n\n2.12.4 pl\n==============\n- [#290] Improved running snippet via @FILE binding.\n- [#296] Fix adding quotes to numeric values.\n- [#297] Make cross context weblink url possible.\n- [#274] [Fenom] User, resource and context properties are now dinamic.\n- [#287] [pdoPage] Remove prev & next meta tags\n- [#294] [#298] Improved pdopage.js and updated minified js files\n\n2.12.3 pl\n==============\n- Fixed E_NOTICE introduced in #285.\n\n2.12.2 pl\n==============\n- Updated chunks for Bootstrap 4.\n\n2.12.1 pl\n==============\n- [pdoMenu] Reverted back #283 and fixed docs for &tplCategoryFolder.\n- [#284] [Fenom] Fixed properties of $_modx->context variable.\n- [#275] [Fenom] Added \"reset\" and \"end\" modifiers.\n\n2.12.0 pl\n==============\n- [Fenom] More security fixes from Sergey Shlokov.\n- [#278] [pdoPage] Fixed caching.\n- [pdoPage] Show internal log on &showLog=`1`.\n- [#283] [pdoMenu] Fixed use of &tplCategoryFolder according to docs.\n- [#281] [pdoTools] Fixed load of models from case sensitive paths.\n- [#277] [pdoCrumbs] Ability to specify &customParents.\n- [#265] [pdoFetch] Fixed return of \"Array\" on SQL errors.\n\n2.11.3 pl\n==============\n- Added French lexicon entries.\n\n2.11.2 pl\n==============\n- Fix detection of element names starting with a number.\n\n2.11.1 pl\n==============\n- Faster processing of static files.\n\n2.11.0 pl\n==============\n- [pdoFetch] Added \"setTotal\" option to enable calculating all rows (\"SQL_CALC_FOUND_ROWS\"), which will also result in the \"totalVar\" placeholder is being set.\n- [pdoFetch] Option \"setTotal\" disabled by default.\n- [pdoPage] Forces \"setTotal\" to provide pagination.\n\n2.10.6 pl\n==============\n- Improved German lexicons.\n\n2.10.5 pl\n==============\n- [pdoTools] Ability to return array from \"prepareSnippet\" for more performance.\n- [FenomX] Fixed method \"getStore\".\n\n2.10.4 pl\n==============\n- [Fenom] Do not output raw tags if there was a compile errors.\n- [#266] [pdoMenu] Fixed the setting of \"here\" and \"self\" classes.\n- [#261] [Fenom] Fixed unexpected behavior of the fenom tag \"ignore\".\n\n2.10.3 pl\n==============\n- Improved compatibility with PHP 7.2\n- [pdoFetch] Ability to use arrays in \"&sortby\".\n\n2.10.2 pl\n==============\n- [Fenom] Improved processing of caching snippets inside uncached.\n\n2.10.1 pl\n==============\n- [#256] [Fenom] Fixed bug with caching of scripts and styles.\n- [pdoPage] \"&setMeta\" now works when \"&cache=`1`\".\n- [Fenom] Improved regular expression to detect Fenom syntax.\n\n2.10.0 pl\n==============\n- [#259] [pdoFetch] Fixed error when passed pure SQL into \"having\" parameter.\n- [#258] [pdoPage] Canonical urls always must be \"full\".\n- [#245] [pdoMenu] Ability to use conditional tpls instead of regular \"tpl\".\n- [#121] [pdoMenu] Improved work of specified chunks with weblinks.\n\n2.9.3 pl\n==============\n- [#255] [Fenom] New system setting \"pdotools_fenom_save_on_errors\" to save code on compilation errors in the cache directory for later debugging.\n\n2.9.2 pl\n==============\n- [pdoParser] Proper traversal trough arrays fields of resources in fast tags.\n\n2.9.1 pl\n==============\n- [Fenom] Updated to version 2.11.8.\n\n2.9.0 pl\n==============\n- [pdoPage] Improved \"&pageLinkScheme\" logic.\n- [#249] A little improvement for resource modifier.\n- [#251] [pdoFetch] More compatibility with PHP 7.1.\n- [#253] [pdoPage] Fixing a missing pagination in Ajax mode.\n- [#254] [Fenom] Options of json modifiers must check version of PHP to proper work.\n\n2.8.6 pl\n==============\n- [pdoArchive] Ability to specify fields with regular dates in the \"&dateField\" parameter.\n- [Fenom] Added all options to json modifiers.\n\n2.8.5 pl\n==============\n- [#248] [pdoPage] Fixed E_WARNING with array values in GET parameters.\n\n2.8.4 pl\n==============\n- Ability to use file elements in core path outside base path.\n- Fixed bug with the caching of elements.\n\n2.8.3 pl\n==============\n- [Fenom] Fixed rare bug with the caching of scripts and styles that was registered via Fenom.\n- [pdoPage] Fixed the \"?page=1\" in the url when ajaxMode is enabled.\n- [pdoPage] Snippet will register \"canonical\" link if \"&setMeta\" is enabled.\n- [pdoPage] Fix processing of request with rawurldecode on some servers.\n- [pdoTools] Added passing of \"scriptProperties\" values into a \"&prepareSnippet\".\n\n2.8.2 pl\n==============\n- [pdoMenu] Fixed the checking of permissions for containers.\n- [pdoPage] Added the ability to run files as &element.\n- [pdoTools] The method runSnippet will return boolean false if snippet was not found.\n- [Fenom] Fixed the possible bugs of caching of scripts and styles.\n\n2.8.1 pl\n==============\n- [#244] Fixed possible duplicate of a container in the jquery.pdopage.js.\n- Added fallback class for the enable modParser.\n\n2.8.0 pl\n==============\n- Ability to use an arrays in the parameters of the snippets.\n- Replaced modX::toJSON and modX::fromJSON to native php functions.\n\n2.7.5 pl\n==============\n- Fenom is now managed via composer.\n- [Fenom] Modifier \"resource\" no longer checks fields of resources in their schema.\n- [Fenom] Modifier \"strrev\" now can work with arrays.\n- [Fenom] Improved modifier \"ismember\".\n\n2.7.4 pl\n==============\n- [#242] Added jquery.pdopage.js plugin and minified versions.\n- [#241] [Fenom] Improved the retrieving of TVs for a current resource.\n- [pdoFetch] Restored the checking of possible SQL injections in the &sortby with xPDO 2.5.1.\n\n2.7.3 pl\n==============\n- Improved compatibility with MODX 2.5.2.\n\n2.7.2 pl\n==============\n- [pdoFetch] Some security improvements.\n\n2.7.1 pl\n==============\n- Some security improvements in the connector.php.\n- Fixed bug with registering scripts in styles via Fenom introduced in version 2.7.0.\n\n2.7.0 pl\n==============\n- [Fenom] Updated to the version 2.11.4.\n- [Fenom] Fixed resource cache for scripts and styles registered by Fenom.\n- [Fenom] Added rand() and number_format() to an allowed PHP functions.\n- [Fenom] New output filter \"number\" (or \"number_format\").\n\n2.6.5 pl\n==============\n- Fixed undeclared variable (PHP 7.1)\n\n2.6.4 pl\n==============\n- Added escaping of a MODX tags that being processed in the &prepareSnippet.\n- [#239] Improved work of the &decodeJSON option.\n\n2.6.3 pl\n==============\n- Fixed possible E_NOTICE on line 305 pdofetch.class.php.\n- Fixed possible E_NOTICE when \"snippet\" and \"chunk\" Fenom modifiers was called.\n\n2.6.2 pl\n==============\n- Fixed possible E_NOTICE on line 1317 pdotools.class.php.\n\n2.6.1 pl\n==============\n- Improved compatibility with PHP 5.3.\n\n2.6.0 pl\n==============\n- [Fenom] The ability to extend Fenom via system event \"pdoToolsOnFenomInit\".\n\n2.5.6 pl\n==============\n- [pdoFetch] Ability to join TVs not only to the query main class.\n\n2.5.5 pl\n==============\n- Fixed parse of INLINE chunks with \"@\" symbols.\n\n2.5.4 pl\n==============\n- [#224] Added microMODX::cleanAlias().\n- [#226] [Fenom] Added \"declension\" modifier.\n\n2.5.3 pl\n==============\n- [#221] Fixed typo in month name.\n- [Fenom] Fixed path to compile dir.\n\n2.5.2 pl\n==============\n- [#220] Cache code of snippet with respect to property set.\n\n2.5.1 pl\n==============\n- Fixed cache of snippets in pdoTools::runSnippet().\n\n2.5.0 pl\n==============\n- Improved support of debugParser.\n- [#209] Improved loading of the models.\n- [Fenom] New modifiers: \"snippet\" and \"chunk\".\n- [Fenom] New elements provider: \"file\".\n- New method pdoTools::runSnippet().\n\n2.4.0 pl\n==============\n- Added snippet pdoArchive.\n- [pdoResources] Faster processing of additional snippet parameters to placeholders.\n- [#123] [pdoMenu] Fixed bug with &displayStart and unpublished root nodes.\n- [#207] [pdoMenu] Fixed &webLinkClass option.\n- [#193] [pdoNeighbors] Added parameter &wrapIfEmpty.\n- [#203] [Fenom] Added more PCRE modifiers.\n\n2.3.5 pl\n==============\n- [pdoFetch] Added escaping of columns names in query.\n\n2.3.4 pl\n==============\n- [#200] [pdoFetch] Fixed &sortbyTV with dot in name.\n\n2.3.3 pl\n==============\n- Added system plugin for \"autoload\" of main classes with respect to their paths in system settings.\n\n2.3.2 pl\n==============\n- [#196] [pdoPage] Added workaround to support ClientConfig tags in ajax mode.\n- [Fenom] Added general MODX output filters as Fenom modifiers.\n- [Fenom] Implemented autoload of modifiers from snippets.\n- [Fenom] Removed system setting \"pdotools_fenom_modifiers\".\n\n2.3.1 pl\n==============\n- [pdoSitemap] Lightning fast work chunks processing with &scheme=`uri`.\n- [Fenom] Improved check of syntax before processing.\n\n2.3.0 pl\n==============\n- Removed shortcuts from system core.\n- PSR-2.\n- [Fenom] Added default modifiers: \"url\" and \"lexicon\".\n- [pdoCrumbs] Changed default chunks to ul -> li.\n- [#190] [pdoSitemap] Changed date format to ISO 8601.\n\n2.2.8 pl\n==============\n- [Fenom] Use modResource::getContent() method to get content of current resource in {$_modx->resource}.\n\n2.2.7 pl\n==============\n- [pdoPage] Ability to get access to a javascript configs from 3rd party scripts.\n\n2.2.6 pl\n==============\n- [#184] [Fenom] Updated to version 2.8.2.\n\n2.2.5 pl\n==============\n- [#182] [pdoTitle] Added passing a parameters into nested pdoCrumbs.\n- [pdoSitemap] Added processing of MODX tags if needed.\n- Added method pdoTools::makeUrl().\n- [#181] New url schema type - \"uri\".\n\n2.2.4 pl\n==============\n- [Fenom] Fixed speed issues when MODX snippets are run as Fenom modifiers.\n- [pdoUsers] Fixed overwrite modUser.id by modUserProfile.id.\n\n2.2.3 pl\n==============\n- [pdoPage] Fixed processing of uncached conditions in chunks when ajax mode is enabled.\n\n2.2.2 pl\n==============\n- [pdoPage] Added new parameter &pageLinkScheme.\n\n2.2.1 pl\n==============\n- [#155] [pdoPage] Added new parameter &ajaxHistory.\n- [pdoPage] Added connector for requests in ajax mode.\n\n2.2.0 pl\n==============\n- [#175] [pdoFetch] Ability to specify sequence of table joins.\n- [#174] [Fenom] Ability to add Fenom modifiers into pdoParser.\n\n2.1.21 pl\n==============\n- [#175] [pdoFetch] Ability to specify sequence of table joins.\n- [#176] [pdoUsers] Fixed &toPlaceholders with &returnIds.\n\n2.1.20 pl\n==============\n- [pdoSitemap] Fixed default &cacheKey.\n\n2.1.19 pl\n==============\n- [Fenom] Disabled $options in cacheManager::set() due to security reasons.\n\n2.1.18 pl\n==============\n- [Fenom] Fixed ability to access to the modX object from {$_modx} variable.\n- [Fenom] Improved method {$_modx->runProcessor()}.\n\n2.1.17 pl\n==============\n- [Fenom] Added {$_modx->getResource($id, $options)}.\n- [Fenom] Added {$_modx->getResources($where, $options)}.\n- [Fenom] Improved support of debugParser.\n\n2.1.16 pl\n==============\n- [Fenom] Added {$_modx->isMember($groups, $matchAll)}.\n- [Fenom] Added {$_modx->getPlaceholders()}.\n\n2.1.15 pl\n==============\n- [pdoPage] Added parameter &strictMode.\n\n2.1.14 pl\n==============\n- [pdoSitemap] Added options for cache snippets results.\n- [pdoSitemap] Cache enabled by default.\n\n2.1.13 pl\n==============\n- [#163] Fixed ignoring of &idx in pdoResources and pdoUsers.\n\n2.1.12 pl\n==============\n- [pdoPage] [#161] Fixed support of arrays in hash when &ajaxMode is enabled.\n\n2.1.11 pl\n==============\n- [#150] [Fenom] Fixed processing of TVs values in a {$_modx->resource}.\n- [#147] [pdoSitemap] Fixed possible duplicates in sitemap.\n- [pdoPage] Support of arrays in hash when &ajaxMode is enabled.\n\n2.1.10 pl\n==============\n- [#157] [Fenom] Fixed pre-processing of Fenom tags in extending templates and chunks.\n- [#145] [pdoPage] Rolled back #81 due to issues with complicate forms.\n\n2.1.9 pl\n==============\n- [#144] [pdoParser] Leave unprocessed FastField tags so other components could parse them.\n- [pdoFetch] Updated syntax for \"SET SQL_BIG_SELECTS = 1\".\n\n2.1.8 pl\n==============\n- [Fenom] Ability to use id of chunks and templates in {include} and {extends}.\n- [Fenom] Added support of debugParser.\n- [Fenom] Added {$_modx->getChildIds()} and {$_modx->getParentIds()}.\n\n2.1.7 pl\n==============\n- Fixed work with integer values from system setting \"link_tag_scheme\".\n\n2.1.6 pl\n==============\n- [Fenom] Updated to version 2.8.0.\n- [Fenom] Improved check of syntax to process content of chunks.\n- [pdoParser] Fixed E_WARNING on line 50 introduced in previous version.\n\n2.1.5 pl\n==============\n- [Fenom] Fixed register of scripts and styles by cached snippets.\n\n2.1.4 pl\n==============\n- [Fenom] Fixed TVs in {$_modx->resource}\n- [Fenom] Added new method {$_modx->getInfo()}\n\n2.1.3 pl\n==============\n- Improved work of system setting \"pdotools_fenom_php\".\n\n2.1.2 pl\n==============\n- [Fenom] Replaced {$_modx->placeholders} to functions.\n\n2.1.1 pl\n==============\n- pdoParser enabled by default.\n- [Fenom] Fixed return content in {$_modx->getChunk}.\n- [Fenom] Added cache for snippets called through {$_modx->runSnippet}.\n- [pdoTools] Added processing of property sets for chunks.\n- [pdoResources] Set additionalPlaceholders in &tplWrapper\n\n2.1.0 pl\n==============\n- [Fenom] Updated Fenom to version 2.7.1.\n- [Fenom] Added safe system variable {$_modx}.\n- [Fenom] Added MODX template provider for chunks and templates.\n\n2.0.5 pl\n==============\n- [#132] Fixed possible E_WARNING on empty chunks.\n- [#122] Ability to use 3rd party pdoPage and pdoMenu classes.\n- [#118] [pdoPage] Fixed parameter &offset.\n- [pdoPage] Fixed default CSS classes in \"empty\" chunks.\n\n2.0.4 pl\n==============\n- Fixed processing of \"pdotools_fenom_cache\" system setting.\n\n2.0.3 pl\n==============\n- [#125] [pdoTitle] Fixed parameter &id.\n\n2.0.2 pl\n==============\n- Improved processing of @FILE binding.\n\n2.0.1 pl\n==============\n- Fixed possible E_WARNING on line 319 and 349 of pdoTools class.\n- Disabled system option \"pdotools_fenom_modx\" by default due to security issues.\n\n2.0.0 pl\n==============\n- New system settings to control the Fenom.\n- Ability to enable caching of Fenom compiled chunks.\n- Improved handling of parameter \"cache_key\".\n- [pdoMenu] Improved work when &cache is enabled.\n\n2.0.0 rc2\n==============\n- Compiled Fenom templates cached to RAM instead of HDD.\n- Removed plugin pdoTools.\n\n2.0.0 rc1\n==============\n- Added Fenom template engine.\n- Fenom enabled by default.\n- pdoParser uses Fenom to process pages.\n\n1.11.2 pl\n==============\n- [#116] [pdoTitle] Disabled &register_js by default.\n\n1.11.1 pl\n==============\n- [pdoSitemap] Fixed default url scheme after last update.\n\n1.11.0 pl1\n==============\n- [pdoTitle] Added new snippet.\n- [pdoPage] Added support of snippet pdoTitle when &ajaxMode is enabled.\n- [pdoPage] Prevent overwriting of scripts and styles of nested &element by default parameters.\n- [pdoPage] Added triggering javascript event \"pdopage_load\".\n\n1.10.2 pl1\n==============\n- [#112] Parameter &scheme was set to system default in all snippets.\n- [#111] [pdoPage] Added ability to set \"prev\" & \"next\" meta tags.\n- [#107] [pdoNeighbors] Added ability to specify &parents for work.\n- [#106] [pdoMenu] Fixed \"hereClass\" and \"selfClass\" enabled &useWeblinkUrl parameter.\n- [#104] [pdoMenu] Snippet now using \"pagetitle\" for link titles if \"titleOfLinks\" is empty.\n\n1.10.1 pl\n==============\n- [#108] [pdoFetch] Fixed E_ERROR when using &sortbyTV.\n- [pdoFetch] Added new parameter &sortbyTVType.\n- [pdoFetch] If &sortdirTV is not set it will be equal to &sortdir.\n\n1.10.0 pl\n==============\n- [pdoMenu] Returned and fixed parameter &showDeleted.\n- [pdoPage] Improved default javascript.\n- [pdoPage] Fixed overwriting &frontend_js and &frontend_css parameters when &ajax is disabled.\n- [pdoFetch] Ability to specify functions in select fields.\n- [pdoTools] Ability to use compound quick placeholders.\n\n1.10.0 beta4\n==============\n- [pdoPage] Ajax pagination out from the box.\n- [pdoFetch] Improved log of getCollection.\n- [pdoTools] Added tplOperator \"contains\".\n\n1.9.7 pl\n==============\n- [#99] [pdoFetch] Fixed returning of primary key in \"ids\" mode.\n- [#97] [pdoTools] Fixed default tplPath for @FILE chunks.\n- [#85] [pdoFetch] Added function getChildIds().\n- [pdoFetch] Disabled \"total\" placeholder for &return=`ids`.\n\n1.9.6 pl2\n==============\n- [pdoFetch] Fixed exclusion of field \"id\" in custom classes.\n- [pdoMenu] Improved parameter &countChildren.\n- [#100] [pdoMenu] Removed parameter &showDeleted because it not working.\n\n1.9.6 rc\n==============\n- Added execution of SQL_BIG_SELECTS = 1 before query.\n- [pdoPage] Added parameter &ajax for supporting of ajax requests.\n\n1.9.5 pl1\n==============\n- Rolled back #72 due to issues in pdoMenu.\n\n1.9.5 pl\n==============\n- Added ability to return JSON or serialized string from pdoFetch::run().\n- [#83] [pdoMenu] Added level placeholder to outer templates.\n- [#82] [pdoFetch] Added support for complex &where parameter.\n- [#81] [pdoPage] Improved handling of arrays in url.\n- [#77] Fixed making of url for modWebLink to another context.\n- [#72] [pdoTools] Fixed order for children of excluded parents in buildTree.\n- [#60] [pdoMenu] Fixed parameter &tplCategoryFolder.\n- [#57] [pdoMenu] Improved placeholder [[+children]].\n- [#57] [pdoMenu] Added parameter &countChildren.\n\n1.9.4 pl1\n==============\n- [#78] [pdoNeighbors] Added parameter &loop=`1` for looping links.\n- [pdoSitemap] Fixed possible E_FATAL php-apc.\n\n1.9.3 pl1\n==============\n- [pdoTools] Ability to specify value for empty quick placeholders.\n- [pdoTools] Ability to use INLINE snippets and filters.\n- [pdoFetch] Improved loading of 3rd party models.\n- [pdoPage] Fixed E_WARNING when &limit=`0`.\n\n1.9.2 pl2\n==============\n- [#56] [pdoParser] Fixed wrong links processing.\n- [#53] Improved loading of classes.\n- [pdoField] Rolled back to original logic of \"top\" and \"topLevel\" parameters due to issues.\n- [pdoField] Added parameter \"ultimate\" to emulate logic of UltimateParent.\n\n1.9.1 pl6\n==============\n- [pdoFetch] Adding alias of main class of query to \"sortby\" if no alias exists.\n- [pdoFetch] Improved selecting of all fields of class with specified alias.\n- [pdoField] Parameter \"topLevel\" works exactly as in UltimateParent.\n- [pdoField] Parameter \"top\" without \"topLevel\" returns parent on \"top\" level.\n\n1.9.1 pl\n==============\n- [#47] [pdoMenu] Fixed processing &tplOuter when output is empty.\n- [#46] [pdoParser] Fixed processing of TVs with dots in name.\n- [#44] [pdoMenu] Improved handling of Wayfinder parameters \"includeDocs\" and \"excludeDocs\".\n- [#37] [pdoField] get the default, only if the field was empty.\n- [#34] Fixed processing of \"modSymLink\" documents.\n- [#32] Improved cache methods.\n- [#26] Replaced FIND_IN_SET() to FIELD().\n- [pdoFetch] Ability to work with objects, that has multiple primary keys.\n- [pdoPage] New parameter &cacheAnonymous.\n- [pdoMenu] New parameter &cacheAnonymous.\n- Added aliases for sort query in order of specified &resources: \"ids\" or \"resources\".\n- Removed unnecessary query in pdoFetch::getCollection().\n- Improved pdoFetch::getCollection().\n- Renamed pdoFetch::getObject() to getArray(). Now it uses getCollection for retrieve results.\n- pdoTools::setCache() now returns cacheKey.\n- pdoFetch::getObject() is now alias of pdoFetch::getArray().\n\n1.9.0 pl2\n==============\n- [pdoMenu] Chunks of parents and categories are now depends on the descendants and ignores parameter isfolder.\n- [pdoNeighbors] Speed improvements.\n- [#27] Ability to specify custom pdoFetch and pdoTools classes through FQN system settings.\n- [pdoParser] Handles TVs in resource tags.\n- [pdoParser] Handles output filters.\n- [pdoFetch] Improved method \"addTVFilters\", that used by \"tvFilters\" parameter in pdoResources.\n- [pdoSitemap] Pass the whole row so we can use more columns.\n\n1.9.0 rc\n==============\n- Improved method pdoTools::getChunk().\n- Improved method pdoTools::parseChunk().\n- Improved method pdoTools::fastProcess().\n- Improved method pdoTools::makePlaceholders().\n- Accelerated snippet pdoNeighbors.\n- Fixed bug in pdoUsers when usersgroups was specified by names.\n- getObject and getCollection() runs in separate instance.\n- Added pdoParser with FastField tags.\n- [pdoPage] Changed default value of parameter \"totalVar\" due to issues.\n- [#24] Fixed prepareTVs and empty tvPrefix.\n- [#23] [pdoResources] Ability to return ids to placeholder.\n- Fixed warning when getObject returns false.\n- Fixed placeholders prefix in recursive makePlaceholders.\n\n1.8.9 pl4\n==============\n- Added german lexicon.\n- [#20] Ability to specify not JSON string in &where=``.\n- [pdoPage] Added parameter \"pageCountVar\" for specifying name of variable with number of pages.\n- [pdoPage] Support Bootstrap3.\n- [pdoField] Ability to specify class for fetching field.\n- Improved joining of tables in pdoFetch.\n- Added preparing and processing TVs in getObject and getCollection methods.\n- Improved load of 3rd party models.\n\n1.8.8 pl2\n==============\n- Rewrited cache of snippets \"pdoMenu\" and \"pdoPage\".\n- New methods pdoTools::getCache() and pdoTools::setCache().\n- [pdoMenu] Fixed parameter \"tplParentRowActive\".\n- [#18] Fixed \"idx\" in pdoTools::defineChunk().\n\n1.8.7 pl\n==============\n- Added boolean parameter \"decodeJSON\" to specify whether or not decode JSON in results rows.\n- Removed default \"sortby\" and \"sortdir\" from class pdoFetch for better work of getCollection() method.\n\n1.8.6 pl2\n==============\n- Fixed possibly E_NOTICE when site has no extension packages installed.\n- [#17] [pdoMenu] Added placeholder [[+wf.menutitle]].\n- [#16] [pdoMenu] Disabled status verification of specified parents.\n- [#13] [pdoMenu] Improved work with root of multiple contexts.\n- [pdoMenu] Fixed bug when specified parent has only the one child.\n- [pdoResources] Added parameter \"&useWeblink\" and placeholder \"[[+link]]\". It is disabled by default.\n\n1.8.5 pl\n==============\n- [#15] [pdoPage] Improved generation of links to pages.\n- [pdoMenu] Improved processing of classes \"modSymlink\" and \"modWeblink\".\n- [pdoBreadcrumbs] Improved processing of classes \"modSymlink\" and \"modWeblink\". Added parameter \"&useWeblink\".\n- [pdoNeighbors] Added parameter \"&useWeblink\" and placeholder \"[[+link]]\".\n- [pdoSitemap] Added parameter \"&useWeblink\" and proper processing of classes \"modSymlink\" and \"modWeblink\".\n\n1.8.4 pl\n==============\n- [pdoCrumbs] Added ability to specify the crumbs root (defaulting to site_start)\n- [pdoCrumbs] Added ability to specify class_key (ie. to generate crumbs only for derivative classes)\n- More accuracy when try to decode json in fetch results.\n\n1.8.3 pl3\n==============\n- Improved preparation of template variables.\n- Improved transfer of additional parameters from snippet to results.\n- [pdoMenu] Added lexicon entries for parameters.\n- [pdoMenu] Allow to specify \"limit\" and \"offset\".\n- [#12] Added parameter \"toPlaceholder\".\n- Increased accuracy of timings log.\n\n1.8.1 pl2\n==============\n- Accelerated method pdoTools::getChunk().\n- Added snippet pdoMenu.\n- Added support for tags [^qt^] and [^q^].\n\n1.8.0 pl\n==============\n- [#10] [pdoPage] Added placeholder \"page\".\n- [#9] [pdoPage] Added placeholder \"pageCount\".\n- [#8] Improved support of big numbers when sorting by TVs.\n- Fixed work of pdoPage when it called multiple times on page.\n- Fixed mistype in pdoFetch::getCollection().\n\n1.8.0 rc5\n==============\n- Added processing of JSON fields. For example, you can use [[+extended.keyname]] in chunks of pdoUsers.\n- pdoTools was removed from system extension packages, but you can still use \"$modx->getService(\'pdoFetch\');\".\n- Fixed getting chunk without any parameters.\n- Added snippet pdoPage.\n\n1.8.0 beta1\n==============\n- Improved handling of \"default_text\" parameter in TVs.\n- Fixed and improved method pdoTools::buildTree().\n- The logic of build the conditions of the query moved into new method pdoFetch::additionalConditions().\n- Improved method pdoFetch::addSelects().\n- Improved method pdoFetch::addSort().\n- Improved some snippets in accordance to new abilities of pdoFetch: pdoResources, pdoNeighbors and pdoSitemap.\n\n1.7.4 pl\n==============\n- [#7] [pdoSitemap] Fixed hidden parameters \"&sortBy\" and \"&sortDir\" that used for compatibility with GoogleSiteMap.\n\n1.7.3 pl1\n==============\n- [pdoCrumbs] Fixed possible E_NOTICE on line 157.\n- [pdoCrumbs] Fixed generation of link to site start in relative mode.\n- [#6] pdoCrumbs and pdoNeighbors are now uses \"menutitle\" by default. If it is empty, will be used \"pagetitle\".\n\n1.7.2 pl1\n==============\n- [pdoField] Added new parameters: \"default=``\" and \"&field=``\".\n- [pdoField] Improved logic of \"&top=``\" and \"&topLevel=``\".\n- Added 2 new methods: pdoFetch::getObject() and pdoFetch::getCollection().\n- Ability to send arrays into common config parameters. JSON is still supported.\n- Improved select of default values in TVs.\n\n1.7.1 pl\n==============\n- [pdoCrumbs] Fixed work with \"modSymLink\" and \"modWebLink\" resources.\n\n1.7.0 pl1\n==============\n- New snippet pdoCrumbs.\n- New snippet pdoField.\n- New snippet pdoSitemap.\n- New snippet pdoNeighbors.\n- Ability to specify snippet for preparation of fetched rows by parameter \"&prepareSnippet=``\".\n- Added method pdoTools::checkPermissions() for checking user privileges to view the results.\n- Added @TEMPLATE binding. You can use name or id of any template. If empty - will use template of each row.\n- [pdoResources] Improved parameter \"&context\".\n- [pdoResources] Script properties are now passed to chunks. You can send any placeholders to it.\n\n1.6.0 pl1\n==============\n- Fixed compatibility issues in PHP < 5.3.\n\n1.6.0 pl\n==============\n- Added parameter \"&loadModels\" for comma-separated list of 3rd party components that needed for query.\n- Added parameters \"&prepareTVs\" and \"&processTVs\".\n- Added parameters \"&tvFilters\", \"&tvFiltersAndDelimiter\" and \"&tvFiltersAndDelimiter\".\n- Added support of parameters \"&sortbyTV\" and \"&sortdirTV\" for compatibility with getResources.\n- Added ability to use @INLINE and @FILE bindings in all template parameters.\n- Removed method pdoTools::getPlaceholders.\n\n1.5.0 pl2\n==============\n- Fixed sort of decimals in TVs.\n\n1.5.0 pl1\n==============\n- Added processing of simple [[~id]] placeholders in fastMode.\n- Added support of default value for TVs.\n- Improved sort by TVs of types \"number\" and \"date\".\n\n1.5.0 rc\n==============\n- [pdoUsers] Added new snippet \"pdoUsers\".\n- [pdoResources] Fixed \"toSeparatePlaceholders\".\n- [pdoResources] Parameter \"parents\" now supports dash prefix for excluding resources from query by parent.\n- [pdoResources] Fixed issue when snippet runs multiple times at one page.\n\n1.4.1 pl1\n==============\n- Improved \"context\" processing.\n- Fixed \"idx\" when multiple snippets called at one page.\n- Fixed default sortby when joined tables exists.\n\n1.4.1 beta3\n==============\n- Added parameters \"tplCondition\", \"tplOperator\" and \"conditionalTpls\".\n- Added parameter \"select\" for specifying needed columns of selected tables. Can be a JSON string with array.\n- Added parameter \"toSeparatePlaceholders\".\n- Improved \"pdoResources\" snippet.\n\n1.4.0 beta1\n==============\n- Ability to specify JSON string in \"sortby\", for example \"&sortby=`{\"pagetitle\":\"asc\",\"createdon\":\"desc\"}`\"\n- Added automatic replacement of tvs in \"where\" and \"having\" parameters.\n- Added automatic replacement of tvs in \"sortby\" parameter.\n- Removed example snippet\n- Added snippet \"pdoResources\", that could replace \"getResources\".\n- Added method pdoTools::defineChunk() for chunk of given idx.\n- Added \"memory usage\" in log.\n\n1.3.0\n==============\n- Improved placeholders processing when fastMode is enabled.\n- Added support of \"having\" conditions.\n\n1.2.1\n==============\n- Fixed not working \"includeTVs\" when \"leftJoin\" is empty.\n\n1.2.0\n==============\n- Native render of quick placeholders, such as \"<!--pdotools_introtext <blockquote>[[+introtext]]</blockquote>-->\".\n- Added joining of TVs in pdoFetch. Use parameter \"includeTVs\" with comma-separated list of template variables.\n- Added method pdoFetch::setConfig() for proper setting options when you run multiple pdoTools snippets at the one page.\n- Method pdoTools::makeArray is now recursive, for processing a multidimensional arrays of values.\n\n1.1.0\n==============\n- Improved getChunk function.\n\n1.0.1\n==============\n- Fixed setting total in \"chunks\" mode.\n- Improved displaying \"where\" condition in log.\n\n1.0.0\n==============\n- Initial release.\";s:7:\"license\";s:15218:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:646:\"--------------------\npdoTools\n--------------------\nAuthor: Vasiliy Naumkin <bezumkin@yandex.ru>\n--------------------\n\nSmall library for creating fast snippets for MODX Revolution that works through PDO.\n\nRequired by Tickets and miniShop2.\n\nMain features\n- Builds queries with xPDO.\n- Retrieve results with PDO.\n- Improved pdoTools::getChunk() function, that processing placeholders faster, than original modX::getChunk().\n\npdoTools snippets will work so faster, than more fields you will retrieve from database at one query.\n\n--------------------\nFeel free to suggest ideas/improvements/bugs on GitHub:\nhttp://github.com/bezumkin/pdoTools/issues\n\";s:9:\"signature\";s:19:\"pdotools-2.12.10-pl\";s:6:\"action\";s:26:\"workspace/packages/install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:47:\"/workspace/package/install/pdotools-2.12.10-pl/\";s:14:\"package_action\";i:0;}', 'pdoTools', 'a:38:{s:2:\"id\";s:24:\"602205f51ef0220b1b288492\";s:7:\"package\";s:24:\"50f8468bf2455436ec00000d\";s:12:\"display_name\";s:19:\"pdotools-2.12.10-pl\";s:4:\"name\";s:8:\"pdoTools\";s:7:\"version\";s:7:\"2.12.10\";s:13:\"version_major\";s:1:\"2\";s:13:\"version_minor\";s:2:\"12\";s:13:\"version_patch\";s:2:\"10\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:0:\"\";s:6:\"author\";s:9:\"bezumkin2\";s:11:\"description\";s:7:\"<p></p>\";s:12:\"instructions\";s:77:\"<p></p><p>For example just run:</p><p></p><p></p><p></p><p></p><p></p><p></p>\";s:9:\"changelog\";s:162:\"<a href=\"https://raw.githubusercontent.com/bezumkin/pdoTools/master/core/components/pdotools/docs/changelog.txt\" title=\"\" target=\"_blank\">See on GitHub</a><p></p>\";s:9:\"createdon\";s:24:\"2021-02-09T03:48:05+0000\";s:9:\"createdby\";s:9:\"bezumkin2\";s:8:\"editedon\";s:24:\"2021-08-11T11:16:35+0000\";s:10:\"releasedon\";s:24:\"2021-02-09T03:48:05+0000\";s:9:\"downloads\";s:6:\"352666\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:5:\"false\";s:8:\"featured\";s:5:\"false\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:24:\"4d4c3fa6b2b0830da9000001\";s:8:\"supports\";s:3:\"2.3\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=602205f51ef0220b1b288493\";s:9:\"signature\";s:19:\"pdotools-2.12.10-pl\";s:11:\"supports_db\";s:5:\"mysql\";s:16:\"minimum_supports\";s:3:\"2.3\";s:9:\"breaks_at\";s:8:\"10000000\";s:10:\"screenshot\";s:97:\"http://modx.s3.amazonaws.com/extras/50f8468bf2455436ec00000d/ffe1e89f12c51f01ad55ce39b88731b1.jpg\";s:4:\"file\";a:7:{s:2:\"id\";s:24:\"602205f51ef0220b1b288493\";s:7:\"version\";s:24:\"602205f51ef0220b1b288492\";s:8:\"filename\";s:33:\"pdotools-2.12.10-pl.transport.zip\";s:9:\"downloads\";s:5:\"13937\";s:6:\"lastip\";s:13:\"91.218.97.145\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=602205f51ef0220b1b288493\";}s:17:\"package-signature\";s:19:\"pdotools-2.12.10-pl\";s:10:\"categories\";s:14:\"administration\";s:4:\"tags\";s:0:\"\";}', 2, 12, 10, 'pl', 0);
INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('wayfinder-2.3.3-pl', '2021-08-09 10:37:09', '2021-08-09 07:37:20', '2021-08-09 10:37:20', 0, 1, 1, 0, 'wayfinder-2.3.3-pl.transport.zip', NULL, 'a:8:{s:7:\"license\";s:15218:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:804:\"::::::::::::::::::::::::::::::::::::::::\n Snippet name: Wayfinder\n Short Desc: builds site navigation\n Version: 2.3.0 (Revolution compatible)\n Authors: \n    Kyle Jaebker (muddydogpaws.com)\n    Ryan Thrash (vertexworks.com)\n    Shaun McCormick (splittingred.com)\n ::::::::::::::::::::::::::::::::::::::::\nDescription:\n    Totally refactored from original DropMenu nav builder to make it easier to\n    create custom navigation by using chunks as output templates. By using templates,\n    many of the paramaters are no longer needed for flexible output including tables,\n    unordered- or ordered-lists (ULs or OLs), definition lists (DLs) or in any other\n    format you desire.\n::::::::::::::::::::::::::::::::::::::::\nExample Usage:\n    [[Wayfinder? &startId=`0`]]\n::::::::::::::::::::::::::::::::::::::::\";s:9:\"changelog\";s:2655:\"Changelog for Wayfinder (for Revolution).\n\nWayfinder 2.3.3\n====================================\n- [#40] Add wf.level placeholder to items for showing current depth\n- [#42] Allow authenticated mgr users with view_unpublished to use new previewUnpublished property to preview unpublished Resources in menus\n- [#41] Fix issue with Wayfinder and truncated result sets due to getIterator call\n\nWayfinder 2.3.2\n====================================\n- [#36] Fix issue with multiple Wayfinder calls using &config\n- [#35] Fix issues with TV bindings rendering\n- Add \"protected\" placeholder that is 1 if Resource is protected by a Resource Group\n- Updated documentation, snippet properties descriptions\n\nWayfinder 2.3.1\n====================================\n- [#31] Add &scheme property for specifying link schemes\n- [#27] Improve caching in Wayfinder to store cache files in resource cache so cache is synced with modx core caching\n\nWayfinder 2.3.0\n====================================\n- [#14] Fix issue with hideSubMenus when using it with a non-zero startId\n- Add all fields of a Resource to the rowTpl placeholder set, such as menutitle, published, etc\n- Properly optimize TV value grabbing to properly parse and cache TVs to improve load times when using TVs in a result set\n- Ensure that caching also caches by user ID to persist access permissions through cached result sets\n\nWayfinder 2.2.0\n====================================\n- [#23] Fix issue that generated error message in error.log due to &contexts always being processed regardless of empty state\n- [#21] Fix issue with unnecessary groupby that was breaking sorting in older mysql versions\n- [#22] Add &cacheResults parameter, which caches queries for faster loading\n- [#8] Add &contexts parameter, and &startIdContext parameter if navigating across multiple contexts and using a non-0 &startId\n\nWayfinder 2.1.3\n====================================\n- [#14] Fix hideSubMenus property\n- Add templates parameter that accepts a comma-delimited list of template IDs to filter by\n- Add where parameter that accepts a JSON object for where conditions\n- Add hereId parameter for specifying the active location\n\nWayfinder 2.1.2\n====================================\n- Fixed bug with includeDocs parameter\n\nWayfinder 2.1.1\n====================================\n- Wayfinder now properly uses MODx parsing system\n- Fixed issue with includeDocs statement\n- Fixed issues with PDO statements\n- Added the missing permissions check\n- Added wayfinder parameter \"permissions\" - default to \"list\", empty to bypass permissions check\n- [#WAYFINDER-20] TemplateVariables not rendering in Wayfinder templates.\n- Added changelog.\";s:9:\"signature\";s:18:\"wayfinder-2.3.3-pl\";s:6:\"action\";s:26:\"workspace/packages/install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:46:\"/workspace/package/install/wayfinder-2.3.3-pl/\";s:14:\"package_action\";i:0;}', 'Wayfinder', 'a:38:{s:2:\"id\";s:24:\"4eaecb1ef24554127d0000b6\";s:7:\"package\";s:24:\"4d556be8b2b083396d0008bd\";s:12:\"display_name\";s:18:\"wayfinder-2.3.3-pl\";s:4:\"name\";s:9:\"Wayfinder\";s:7:\"version\";s:5:\"2.3.3\";s:13:\"version_major\";s:1:\"2\";s:13:\"version_minor\";s:1:\"3\";s:13:\"version_patch\";s:1:\"3\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:1:\"0\";s:6:\"author\";s:12:\"splittingred\";s:11:\"description\";s:230:\"<p>Wayfinder is a highly flexible navigation builder for MODx Revolution.</p><p>See the official docs here:&nbsp;<a href=\"http://rtfm.modx.com/display/ADDON/Wayfinder\">http://rtfm.modx.com/display/ADDON/Wayfinder</a></p><ul>\n</ul>\";s:12:\"instructions\";s:38:\"<p>Install via Package Management.</p>\";s:9:\"changelog\";s:2306:\"<p style=\"padding-top: 2px; padding-right: 2px; padding-bottom: 2px; padding-left: 2px; \"><b>New in 2.3.3</b></p><ul><li>&#91;#40&#93; Add wf.level placeholder to items for showing current depth</li><li>&#91;#42&#93; Allow authenticated mgr users with view_unpublished to use new previewUnpublished property to preview unpublished Resources in menus</li><li>&#91;#41&#93; Fix issue with Wayfinder and truncated result sets due to getIterator call</li></ul><p></p><p style=\"padding-top: 2px; padding-right: 2px; padding-bottom: 2px; padding-left: 2px; \"><b>New in 2.3.2</b></p><ul><li>&#91;#36&#93; Fix issue with multiple Wayfinder calls using &amp;config</li><li>&#91;#35&#93; Fix issues with TV bindings rendering</li><li>Add \"protected\" placeholder that is 1 if Resource is protected by a Resource Group</li><li>Updated documentation, snippet properties descriptions</li></ul><p></p><p style=\"padding-top: 2px; padding-right: 2px; padding-bottom: 2px; padding-left: 2px; \"><b>New in 2.3.1</b></p><ul><li>&#91;#31&#93; Add &amp;scheme property for specifying link schemes</li><li>&#91;#27&#93; Improve caching in Wayfinder to store cache files in resource cache so cache is synced with modx core caching</li></ul><p></p><p style=\"padding-top: 2px; padding-right: 2px; padding-bottom: 2px; padding-left: 2px; \"><b>New in 2.3.0</b></p><ul><li>&#91;#14&#93; Fix issue with hideSubMenus when using it with a non-zero startId</li><li>Add all fields of a Resource to the rowTpl placeholder set, such as menutitle, published, etc</li><li>Properly optimize TV value grabbing to properly parse and cache TVs to improve load times when using TVs in a result set</li><li>Ensure that caching also caches by user ID to persist access permissions through cached result sets</li></ul><p><b>New in 2.2.0</b></p><ul><li>&#91;#23&#93; Fix issue that generated error message in error.log due to &amp;contexts always being processed regardless of empty state</li><li>&#91;#21&#93; Fix issue with unnecessary groupby that was breaking sorting in older mysql versions</li><li>&#91;#22&#93; Add &amp;cacheResults parameter, which caches queries for faster loading</li><li>&#91;#8&#93; Add &amp;contexts parameter, and &amp;startIdContext parameter if navigating across multiple contexts and using a non-0 &amp;startId</li></ul>\";s:9:\"createdon\";s:24:\"2011-10-31T16:21:50+0000\";s:9:\"createdby\";s:12:\"splittingred\";s:8:\"editedon\";s:24:\"2021-08-09T05:19:02+0000\";s:10:\"releasedon\";s:24:\"2011-10-31T16:21:50+0000\";s:9:\"downloads\";s:6:\"312281\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:5:\"false\";s:8:\"featured\";s:4:\"true\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:24:\"4d4c3fa6b2b0830da9000001\";s:8:\"supports\";s:1:\"2\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=4eaecb20f24554127d0000b8\";s:9:\"signature\";s:18:\"wayfinder-2.3.3-pl\";s:11:\"supports_db\";s:12:\"mysql,sqlsrv\";s:16:\"minimum_supports\";s:1:\"2\";s:9:\"breaks_at\";s:8:\"10000000\";s:10:\"screenshot\";s:0:\"\";s:4:\"file\";a:7:{s:2:\"id\";s:24:\"4eaecb20f24554127d0000b8\";s:7:\"version\";s:24:\"4eaecb1ef24554127d0000b6\";s:8:\"filename\";s:32:\"wayfinder-2.3.3-pl.transport.zip\";s:9:\"downloads\";s:6:\"221852\";s:6:\"lastip\";s:15:\"158.181.235.200\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:60:\"http://modx.com/extras/download/?id=4eaecb20f24554127d0000b8\";}s:17:\"package-signature\";s:18:\"wayfinder-2.3.3-pl\";s:10:\"categories\";s:15:\"menu,navigation\";s:4:\"tags\";s:44:\"menus,flyover,navigation,structure,menu,site\";}', 2, 3, 3, 'pl', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_transport_providers`
--

CREATE TABLE `modx_transport_providers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `service_url` tinytext,
  `username` varchar(191) NOT NULL DEFAULT '',
  `api_key` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `priority` tinyint(4) NOT NULL DEFAULT '10',
  `properties` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_transport_providers`
--

INSERT INTO `modx_transport_providers` (`id`, `name`, `description`, `service_url`, `username`, `api_key`, `created`, `updated`, `active`, `priority`, `properties`) VALUES
(1, 'modx.com', 'The official MODX transport provider for 3rd party components.', 'https://rest.modx.com/extras/', '', '', '2021-05-28 09:04:51', NULL, 1, 10, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_users`
--

CREATE TABLE `modx_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `cachepwd` varchar(255) NOT NULL DEFAULT '',
  `class_key` varchar(100) NOT NULL DEFAULT 'modUser',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `remote_key` varchar(191) DEFAULT NULL,
  `remote_data` text,
  `hash_class` varchar(100) NOT NULL DEFAULT 'hashing.modNative',
  `salt` varchar(100) NOT NULL DEFAULT '',
  `primary_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `session_stale` text,
  `sudo` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `createdon` int(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_users`
--

INSERT INTO `modx_users` (`id`, `username`, `password`, `cachepwd`, `class_key`, `active`, `remote_key`, `remote_data`, `hash_class`, `salt`, `primary_group`, `session_stale`, `sudo`, `createdon`) VALUES
(1, 'masha_admin', '$2y$10$1IxmensGO6FNv.phAHZAEubUEdLR90DpKl.3JsjLj5Xja2fNnQmTa', '', 'modUser', 1, NULL, NULL, 'hashing.modNative', 'c79f84879fd88e6566ac6147bfbee83f', 1, NULL, 1, 1628244737);

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_attributes`
--

CREATE TABLE `modx_user_attributes` (
  `id` int(10) UNSIGNED NOT NULL,
  `internalKey` int(10) NOT NULL,
  `fullname` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(100) NOT NULL DEFAULT '',
  `mobilephone` varchar(100) NOT NULL DEFAULT '',
  `blocked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `blockeduntil` int(11) NOT NULL DEFAULT '0',
  `blockedafter` int(11) NOT NULL DEFAULT '0',
  `logincount` int(11) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT '0',
  `thislogin` int(11) NOT NULL DEFAULT '0',
  `failedlogincount` int(10) NOT NULL DEFAULT '0',
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `dob` int(10) NOT NULL DEFAULT '0',
  `gender` int(1) NOT NULL DEFAULT '0',
  `address` text NOT NULL,
  `country` varchar(191) NOT NULL DEFAULT '',
  `city` varchar(191) NOT NULL DEFAULT '',
  `state` varchar(25) NOT NULL DEFAULT '',
  `zip` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `photo` varchar(191) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `website` varchar(191) NOT NULL DEFAULT '',
  `extended` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_user_attributes`
--

INSERT INTO `modx_user_attributes` (`id`, `internalKey`, `fullname`, `email`, `phone`, `mobilephone`, `blocked`, `blockeduntil`, `blockedafter`, `logincount`, `lastlogin`, `thislogin`, `failedlogincount`, `sessionid`, `dob`, `gender`, `address`, `country`, `city`, `state`, `zip`, `fax`, `photo`, `comment`, `website`, `extended`) VALUES
(1, 1, 'Администратор по умолчанию', 'masterkadaj@gmail.com', '', '', 0, 0, 0, 6, 1628752219, 1635490682, 0, 'f1855c976d708b2a682fd89e521fd3ea', 0, 0, '', '', '', '', '', '', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_group_roles`
--

CREATE TABLE `modx_user_group_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_user_group_roles`
--

INSERT INTO `modx_user_group_roles` (`id`, `name`, `description`, `authority`) VALUES
(1, 'Member', NULL, 9999),
(2, 'Super User', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_group_settings`
--

CREATE TABLE `modx_user_group_settings` (
  `group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key` varchar(50) NOT NULL,
  `value` text,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(191) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_messages`
--

CREATE TABLE `modx_user_messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(15) NOT NULL DEFAULT '',
  `subject` varchar(191) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `sender` int(10) NOT NULL DEFAULT '0',
  `recipient` int(10) NOT NULL DEFAULT '0',
  `private` tinyint(4) NOT NULL DEFAULT '0',
  `date_sent` datetime DEFAULT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_settings`
--

CREATE TABLE `modx_user_settings` (
  `user` int(11) NOT NULL DEFAULT '0',
  `key` varchar(50) NOT NULL DEFAULT '',
  `value` text,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(191) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_workspaces`
--

CREATE TABLE `modx_workspaces` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `path` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `attributes` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_workspaces`
--

INSERT INTO `modx_workspaces` (`id`, `name`, `path`, `created`, `active`, `attributes`) VALUES
(1, 'Default MODX workspace', '{core_path}', '2021-08-06 13:12:13', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `modx_access_actiondom`
--
ALTER TABLE `modx_access_actiondom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Indexes for table `modx_access_actions`
--
ALTER TABLE `modx_access_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Indexes for table `modx_access_category`
--
ALTER TABLE `modx_access_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_context`
--
ALTER TABLE `modx_access_context`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Indexes for table `modx_access_elements`
--
ALTER TABLE `modx_access_elements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_media_source`
--
ALTER TABLE `modx_access_media_source`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_menus`
--
ALTER TABLE `modx_access_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Indexes for table `modx_access_namespace`
--
ALTER TABLE `modx_access_namespace`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_permissions`
--
ALTER TABLE `modx_access_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `template` (`template`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `modx_access_policies`
--
ALTER TABLE `modx_access_policies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent` (`parent`),
  ADD KEY `class` (`class`),
  ADD KEY `template` (`template`);

--
-- Indexes for table `modx_access_policy_templates`
--
ALTER TABLE `modx_access_policy_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_access_policy_template_groups`
--
ALTER TABLE `modx_access_policy_template_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_access_resources`
--
ALTER TABLE `modx_access_resources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_resource_groups`
--
ALTER TABLE `modx_access_resource_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`,`target`,`principal`,`authority`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_templatevars`
--
ALTER TABLE `modx_access_templatevars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_actiondom`
--
ALTER TABLE `modx_actiondom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `set` (`set`),
  ADD KEY `action` (`action`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`),
  ADD KEY `for_parent` (`for_parent`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_actions`
--
ALTER TABLE `modx_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `controller` (`controller`);

--
-- Indexes for table `modx_actions_fields`
--
ALTER TABLE `modx_actions_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `action` (`action`),
  ADD KEY `type` (`type`),
  ADD KEY `tab` (`tab`);

--
-- Indexes for table `modx_active_users`
--
ALTER TABLE `modx_active_users`
  ADD PRIMARY KEY (`internalKey`);

--
-- Indexes for table `modx_categories`
--
ALTER TABLE `modx_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category` (`parent`,`category`),
  ADD KEY `parent` (`parent`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_categories_closure`
--
ALTER TABLE `modx_categories_closure`
  ADD PRIMARY KEY (`ancestor`,`descendant`);

--
-- Indexes for table `modx_class_map`
--
ALTER TABLE `modx_class_map`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `class` (`class`),
  ADD KEY `parent_class` (`parent_class`),
  ADD KEY `name_field` (`name_field`);

--
-- Indexes for table `modx_collection_resource_template`
--
ALTER TABLE `modx_collection_resource_template`
  ADD PRIMARY KEY (`collection_template`,`resource_template`);

--
-- Indexes for table `modx_collection_selections`
--
ALTER TABLE `modx_collection_selections`
  ADD PRIMARY KEY (`collection`,`resource`);

--
-- Indexes for table `modx_collection_settings`
--
ALTER TABLE `modx_collection_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `collection` (`collection`);

--
-- Indexes for table `modx_collection_templates`
--
ALTER TABLE `modx_collection_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `modx_collection_template_columns`
--
ALTER TABLE `modx_collection_template_columns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_content_type`
--
ALTER TABLE `modx_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `modx_context`
--
ALTER TABLE `modx_context`
  ADD PRIMARY KEY (`key`),
  ADD KEY `name` (`name`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_context_resource`
--
ALTER TABLE `modx_context_resource`
  ADD PRIMARY KEY (`context_key`,`resource`);

--
-- Indexes for table `modx_context_setting`
--
ALTER TABLE `modx_context_setting`
  ADD PRIMARY KEY (`context_key`,`key`);

--
-- Indexes for table `modx_dashboard`
--
ALTER TABLE `modx_dashboard`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `hide_trees` (`hide_trees`);

--
-- Indexes for table `modx_dashboard_widget`
--
ALTER TABLE `modx_dashboard_widget`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `type` (`type`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `lexicon` (`lexicon`);

--
-- Indexes for table `modx_dashboard_widget_placement`
--
ALTER TABLE `modx_dashboard_widget_placement`
  ADD PRIMARY KEY (`dashboard`,`widget`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_documentgroup_names`
--
ALTER TABLE `modx_documentgroup_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `modx_document_groups`
--
ALTER TABLE `modx_document_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `document_group` (`document_group`),
  ADD KEY `document` (`document`);

--
-- Indexes for table `modx_element_property_sets`
--
ALTER TABLE `modx_element_property_sets`
  ADD PRIMARY KEY (`element`,`element_class`,`property_set`);

--
-- Indexes for table `modx_extension_packages`
--
ALTER TABLE `modx_extension_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `modx_fc_profiles`
--
ALTER TABLE `modx_fc_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `rank` (`rank`),
  ADD KEY `active` (`active`);

--
-- Indexes for table `modx_fc_profiles_usergroups`
--
ALTER TABLE `modx_fc_profiles_usergroups`
  ADD PRIMARY KEY (`usergroup`,`profile`);

--
-- Indexes for table `modx_fc_sets`
--
ALTER TABLE `modx_fc_sets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profile` (`profile`),
  ADD KEY `action` (`action`),
  ADD KEY `active` (`active`),
  ADD KEY `template` (`template`);

--
-- Indexes for table `modx_gallery_albums`
--
ALTER TABLE `modx_gallery_albums`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent` (`parent`),
  ADD KEY `name` (`name`),
  ADD KEY `createdby` (`createdby`),
  ADD KEY `rank` (`rank`),
  ADD KEY `active` (`active`),
  ADD KEY `prominent` (`prominent`);

--
-- Indexes for table `modx_gallery_album_contexts`
--
ALTER TABLE `modx_gallery_album_contexts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `album` (`album`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_gallery_album_items`
--
ALTER TABLE `modx_gallery_album_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`item`),
  ADD KEY `album` (`album`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_gallery_items`
--
ALTER TABLE `modx_gallery_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `createdby` (`createdby`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`),
  ADD KEY `mediatype` (`mediatype`);

--
-- Indexes for table `modx_gallery_tags`
--
ALTER TABLE `modx_gallery_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item` (`item`),
  ADD KEY `tag` (`tag`);

--
-- Indexes for table `modx_lexicon_entries`
--
ALTER TABLE `modx_lexicon_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `topic` (`topic`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `language` (`language`);

--
-- Indexes for table `modx_lingua_langs`
--
ALTER TABLE `modx_lingua_langs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lang_code` (`lang_code`);

--
-- Indexes for table `modx_lingua_resource_scopes`
--
ALTER TABLE `modx_lingua_resource_scopes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_lingua_site_content`
--
ALTER TABLE `modx_lingua_site_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `uri` (`uri`(333)),
  ADD KEY `uri_override` (`uri_override`),
  ADD KEY `cache_refresh_idx` (`id`,`parent`),
  ADD KEY `parent` (`parent`),
  ADD KEY `context_key` (`context_key`),
  ADD KEY `isfolder` (`isfolder`);
ALTER TABLE `modx_lingua_site_content` ADD FULLTEXT KEY `content_ft_idx` (`pagetitle`,`longtitle`,`description`,`introtext`,`content`);

--
-- Indexes for table `modx_lingua_site_tmplvars`
--
ALTER TABLE `modx_lingua_site_tmplvars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tmplvarid` (`tmplvarid`);

--
-- Indexes for table `modx_lingua_site_tmplvars_patterns`
--
ALTER TABLE `modx_lingua_site_tmplvars_patterns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_lingua_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_lingua_site_tmplvar_contentvalues`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tmplvarid` (`tmplvarid`),
  ADD KEY `contentid` (`contentid`),
  ADD KEY `tv_cnt` (`tmplvarid`,`contentid`,`lang_id`),
  ADD KEY `lang_id` (`lang_id`);

--
-- Indexes for table `modx_manager_log`
--
ALTER TABLE `modx_manager_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_occurred` (`user`,`occurred`);

--
-- Indexes for table `modx_media_sources`
--
ALTER TABLE `modx_media_sources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `is_stream` (`is_stream`);

--
-- Indexes for table `modx_media_sources_contexts`
--
ALTER TABLE `modx_media_sources_contexts`
  ADD PRIMARY KEY (`source`,`context_key`);

--
-- Indexes for table `modx_media_sources_elements`
--
ALTER TABLE `modx_media_sources_elements`
  ADD PRIMARY KEY (`source`,`object`,`object_class`,`context_key`);

--
-- Indexes for table `modx_membergroup_names`
--
ALTER TABLE `modx_membergroup_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent` (`parent`),
  ADD KEY `rank` (`rank`),
  ADD KEY `dashboard` (`dashboard`);

--
-- Indexes for table `modx_member_groups`
--
ALTER TABLE `modx_member_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role` (`role`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_menus`
--
ALTER TABLE `modx_menus`
  ADD PRIMARY KEY (`text`),
  ADD KEY `parent` (`parent`),
  ADD KEY `action` (`action`),
  ADD KEY `namespace` (`namespace`);

--
-- Indexes for table `modx_namespaces`
--
ALTER TABLE `modx_namespaces`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `modx_property_set`
--
ALTER TABLE `modx_property_set`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `modx_register_messages`
--
ALTER TABLE `modx_register_messages`
  ADD PRIMARY KEY (`topic`,`id`),
  ADD KEY `created` (`created`),
  ADD KEY `valid` (`valid`),
  ADD KEY `accessed` (`accessed`),
  ADD KEY `accesses` (`accesses`),
  ADD KEY `expires` (`expires`);

--
-- Indexes for table `modx_register_queues`
--
ALTER TABLE `modx_register_queues`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `modx_register_topics`
--
ALTER TABLE `modx_register_topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `queue` (`queue`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `modx_session`
--
ALTER TABLE `modx_session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `access` (`access`);

--
-- Indexes for table `modx_site_content`
--
ALTER TABLE `modx_site_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `published` (`published`),
  ADD KEY `pub_date` (`pub_date`),
  ADD KEY `unpub_date` (`unpub_date`),
  ADD KEY `parent` (`parent`),
  ADD KEY `isfolder` (`isfolder`),
  ADD KEY `template` (`template`),
  ADD KEY `menuindex` (`menuindex`),
  ADD KEY `searchable` (`searchable`),
  ADD KEY `cacheable` (`cacheable`),
  ADD KEY `hidemenu` (`hidemenu`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `context_key` (`context_key`),
  ADD KEY `uri` (`uri`(191)),
  ADD KEY `uri_override` (`uri_override`),
  ADD KEY `hide_children_in_tree` (`hide_children_in_tree`),
  ADD KEY `show_in_tree` (`show_in_tree`),
  ADD KEY `cache_refresh_idx` (`parent`,`menuindex`,`id`);
ALTER TABLE `modx_site_content` ADD FULLTEXT KEY `content_ft_idx` (`pagetitle`,`longtitle`,`description`,`introtext`,`content`);

--
-- Indexes for table `modx_site_htmlsnippets`
--
ALTER TABLE `modx_site_htmlsnippets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_plugins`
--
ALTER TABLE `modx_site_plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `disabled` (`disabled`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_plugin_events`
--
ALTER TABLE `modx_site_plugin_events`
  ADD PRIMARY KEY (`pluginid`,`event`),
  ADD KEY `priority` (`priority`);

--
-- Indexes for table `modx_site_snippets`
--
ALTER TABLE `modx_site_snippets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `moduleguid` (`moduleguid`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_templates`
--
ALTER TABLE `modx_site_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `templatename` (`templatename`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_tmplvars`
--
ALTER TABLE `modx_site_tmplvars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `rank` (`rank`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_tmplvar_access`
--
ALTER TABLE `modx_site_tmplvar_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tmplvar_template` (`tmplvarid`,`documentgroup`);

--
-- Indexes for table `modx_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_site_tmplvar_contentvalues`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tv_cnt` (`tmplvarid`,`contentid`),
  ADD KEY `tmplvarid` (`tmplvarid`),
  ADD KEY `contentid` (`contentid`);

--
-- Indexes for table `modx_site_tmplvar_templates`
--
ALTER TABLE `modx_site_tmplvar_templates`
  ADD PRIMARY KEY (`tmplvarid`,`templateid`);

--
-- Indexes for table `modx_system_eventnames`
--
ALTER TABLE `modx_system_eventnames`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `modx_system_settings`
--
ALTER TABLE `modx_system_settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `modx_transport_packages`
--
ALTER TABLE `modx_transport_packages`
  ADD PRIMARY KEY (`signature`),
  ADD KEY `workspace` (`workspace`),
  ADD KEY `provider` (`provider`),
  ADD KEY `disabled` (`disabled`),
  ADD KEY `package_name` (`package_name`),
  ADD KEY `version_major` (`version_major`),
  ADD KEY `version_minor` (`version_minor`),
  ADD KEY `version_patch` (`version_patch`),
  ADD KEY `release` (`release`),
  ADD KEY `release_index` (`release_index`);

--
-- Indexes for table `modx_transport_providers`
--
ALTER TABLE `modx_transport_providers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `api_key` (`api_key`),
  ADD KEY `username` (`username`),
  ADD KEY `active` (`active`),
  ADD KEY `priority` (`priority`);

--
-- Indexes for table `modx_users`
--
ALTER TABLE `modx_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `remote_key` (`remote_key`),
  ADD KEY `primary_group` (`primary_group`);

--
-- Indexes for table `modx_user_attributes`
--
ALTER TABLE `modx_user_attributes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `internalKey` (`internalKey`);

--
-- Indexes for table `modx_user_group_roles`
--
ALTER TABLE `modx_user_group_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `authority` (`authority`);

--
-- Indexes for table `modx_user_group_settings`
--
ALTER TABLE `modx_user_group_settings`
  ADD PRIMARY KEY (`group`,`key`);

--
-- Indexes for table `modx_user_messages`
--
ALTER TABLE `modx_user_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_user_settings`
--
ALTER TABLE `modx_user_settings`
  ADD PRIMARY KEY (`user`,`key`);

--
-- Indexes for table `modx_workspaces`
--
ALTER TABLE `modx_workspaces`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `path` (`path`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `modx_access_actiondom`
--
ALTER TABLE `modx_access_actiondom`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_actions`
--
ALTER TABLE `modx_access_actions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_category`
--
ALTER TABLE `modx_access_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_context`
--
ALTER TABLE `modx_access_context`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `modx_access_elements`
--
ALTER TABLE `modx_access_elements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_media_source`
--
ALTER TABLE `modx_access_media_source`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_menus`
--
ALTER TABLE `modx_access_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_namespace`
--
ALTER TABLE `modx_access_namespace`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_permissions`
--
ALTER TABLE `modx_access_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=228;

--
-- AUTO_INCREMENT for table `modx_access_policies`
--
ALTER TABLE `modx_access_policies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `modx_access_policy_templates`
--
ALTER TABLE `modx_access_policy_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `modx_access_policy_template_groups`
--
ALTER TABLE `modx_access_policy_template_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `modx_access_resources`
--
ALTER TABLE `modx_access_resources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_resource_groups`
--
ALTER TABLE `modx_access_resource_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_templatevars`
--
ALTER TABLE `modx_access_templatevars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_actiondom`
--
ALTER TABLE `modx_actiondom`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_actions`
--
ALTER TABLE `modx_actions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `modx_actions_fields`
--
ALTER TABLE `modx_actions_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `modx_categories`
--
ALTER TABLE `modx_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `modx_class_map`
--
ALTER TABLE `modx_class_map`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `modx_collection_settings`
--
ALTER TABLE `modx_collection_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_collection_templates`
--
ALTER TABLE `modx_collection_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modx_collection_template_columns`
--
ALTER TABLE `modx_collection_template_columns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `modx_content_type`
--
ALTER TABLE `modx_content_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `modx_dashboard`
--
ALTER TABLE `modx_dashboard`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_dashboard_widget`
--
ALTER TABLE `modx_dashboard_widget`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `modx_documentgroup_names`
--
ALTER TABLE `modx_documentgroup_names`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_document_groups`
--
ALTER TABLE `modx_document_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_extension_packages`
--
ALTER TABLE `modx_extension_packages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_fc_profiles`
--
ALTER TABLE `modx_fc_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_fc_sets`
--
ALTER TABLE `modx_fc_sets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_gallery_albums`
--
ALTER TABLE `modx_gallery_albums`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modx_gallery_album_contexts`
--
ALTER TABLE `modx_gallery_album_contexts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_gallery_album_items`
--
ALTER TABLE `modx_gallery_album_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `modx_gallery_items`
--
ALTER TABLE `modx_gallery_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `modx_gallery_tags`
--
ALTER TABLE `modx_gallery_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_lexicon_entries`
--
ALTER TABLE `modx_lexicon_entries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_lingua_langs`
--
ALTER TABLE `modx_lingua_langs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `modx_lingua_resource_scopes`
--
ALTER TABLE `modx_lingua_resource_scopes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_lingua_site_content`
--
ALTER TABLE `modx_lingua_site_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `modx_lingua_site_tmplvars`
--
ALTER TABLE `modx_lingua_site_tmplvars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_lingua_site_tmplvars_patterns`
--
ALTER TABLE `modx_lingua_site_tmplvars_patterns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `modx_lingua_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_lingua_site_tmplvar_contentvalues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_manager_log`
--
ALTER TABLE `modx_manager_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1091;

--
-- AUTO_INCREMENT for table `modx_media_sources`
--
ALTER TABLE `modx_media_sources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_membergroup_names`
--
ALTER TABLE `modx_membergroup_names`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_member_groups`
--
ALTER TABLE `modx_member_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_property_set`
--
ALTER TABLE `modx_property_set`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_register_queues`
--
ALTER TABLE `modx_register_queues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modx_register_topics`
--
ALTER TABLE `modx_register_topics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modx_site_content`
--
ALTER TABLE `modx_site_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `modx_site_htmlsnippets`
--
ALTER TABLE `modx_site_htmlsnippets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `modx_site_plugins`
--
ALTER TABLE `modx_site_plugins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `modx_site_snippets`
--
ALTER TABLE `modx_site_snippets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `modx_site_templates`
--
ALTER TABLE `modx_site_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `modx_site_tmplvars`
--
ALTER TABLE `modx_site_tmplvars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modx_site_tmplvar_access`
--
ALTER TABLE `modx_site_tmplvar_access`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_site_tmplvar_contentvalues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `modx_transport_providers`
--
ALTER TABLE `modx_transport_providers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_users`
--
ALTER TABLE `modx_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_user_attributes`
--
ALTER TABLE `modx_user_attributes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_user_group_roles`
--
ALTER TABLE `modx_user_group_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modx_user_messages`
--
ALTER TABLE `modx_user_messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_workspaces`
--
ALTER TABLE `modx_workspaces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
